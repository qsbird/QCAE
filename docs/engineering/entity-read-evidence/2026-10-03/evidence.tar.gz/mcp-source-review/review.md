# entity_mcp195 源码冻结与 QG-02 静态审查

状态：SOURCE_FROZEN_STATIC_ONLY / **NOT RUN**。本代理独占 `tests/mcp_bridge_tests.py`；基准 HEAD 为 `8a04ebd`。仅实际执行 Python AST 语法解析（PASS）并读取源码/差异；生成器、格式/设计/diff门禁、编译、CTest、MCP/CLI/SQLite 产品均由 root 统一执行，本报告没有执行或通过这些项的证据。

| 文件 | SHA256 |
|---|---|
| `/private/tmp/qcae-framework-delivery80/tests/mcp_bridge_tests.py` | `931019fa2038d45146e36d47020a88c07611f83b2900eca40d6cb65a17616936` |

## QG-02 可理解代码

入口链路明确：现有两个真实 stdio MCP Client 与实际 CLI → 同一个 local IPC engine → RecordApplication 不可变 snapshot → 既有 query/reference 服务。Python 只驱动公共契约与比对响应，不建立业务模型、不伪造 actor，不修改 MCP 生产路由。`--durable` 时沿用现有 engine 的明确 SQLite workspace；未设置该选项时不宣称持久化。

`assert_entity_read_discovery`（行 127）保护引擎能力文本/description来源、v1/具名schema/input类型、现有symbolic outputs/targets/context flags、字段ID/顺序/raw类型/单位及语义分页类型，且对比 MCP inputSchema 与完整 engine arguments_schema。parameters 对象必须同 descriptor.parameters_schema；query 的 MCP parameters 可省略，refs 必需该参数。raw schema 仍7/2字段、kind不冻结enum、ids不禁止重复、分页接受0。

`assert_entity_read_pair`（行 181）统一省略/v1两客户端 envelope比对，仅排除请求关联ID；成功读还核对内外revision。`assert_cli_entity_read`（行 198）在同endpoint调用实际CLI，对每个成功参数样本比较省略/v1的完整MCP envelope，CLI API仍发送parameters对象。`entity_read_state`（行 191）复用current/status/model.summary/history.list，补完整实体页与Material字段，成功、raw/service拒绝、版本/context拒绝三个阶段都与读取前完整快照一致。

`assert_entity_read_calls`（行 210）紧接既有 Steel Material提交执行，不新增记录或建模流程，保护重复IDs/空IDs、空name/空白name、known/unknown kind、组织owner服务规则、0/上限/整数浮点分页、incoming/outgoing/default refs，以及unused revision/key任意JSON的兼容。拒绝分层清楚：MCP仅拒绝非object parameters容器；其余成员shape和服务条件由engine拒绝。未来/坏版本与坏参数及缺失/陈旧context组合确认版本优先；省略/v1旧epoch加坏参数确认旧context优先；expected_profile保持更早envelope拒绝。

静态可读性结论：PASS。新代码用固定合同表、命名快照/成对响应/CLI helper及有界case表表达测试目的，没有新registry、业务算法或生产分支。运行时断言是否通过仍待root实际执行。

## 证据边界

Material共享夹具当前无引用边，incoming/outgoing均空；非空引用及超过内部页的完整响应由root负责的既有SQLite entity fixture保护。两个MCP连接都为可信local-user，不构成跨principal隔离证据。本文件未直接观察SQLite I/O counters；typed与SQLite验证由root收敛。未扩展GUI、solver、真实AI、性能或完整SK/P0场景。
