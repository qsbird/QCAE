# Entity reads C++ 合同与行为保护静态审查194

状态：**STATIC REVIEW ONLY / NOT RUN**。本 agent 仅修改 `tests/typed_host_tests.cpp`，root 最终格式化后停止写入。没有运行生成器、构建、格式化、检查、测试、产品或 Git 修改。root 的实际验证结果须另行记录。

依据：`docs/baseline/README.md`、REQ-16、TST-F08、TST-A01、QG-02、`docs/architecture/` 和计划188。计划的 query arguments 修正已采用：query 仅需 document_id/epoch；references 还需 parameters；IPC envelope 的 parameters 对象仍必需，MCP 省略 query parameters 时补 `{}`。

新增入口：`entity_read_descriptors_and_projection`（typed_host_tests.cpp:1962）、`entity_read_contracts_preserve_application`（:2143），main调用该成组场景。一个发现/投影表与一个真实应用场景复用原有 OpenContractStore、open_contract_state、lookup_without_effects、lookup_installed_versions；没有逐参数复制生命周期。

## 合同与兼容保护

- 两个 exact v1 definition、字段 ID/顺序/optional/allow_empty/units、raw schema 与完整 arguments schema；保留旧 output labels。分页 raw integer 与 finite-number 语义投影分别断言。
- DTO 省略/空数组区别、空及空白 name、unique ID 顺序、零和分页边界；实际 raw 重复 IDs 与去重查询全包一致，unknown/空 ID 过滤仍合法。稳定首出现投影另已静态核对产品 for-loop，不宣称原始重复数组字节 roundtrip。
- 省略/v1 的成功与失败全 envelope 相同；不同 request_id 只影响关联。bad version 先于坏文档/epoch/raw 参数；旧 epoch 仍先于参数解析；全局非对象/missing parameters 和 expected_profile 的原拒绝顺序保留。
- raw extra/字符串/数组/分页的各类 JSON shape 与原 unfielded 错误文本；refs required identity、direction 默认 incoming/显式 outgoing，unknown refs 保留 service 诊断。
- unused revision/key 任意 JSON 代表类不参与读取；第二可信 caller 读取同样实体事实，原 mutation facts 仍 caller-scoped。自定义 local_geometry kind 实际由 test registry 经应用路径读取，组织 view/owner 仍由 query service 判定。
- populated 场景一次 execute seed 12 个公开实体与一个 source record，再保存、编辑形成 dirty+两项 history。六组织闭包、完整 refs/affected analyses 响应及内外 snapshot revision 一致性保持；逐请求及组后比较完整 DocumentView/version、metadata/保存点、rows/generation、project payload、history/cursor、原 host/document facts 和 fake-store I/O counters。

## QG-02 静态结论

本切片路径清晰：ipc_api 统一 version admission → dispatch_model 先 snapshot →保留旧 raw 校验→有限 DTO 投影→已有 query/ref 服务→原 serializers。RecordApplication 是文档、历史及 caller write facts 的权威，DTO 不持有业务状态；上下文只需 document/epoch。raw 整数/范围先校验，IDs 稳定去重且不改字节，省略与 [] 不合并，registry kind 不枚举冻结。references 原 bounded-page 读取循环继续返回全部引用，无新输出 DTO/选择句柄。

测试 seed 仍走应用 execute/保存路径；只在冻结前给已有 GeometryLine descriptor 换 test query_kind，无新类型、依赖、CMake target、架构 shell 或性能场景。共享完整状态助手避免复制生命周期；失败明确区分 named version、旧 unfielded raw 与 service query 诊断。独立静态审查发现 refs 手写预期 data 漏掉原 ipc_model::ok 插入的 data.revision；已补预期字段，并对本组每个成功 query/ref invoke 断言 data.revision == outer revision == snapshot revision。同组其余比较取实际 baseline，无相同遗漏。root 保留首次尝试原证据，新尝试02由 root 独立执行；本 agent 无运行结果。随后 root 实际 attempt-02 暴露下述 fixture 签名错误，已由 root 最小修复；随后第一次定向复验发现下述 legacy action 查询误用，root 再作测试修正；第二次定向复验仍由 root 执行，当前 owner 记录不宣称复验通过。该结论不代替运行检查或项目级 QG-02。

## 实际发现与 root 最小修复

root 报告 attempt-02 五配置实际总计 **257/261 通过、4 项 typed_host 失败**：local、SQLite package ON、SQLite package OFF、ASan，均报 `Prepared operation signature does not match normalized input`。原始 local 日志位于 `/private/tmp/qcae-entity198-regression/attempt-02/local-ctest.stdout.log:509`；实际执行与统计由 root 负责，本 agent 仅只读定位。

错误属于本次 test fixture：第二次 `test.entity.edit` execute 使用字面量 `material:220000`，而共享 `material_change(220000)` 经 `modulus_signature(double)` 准备 `material:220000.000000`。应用既有 execute 在 core.cpp:649 要求两者逐字一致，seed 的两侧 `entity-read-seed` 原本一致。root 只将测试字面量换成 `runtime_test::modulus_signature(220000)` 并格式化，复用 prepare 的同一归一化函数；未改产品、核心提交规则或其余五源码。

修复前 owned hash `fb00e3c4d2f346684404105bffabc0ab82dfc56a427668dd600171f7d1a158b5` 及审查全文保存为 `review.before-signature-fix.md/json`。签名修复后的 owned hash `2c24728e0745bbb75a3279df8aaaaf3541dd5ce605f20c3f1e9ed967425d85f1`。签名修正后的第一次定向复验仍有四个 Unknown operation 失败；后续 action_outcome 修正及第二次定向复验见下。

本次诊断遵守运行矩阵冻结：本 agent 未写仓库源码，也未执行 generation、build、check、CTest 或产品。

## 第二阶段实际失败与 action 事实读取修正

root 报告签名修正后的第一次四目标定向复验 **0/4 通过、4 项同报 Unknown operation**。与原五配置矩阵的四个签名失败合计，是两个阶段的 **八次失败发生**，仍为四个受影响 typed_host 目标，不能写成八个不同目标或覆盖原 257/261 结果。

只读定位确认 fixture 使用了受限的 MemoryApplication::operation：它转发 RecordApplication::operation，后者仅支持 commit/undo/redo，遇到 test.entity.seed 即返回 INVALID_INPUT/operation_name/Unknown operation；初始 good(seed) 因此失败。末尾 other caller 与 query/reference unused key 的 !ok 原本也可能因 operation 名字不被 wrapper 接受而假阳性，不能证明 retained key 缺失。

root 使用现有 RecordApplication::action_outcome（record_application.hpp:184、core.cpp:668；ipc_api.cpp:949 已使用同一接口）替换新 fixture 五处调用：seed receipt 前后两次、other caller 一次，以及 query/reference unused key 两次。该接口沿原 document check、operation_scope 与 caller scoped key 读取任意 execute facts；没有新增 API、修改核心规则或产品行为。

修复前 owned hash `2c24728e0745bbb75a3279df8aaaaf3541dd5ce605f20c3f1e9ed967425d85f1` 的 owner review 全文另存 review.before-action-fix.md/json；修复后 root 提供 hash `467c883d9c126d9e6fb8e6bf80a5652985ce9d908219ca8b5e553501efd02fbc`。root 正在第二次定向重建/复验四目标，当前结果待登记。

本 agent 在两个 runtime 诊断及此次 review 更新期间均只读仓库，只写外部 review artifacts；所有 generation/build/check/CTest/product 执行仍 NOT RUN。

## 冻结与 NOT RUN

初次 owned SHA256 `01d197b9230765bbe858e9c2bdee5dd073021758e12971b172ca7971d13cbbfb` 已被 revision 预期修正后的冻结取代。初次静态 review 另存 `review.initial-freeze.md/json` 并明确 superseded；最终表以下述新冻结为准。

root freeze：`/private/tmp/qcae-entity198-regression/source-freeze.json`。最终 typed_host_tests.cpp SHA256 由 root 提供，其余五个源码 hash 由 root 确认不变；本次仅更新外部审查 artifacts，未重新计算仓库哈希。前一冻结的六文件只读核对记录保留在 review.before-signature-fix.md/json。

| 文件 | SHA256 |
|---|---|
| `schemas/operations/entity_reads.json` | `e361fa4670c190aef0aaa59390298b089ac0243e9e7de699679061dfbebfcfe7` |
| `adapters/engine_api/src/ipc_api.cpp` | `7b1e5e8ea102f97de10773f260df44aff667478cad3ee7f1abde47ffd4c927b3` |
| `adapters/engine_api/src/ipc_model.cpp` | `5ef1e0a248d1fef8bca3a9be606ee592efc3e54f64e6742dd9f4c31a8c4500b6` |
| `tests/typed_host_tests.cpp` | `467c883d9c126d9e6fb8e6bf80a5652985ce9d908219ca8b5e553501efd02fbc` |
| `tests/entity_query_ipc_tests.py` | `ecb8cd3244c94f540acb36f325f9e407b110b7407be48711e1f7c03c0dcd41ba` |
| `tests/mcp_bridge_tests.py` | `931019fa2038d45146e36d47020a88c07611f83b2900eca40d6cb65a17616936` |

NOT RUN：generation/freshness、public-header consumer、CMake/CTest（含 typed_host_tests）、design/format/diff gates、真实 SQLite/CLI/MCP、package ON/OFF、产品与 Git 修改。真实 SQLite 及超过内部页的 references 由 root 共享集成场景验证；OpenContractStore 只证明真实应用状态保护断言，不能替代 SQLite I/O 证据。

未宣称完整 REQ-16/SK/P0、完整图形门禁、真实 solver/AI 集成或大模型性能通过。根任务拥有所有实际执行结果。
