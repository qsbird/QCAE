# Entity reads production source review — owner 193

Status: OWNED SOURCE FROZEN / STATIC REVIEW ONLY / runtime gates NOT RUN by this owner. The three allocated production files are complete; root owns unified generation, formatting, builds, checks, products, tests and Git mutations.

Basis: plan188, docs/baseline/README.md, REQ-16, TST-F08, TST-A01, QG-02, architecture README/runtime-and-data/module dependency graph. The one compatibility correction is that MCP may omit the all-optional entity.query parameters: its bridge supplies {}; therefore query arguments require document_id and document_epoch, while references also require parameters. The global IPC envelope still requires a parameters object.

## Frozen owned source hashes

| Path | SHA256 |
|---|---|
| `schemas/operations/entity_reads.json` | `e361fa4670c190aef0aaa59390298b089ac0243e9e7de699679061dfbebfcfe7` |
| `adapters/engine_api/src/ipc_api.cpp` | `f1f42368891880f1aefa8550da76c72f57e99baf009ab01cb370748dc60e420e` |
| `adapters/engine_api/src/ipc_model.cpp` | `5ef1e0a248d1fef8bca3a9be606ee592efc3e54f64e6742dd9f4c31a8c4500b6` |

The base HEAD is 8a04ebd80d1181e18b6fc74bdcdab44a787f6b24. These identify this owner snapshot; root formatting can change final source hashes without changing semantics.

## QG-02 readable authority and call paths

The new entity_reads.json defines two v1 read_only semantic DTOs. The legacy discovered effect remains query, and its EntityQuery/SelectionResult/conditional and ReferenceQuery/ReferenceResult/none labels remain intact. wire_output_type repeats the existing SelectionResult/ReferenceResult serialization label and does not claim a generated output DTO.

ipc_api.cpp owns envelope/version admission and discovery. It reuses version_rejection after existing global parameters-object and expected_profile checks, before dispatch_model can read a document snapshot. read_parameters_schema remains the authoritative raw JSON shape and bounds; describe_entity_read derives field IDs, order, required flags, allow_empty and units from the generated definitions, describes pagination as raw integer plus semantic finite_number, and attaches a closed complete arguments schema whose parameters value is exactly the same schema.

ipc_model.cpp keeps dispatch_model -> RecordApplication::snapshot(ref) before business input parsing. entity_query_input preserves existing fields/str/ids/page_index validation order, then builds a finite semantic Value object. Only the ids filter set is stably deduplicated, after every raw member has been validated. InputTraits<EntityQueryInput>::from_value supplies the actual EntityFilter and pagination used by query_page -> query_entities. entity_references_input preserves entity_id/direction validation and supplies the selected ID and direction used by query_references and query_affected_analyses. Existing entity fields, source provenance, page rows, revisions and complete reference serialization remain unchanged; references continue internal 1000-row paging.

The authoritative engineering state is the immutable RecordSnapshot from the existing application; the DTO owns only transport-neutral semantic input. No registry, application/store/history, generator, Value, TypedHost, CMake, MCP production code, dependency, or performance change was introduced.

Raw failures still use BadInput with the same message and no added field. Existing query-service statuses/fields still flow through error(). Generated decoding runs after raw checks and never silently drops invalid raw fields/shapes. Malformed/future named versions use the shared INVALID_INPUT/requested_version or SCHEMA_UNSUPPORTED/requested_version behavior. Omission/v1 preserves old snapshot/context error precedence.

Preserved invariants: omitted IDs differ from []; duplicates and whitespace IDs are accepted; strings are not trimmed or folded; kind remains open to the record registry; zero offset/limit and the old maxima remain accepted; direction defaults incoming; unused top-level revision/key accept any JSON; no write state or new caller restrictions are introduced.

## Validation boundary

NOT RUN by source owner: generation/freshness, formatting/format gate, design gate, git diff --check, compiler/build, tests/CTest, CLI/engine/MCP products, and all Git mutations. Root and the two test owners provide executable validation through the existing typed_host, entity_query_ipc and mcp_bridge fixtures. Static review is complete and runtime gates remain pending root execution.

No claim is made for full REQ-16/SK/P0, solver execution, real AI integration, GUI selection, or large-model/performance acceptance.
