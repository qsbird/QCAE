#!/usr/bin/env python3
"""Archive actual entity-read results; preserve previous evidence and unknown changes."""
import copy
import datetime
import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

SOURCE = Path('/private/tmp/qcae-framework-delivery80')
MAIN = Path('/Users/qs/Documents/ChatGPT/QCAE')
ROOT = Path(__file__).resolve().parent
MATRIX = Path('/private/tmp/qcae-entity198-regression')
REPAIR = Path('/private/tmp/qcae-entity198-repair')
BUILD = Path('/private/tmp/qcae-entity198-builds-attempt02')
COMMIT = Path('/private/tmp/qcae-entity199-commit')
DEST = SOURCE / 'docs/engineering/entity-read-evidence/2026-10-03'
REPORT = SOURCE / 'docs/engineering/entity-read-contracts-2026-10-03.md'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def fact(path):
    return {'bytes': path.stat().st_size, 'sha256': sha(path)}

def dump(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

def insert(path, marker, text):
    previous = path.read_text()
    assert previous.count(marker) == 1, (path, marker)
    path.write_text(previous.replace(marker, text + '\n\n' + marker))

assert not DEST.exists() and not REPORT.exists()
candidate = json.loads((REPAIR / 'attempt-02/candidate.json').read_text())
completed = json.loads((REPAIR / 'attempt-02/complete.json').read_text())
head = json.loads((COMMIT / 'complete.json').read_text())['implementation_commit']
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=SOURCE, text=True).strip() == head
assert completed['actual_exit_code'] == 0 and completed['resolved_configuration_case_count'] == 261 and completed['targeted_passed'] == 4
inputs = candidate['candidate_files']
assert len(inputs) == 422 and all(sha(SOURCE / name) == digest and sha(MAIN / name) == digest
                                 for name, digest in inputs.items())
assert sha(MAIN / 'AGENTS.md') == 'eaa469194e6952cc8e7a73859f8023216379fa65085ccd8bfd7efc075fe9eaa9'
DEST.mkdir(parents=True)
dump(ROOT / 'freeze.json', {'implementation_commit': head, 'source_files': inputs,
    'source_files_count': len(inputs), 'source_dictionary_sha256': candidate['source_dictionary_sha256'],
    'source_hash_algorithm': 'canonical sorted relative-path to file-SHA256 JSON; not C4-source-v1',
    'main_private_compiled_source_equal': True})
products = {}
for configuration in ('core', 'local', 'sqlite-on', 'sqlite-off', 'sanitized'):
    for name in ('qcae_typed_host_tests', 'qcae-engine', 'qcae-cli', 'qcae-mcp', 'qcae_mcp_bridge.py'):
        path = BUILD / configuration / name
        if path.is_file():
            products[str(path)] = fact(path)
dump(ROOT / 'tested-products.json', products)
members = {}

def add_tree(prefix, directory):
    assert directory.exists(), directory
    for path in sorted(directory.rglob('*')):
        if path.is_file():
            assert path.suffix in {'.py', '.json', '.md', '.txt', '.log', '.cpp', '.hpp'}, path
            name = str(Path(prefix) / path.relative_to(directory))
            assert name not in members
            members[name] = path

for prefix, directory in (
        ('matrix', MATRIX), ('test-only-repair', REPAIR), ('baseline', Path('/private/tmp/qcae-entity196-baseline')),
        ('implementation-commit', COMMIT), ('product-source-review', Path('/private/tmp/qcae-entity193-product')),
        ('mcp-source-review', Path('/private/tmp/qcae-entity195-mcp')),
        ('cpp-source-review', Path('/private/tmp/qcae-entity194-cpp')),
        ('final-independent-source-review', Path('/private/tmp/qcae-entity197-review'))):
    add_tree(prefix, directory)
for configuration in ('sqlite-on', 'sqlite-off'):
    add_tree('actual-sqlite/' + configuration, BUILD / configuration / 'next-evidence/queries')
for name in ('freeze.json', 'tested-products.json'):
    members[name] = ROOT / name
members['archive-method.py'] = Path(__file__)
index = {name: {'origin': str(path), **fact(path)} for name, path in sorted(members.items())}
archive = DEST / 'evidence.tar.gz'
with archive.open('xb') as raw, gzip.GzipFile(fileobj=raw, mode='wb', mtime=0) as compressed:
    with tarfile.open(fileobj=compressed, mode='w') as tar:
        for name, path in sorted(members.items()):
            data = path.read_bytes()
            info = tarfile.TarInfo(name)
            info.size, info.mode, info.mtime = len(data), 0o644, 0
            tar.addfile(info, io.BytesIO(data))
with tarfile.open(archive, 'r:gz') as tar:
    assert set(tar.getnames()) == set(index)
    for name, record in index.items():
        data = tar.extractfile(name).read()
        assert len(data) == record['bytes'] and hashlib.sha256(data).hexdigest() == record['sha256']
        assert fact(members[name]) == {key: record[key] for key in ('bytes', 'sha256')}
dump(DEST / 'archive-index.json', {'member_count': len(index), 'archive': fact(archive), 'members': index})
sqlite = {}
for configuration in ('sqlite-on', 'sqlite-off'):
    directory = BUILD / configuration / 'next-evidence/queries'
    cases = {}
    for case in ('geometry', 'organization'):
        path = directory / (case + '-contract-observations.json')
        if not path.exists():
            assert configuration == 'sqlite-off' and case == 'organization'
            continue
        observations = json.loads(path.read_text())
        statuses = {'success': 0, 'failed': 0, 'conflict': 0}
        pairs = singles = 0
        for item in observations:
            assert item['complete_state_unchanged']
            assert item['authority_before_sha256'] == item['authority_after_sha256']
            if 'omitted' in item:
                pairs += 1
                for key in ('omitted', 'explicit'):
                    statuses[item[key]['status']] += 1
            else:
                singles += 1
                statuses[item['response']['status']] += 1
        assert (len(observations), pairs, singles, statuses) == (
            (53, 35, 18, {'success': 26, 'failed': 58, 'conflict': 4}) if case == 'geometry'
            else (2, 2, 0, {'success': 4, 'failed': 0, 'conflict': 0}))
        cases[case] = {'observations': len(observations), 'omitted_v1_pairs': pairs,
                      'version_single_requests': singles, 'actual_request_statuses': statuses,
                      'logical_rows_document_history_generation_unchanged': True}
    initial = json.loads((directory / 'geometry-authority-initial.json').read_text())
    assert not initial['document']['dirty'] and initial['document']['saved_content_state']
    sqlite[configuration] = {'cases': cases, 'saved_clean_initial_state': True,
        'full_1003_reference_response_preserved': True,
        'actual_contract_requests': sum(sum(case['actual_request_statuses'].values()) for case in cases.values())}
review = json.loads(Path('/private/tmp/qcae-entity197-review/review.json').read_text())
assert not review['unresolved_blockers']
validation = {'schema_version': 1, 'status': 'entity_read_contracts_validated_non_graphical_full_acceptance_open',
    'implementation_commit': head, 'tested_source_count': 422,
    'tested_source_dictionary_sha256': candidate['source_dictionary_sha256'],
    'source_hash_algorithm': 'canonical sorted relative-path to file-SHA256 JSON; not C4-source-v1',
    'initial_configuration_counts': completed['previous_results'],
    'resolved_configuration_case_counts': {name: result['executed'] for name, result in completed['previous_results'].items()},
    'targeted_repair_passed': 4, 'retained_unchanged_products_passed': 257, 'unresolved_failed_cases': 0,
    'post_fix_fresh_full_matrix': 'NOT RUN; only four test binaries changed,13 unaffected products identical',
    'actual_ctest_executions': 269, 'actual_ctest_passed': 261, 'actual_ctest_failed_preserved': 8,
    'compiler_warnings': 0, 'strict_cpp20': True, 'asan_ubsan_scope': 'typed_host only', 'lsan': 'NOT RUN',
    'baseline': {'existing_cases_passed': 6, 'not_in_261_ctest_denominator': True,
                 'copied_interpreted_bridge_identified_separately': True},
    'actual_SQLite': sqlite, 'independent_source_review_blockers': 0,
    'source_review_findings': review['findings'],
    'repaired_actual_test_fixture_failures': ['initial normalized-signature mismatch in4typed_host configs', 'legacy-fact lookup rejects custom action names in first4targeted retests'],
    'production_source_unchanged_by_repairs': True,
    'cancelled_attempt': {'attempt': 'attempt-01', 'CTest_executions': 0,
                          'reason': 'Static review found omitted existing inner revision in a test assertion',
                          'original_candidate_method_build_logs_retained': True},
    'archive': {**fact(archive), 'member_count': len(index), 'all_members_and_origins_reverified': True},
    'docs_only_frozen_input_delta': ['adapters/engine_api/README.md'],
    'limits': ['Current GUI cumulative failures and graphical gate remain open; no GUI executed in this matrix',
               'Old f2d local bundle is unrefreshed; package evidence keeps its original source scope',
               'No real solver/full external AI/performance/full SK or P0 acceptance',
               'Unknown SDK copy coverage deferred only from C4 startup; measured budgets and original material14/30 failures retained',
               'Existing SelectionResult/ReferenceResult labels are serializers, not generated output DTOs',
               'Actual MCP/CLI use fixed trusted caller local-user; distinct trusted callers checked in C++',
               'Other legacy contracts and complete REQ-16/SK-04 remain open']}
dump(DEST / 'validation.json', validation)
REPORT.write_text(f'''# 两个实体读取接口的生成契约

实现提交 `{head}` 已为既有 entity.query/entity.references 补齐版本1语义输入、真实参数和完整上下文发现。五配置初轮实际257/261通过；两处测试夹具修正后的四个目标定向复验均通过，其余257项绑定未变产品。累计269次执行261通过/8原失败，六项修改前基线另列；原图形累计失败、本机旧包与完整SK/P0仍未关闭。

EntityQueryInput 的七个可选字段为kind、name_contains、ids、view、owner_id、offset和limit；EntityReferencesInput要求entity_id，direction可省略，默认incoming，也支持outgoing。schema分别为qcae.operation.entity.query.v1和qcae.operation.entity.references.v1。DTO实际供给原query_page、query_references及query_affected_analyses，状态仍由RecordApplication的不可变快照提供。没有新输出DTO、业务实现副本或事务路径。

先保留原字段/字符串/ID/分页校验，再投影生成输入。重复ID仍合法，仅稳定去重后供给语义数组；空数组匹配零实体，省略不限制ID，非空ID字节保留。name_contains允许空和空白。分页仍接受0、积分浮点数及原offset上限100000/limit上限1000，省略分别为0/100；原整数/range校验后供给dimensionless finite_number字段，发现明确区分raw integer与semantic类型。kind仍来自实际record registry。引用结果保留全部引用及受影响分析，原1000大小内部页循环未改变。

两个入口仅要求document_id/epoch，原未使用的expected_revision及顶层idempotency_key继续忽略任意JSON，不保留写键。完整arguments_schema复用原闭合parameters_schema。MCP的entity.query parameters继续可省略并由原桥填成空对象，references则必需；实际IPC envelope仍要求parameters对象。MCP生产源码未改，继续原样公布经过有界元数据校验的schema。

requested_version可省略或为安装版本1。非法值返回INVALID_INPUT/requested_version，其他合法版本返回SCHEMA_UNSUPPORTED/requested_version，在模型快照之前拒绝；原envelope/parameters对象及expected_profile检查仍更早。省略/版本1保持原context/snapshot先于参数的错误顺序，输出内外revision与原序列化标签不变。

| 配置 | 初轮通过/执行 |
|---|---:|
| 纯核心Release | 40/40 |
| 本地Debug | 54/55 |
| SQLite/Nastran ON，无桌面 | 86/87 |
| SQLite/Nastran OFF，无桌面 | 77/78 |
| ASan/UBSan typed_host专项 | 0/1 |
| 初轮合计 | 257/261 |

初轮四个失败均为新夹具签名手写值不一致。改用现有规范化helper后四次专项又发现自定义事实误走只支持commit/undo/redo的旧wrapper；只在测试改用同一应用的action_outcome后四次专项全部通过。累计269实际执行261通过/8失败，原失败保留；修复仅改变测试CPP和四个测试二进制，其余421输入及13记录产品不变，没有重跑无关产品或声称修复后新全量矩阵。

严格C++20、零编译警告；ASan/UBSan只运行typed_host，LSan未测。六项修改前C++/IPC/MCP/协议/实际实体查询基线全部通过，未计入261。所有配置关闭桌面。

真实SQLite ON/OFF新增契约请求分别92/88次：geometry各53观察、88请求，其中26成功/58失败/4冲突；ON额外organization两组省略/v1对、4成功请求。逐请求对比完整逻辑行、模型、保存内容身份、文档元数据、generation及历史不变；先实际save_as形成非空保存点。保留既有501段网格的1003引用完整结果，以省略/v1和全状态比较保护内部分页，未扩大性能测试。C++使用真实应用及已有测试存储，覆盖组织闭包、动态registry kind、保存后编辑历史、可信caller与原诊断文本；不冒充SQLite证据。两个实际MCP及CLI覆盖原始schema透传、完整返回包、省略参数、零分页、ID过滤、版本/上下文拒绝和共享状态。

独立QG-02发现refs测试精确预期缺既有内层revision。首次构建在任何CTest前取消，原方法/candidate/日志保留；修正预期及全部成功读的内外revision断言后，使用新目录重新冻结构建。此为静态测试缺陷，未冒充实际产品测试失败。两次实际测试失败原因、修复及定向复验均单列。最终六文件独立审查无阻塞；设计、clang-format21、diff门禁通过。

[机器结果](entity-read-evidence/2026-10-03/validation.json)、[索引](entity-read-evidence/2026-10-03/archive-index.json)与[原始归档](entity-read-evidence/2026-10-03/evidence.tar.gz)保留实际命令/日志、422输入/产品/复制桥脚本hash、SQLite观察与请求、静态审查及取消尝试。归档{len(index)}成员、{archive.stat().st_size}字节，SHA256 `{sha(archive)}`，成员及原来源回读相等；没有数据库、二进制或构建树。冻结字典SHA256 `{candidate['source_dictionary_sha256']}`，canonical排序路径到文件SHA256 JSON，非C4-source-v1。

说明阶段仅engine_api README是冻结输入内文档差异，其余421输入及产品保持；不为文档重复运行产品。24个兼容列表入口中已有16个生成版本输入，其余8个是已实现接口的合同补齐，计数不包括TypedHost固有入口或资源/传输路由，也不代表完整SK-04。原图形180秒累计失败、旧隔离诊断、未刷新f2d包、真实求解/完整AI、性能、未知SDK与原已测预算失败保持原范围。本切片不完成全部REQ-16、C3/C4或SK/P0，不追加非必要性能优化。
''')
short = head[:7]
latest = f'2026-10-03，`{short}` 成组补齐 entity.query/entity.references 的生成语义输入、真实发现和版本拒绝；初轮257/261，测试夹具修正后的4目标专项通过，未受影响产品保持，见[验证](../engineering/entity-read-contracts-2026-10-03.md)。空/重复ID、零分页、MCP省略查询参数及完整引用兼容保持，真实SQLite读/拒绝不写模型或历史。继续其余同质接口合同与核心正式验收；原图形失败、旧包、真实环境、性能及完整SK/P0范围不变。'
for name in ('docs/baseline/README.md', 'docs/baseline/development-plan.md'):
    insert(SOURCE / name, '2026-10-03，`cf2f4c4`', latest)
insert(SOURCE / 'docs/README.md', '[原结果查询条件契约]', f'[实体读取生成契约](engineering/entity-read-contracts-2026-10-03.md)：`{short}` 初轮257/261加修正后4目标通过，两个实际MCP/CLI及SQLite状态/历史保护验证；原图形与完整验收范围保留。')
for path, link in ((SOURCE / 'README.md', 'docs/engineering/entity-read-contracts-2026-10-03.md'),
                   (SOURCE / 'docs/implementation/core-local-handoff.md', '../engineering/entity-read-contracts-2026-10-03.md')):
    previous = path.read_text()
    old = next(line for line in previous.splitlines() if line.startswith('最新源码 `cf2f4c4`'))
    path.write_text(previous.replace(old, f'最新源码 `{short}` 已补齐两个实体读取入口生成输入、发现及版本，初轮257/261加修正后4目标通过，见[本轮证据]({link})。原ID/分页/查询参数省略和引用返回兼容保持，SQLite与两个MCP/CLI读取/拒绝不写模型或历史。本机包仍为 `f2d2e7f`，未刷新；原累计图形失败与完整图形门禁未关闭。剩余8个兼容列表接口继续补齐合同，真实求解/完整AI、性能、原已测约束与完整SK/P0保持未验收范围。'))
section = '''### Versioned entity reads

Existing entity.query/entity.references now consume generated EntityQueryInput and
EntityReferencesInput, installed version1 with schema IDs qcae.operation.entity.query.v1
and qcae.operation.entity.references.v1. Both require document_id/epoch only. Unused
revision/key JSON values remain ignored. Closed complete argument discovery reuses raw
parameters: query parameters remain optional in MCP, whose bridge defaults them to {};
references parameters are required. The IPC envelope still requires a parameters object.

Raw parsing keeps old field/error order before DTO projection. IDs preserve bytes; []
matches none, omission is unrestricted, and accepted duplicates project once in encounter
order. Pagination still accepts zero and integer JSON values within offset0..100000 and
limit0..1000 (defaults0/100), validated before dimensionless finite_number DTO decoding.
Discovery describes raw integer type and bounds explicitly. Kind comes from the registry.
References keep the complete existing result across bounded internal pages.

Version refusal precedes snapshot, after existing envelope/parameters/profile admission;
omitted/v1 retain snapshot/context before raw parameter validation. Existing result labels
and inner/outer revision remain. Neither call writes model/history or retains a write key.
[Actual scope](../../docs/engineering/entity-read-contracts-2026-10-03.md).

'''
insert(SOURCE / 'adapters/engine_api/README.md', '### C3 versioned display resources and events', section.rstrip())
path = SOURCE / 'docs/contracts/README.md'
previous = path.read_text().replace('及 `operations.get` 同样接受操作版本', '、`operations.get` 及两个实体读取入口同样接受操作版本')
previous += '\n## 实体读取生成输入\n\nentity.query/entity.references 使用生成版本1语义DTO与真实闭合参数/完整上下文schema，仍仅要求文档ID/epoch。重复/空ID过滤、零分页、动态registry kind、MCP查询参数省略及全部引用返回保持原兼容；旧校验先于语义投影，版本拒绝先于snapshot。现有查询服务、输出标签与单一应用状态保留，读取及拒绝不写模型或历史。实际范围见[验证](../engineering/entity-read-contracts-2026-10-03.md)，完整目录/REQ-16/SK/P0仍未验收。\n'
path.write_text(previous)
path = SOURCE / 'docs/engineering/execution-status.json'
state = json.loads(path.read_text());previous = state['current_core_framework']
assert 'historical_core_framework_before_entity_reads' not in state
state['historical_core_framework_before_entity_reads'] = copy.deepcopy(previous)
current = copy.deepcopy(previous)
current.update(status='entity_read_contracts_validated_non_graphical_full_graphical_gate_open',
    tested_implementation_commit=head, source_files_count=422,
    source_dictionary_sha256=candidate['source_dictionary_sha256'],
    manifest='docs/engineering/entity-read-evidence/2026-10-03/validation.json',
    report='docs/engineering/entity-read-contracts-2026-10-03.md',
    versioned_existing_host_inputs=previous['versioned_existing_host_inputs'] + ['entity.query', 'entity.references'],
    bounded_entity_reads_SQLite=sqlite,
    compatibility_list_contract_counts={'total': 24, 'generated': 16, 'remaining': 8,
        'scope': 'Compatibility supported list only; excludes TypedHost intrinsic and transport/resources'},
    next_core_interface='Group remaining homogeneous implemented interface contracts, then applicable formal core acceptance; not implemented',
    limits=validation['limits'] + ['ASan/UBSan typed_host only; LSan unmeasured',
        'Previous lookup evidence retained under historical_core_framework_before_entity_reads'])
state['current_core_framework'] = current
state['updated_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
dump(path, state)
delta = [name for name, digest in inputs.items() if sha(SOURCE / name) != digest]
assert delta == ['adapters/engine_api/README.md'], delta
assert all(fact(Path(name)) == record for name, record in products.items())
dump(ROOT / 'post-doc-source.json', {'frozen_input_documentation_delta': delta,
    'other421_inputs_unchanged': True, 'compiled_products_before_after_equal': True,
    'documentation_product_rerun': 'NOT RUN; only README within frozen inputs changed'})
print(json.dumps({'implementation_commit': head, 'archive_members': len(index),
    'archive_bytes': archive.stat().st_size, 'actual_SQLite': sqlite}), flush=True)
