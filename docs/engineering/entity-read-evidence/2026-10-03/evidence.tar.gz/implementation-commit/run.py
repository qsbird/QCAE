#!/usr/bin/env python3
"""Commit only the frozen, executed entity-read slice and fast-forward its workspace."""
import hashlib
import json
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).resolve().parent
SOURCE = Path('/private/tmp/qcae-framework-delivery80')
MAIN = Path('/Users/qs/Documents/ChatGPT/QCAE')
MATRIX = Path('/private/tmp/qcae-entity198-repair/attempt-02')
BASE = '8a04ebd80d1181e18b6fc74bdcdab44a787f6b24'
AGENTS = 'eaa469194e6952cc8e7a73859f8023216379fa65085ccd8bfd7efc075fe9eaa9'
FILES = ['schemas/operations/entity_reads.json', 'adapters/engine_api/src/ipc_api.cpp',
         'adapters/engine_api/src/ipc_model.cpp', 'tests/typed_host_tests.cpp',
         'tests/entity_query_ipc_tests.py', 'tests/mcp_bridge_tests.py']


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(cwd, *args):
    return subprocess.check_output(['git', *args], cwd=cwd, text=True)


def dump(path, value):
    with path.open('x') as output:
        json.dump(value, output, indent=2)
        output.write('\n')


def command(name, cwd, argv):
    start = time.time()
    result = subprocess.run(argv, cwd=cwd, capture_output=True, text=True)
    (ROOT / (name + '.stdout.log')).write_text(result.stdout)
    (ROOT / (name + '.stderr.log')).write_text(result.stderr)
    dump(ROOT / (name + '.json'), {'argv': argv, 'cwd': str(cwd),
         'actual_exit_code': result.returncode, 'started_unix': start,
         'elapsed_seconds': time.time() - start})
    print(json.dumps({'command': name, 'actual_exit_code': result.returncode}), flush=True)
    assert result.returncode == 0


candidate = json.loads((MATRIX / 'candidate.json').read_text())
completed = json.loads((MATRIX / 'complete.json').read_text())
assert completed['actual_exit_code'] == 0 and completed['resolved_configuration_case_count'] == 261 and completed['targeted_passed'] == 4
inputs = candidate['candidate_files']
assert len(inputs) == 422 and all(sha(SOURCE / name) == digest for name, digest in inputs.items())
review = json.loads(Path('/private/tmp/qcae-entity197-review/review.json').read_text())
assert not review['unresolved_blockers']
assert review['final_source_sha256'] == {name: inputs[name] for name in FILES}
assert read(SOURCE, 'rev-parse', 'HEAD').strip() == BASE
assert read(MAIN, 'rev-parse', 'HEAD').strip() == BASE
assert read(MAIN, 'status', '--porcelain') == ' M AGENTS.md\n'
assert sha(MAIN / 'AGENTS.md') == AGENTS
assert not read(SOURCE, 'diff', '--cached', '--name-only')
actual = {line[3:] for line in read(SOURCE, 'status', '--porcelain').splitlines()}
assert actual == set(FILES), actual
manifest = MAIN / 'out/local-delivery138-02/QCAE-manifest.json'
manifest_sha = sha(manifest)
assert manifest_sha == '8d5fdd2df0a77aefa4fdc06ef53ae6ceb2155e65c1065745792efc787920af64'
message = '''Complete entity read contracts through existing query services

entity.query and entity.references already served records but lacked generated
installed inputs and versioned discovery. Add semantic DTOs and complete raw
argument schemas, preserving empty/duplicate ID filters, zero pagination, the
full reference response and MCP's omitted-query-parameters default. Raw admission
retains the previous snapshot/error order; both DTOs feed the same query services.

Constraint: One RecordApplication remains authoritative; no core/public SDK, generator, registry, storage, CMake, dependency or performance change.
Rejected: Positive-only pagination, raw unique IDs or required MCP query parameters would break existing successful requests.
Directive: Core framework quality and speed first; preserve measured budgets and all open acceptance gates.
Tested: Initial five configurations executed261, with257passed and4typed_host fixture-signature failures. First correction exposed4legacy-fact lookup fixture failures; both attempts retained. Final test-only corrections then4targeted typed_host rebuild/retests passed; all other products unchanged.
Tested: Six existing baseline cases separately; real SQLite ON/OFF saved/dirty state and history unchanged by reads/refusals; actual two-MCP/CLI parity.
Tested: Design, clang-format21, diff checks; independent QG-02 source review. A missing test payload revision was fixed after static review before CTest; actual signature/fact-lookup fixture failures fixed using existing normalization helper and action_outcome.
Not-tested: Current GUI cumulative gate, LSan, refreshed local bundle, real solver/full external AI/performance/full SK or P0 acceptance.
Confidence: High within executed non-graphical scope; source and product hashes retained.
Scope-risk: Low; generated adapter input and discovery preserve existing application calls and response envelopes.
'''
(ROOT / 'message.txt').write_text(message)
command('stage', SOURCE, ['git', 'add', '--', *FILES])
assert set(read(SOURCE, 'diff', '--cached', '--name-only').splitlines()) == set(FILES)
command('commit', SOURCE, ['git', 'commit', '--file', str(ROOT / 'message.txt')])
head = read(SOURCE, 'rev-parse', 'HEAD').strip()
assert not read(SOURCE, 'status', '--porcelain')
assert all(sha(SOURCE / name) == digest for name, digest in inputs.items())
command('main-fast-forward', MAIN, ['git', 'merge', '--ff-only', head])
assert read(MAIN, 'rev-parse', 'HEAD').strip() == head
assert read(MAIN, 'status', '--porcelain') == ' M AGENTS.md\n'
assert sha(MAIN / 'AGENTS.md') == AGENTS and sha(manifest) == manifest_sha
assert all(sha(MAIN / name) == digest for name, digest in inputs.items())
dump(ROOT / 'complete.json', {'implementation_commit': head, 'committed_files': FILES,
     'actual_ctest_executions': 269, 'actual_ctest_passed': 261, 'actual_ctest_failed_preserved': 8, 'targeted_repair_passed': 4, 'unresolved_failed_cases': 0, 'main_private_compiled_source_equal': True,
     'unknown_AGENTS_preserved': AGENTS, 'old_bundle_manifest_unchanged': manifest_sha})
print(json.dumps({'implementation_commit': head, 'main_fast_forwarded': True}), flush=True)
