#!/usr/bin/env python3
"""Root-owned fresh, non-graphical contract regressions. Original GUI failures stay open."""
from concurrent.futures import ThreadPoolExecutor
import hashlib,json,os,re,subprocess,time
from pathlib import Path
SOURCE=Path('/private/tmp/qcae-framework-delivery80');ROOT=Path(__file__).resolve().parent
OUT=ROOT/'attempt-01';BUILD=Path('/private/tmp/qcae-entity198-builds-attempt02')
BASE=Path('/private/tmp/qcae-lookup190-archive/freeze.json')
CMAKE='/opt/homebrew/Cellar/cmake/4.3.0/bin/cmake';CTEST='/opt/homebrew/Cellar/cmake/4.3.0/bin/ctest'
PYTHON='/Library/Frameworks/Python.framework/Versions/3.14/bin/python3.14';COMPILER='/Library/Developer/CommandLineTools/usr/bin/c++'
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def fact(path):
 p=Path(path);return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
def dump(path,value):
 with Path(path).open('x') as f:json.dump(value,f,indent=2,sort_keys=True);f.write('\n')
assert not OUT.exists() and BUILD.exists();OUT.mkdir()
files=set(json.loads(BASE.read_text())['source_files'])
for name in subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=SOURCE,text=True).splitlines():
 assert name in ['schemas/operations/entity_reads.json'],name
 files.add(name)
inputs={n:sha(SOURCE/n) for n in sorted(files)};assert len(inputs)==422
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=SOURCE,text=True).strip();assert head=='8a04ebd80d1181e18b6fc74bdcdab44a787f6b24'
method=fact(__file__)
dump(OUT/'candidate.json',{'base_head':head,'source':str(SOURCE),'candidate_files':inputs,'candidate_files_count':len(inputs),'source_dictionary_sha256':hashlib.sha256(json.dumps(inputs,sort_keys=True,separators=(',',':')).encode()).hexdigest(),'method':method,'reused_build_root':str(BUILD),'scope':'Test-fixture-only signature correction. Incremental four typed_host builds and targeted tests; previous257 passing cases retained only with unchanged unaffected products. No fresh full-matrix claim.','tools':{n:fact(p) for n,p in {'cmake':CMAKE,'ctest':CTEST,'python':PYTHON,'compiler':COMPILER}.items()}})
def guard():
 assert inputs=={n:sha(SOURCE/n) for n in inputs},'Candidate changed'
 assert method==fact(__file__),'Method changed'
 assert head==subprocess.check_output(['git','rev-parse','HEAD'],cwd=SOURCE,text=True).strip(),'HEAD changed'
def command(name,argv,extra=None):
 guard();env=os.environ.copy()
 for key in ['ASAN_OPTIONS','UBSAN_OPTIONS','LSAN_OPTIONS','DYLD_INSERT_LIBRARIES','DYLD_LIBRARY_PATH','DYLD_PRINT_LIBRARIES','QT_QPA_PLATFORM']:env.pop(key,None)
 env.update(extra or {});start=time.time();out=OUT/(name+'.stdout.log');err=OUT/(name+'.stderr.log')
 with out.open('xb') as o,err.open('xb') as e:r=subprocess.run(argv,cwd=SOURCE,env=env,stdout=o,stderr=e)
 guard();receipt={'actual_exit_code':r.returncode,'argv':argv,'cwd':str(SOURCE),'started_unix':start,'elapsed_seconds':time.time()-start,'explicit_environment':extra or {},'stdout':fact(out),'stderr':fact(err),'candidate_before_after_equal':True};dump(OUT/(name+'.json'),receipt)
 print(json.dumps({'command':name,'actual_exit_code':r.returncode,'elapsed_seconds':receipt['elapsed_seconds']}),flush=True)
 if not name.endswith('-ctest'): assert r.returncode==0,name+' failed; original evidence retained'
 if name.endswith('-build'):assert not re.findall(r'(?m)^.*\bwarning:.*$',out.read_text(errors='replace')+err.read_text(errors='replace')),'Compiler warning'
 return receipt
ORIGINAL=Path('/private/tmp/qcae-entity198-regression/attempt-02')
original=json.loads((ORIGINAL/'candidate.json').read_text())
delta=[n for n,h in original['candidate_files'].items() if inputs[n]!=h]
assert delta==['tests/typed_host_tests.cpp'],delta
failures={}
for name in ['core','local','sqlite-on','sqlite-off','sanitized']:
 receipt=json.loads((ORIGINAL/(name+'-tests.json')).read_text())
 raw=(ORIGINAL/(name+'-ctest.stdout.log')).read_text()
 count=re.search(r'(\d+)% tests passed, (\d+) tests failed out of (\d+)',raw)
 assert count and int(count[3])==receipt['executed_count']
 failed=int(count[2]);assert failed==(0 if name=='core' else 1)
 if failed:assert len(re.findall(r'Test #\d+: typed_host[^\n]*\*\*\*Failed',raw))==1
 failures[name]={'executed':receipt['executed_count'],'failed':failed,'passed':receipt['executed_count']-failed}
assert sum(x['passed'] for x in failures.values())==257
products={}
for configuration in ['core','local','sqlite-on','sqlite-off','sanitized']:
 for name in ['qcae_typed_host_tests','qcae-engine','qcae-cli','qcae-mcp','qcae_mcp_bridge.py']:
  p=BUILD/configuration/name
  if p.is_file():products[str(p)]=fact(p)
backup=Path('/private/tmp/qcae-entity198-failed-products');backup.mkdir()
for configuration in ['local','sqlite-on','sqlite-off','sanitized']:
 p=BUILD/configuration/'qcae_typed_host_tests';target=backup/configuration
 target.write_bytes(p.read_bytes());assert fact(target)['sha256']==fact(p)['sha256']
dump(OUT/'original-results.json',{'previous_configuration_counts':failures,'previous_actual_executions':261,'previous_passed':257,'previous_failed':4,'test_only_source_delta':delta,'products_before':products,'failed_typed_binaries_preserved_at':str(backup)})
configs=[('local',False),('sqlite-on',False),('sqlite-off',False),('sanitized',True)]
def build(config):
 name,sanitize=config;directory=BUILD/name
 command(name+'-build',[CMAKE,'--build',str(directory),'--target','qcae_typed_host_tests','-j','3'])
 compilation=json.loads((directory/'compile_commands.json').read_text());assert all('-std=c++20' in row['command'] and '-std=gnu++20' not in row['command'] for row in compilation)
 dump(OUT/(name+'-compile-summary.json'),{'strict_cpp20':True,'compiler_warnings':[],'configured_compile_units':len(compilation),'rebuild_scope':'qcae_typed_host_tests only'})

for name,argv in [('design',[PYTHON,'tools/check_design.py']),('format',[PYTHON,'tools/check_cpp_format.py']),('diff',['git','diff','--check'])]:command(name,argv)
with ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(build,configs))
def test(config):
 name,sanitize=config;directory=BUILD/name
 env={'ASAN_OPTIONS':'detect_leaks=0:halt_on_error=1','UBSAN_OPTIONS':'halt_on_error=1:print_stacktrace=1'} if sanitize else None
 receipt=command(name+'-ctest',[CTEST,'--test-dir',str(directory),'--output-on-failure','--verbose','-j','1','-R','^typed_host$'],env)
 copy=OUT/(name+'-LastTest.log');copy.write_bytes((directory/'Testing/Temporary/LastTest.log').read_bytes())
 result={'configuration':name,'actual_exit_code':receipt['actual_exit_code'],'executed_test_names':['typed_host'],'executed_count':1,'raw_log':fact(copy),'scope':'targeted typed_host after test-fixture-only signature correction'};dump(OUT/(name+'-tests.json'),result);return result
with ThreadPoolExecutor(max_workers=2) as pool:completed=list(pool.map(test,configs))
assert all(x['actual_exit_code']==0 for x in completed),'Targeted CTest failure retained; no complete receipt'
guard();changed_products=[]
for path,record in products.items():
 if fact(Path(path))!=record:
  assert Path(path).name=='qcae_typed_host_tests',path
  changed_products.append(path)
assert len(changed_products)==4
dump(OUT/'complete.json',{'actual_exit_code':0,'candidate_before_after_equal':True,'candidate':fact(OUT/'candidate.json'),'method':method,'configurations':completed,'targeted_test_executions':4,'targeted_passed':4,'retained_unaffected_original_passed':257,'resolved_configuration_case_count':261,'total_actual_executions_across_attempt02_and_repair':265,'total_actual_passed':261,'total_actual_failed_preserved':4,'test_only_source_delta':delta,'unchanged_unaffected_product_count':len(products)-len(changed_products),'rebuilt_typed_product_paths':changed_products,'previous_results':failures,'fresh_full_matrix_after_test_fix':'NOT RUN; unrelated products byte-identical','original_graphical_gate_still_open':True})
print(json.dumps({'targeted_passed':4,'retained_unchanged_passed':257,'initial_failures_preserved':4}),flush=True)
