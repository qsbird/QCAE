# entity197：六文件冻结切片 QG-02 静态审查（签名修复后）

结论：**PASS_STATIC_AFTER_TWO_FIXED_TEST_FINDINGS_RUNTIME_RETEST_PENDING**。未解决源码阻塞项：**0**。最终四个 typed_host 定向复验仍为 **PENDING**；不能报告修复后的产品测试通过。本代理仅只读复核源码及哈希，没有修改源码、运行生成/检查/编译/CTest/产品或操作Git。

上一版审查原样保留为 `review.before-signature-fix.md` 与 `review.before-signature-fix.json`，对应 typed SHA `fb00e3c4d2f346684404105bffabc0ab82dfc56a427668dd600171f7d1a158b5`。本轮五个其他源文件哈希不变，只有 fixture 的 typed_host 源码重新冻结。

## 冻结来源

更新后的 `/private/tmp/qcae-entity198-regression/source-freeze.json` 文件 SHA256：`0640cbcc652ebf7dfc88e86432a2cb5fb0b9f2e354ce9818ee5ec4d73a42f0f0`。六源文件逐项与本代理读取的最终源码相同。规范排序紧凑序列化后的源字典 SHA256：`a59182093dfca9f8be67782af3f767205750e6aaa67157629d64f6a7e733e721`。

| 文件 | 最终 SHA256 |
|---|---|
| `schemas/operations/entity_reads.json` | `e361fa4670c190aef0aaa59390298b089ac0243e9e7de699679061dfbebfcfe7` |
| `adapters/engine_api/src/ipc_api.cpp` | `7b1e5e8ea102f97de10773f260df44aff667478cad3ee7f1abde47ffd4c927b3` |
| `adapters/engine_api/src/ipc_model.cpp` | `5ef1e0a248d1fef8bca3a9be606ee592efc3e54f64e6742dd9f4c31a8c4500b6` |
| `tests/typed_host_tests.cpp` | `2c24728e0745bbb75a3279df8aaaaf3541dd5ce605f20c3f1e9ed967425d85f1` |
| `tests/entity_query_ipc_tests.py` | `ecb8cd3244c94f540acb36f325f9e407b110b7407be48711e1f7c03c0dcd41ba` |
| `tests/mcp_bridge_tests.py` | `931019fa2038d45146e36d47020a88c07611f83b2900eca40d6cb65a17616936` |

## 发现与处理事实

ENTITY197-01 / P2 / FIXED_AND_STATICALLY_RECHECKED：原 references 成功断言的精确 expected data 漏了现有 `ipc_model.cpp::ok` 插入的内层 revision。负责人在先前修订 `fb00e3c4d2f346684404105bffabc0ab82dfc56a427668dd600171f7d1a158b5` 中补齐预期，并对所有成功 entity invoke 核对内外 revision。本发现来自静态审查，没有观察到该问题导致产品执行失败；取消构建/0 CTest不列为实际产品失败。

ENTITY197-02 / P2 / TEST_SOURCE_FIXED_AND_STATICALLY_RECHECKED_RUNTIME_RETEST_PENDING：root报告实际初轮 **261执行、257通过、4失败**，四配置 typed_host 均报 `Prepared operation signature mismatch`。原新fixture用 literal `material:220000`，而 `runtime_test::material_change(220000)` 返回的 prepared signature 为 `material:220000.000000`，触发应用既有一致性检查。root仅将fixture参数改为既有 `runtime_test::modulus_signature(220000)`，与同数值 `material_change(220000)` 配对；本代理重读该调用并核对最终typed SHA `2c24728e0745bbb75a3279df8aaaaf3541dd5ce605f20c3f1e9ed967425d85f1`，其余五文件SHA与上一报告一致。

第二项的实际初轮结果来自root消息，本代理没有执行回归或读取产品日志；真实四失败保持为历史执行事实，不能写成“静态发现/未运行”。修复后的定向复验尚未报告结果。root计划仅增量重建并定向复验四个typed_host，保留未受影响产品hash及原257通过，不作无依据的全部重跑。本报告不提前宣称这些复验通过。

## 权威路径与错误顺序

公共 IPC/MCP/CLI读取经同一engine活动文档进入RecordApplication不可变snapshot，再使用既有查询/引用/影响分析与序列化。新增DTO实际参与业务过滤和引用输入；没有新增事务提交、revision/key保留、历史或store写入路径。

错误顺序保留：envelope/API/op/parameters-object/expected_profile → named version admission → document/epoch snapshot → 原fields/string/ID/page parser → semantic projection → 既有service诊断。省略/v1保留context-before-parameters，未来/坏版本先于文档及业务输入；容器shape与expected_profile仍更早拒绝。

原ID成员先全部校验，再仅对查询过滤集合稳定去重，保持字节及省略/显式空数组区别；分页先校验integer和范围，继续接受0与整数形式浮点值。MCP query省略parameters保留默认{}；refs省略参数拒绝；CLI API仍发送parameters对象。测试继续观察完整元数据、dirty/save token、rows/generation/history/cursor/immutable view及提供的计数器，不把test store冒充SQLite。

## 逐文件 QG-02 结论

### `schemas/operations/entity_reads.json` — PASS_STATIC

权威：Only the two existing reads receive installed v1 input contracts, stable field IDs and read-only document/epoch context.

不变量：All query fields optional; references entity_id required and direction optional; empty name/ID array allowed; pagination uses dimensionless finite_number after adapter-owned raw integer validation.

范围：No output DTO, registry, mutation context, generator change or new business operation.

### `adapters/engine_api/src/ipc_api.cpp` — PASS_STATIC

权威：Existing operation catalog plus generated input definitions; raw parameters schema remains the accepted structural contract.

不变量：Only two names join generated version admission. Existing envelope/API/operation/parameters-object and expected_profile refusals remain earlier; named version refusal runs before dispatch_model snapshot. Complete arguments reuse exact raw parameters schema; query parameters optional in MCP, references parameters required; revision/key unconstrained JSON and no profile property.

范围：Metadata preserves query/reference symbolic input/output/target labels; kind remains record-registry defined; pagination raw type/range and semantic projection are explicit.

### `adapters/engine_api/src/ipc_model.cpp` — PASS_STATIC

权威：RecordApplication immutable snapshot followed by existing query_entities/query_references/query_affected_analyses and existing serializers.

不变量：Snapshot/context still precedes raw parameters on omitted/v1. Original fields/string/ID/page parsing order retained. Stable raw ID dedup happens only after all members validate, preserves ID bytes and explicit [] versus omission. Zero and integer bounds validate before finite-number DTO conversion. DTO values feed the actual filter/reference service; no unused semantic shell.

范围：No document transaction, revision/key retention, history mutation or new serializer; complete reference loop remains internally paged at 1000.

### `tests/typed_host_tests.cpp` — PASS_STATIC_AFTER_REVISION_AND_SIGNATURE_FIXES

权威：Actual application fixture with a test store that persists real application rows/project payloads; explicitly not SQLite I/O evidence.

不变量：Seeded records, custom registry query kind, save point then dirty edit and two-item history make full state preservation observable. Each read/refusal helper checks persisted rows/generation/project payloads/save token/current metadata/history/counters and complete immutable record view. Host/change facts retain original owners; ordinary entity reads share facts across explicit trusted direct callers and do not retain write keys.

范围：Paired omitted/v1 full envelope, raw shape/context/version/error text, organization closure and duplicate/empty-ID/pagination coverage reuse existing observation helpers. Fixed exact inner revision expectation re-read; all successful entity invokes now assert equal inner/outer revisions. The dirty Material edit signature now uses the existing modulus_signature helper matching material_change; literal signature mismatch removed. Four root-reported runtime fixture failures remain historical facts; targeted runtime revalidation is pending.

### `tests/entity_query_ipc_tests.py` — PASS_STATIC

权威：Existing actual engine/CLI SQLite fixture (--workspace work.sqlite), existing snapshot observer, and existing line/mesh/organization workflows.

不变量：Thin contract_call adds only document/epoch and forwards raw extra context/version; contract_pair observes before/after full authority and compares omitted/v1 envelope before marking unchanged. Existing line and mesh identities retained across the new reads and later assertions; no replacement workflow or overwriting of material/mesh fixture record variables. Nonempty refs and 1003 complete incoming references remain covered.

范围：Save-as prepares an explicit saved observation state; initial authority and paired state digests written only after real response assertions. Imported snapshot helper implementation is outside the six-file read scope and was not separately re-reviewed here.

### `tests/mcp_bridge_tests.py` — PASS_STATIC

权威：Existing two actual MCP stdio connections and actual CLI share one local IPC engine; --durable retains existing explicit SQLite workspace.

不变量：Exact engine capability text/descriptions and tool arguments schema compared; MCP query omission tested against explicit {} while API CLI still sends parameters object. Existing Steel Material commit reused; zero/upper pagination, empty/duplicate IDs, known/unknown kinds, owner/service/shape/context/version refusals and ignored arbitrary JSON revision/key covered. Full current/status/model/history/entities/fields observations preserved across success and refusal groups.

范围：Both actual MCP connections are trusted local-user, not cross-principal evidence. Material fixture has no reference edges; SQLite fixture provides nonempty/multi-page ref coverage. No business model copies or new mutation workflow.

## 运行和证据边界

本代理执行验证为 **NOT RUN**：未运行AST/check脚本、生成器、格式、编译、CTest、engine/CLI/MCP/SQLite产品、GUI、solver、AI或性能验证。六文件哈希核对与单点源码重读是本报告直接证据。root报告的实际初轮261/257/4已单独注明来源与状态；最终源码四target复验待root实际证据。

两个MCP连接为同一可信local-user，不作跨principal证据；MCP共享Material无引用边，SQLite原有line/mesh/组织场景承担非空及1003完整refs范围。Imported snapshot observer实现仍在六文件审查范围外。完整SK/P0、GUI、真实solver/AI和性能验收不因本切片审查完成而关闭。
