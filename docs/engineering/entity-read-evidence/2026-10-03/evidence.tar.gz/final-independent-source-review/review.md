# entity197：六文件冻结切片 QG-02 静态审查（action outcome修复后）

结论：**PASS_STATIC_AFTER_THREE_FIXED_TEST_FINDINGS_SECOND_TARGETED_RETEST_PENDING**。未解决源码阻塞项：**0**。第二次四目标typed_host复验仍为 **PENDING**；不报告最终修复产品测试通过。本代理只读复核新scene的五处action_outcome及六文件最终哈希，无源码/Git修改或执行验证。

上一版原样保存为 `review.before-action-fix.md/json`（typed SHA `2c24728e0745bbb75a3279df8aaaaf3541dd5ce605f20c3f1e9ed967425d85f1`）；更早静态审查仍保留 `review.before-signature-fix.md/json`。本轮只有typed fixture源码变更，另外五源文件SHA不变。

## 冻结来源

更新后的 `/private/tmp/qcae-entity198-regression/source-freeze.json` 文件SHA256：`fe01474394ed27d207985aef2557b6dfa1ffdf5992174a04239ad6e6a223a98d`。六文件逐项匹配本代理读取的源码；规范排序紧凑源字典SHA256：`e468ca603ddb8a63d7ee1408cee6276057c3921038cc14c713933ddef6c3ea6c`。

| 文件 | 最终 SHA256 |
|---|---|
| `schemas/operations/entity_reads.json` | `e361fa4670c190aef0aaa59390298b089ac0243e9e7de699679061dfbebfcfe7` |
| `adapters/engine_api/src/ipc_api.cpp` | `7b1e5e8ea102f97de10773f260df44aff667478cad3ee7f1abde47ffd4c927b3` |
| `adapters/engine_api/src/ipc_model.cpp` | `5ef1e0a248d1fef8bca3a9be606ee592efc3e54f64e6742dd9f4c31a8c4500b6` |
| `tests/typed_host_tests.cpp` | `467c883d9c126d9e6fb8e6bf80a5652985ce9d908219ca8b5e553501efd02fbc` |
| `tests/entity_query_ipc_tests.py` | `ecb8cd3244c94f540acb36f325f9e407b110b7407be48711e1f7c03c0dcd41ba` |
| `tests/mcp_bridge_tests.py` | `931019fa2038d45146e36d47020a88c07611f83b2900eca40d6cb65a17616936` |

## 发现、实际失败与修复

ENTITY197-01 / P2 / FIXED_AND_STATICALLY_RECHECKED：静态发现references精确expected data漏了现有ok序列化插入的内层revision；前次负责人修复expected并统一核对成功读取内外revision。这项来源是静态审查，未观察到其产品执行失败；取消构建/0 CTest不写成失败。

ENTITY197-02 / P2 / SIGNATURE_FIXED：root报告初轮实际 **261执行、257通过、4 typed_host失败**，错误 `Prepared operation signature mismatch`。新fixture literal `material:220000` 与 material_change返回的 `material:220000.000000` 不一致。负责人仅改用既有 `runtime_test::modulus_signature(220000)`，与同值material_change配对。签名修复后第一次四目标复验已实际执行，仍 **4失败**，但失败点为后续 `Unknown operation`；这轮结果不能被写成“复验pending”或通过。

ENTITY197-03 / P2 / LOOKUP_FIXED_AND_STATICALLY_RECHECKED：root定位第一次四目标复验的 `Unknown operation` 来自新scene用 `app.operation` 查test.entity.seed及entity read事实，而该facade仅接纳commit/undo/redo。原负向读键检查也只能证明facade拒绝，不能证明record action事实未保留。本轮五处替换为既有 `app.record_application().action_outcome`，分别查原seed回执、读取后seed回执、另一caller的seed拒绝及query/references unused读键缺失；均使用execute维护的记录动作事实权威。本代理核对该scene有且只有五处action_outcome，且不再有app.operation调用，最终typed SHA为 `467c883d9c126d9e6fb8e6bf80a5652985ce9d908219ca8b5e553501efd02fbc`。生产三文件与其他测试两文件均未变。

两轮原失败总计 **8**：初轮四signature失败＋签名修复后四Unknown operation失败，均保留为真实执行历史，来源为root消息。本代理未执行回归或查阅产品日志。第二次四目标复验（action outcome修复后）仍待root实际结果，不提前声明通过。原257通过及未受影响产品hash由root保留收敛。

## 权威路径、原兼容和错误顺序

公共IPC/MCP/CLI读取仍经同一engine活动文档的不可变RecordApplication snapshot进入既有query/reference/affected-analysis服务和serializer。生成DTO用于实际业务输入；没有新事务、history/store写入或读键保留路径。record action查回只改测试观察入口，没有更改生产路由。

源码错误顺序继续为envelope/API/op/parameters-object/expected_profile → named version → document/epoch snapshot → 原fields/string/ID/page parser → semantic projection → 既有service诊断。省略/v1保持context-before-parameters；future/malformed version先于document/business；parameters容器和expected_profile更早拒绝。

IDs先完整校验再稳定去重，仅形成过滤集合，保持字节、空数组/省略区别。offset/limit仍经过原integer/range检查再投影，0与整数浮点形式保留。MCP query省略parameters仍默认{}，refs省略参数失败，CLI API仍需要parameters对象。实际line/mesh与双MCP Steel Material既有fixture继续复用，未复制独立业务模型或覆盖实体记录变量。

## 逐文件 QG-02 结论

### `schemas/operations/entity_reads.json` — PASS_STATIC

权威：Only the two existing reads receive installed v1 input contracts, stable field IDs and read-only document/epoch context.

不变量：All query fields optional; references entity_id required and direction optional; empty name/ID array allowed; pagination uses dimensionless finite_number after adapter-owned raw integer validation.

范围：No output DTO, registry, mutation context, generator change or new business operation.

### `adapters/engine_api/src/ipc_api.cpp` — PASS_STATIC

权威：Existing operation catalog plus generated input definitions; raw parameters schema remains the accepted structural contract.

不变量：Only two names join generated version admission. Existing envelope/API/operation/parameters-object and expected_profile refusals remain earlier; named version refusal runs before dispatch_model snapshot. Complete arguments reuse exact raw parameters schema; query parameters optional in MCP, references parameters required; revision/key unconstrained JSON and no profile property.

范围：Metadata preserves query/reference symbolic input/output/target labels; kind remains record-registry defined; pagination raw type/range and semantic projection are explicit.

### `adapters/engine_api/src/ipc_model.cpp` — PASS_STATIC

权威：RecordApplication immutable snapshot followed by existing query_entities/query_references/query_affected_analyses and existing serializers.

不变量：Snapshot/context still precedes raw parameters on omitted/v1. Original fields/string/ID/page parsing order retained. Stable raw ID dedup happens only after all members validate, preserves ID bytes and explicit [] versus omission. Zero and integer bounds validate before finite-number DTO conversion. DTO values feed the actual filter/reference service; no unused semantic shell.

范围：No document transaction, revision/key retention, history mutation or new serializer; complete reference loop remains internally paged at 1000.

### `tests/typed_host_tests.cpp` — PASS_STATIC_AFTER_REVISION_SIGNATURE_AND_ACTION_FACT_FIXES

权威：Actual application fixture with a test store that persists real application rows/project payloads; explicitly not SQLite I/O evidence.

不变量：Seeded records, custom registry query kind, save point then dirty edit and two-item history make full state preservation observable. Each read/refusal helper checks persisted rows/generation/project payloads/save token/current metadata/history/counters and complete immutable record view. Host/change facts retain original owners; ordinary entity reads share facts across explicit trusted direct callers and do not retain write keys.

范围：Paired omitted/v1 full envelope, raw shape/context/version/error text, organization closure and duplicate/empty-ID/pagination coverage reuse existing observation helpers. The exact references expectation retains inner revision and all successful entity invokes assert equal inner/outer revisions. The dirty Material fixture uses modulus_signature matching material_change. Five seed/read retained-fact probes now use the record application action_outcome authority, so original receipt/caller isolation/read-key absence checks examine actual record action facts rather than generic facade rejection. Root-reported initial four signature failures plus first-retest four Unknown operation failures remain historical facts; second targeted revalidation is pending.

### `tests/entity_query_ipc_tests.py` — PASS_STATIC

权威：Existing actual engine/CLI SQLite fixture (--workspace work.sqlite), existing snapshot observer, and existing line/mesh/organization workflows.

不变量：Thin contract_call adds only document/epoch and forwards raw extra context/version; contract_pair observes before/after full authority and compares omitted/v1 envelope before marking unchanged. Existing line and mesh identities retained across the new reads and later assertions; no replacement workflow or overwriting of material/mesh fixture record variables. Nonempty refs and 1003 complete incoming references remain covered.

范围：Save-as prepares an explicit saved observation state; initial authority and paired state digests written only after real response assertions. Imported snapshot helper implementation is outside the six-file read scope and was not separately re-reviewed here.

### `tests/mcp_bridge_tests.py` — PASS_STATIC

权威：Existing two actual MCP stdio connections and actual CLI share one local IPC engine; --durable retains existing explicit SQLite workspace.

不变量：Exact engine capability text/descriptions and tool arguments schema compared; MCP query omission tested against explicit {} while API CLI still sends parameters object. Existing Steel Material commit reused; zero/upper pagination, empty/duplicate IDs, known/unknown kinds, owner/service/shape/context/version refusals and ignored arbitrary JSON revision/key covered. Full current/status/model/history/entities/fields observations preserved across success and refusal groups.

范围：Both actual MCP connections are trusted local-user, not cross-principal evidence. Material fixture has no reference edges; SQLite fixture provides nonempty/multi-page ref coverage. No business model copies or new mutation workflow.

## 执行与证据边界

本代理执行验证仍为 **NOT RUN**：未运行AST/check、生成、格式、编译、CTest、engine/CLI/MCP/SQLite产品或Git写操作。直接证据仅源码读取、五处替换核对及最终SHA。root报告的两轮实际结果261/257/4与4/0/4已分别记录，第二次定向复验pending。

C++test store不冒充SQLite I/O；提供的实际应用行、project payload、generation、save/dirty、history、view与计数器由观察helper保护。实际SQLite使用既有fixture及snapshot observer，其外部实现不属于六文件只读范围。两MCP同可信local-user，未声明跨principal；共享Material无引用边，原SQLite非空与1003refs场景保持单独证据范围。完整SK/P0、GUI、真实solver/AI、性能均不在本审查关闭范围。
