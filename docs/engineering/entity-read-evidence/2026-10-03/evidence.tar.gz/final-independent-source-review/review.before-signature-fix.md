# entity197：六文件冻结切片 QG-02 静态审查

结论：**PASS_STATIC_AFTER_ONE_FIXED_TEST_FINDING**。未解决阻塞项：**0**。本审查只读六个源文件及其差异，并读取 root 指定的最终冻结字典做 SHA256 核对；未修改源码。生成器、格式/设计/diff门禁、编译、CTest 与 engine/CLI/MCP/SQLite 产品执行均为 **NOT RUN**，不能据此报告运行回归通过。

## 冻结来源

最终字典 `/private/tmp/qcae-entity198-regression/source-freeze.json` 的文件 SHA256：`b7e816ba9d9497035b32332052ccc3d5f1546e2a6125ecb1db58b6e6c0474b24`。该文件列出的六个源文件哈希与本审查读取的最终源码逐项相同。排序并紧凑序列化后的最终源字典 SHA256：`25291a2b08f7084cbd29349d8d1294779de2dae647a8e520e1ab8175bdd24bb3`。

| 文件 | 最终 SHA256 |
|---|---|
| `schemas/operations/entity_reads.json` | `e361fa4670c190aef0aaa59390298b089ac0243e9e7de699679061dfbebfcfe7` |
| `adapters/engine_api/src/ipc_api.cpp` | `7b1e5e8ea102f97de10773f260df44aff667478cad3ee7f1abde47ffd4c927b3` |
| `adapters/engine_api/src/ipc_model.cpp` | `5ef1e0a248d1fef8bca3a9be606ee592efc3e54f64e6742dd9f4c31a8c4500b6` |
| `tests/typed_host_tests.cpp` | `fb00e3c4d2f346684404105bffabc0ab82dfc56a427668dd600171f7d1a158b5` |
| `tests/entity_query_ipc_tests.py` | `ecb8cd3244c94f540acb36f325f9e407b110b7407be48711e1f7c03c0dcd41ba` |
| `tests/mcp_bridge_tests.py` | `931019fa2038d45146e36d47020a88c07611f83b2900eca40d6cb65a17616936` |

## 已修复静态发现

ENTITY197-01 / P2 / FIXED_AND_STATICALLY_RECHECKED：原 `tests/typed_host_tests.cpp::entity_read_contracts_preserve_application` 的 references 成功断言精确比较 `data`，却缺少现有 `ipc_model.cpp::ok` 插入的内层 `revision`。原 observation helper 直接返回完整 dispatch envelope，不会剔除该字段。负责人已补齐 expected data.revision，并在每个成功 entity invoke 上核对内外revision等于快照修订。本审查重读修正后源码，最终 typed hash 为 `fb00e3c4d2f346684404105bffabc0ab82dfc56a427668dd600171f7d1a158b5`。

这是一项静态发现的测试断言缺陷；本审查没有执行产品或观察到测试失败。不将取消构建或未启动CTest写成实际产品测试失败。修复后没有遗留该阻塞项。

## 权威路径与错误顺序

公共 IPC/MCP/CLI 请求经同一个活动 engine 文档进入 RecordApplication 不可变 snapshot，再调用既有实体查询、引用查询、影响分析与既有响应序列化。新增生成 DTO 真正参与业务过滤/引用输入；生产路径未新增事务、修订提交、历史写入或读取键事实保留。

错误顺序从源码可清楚定位：全局 envelope/API/op/parameters-object/expected_profile → 具名 version admission → document/epoch snapshot → 原 fields/string/ID/page raw parser → 有限 semantic projection → query/reference service诊断。省略/v1继续保留context-before-parameters；未来/坏版本先于文档和业务输入；parameters容器与expected_profile仍更早拒绝。有限投影没有静默丢弃extra/null/nested字段。

raw ID全部先校验后，仅对查询集合稳定去重；字节不trim、不改大小写，省略与显式空数组分开。offset/limit仍在原integer/范围检查之后转换DTO，0和整数形式浮点值不因positive_uint32误用而丢失。MCP query省略arguments.parameters仍默认{}，refs省略参数仍拒绝；CLI API本身始终需要parameters对象。

## 逐文件 QG-02 结论

### `schemas/operations/entity_reads.json` — PASS_STATIC

权威：Only the two existing reads receive installed v1 input contracts, stable field IDs and read-only document/epoch context.

不变量：All query fields optional; references entity_id required and direction optional; empty name/ID array allowed; pagination uses dimensionless finite_number after adapter-owned raw integer validation.

范围：No output DTO, registry, mutation context, generator change or new business operation.

### `adapters/engine_api/src/ipc_api.cpp` — PASS_STATIC

权威：Existing operation catalog plus generated input definitions; raw parameters schema remains the accepted structural contract.

不变量：Only two names join generated version admission. Existing envelope/API/operation/parameters-object and expected_profile refusals remain earlier; named version refusal runs before dispatch_model snapshot. Complete arguments reuse exact raw parameters schema; query parameters optional in MCP, references parameters required; revision/key unconstrained JSON and no profile property.

范围：Metadata preserves query/reference symbolic input/output/target labels; kind remains record-registry defined; pagination raw type/range and semantic projection are explicit.

### `adapters/engine_api/src/ipc_model.cpp` — PASS_STATIC

权威：RecordApplication immutable snapshot followed by existing query_entities/query_references/query_affected_analyses and existing serializers.

不变量：Snapshot/context still precedes raw parameters on omitted/v1. Original fields/string/ID/page parsing order retained. Stable raw ID dedup happens only after all members validate, preserves ID bytes and explicit [] versus omission. Zero and integer bounds validate before finite-number DTO conversion. DTO values feed the actual filter/reference service; no unused semantic shell.

范围：No document transaction, revision/key retention, history mutation or new serializer; complete reference loop remains internally paged at 1000.

### `tests/typed_host_tests.cpp` — PASS_STATIC_AFTER_FIX

权威：Actual application fixture with a test store that persists real application rows/project payloads; explicitly not SQLite I/O evidence.

不变量：Seeded records, custom registry query kind, save point then dirty edit and two-item history make full state preservation observable. Each read/refusal helper checks persisted rows/generation/project payloads/save token/current metadata/history/counters and complete immutable record view. Host/change facts retain original owners; ordinary entity reads share facts across explicit trusted direct callers and do not retain write keys.

范围：Paired omitted/v1 full envelope, raw shape/context/version/error text, organization closure and duplicate/empty-ID/pagination coverage reuse existing observation helpers. Fixed exact inner revision expectation re-read; all successful entity invokes now assert equal inner/outer revisions.

### `tests/entity_query_ipc_tests.py` — PASS_STATIC

权威：Existing actual engine/CLI SQLite fixture (--workspace work.sqlite), existing snapshot observer, and existing line/mesh/organization workflows.

不变量：Thin contract_call adds only document/epoch and forwards raw extra context/version; contract_pair observes before/after full authority and compares omitted/v1 envelope before marking unchanged. Existing line and mesh identities retained across the new reads and later assertions; no replacement workflow or overwriting of material/mesh fixture record variables. Nonempty refs and 1003 complete incoming references remain covered.

范围：Save-as prepares an explicit saved observation state; initial authority and paired state digests written only after real response assertions. Imported snapshot helper implementation is outside the six-file read scope and was not separately re-reviewed here.

### `tests/mcp_bridge_tests.py` — PASS_STATIC

权威：Existing two actual MCP stdio connections and actual CLI share one local IPC engine; --durable retains existing explicit SQLite workspace.

不变量：Exact engine capability text/descriptions and tool arguments schema compared; MCP query omission tested against explicit {} while API CLI still sends parameters object. Existing Steel Material commit reused; zero/upper pagination, empty/duplicate IDs, known/unknown kinds, owner/service/shape/context/version refusals and ignored arbitrary JSON revision/key covered. Full current/status/model/history/entities/fields observations preserved across success and refusal groups.

范围：Both actual MCP connections are trusted local-user, not cross-principal evidence. Material fixture has no reference edges; SQLite fixture provides nonempty/multi-page ref coverage. No business model copies or new mutation workflow.

## 静态证据与运行边界

本审查执行内容仅为源码/差异读取和六文件SHA256与最终冻结字典核对。没有运行 AST/check脚本、生成器、格式化、编译、CTest、实际产品或写入Git。root统一负责五配置执行矩阵与实际产物证据。

C++测试store观察真实应用行、项目payload、generation、history/cursor、dirty/save metadata与提供的I/O counters，但本身不证明SQLite I/O。实际SQLite测试通过既有引擎夹具及既有snapshot观察器衔接；该外部观察器实现不属于本次六文件只读范围。MCP共享Material无引用边，非空/多内部页引用由SQLite既有夹具承担。两路真实MCP同为可信local-user，不构成跨principal隔离证据；直接C++caller测试保持单独范围。不扩展GUI、solver、真实AI、性能或完整SK/P0验收。
