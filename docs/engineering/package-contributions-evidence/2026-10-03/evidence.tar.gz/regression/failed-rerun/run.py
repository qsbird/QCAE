#!/usr/bin/env python3
"""Root-only unchanged-source recovery of one failed existing GUI test and unrun configurations."""
from pathlib import Path
import hashlib,json,os,re,subprocess,time
SOURCE=Path('/private/tmp/qcae-framework-delivery80')
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'attempt-01'
FULL=Path('/private/tmp/qcae-package-contributions151-successor01/attempt-01')
BUILD=Path('/private/tmp/qcae-package-contributions151-builds')
CTEST='/opt/homebrew/Cellar/cmake/4.3.0/bin/ctest'
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def fact(path):
 p=Path(path);return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
def dump(path,value):
 with Path(path).open('x') as f:json.dump(value,f,indent=2,sort_keys=True);f.write('\n')
assert not OUT.exists() and not (FULL/'complete.json').exists()
OUT.mkdir()
candidate=json.loads((FULL/'candidate.json').read_text());inputs=candidate['candidate_files'];head=candidate['base_head'];method=fact(__file__)
assert len(inputs)==416
assert json.loads((FULL/'desktop-ctest.json').read_text())['actual_exit_code']!=0
for name in ['core','local']:assert json.loads((FULL/(name+'-complete.json')).read_text())['actual_exit_code']==0
log=(FULL/'desktop-ctest.stdout.log').read_text()
rows=re.findall(r'(?m)^\s*\d+/96 Test\s+#\d+:\s+(\S+)\s+\.+\s*(Passed|\*\*\*Timeout|\*\*\*Failed)\s+',log)
assert len(rows)==96 and [(name,state) for name,state in rows if state!='Passed']==[('desktop_selection','***Timeout')],rows
raw=OUT/'desktop-original-failed-LastTest.log';raw.write_bytes((BUILD/'desktop/Testing/Temporary/LastTest.log').read_bytes())
dump(OUT/'candidate.json',{'candidate':fact(FULL/'candidate.json'),'source_files':inputs,'source_dictionary_sha256':candidate['source_dictionary_sha256'],'method':method,'original_desktop_test_outcomes':rows,'failed_full_ctest':fact(FULL/'desktop-ctest.json'),'original_failed_raw_log':fact(raw),'scope':'Original 180-second desktop_selection limit and unchanged candidate; earlier 95 desktop passes kept, not rerun; remaining OFF/sanitizer configurations run now'})
def guard():
 assert inputs=={name:sha(SOURCE/name) for name in inputs}
 assert head==subprocess.check_output(['git','rev-parse','HEAD'],cwd=SOURCE,text=True).strip()
 assert method==fact(__file__)
def command(name,argv,extra=None):
 guard();env=os.environ.copy()
 for key in ['ASAN_OPTIONS','UBSAN_OPTIONS','LSAN_OPTIONS','DYLD_INSERT_LIBRARIES','DYLD_LIBRARY_PATH','DYLD_PRINT_LIBRARIES','QT_QPA_PLATFORM']:env.pop(key,None)
 env.update(extra or {});stdout=OUT/(name+'.stdout.log');stderr=OUT/(name+'.stderr.log');start=time.time()
 with stdout.open('xb') as out,stderr.open('xb') as err:result=subprocess.run(argv,cwd=SOURCE,env=env,stdout=out,stderr=err)
 guard();dump(OUT/(name+'.json'),{'actual_exit_code':result.returncode,'argv':argv,'cwd':str(SOURCE),'started_unix':start,'finished_unix':time.time(),'elapsed_seconds':time.time()-start,'explicit_environment':extra or {},'stdout':fact(stdout),'stderr':fact(stderr),'candidate_unchanged':True})
 print(json.dumps({'command':name,'actual_exit_code':result.returncode}),flush=True)
 if name.endswith('-ctest'):(OUT/(name+'-LastTest.log')).write_bytes((BUILD/('desktop' if name=='desktop-selection-ctest' else name.removesuffix('-ctest'))/'Testing/Temporary/LastTest.log').read_bytes())
 assert result.returncode==0,name+' failed; original logs retained'
completed=[json.loads((FULL/(name+'-complete.json')).read_text()) for name in ['core','local']]
command('desktop-selection-ctest',[CTEST,'--test-dir',str(BUILD/'desktop'),'--output-on-failure','--verbose','-R','^desktop_selection$'])
names=[test['name'] for test in json.loads((FULL/'desktop-inventory.stdout.log').read_text())['tests']]
assert len(names)==96
completed.append({'configuration':'desktop','actual_exit_code':0,'executed_test_names':names,'executed_count':96,'original_95_passes':fact(FULL/'desktop-ctest.stdout.log'),'one_original_timeout':True,'unchanged_source_one_test_rerun':fact(OUT/'desktop-selection-ctest.json'),'scope':'95 original passes plus one original-limit rerun; not a single all-green full CTest invocation'})
for name,sanitize in [('package-off',False),('sanitized',True)]:
 command(name+'-inventory',[CTEST,'--test-dir',str(BUILD/name),'--show-only=json-v1'])
 names=[t['name'] for t in json.loads((OUT/(name+'-inventory.stdout.log')).read_text())['tests']]
 executed=['engine_assembly','engine_validation_binding','typed_host'] if sanitize else names
 assert all(n in names for n in executed)
 command(name+'-ctest',[CTEST,'--test-dir',str(BUILD/name),'--output-on-failure','--verbose','-j','1',*(['-R','^(engine_assembly|engine_validation_binding|typed_host)$'] if sanitize else [])],{'ASAN_OPTIONS':'detect_leaks=0:halt_on_error=1','UBSAN_OPTIONS':'halt_on_error=1:print_stacktrace=1'} if sanitize else None)
 record={'configuration':name,'actual_exit_code':0,'executed_count':len(executed),'executed_test_names':executed,'configured_test_names':names,'scope':'ASan/UBSan three selected tests; LSan unmeasured' if sanitize else 'existing full OFF regression'}
 dump(OUT/(name+'-complete.json'),record);completed.append(record)
guard();total=sum(record['executed_count'] for record in completed)
assert total==270 and [record['executed_count'] for record in completed]==[40,55,96,76,3]
dump(OUT/'complete.json',{'actual_exit_code':0,'candidate':fact(FULL/'candidate.json'),'source_before_after_equal':True,'configurations':completed,'total_test_executions':270,'unique_applicable_configuration_tests_passed':270,'actual_including_original_failure_executions':271,'original_failed_executions':1,'scope':'270 distinct configuration tests have actual passing observations; includes unchanged-source one-test rerun after original desktop_selection timeout, not 270/270 on first full invocations'})
print(json.dumps({'completed':True,'unique_applicable_passed':270,'actual_executions':271,'original_timeout_retained':True}),flush=True)
