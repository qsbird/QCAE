#!/usr/bin/env python3
"""Root-only unaffected OFF/ASan checks while the existing GUI timeout is investigated."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import hashlib,json,os,subprocess,time
SOURCE=Path('/private/tmp/qcae-framework-delivery80')
ROOT=Path(__file__).resolve().parent
BUILD=Path('/private/tmp/qcae-package-contributions151-builds')
CANDIDATE=Path('/private/tmp/qcae-package-contributions151-successor01/attempt-01/candidate.json')
CTEST='/opt/homebrew/Cellar/cmake/4.3.0/bin/ctest'
inputs=json.loads(CANDIDATE.read_text())['candidate_files']
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def fact(p):
 p=Path(p);return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
method=fact(__file__)
def dump(p,j):
 with Path(p).open('x') as f:json.dump(j,f,indent=2,sort_keys=True);f.write('\n')
def guard():assert inputs=={name:sha(SOURCE/name) for name in inputs} and method==fact(__file__)
def command(name,argv,extra=None):
 guard();env=os.environ.copy()
 for key in ['ASAN_OPTIONS','UBSAN_OPTIONS','LSAN_OPTIONS','DYLD_INSERT_LIBRARIES','DYLD_LIBRARY_PATH','DYLD_PRINT_LIBRARIES','QT_QPA_PLATFORM']:env.pop(key,None)
 env.update(extra or {});stdout=ROOT/(name+'.stdout.log');stderr=ROOT/(name+'.stderr.log');start=time.time()
 with stdout.open('xb') as out,stderr.open('xb') as err:result=subprocess.run(argv,cwd=SOURCE,env=env,stdout=out,stderr=err)
 guard();dump(ROOT/(name+'.json'),{'actual_exit_code':result.returncode,'argv':argv,'cwd':str(SOURCE),'started_unix':start,'finished_unix':time.time(),'elapsed_seconds':time.time()-start,'explicit_environment':extra or {},'stdout':fact(stdout),'stderr':fact(stderr),'source_unchanged':True})
 print(json.dumps({'command':name,'actual_exit_code':result.returncode}),flush=True)
 if name.endswith('-ctest'):(ROOT/(name+'-LastTest.log')).write_bytes((BUILD/name.removesuffix('-ctest')/'Testing/Temporary/LastTest.log').read_bytes())
 assert result.returncode==0,name
 return fact(ROOT/(name+'.json'))
def run(name):
 command(name+'-inventory',[CTEST,'--test-dir',str(BUILD/name),'--show-only=json-v1'])
 names=[test['name'] for test in json.loads((ROOT/(name+'-inventory.stdout.log')).read_text())['tests']]
 selected=['engine_assembly','engine_validation_binding','typed_host'] if name=='sanitized' else names
 assert len(selected)==(3 if name=='sanitized' else 76)
 extra={'ASAN_OPTIONS':'detect_leaks=0:halt_on_error=1','UBSAN_OPTIONS':'halt_on_error=1:print_stacktrace=1'} if name=='sanitized' else None
 receipt=command(name+'-ctest',[CTEST,'--test-dir',str(BUILD/name),'--output-on-failure','--verbose','-j','1',*(['-R','^(engine_assembly|engine_validation_binding|typed_host)$'] if name=='sanitized' else [])],extra)
 value={'configuration':name,'actual_exit_code':0,'executed_count':len(selected),'executed_test_names':selected,'configured_test_names':names,'receipt':receipt}
 dump(ROOT/(name+'-complete.json'),value);return value
with ThreadPoolExecutor(max_workers=2) as pool:results=list(pool.map(run,['package-off','sanitized']))
guard();dump(ROOT/'complete.json',{'actual_exit_code':0,'executed_count':sum(item['executed_count'] for item in results),'configurations':results,'candidate':fact(CANDIDATE),'known_full_desktop_suite_failure':'Two prior desktop_selection180s timeouts are not closed by these non-graphical checks','source_unchanged':True})
print(json.dumps({'completed':True,'executed_count':sum(item['executed_count'] for item in results)}),flush=True)
