#!/usr/bin/env python3
"""Root-only fresh regression for actual six-category engine registrations."""
from concurrent.futures import ThreadPoolExecutor
import hashlib,json,os,re,subprocess,time
from pathlib import Path
SOURCE=Path('/private/tmp/qcae-framework-delivery80')
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'attempt-01'
BUILD=Path('/private/tmp/qcae-package-contributions151-builds')
BASE=Path('/private/tmp/qcae-framework-contracts141-successor01/attempt-01/candidate.json')
CMAKE='/opt/homebrew/Cellar/cmake/4.3.0/bin/cmake'
CTEST='/opt/homebrew/Cellar/cmake/4.3.0/bin/ctest'
PYTHON='/Library/Frameworks/Python.framework/Versions/3.14/bin/python3.14'
COMPILER='/Library/Developer/CommandLineTools/usr/bin/c++'
VTK='/Users/qs/Documents/ChatGPT/QCAE/build-vtk-deps/install/lib/cmake/vtk-9.7'
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def fact(path):
 p=Path(path);return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
def dump(path,obj):
 with Path(path).open('x') as f: json.dump(obj,f,indent=2,sort_keys=True);f.write('\n')
assert not OUT.exists() and not BUILD.exists(),'Fresh receipts and build directories required'
OUT.mkdir()
files=set(json.loads(BASE.read_text())['candidate_files'])
for name in subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=SOURCE,text=True).splitlines():
 assert name.startswith(('tests/','schemas/')),'Unexpected untracked source '+name
 files.add(name)
inputs={name:sha(SOURCE/name) for name in sorted(files)}
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=SOURCE,text=True).strip()
assert head=='22362d0d1cf90bf7f2f35a64c7a8e24baf51a0ad'
assert len(inputs)==416, len(inputs)
method=fact(__file__)
dump(OUT/'candidate.json',{'base_head':head,'source':str(SOURCE),'candidate_files':inputs,'candidate_files_count':len(inputs),'source_dictionary_sha256':hashlib.sha256(json.dumps(inputs,sort_keys=True,separators=(',',':')).encode()).hexdigest(),'method':method,'previous_completed_candidate':fact(BASE),'build_cache_scope':'New build roots for this six-category implementation. No previous build directory is modified.','tools':{n:fact(p) for n,p in {'cmake':CMAKE,'ctest':CTEST,'python':PYTHON,'compiler':COMPILER}.items()},'scope':'Fresh existing full regressions and bounded sanitizer checks; no SDK-copy or performance claims.'})
def guard():
 assert inputs=={n:sha(SOURCE/n) for n in inputs},'Candidate changed'
 assert method==fact(__file__),'Method changed'
 assert head==subprocess.check_output(['git','rev-parse','HEAD'],cwd=SOURCE,text=True).strip(),'HEAD changed'
def command(name,argv,extra=None):
 guard();env=os.environ.copy()
 for key in ['ASAN_OPTIONS','UBSAN_OPTIONS','LSAN_OPTIONS','DYLD_INSERT_LIBRARIES','DYLD_LIBRARY_PATH','DYLD_PRINT_LIBRARIES','QT_QPA_PLATFORM']:
  env.pop(key,None)
 env.update(extra or {});start=time.time();stdout=OUT/(name+'.stdout.log');stderr=OUT/(name+'.stderr.log')
 with stdout.open('xb') as out,stderr.open('xb') as err:
  result=subprocess.run(argv,cwd=SOURCE,env=env,stdout=out,stderr=err)
 guard();dump(OUT/(name+'.json'),{'actual_exit_code':result.returncode,'argv':argv,'cwd':str(SOURCE),'started_unix':start,'finished_unix':time.time(),'elapsed_seconds':time.time()-start,'explicit_environment':extra or {},'stdout':fact(stdout),'stderr':fact(stderr),'candidate_before_after_equal':True})
 print(json.dumps({'command':name,'actual_exit_code':result.returncode}),flush=True)
 assert result.returncode==0,name+' failed; original logs retained'
 if name.endswith('-build'):
  assert not re.findall(r'(?m)^.*\bwarning:.*$',stdout.read_text(errors='replace')+stderr.read_text(errors='replace')),'Compiler warnings'
configs=[('core',False,False,False,True,'Release',False),('local',True,False,False,True,'Debug',False),('desktop',True,True,True,True,'Release',False),('package-off',True,True,False,False,'Release',False),('sanitized',True,False,False,True,'Release',True)]
def build(config):
 name,ipc,storage,desktop,package,mode,sanitize=config;directory=BUILD/name
 argv=[CMAKE,'-S',str(SOURCE),'-B',str(directory),'-G','Ninja','-DBUILD_TESTING=ON','-DCMAKE_EXPORT_COMPILE_COMMANDS=ON','-DCMAKE_CXX_EXTENSIONS=OFF','-DCMAKE_CXX_COMPILER='+COMPILER,'-DPython3_EXECUTABLE='+PYTHON,'-DCMAKE_BUILD_TYPE='+mode,'-DQCAE_BUILD_IPC='+('ON' if ipc else 'OFF'),'-DQCAE_BUILD_STORAGE='+('ON' if storage else 'OFF'),'-DQCAE_BUILD_DESKTOP='+('ON' if desktop else 'OFF'),'-DQCAE_ENABLE_NASTRAN_PACKAGE='+('ON' if package else 'OFF')]
 if ipc:argv+=['-DCMAKE_PREFIX_PATH=/opt/homebrew/opt/qt']
 if storage:argv+=['-DSQLite3_LIBRARY=/opt/homebrew/Cellar/sqlite/3.53.4/lib/libsqlite3.3.53.4.dylib','-DSQLite3_INCLUDE_DIR=/opt/homebrew/Cellar/sqlite/3.53.4/include']
 if desktop:argv+=['-DVTK_DIR='+VTK]
 if sanitize:argv+=['-DQCAE_ENABLE_SANITIZERS=ON']
 command(name+'-configure',argv)
 command(name+'-build',[CMAKE,'--build',str(directory),'-j','3',*(['--target','qcae_typed_host_tests','qcae_engine_assembly_tests','qcae_engine_validation_binding_tests'] if sanitize else [])])
 compilation=json.loads((directory/'compile_commands.json').read_text())
 assert all('-std=c++20' in row['command'] and '-std=gnu++20' not in row['command'] for row in compilation)
 dump(OUT/(name+'-compile-summary.json'),{'strict_cpp20':True,'compiler_warnings':[],'compile_commands':fact(directory/'compile_commands.json'),'configured_compile_units':len(compilation)})
for name,argv in [('design',[PYTHON,'tools/check_design.py']),('format',[PYTHON,'tools/check_cpp_format.py']),('diff',['git','diff','--check'])]:command(name,argv)
with ThreadPoolExecutor(max_workers=3) as pool:
 list(pool.map(build,configs[:3]))
with ThreadPoolExecutor(max_workers=2) as pool:
 list(pool.map(build,configs[3:]))
completed=[]
for config in configs:
 name,*rest=config;sanitize=config[-1];directory=BUILD/name
 command(name+'-inventory',[CTEST,'--test-dir',str(directory),'--show-only=json-v1'])
 names=[t['name'] for t in json.loads((OUT/(name+'-inventory.stdout.log')).read_text())['tests']]
 executed=['engine_assembly','engine_validation_binding','typed_host'] if sanitize else names
 assert all(n in names for n in executed)
 command(name+'-ctest',[CTEST,'--test-dir',str(directory),'--output-on-failure','--verbose','-j','1',*(['-R','^(engine_assembly|engine_validation_binding|typed_host)$'] if sanitize else [])],{'ASAN_OPTIONS':'detect_leaks=0:halt_on_error=1','UBSAN_OPTIONS':'halt_on_error=1:print_stacktrace=1'} if sanitize else None)
 raw=OUT/(name+'-LastTest.log');raw.write_bytes((directory/'Testing/Temporary/LastTest.log').read_bytes())
 result={'configuration':name,'actual_exit_code':0,'configured_test_names':names,'executed_test_names':executed,'executed_count':len(executed),'raw_log':fact(raw),'scope':'ASan+UBSan three affected adapter tests only; LSan unmeasured' if sanitize else 'existing full regression; no benchmark acceptance'}
 dump(OUT/(name+'-complete.json'),result);completed.append(result)
guard();dump(OUT/'complete.json',{'actual_exit_code':0,'candidate_before_after_equal':True,'candidate':fact(OUT/'candidate.json'),'method':method,'configurations':completed,'total_test_executions':sum(x['executed_count'] for x in completed)})
print(json.dumps({'complete':True,'test_executions':sum(x['executed_count'] for x in completed)}),flush=True)
