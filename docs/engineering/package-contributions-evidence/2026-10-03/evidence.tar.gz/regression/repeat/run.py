#!/usr/bin/env python3
"""Root-only repeatability verification after the test-only evidence-dir correction."""
from pathlib import Path
import hashlib,json,os,subprocess,time
SOURCE=Path('/private/tmp/qcae-framework-delivery80')
OUT=Path(__file__).resolve().parent
FULL=Path('/private/tmp/qcae-package-contributions151-successor01/attempt-01')
BUILD=Path('/private/tmp/qcae-package-contributions151-builds/desktop')
CTEST='/opt/homebrew/Cellar/cmake/4.3.0/bin/ctest'
PYTHON='/Library/Frameworks/Python.framework/Versions/3.14/bin/python3.14'
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def fact(path):
 p=Path(path);return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
def dump(path,value):
 with Path(path).open('x') as f:json.dump(value,f,indent=2,sort_keys=True);f.write('\n')
assert json.loads((FULL/'core-complete.json').read_text())['executed_count']==40
assert json.loads((FULL/'local-complete.json').read_text())['executed_count']==55
assert json.loads(Path('/private/tmp/qcae-package-contributions157-remaining/complete.json').read_text())['executed_count']==79
assert json.loads((FULL/'desktop-ctest.json').read_text())['actual_exit_code']==8
old=json.loads((FULL/'candidate.json').read_text())['candidate_files']
inputs={name:sha(SOURCE/name) for name in old}
delta=[name for name in inputs if old[name]!=inputs[name]]
assert delta==['tests/package_contributions_ipc_tests.py'],delta
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=SOURCE,text=True).strip()
assert head=='22362d0d1cf90bf7f2f35a64c7a8e24baf51a0ad'
method=fact(__file__)
products={name:sha(BUILD/name) for name in ['qcae-engine','qcae-cli','qcae-desktop','qcae-mcp','qcae_platform_engine']}
evidence=BUILD/'package-contributions-evidence'
original={str(p.relative_to(evidence)):sha(p) for p in evidence.rglob('*') if p.is_file()}
assert original and not any(p.is_dir() for p in evidence.iterdir()),'Only original flat evidence expected'
dump(OUT/'candidate.json',{'source':str(SOURCE),'base_head':head,'source_files':inputs,'source_dictionary_sha256':hashlib.sha256(json.dumps(inputs,sort_keys=True,separators=(',',':')).encode()).hexdigest(),'post_full_regression_source_delta':delta,'full_regression_candidate':fact(FULL/'candidate.json'),'method':method,'build_products':products,'original_full_ipc_evidence':original,'scope':'Same actual built product, test-only evidence-directory change; no compilation or unrelated reruns. Existing desktop_selection remains failed after two original180s CTest timeouts and one native full diagnostic timeout'})
def guard():
 assert inputs=={name:sha(SOURCE/name) for name in inputs}
 assert method==fact(__file__) and head==subprocess.check_output(['git','rev-parse','HEAD'],cwd=SOURCE,text=True).strip()
 assert products=={name:sha(BUILD/name) for name in products}
 assert all(sha(evidence/name)==value for name,value in original.items())
def command(name,argv):
 guard();env=os.environ.copy()
 for key in ['ASAN_OPTIONS','UBSAN_OPTIONS','LSAN_OPTIONS','DYLD_INSERT_LIBRARIES','DYLD_LIBRARY_PATH','DYLD_PRINT_LIBRARIES','QT_QPA_PLATFORM']:env.pop(key,None)
 stdout=OUT/(name+'.stdout.log');stderr=OUT/(name+'.stderr.log');start=time.time()
 with stdout.open('xb') as out,stderr.open('xb') as err:result=subprocess.run(argv,cwd=SOURCE,env=env,stdout=out,stderr=err)
 guard();dump(OUT/(name+'.json'),{'actual_exit_code':result.returncode,'argv':argv,'cwd':str(SOURCE),'started_unix':start,'finished_unix':time.time(),'elapsed_seconds':time.time()-start,'stdout':fact(stdout),'stderr':fact(stderr),'guards_unchanged':True})
 print(json.dumps({'command':name,'actual_exit_code':result.returncode}),flush=True)
 assert result.returncode==0,name
for name,argv in [('design',[PYTHON,'tools/check_design.py']),('format',[PYTHON,'tools/check_cpp_format.py']),('diff',['git','diff','--check'])]:command(name,argv)
command('repeat-ctest',[CTEST,'--test-dir',str(BUILD),'--output-on-failure','--verbose','-R','^package_contributions_ipc$','--repeat','until-fail:2'])
(OUT/'repeat-LastTest.log').write_bytes((BUILD/'Testing/Temporary/LastTest.log').read_bytes())
runs=sorted(p for p in evidence.iterdir() if p.is_dir())
assert len(runs)==2 and all(p.name.startswith('run-') for p in runs)
assert (OUT/'repeat-ctest.stdout.log').read_text().count('PASS: six-category package discovery joined')==2
for run in runs:
 observations=json.loads((run/'observations.json').read_text())
 assert observations['completed'] and observations['ui']['before']==observations['ui']['after']
 assert observations['validation']['before']==observations['validation']['after']
 assert observations['export']['physical_fields']==observations['semantic_readback']
 assert observations['engine_returncode']==-15
 assert json.loads((run/'transcript.json').read_text())
guard();dump(OUT/'complete.json',{'actual_exit_code':0,'executions':2,'candidate':fact(OUT/'candidate.json'),'runs':[str(p) for p in runs],'production_and_original_evidence_unchanged':True,'source_before_after_equal':True})
print(json.dumps({'completed':True,'executions':2,'evidence_runs':[p.name for p in runs]}),flush=True)
