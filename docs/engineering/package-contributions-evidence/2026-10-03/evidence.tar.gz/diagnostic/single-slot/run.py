#!/usr/bin/env python3
"""Root-only native single-slot timing/stack observation, bounded by original 180s."""
from pathlib import Path
import hashlib,json,os,subprocess,threading,time
ROOT=Path(__file__).resolve().parent
SOURCE=Path('/private/tmp/qcae-framework-delivery80')
CANDIDATE=Path('/private/tmp/qcae-package-contributions151-successor01/attempt-01/candidate.json')
BINARY=Path('/private/tmp/qcae-package-contributions151-builds/desktop/qcae_desktop_selection_tests')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def fact(p):
 p=Path(p);return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
inputs=json.loads(CANDIDATE.read_text())['candidate_files'];before_binary=fact(BINARY);before_method=fact(__file__)
def guard():
 assert all(sha(SOURCE/name)==value for name,value in inputs.items())
 assert before_binary==fact(BINARY) and before_method==fact(__file__)
guard();env=os.environ.copy()
for key in ['ASAN_OPTIONS','UBSAN_OPTIONS','LSAN_OPTIONS','DYLD_INSERT_LIBRARIES','DYLD_LIBRARY_PATH','DYLD_PRINT_LIBRARIES','QT_QPA_PLATFORM']:env.pop(key,None)
argv=[str(BINARY),'latestTreeSelectionSurvivesViewRefreshAndEnablesMeshTools','-v1']
start=time.time();timeline=[];samples=[];process=subprocess.Popen(argv,cwd=SOURCE,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
def copy_lines(stream,path,label):
 with path.open('xb') as output:
  for line in iter(stream.readline,b''):
   output.write(line);output.flush();timeline.append({'stream':label,'elapsed_seconds':time.time()-start,'line':line.decode(errors='replace').rstrip()})
threads=[threading.Thread(target=copy_lines,args=(process.stdout,ROOT/'stdout.log','stdout')),threading.Thread(target=copy_lines,args=(process.stderr,ROOT/'stderr.log','stderr'))]
for thread in threads:thread.start()
terminated=False;killed=False
while process.poll() is None:
 elapsed=time.time()-start
 for threshold in [15,45,90,150]:
  if elapsed>=threshold and not any(item['threshold']==threshold for item in samples):
   output=ROOT/f'sample-{threshold}.txt';sample_argv=['/usr/bin/sample',str(process.pid),'1','10','-file',str(output)]
   sample_start=time.time();result=subprocess.run(sample_argv,cwd=SOURCE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=10)
   (ROOT/f'sample-{threshold}.stdout.log').write_bytes(result.stdout);(ROOT/f'sample-{threshold}.stderr.log').write_bytes(result.stderr)
   samples.append({'threshold':threshold,'argv':sample_argv,'actual_exit_code':result.returncode,'elapsed_seconds':time.time()-sample_start,'observed_pid':process.pid,'owning_popen_pid':process.pid,'sample':fact(output) if output.exists() else None})
   print(json.dumps({'sample':threshold,'actual_exit_code':result.returncode}),flush=True)
 if elapsed>=180:
  terminated=True;process.terminate()
  try:process.wait(timeout=3)
  except subprocess.TimeoutExpired:killed=True;process.kill();process.wait()
  break
 time.sleep(0.1)
process.wait()
for thread in threads:thread.join()
guard();(ROOT/'timeline.json').write_text(json.dumps(sorted(timeline,key=lambda item:item['elapsed_seconds']),indent=2)+'\n')
receipt={'scope':'diagnostic one Qt slot only; does not replace the failed full suite or assert cause from one stack','argv':argv,'cwd':str(SOURCE),'owning_pid':process.pid,'actual_exit_code':process.returncode,'elapsed_seconds':time.time()-start,'terminated_at_original_180s_bound':terminated,'required_kill':killed,'candidate':fact(CANDIDATE),'binary_before_after_equal':True,'source_before_after_equal':True,'stdout':fact(ROOT/'stdout.log'),'stderr':fact(ROOT/'stderr.log'),'timeline':fact(ROOT/'timeline.json'),'samples':samples}
(ROOT/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'finished':True,'actual_exit_code':process.returncode,'elapsed_seconds':receipt['elapsed_seconds'],'timed_out':terminated,'samples':len(samples)}),flush=True)
