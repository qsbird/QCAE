# desktop_selection 180 秒超时：有限只读调查155

本轮是真实失败：`desktop_selection` 在180.03秒触及原CTest上限；现有desktop全轮receipt为exit8。旧141同测试120.83秒、Qt71/0/0真实通过，不能拿旧PASS代替新来源。

已核对当前416候选中5个相关文件（selection测试、desktop实现/头、VTK实现/头），SHA全部与旧141冻结文件相同。当前候选为HEAD22362d0上的冻结未提交变更，dictionary SHA为`b05c22c2c04e191aa5e8f4638d482b9f05e5d4d33a6335c7e8a1ba8df7b07d7a`；本审查没有执行全416 guard。当前/旧receipt的stdout、stderr实际hash均吻合。

## 能确定的定位

- `CMakeLists.txt:481–482`及当前实际CTest注册为整个可执行程序TIMEOUT180，命令没有case过滤，runner使用`-j1`。不是这个Qt slot单独拥有180秒。
- 超时前已有65个Qt PASS（包含init，即64个数据行），无Qt FAIL行；最后通过的是`cameraUpdateWaitsForThePendingResourceInstallation`。尚未形成该失败进程的Qt最终Totals。
- `tests/desktop_selection_tests.cpp:1699–1702`打印的两组setup，是同一个slot在10000ms idle等待前后各打印一次。第二组已经`idle=true`、viewport timer=false、pending requests=0，view.render_data达到revision4。旧通过日志在相同位置呈现相同的归一化状态。因此不能把末尾说成“第二轮运行卡在idle等待”。

## 累计等待与未证实原因

按64个已通过的数据行展开源码，有64次Window建立/窗口暴露等待、16次orient（各请求500ms）、53处直接barrier（5000ms退出timer）、342处QTRY，以及其他字面qWait共2800ms。固定请求等待合计10800ms；这不是实测耗时，不包含原生渲染、事件处理和helper重试。不能把其余169.2秒归因于某个等待。单条日志没有时间戳，也没有每个slot的实际开始时间。

最后setup后是`desktop.click(0)`（测试1703）：鼠标释放进入`VtkView::eventFilter:1254–1279`，通过`visibleBox:546`同步调用`hardwareBox:507–513`的`vtkHardwareSelector::Select()`，随后desktop按viewport上下文fence发送selection.evaluate。slot剩余内容还有hold update/render、barrier及QTRY阶段。缺少后续进度日志，无法确定180秒时进程处于拾取、后续等待还是销毁。原生图形停顿、此前累计耗时及上下文竞争均只是静态可达假设；没有证明新的确定产品缺陷。

SelectionEngine是本测试的本地wire替身，手动回答selection.evaluate/get，默认Window请求timeout5000ms（测试613）、barrier退出5000ms（648–659）；此次包发现变化没有加入它的fake响应协议。相关5文件不变排除了直接源码差分，但不排除整个新build或运行环境影响。日志的CoreAnalytics context leak文字不能单独证明Qt/VTK泄漏；睡眠、焦点/前台干扰、GPU栈与逐slot耗时均未知。

## 最小验证（全部NOT RUN）

根代理先在现队列结束后，按原环境及原CTest180秒限制执行完整`desktop_selection`，`-j1`，新目录保留argv/source/binary/exit/raw；原失败不覆盖。若重复，再由外层只读记录stdout时间戳与被拥有PID的栈，区分“此前已累计近180秒”与“同步硬件选择长期阻塞”。可另用现有QTest entering/leaving日志作诊断。只有定位持续slot后才作同binary单slot诊断；它不能代替完整suite验收。不增timeout、不删负例、不改真正pick或候选。

本代理只读取源码/既有日志并处理hash；未编译、运行测试、启动GUI/engine/product，未改AGENTS/Git/候选。当前阻塞是原真实回归超时；代码缺陷是否存在仍待上述有界实际定位。
