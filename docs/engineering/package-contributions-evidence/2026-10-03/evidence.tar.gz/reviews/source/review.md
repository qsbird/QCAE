# QG-02 独立只读审查 152

结论：产品代码及其他测试未发现阻塞；新 IPC 测试可重复执行问题 **152-01 尚未修复**。审查者 **NOT RUN**，没有编译、测试、产品运行、生成器/guard或 Git/候选修改。

依据：baseline README、REQ-08/09/10/11/12/15/16/17、SK-11/BP-10、acceptance QG-02 及 architecture 的统一宿主、能力包、事务/发布边界。当前单一 owner 是 `qcae.nastran`。

152-01（P2，必须修正）：`tests/package_contributions_ipc_tests.py:147` 使用 `exist_ok=False`，而 `CMakeLists.txt:332` 固定提供构建目录下同一证据路径。同一 CTest 第二次运行在 engine 启动前必然因目录已存在失败。根代理确认会把该路径作为父目录，每轮建立唯一子目录并保留旧 flat 证据；当前冻结候选仍保留此问题。

路径：`run_engine → assemble_engine → frozen RecordRegistry → 同一 RecordApplication → TypedHost 实际注册 → 成功 capabilities.list 附加 catalog`。核心来自新增类型与具名追加规则；操作来自每位贡献者实际新增 descriptor；codec/Profile 来自已选择端口；validation 是进入原 `model.export` 的同一回调副本；UI 引用自身可用的只读 handler；render 保留工厂实际已冻结投影。这些增加发现与绑定，没有新增事务/历史/产物发布业务链。

寿命：codec/Profile 两端口 alias 同一 State；validator 捕获 State 值，catalog 与 registry 保留回调副本；State 无 catalog/registry/coordinator 强回指。生产顺序保证 TaskService/TypedHost 先于 application 释放。失败：注册和 UI 校验完成前 catalog 不可读取；失败 host 不进入对客户端提供目录的事件循环。该结论不宣称 socket 或工作区初始化无副作用，因为原宿主在装配前已 listen。

验证拒绝仍发生于 pending/task/file 副作用前，保留原错误与 replay 顺序。新测试分别直接调用六类绑定、注入真实 registry validator 后检查全 row bytes/历史/代次与无任务文件、通过实际 SQLite IPC 检查发现/只读 UI/codec import/render/拒绝/export manifest/物理语义 re-import；OFF 与 ON platform-only 检查包 owner 缺席和公共 create/geometry/query/undo。均为源码审查，不能写运行通过。完整 SK-11 格式语义指标、GUI、真实求解/AI、性能、全部 SK/P0 不由本记录宣布完成。

冻结锚点：successor01 `candidate.json` SHA256 `1c1b9704865874c4a7ba0f7d6e55350afcac300a0d1b0bbcdd881c1ba8d01f2e`；base `22362d0d1cf90bf7f2f35a64c7a8e24baf51a0ad`；source dictionary `b05c22c2c04e191aa5e8f4638d482b9f05e5d4d33a6335c7e8a1ba8df7b07d7a`。起止 416/416 路径哈希匹配；十文件 SHA 见 `review.json`。首轮 151 candidate 已因根代理 json_ledger 修正被取代。后续 Python 修正需追加终态 SHA 复核。
