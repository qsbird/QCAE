#!/usr/bin/env python3
"""Archive completed root-owned six-category evidence without editing origins."""
from pathlib import Path
import hashlib,io,json,subprocess,tarfile
REPO=Path('/private/tmp/qcae-framework-delivery80')
DEST=REPO/'docs/engineering/package-contributions-evidence/2026-10-03'
entries={}
def digest(data):return hashlib.sha256(data).hexdigest()
def add(name,path):
 path=Path(path)
 assert path.is_file() and not path.is_symlink(),path
 assert name not in entries and not name.startswith('/') and '..' not in Path(name).parts
 assert path.suffix in {'.json','.log','.py','.md','.txt','.patch','.cpp','.hpp'},path
 entries[name]=(path,path.read_bytes())
def tree(label,root):
 root=Path(root);assert root.is_dir(),root
 for path in sorted(root.rglob('*')):
  if path.is_file() and not path.is_symlink() and '__pycache__' not in path.parts and path.suffix in {'.json','.log','.py','.md','.txt','.patch','.cpp','.hpp'}:
   add(label+'/'+str(path.relative_to(root)),path)
for label,root in [('regression/first-failed','/private/tmp/qcae-package-contributions151'),('regression/full','/private/tmp/qcae-package-contributions151-successor01'),('regression/failed-rerun','/private/tmp/qcae-package-contributions151-successor02'),('regression/remaining','/private/tmp/qcae-package-contributions157-remaining'),('diagnostic/single-slot','/private/tmp/qcae-package-contributions156-diagnostic'),('diagnostic/full-suite','/private/tmp/qcae-package-contributions158-full-diagnostic'),('reviews/graphical-static','/private/tmp/qcae-desktop-selection-investigation155'),('regression/repeat','/private/tmp/qcae-package-contributions154-repeat'),('reviews/source','/private/tmp/qcae-package-contributions152-review'),('source/final','/private/tmp/qcae-package-contributions154-source')]:tree(label,root)
for config in ['core','local','desktop','package-off','sanitized']:
 root=Path('/private/tmp/qcae-package-contributions151-builds')/config
 for name in ['CMakeCache.txt','compile_commands.json']:add('build-inputs/'+config+'/'+name,root/name)
tree('native/six-category','/private/tmp/qcae-package-contributions151-builds/desktop/package-contributions-evidence')
add('methods/archive.py',__file__)
final=json.loads(entries['source/final/freeze.json'][1])
candidate=json.loads(entries['regression/full/attempt-01/candidate.json'][1])
remaining=json.loads(entries['regression/remaining/complete.json'][1])
desktop=json.loads(entries['regression/full/attempt-01/desktop-ctest.json'][1])
rerun=json.loads(entries['regression/failed-rerun/attempt-01/desktop-selection-ctest.json'][1])
single=json.loads(entries['diagnostic/single-slot/receipt.json'][1])
graphical=json.loads(entries['diagnostic/full-suite/receipt.json'][1])
repeat=json.loads(entries['regression/repeat/complete.json'][1])
assert final['implementation_commit']==subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip()
assert len(final['source_files'])==416
assert json.loads(entries['regression/full/attempt-01/core-complete.json'][1])['executed_count']==40
assert json.loads(entries['regression/full/attempt-01/local-complete.json'][1])['executed_count']==55
assert remaining['actual_exit_code']==0 and [r['executed_count'] for r in remaining['configurations']]==[76,3]
assert desktop['actual_exit_code']==8 and rerun['actual_exit_code']==8
assert single['actual_exit_code']==0 and graphical['actual_exit_code']==-15 and graphical['terminated_at_original_180s_bound']
assert repeat['actual_exit_code']==0 and repeat['executions']==2
assert final['post_full_regression_source_delta']==['tests/package_contributions_ipc_tests.py']
assert set(final['source_files'])==set(candidate['candidate_files'])
for name,value in final['source_files'].items():assert digest((REPO/name).read_bytes())==value,name
for name,value in candidate['candidate_files'].items():
 if name not in final['post_full_regression_source_delta']:assert final['source_files'][name]==value,name
assert not DEST.exists();DEST.mkdir(parents=True)
archive=DEST/'evidence.tar.gz'
with tarfile.open(archive,'w:gz',format=tarfile.PAX_FORMAT) as output:
 for name,(_,data) in sorted(entries.items()):
  item=tarfile.TarInfo(name);item.size=len(data);item.mode=0o444;item.mtime=0
  output.addfile(item,io.BytesIO(data))
with tarfile.open(archive,'r:gz') as archive_input:
 members=archive_input.getmembers();assert [m.name for m in members]==sorted(entries)
 for member in members:
  origin,data=entries[member.name];assert member.isfile() and archive_input.extractfile(member).read()==data
  assert origin.read_bytes()==data,origin
manifest={'schema_version':1,'tested_implementation_commit':final['implementation_commit'],'source_files_count':416,'source_dictionary_sha256':final['source_dictionary_sha256'],'full_regression_source_dictionary_sha256':candidate['source_dictionary_sha256'],'post_full_regression_source_delta':final['post_full_regression_source_delta'],'source_hash_algorithm':'SHA256 of canonical sorted relative-path to file-SHA256 JSON; not C4-source-v1','archive':{'path':'evidence.tar.gz','bytes':archive.stat().st_size,'sha256':digest(archive.read_bytes()),'members':len(entries)},'verification':{'all_members_read_back_equal':True,'all_origins_re_read_equal':True,'runtime_database_or_product_binary_included':False},'entries':[{'member':name,'origin':str(path),'bytes':len(data),'sha256':digest(data)} for name,(path,data) in sorted(entries.items())],'limits':['Initial distinct configuration inventory270 includes269 passes and1 desktop_selection timeout; same test rerun timed out again at original180s; two additional IPC repeats passed after one test-only evidence-directory correction','Initial compile failure, two original-limit CTest timeouts and full-suite native diagnostic timeout retained; full graphical gate remains open and driver-readback sample does not establish root cause','No current-bundle refresh, real Nastran, full external AI, LSan, performance or complete SK/P0 claim']}
(DEST/'archive-index.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'archive':manifest['archive'],'index_sha256':digest((DEST/'archive-index.json').read_bytes()),'verified_origins':len(entries)}))
