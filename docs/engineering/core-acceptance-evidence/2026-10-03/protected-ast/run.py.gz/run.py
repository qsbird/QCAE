#!/usr/bin/env python3
"""Run the existing AST gate against the unchanged frozen source85/build86."""
import hashlib
import json
from pathlib import Path
import subprocess
import time

OUT = Path(__file__).resolve().parent
SOURCE = Path('/private/tmp/qcae-framework-preference-fix85')
FREEZE = Path('/private/tmp/qcae-framework-runtime86/frozen-candidate.json')
BUILD = Path('/private/tmp/qcae-framework86-builds/desktop')
LIB = Path('/opt/homebrew/opt/llvm/lib/libclang.dylib')
BINDINGS = Path('/opt/homebrew/opt/llvm/lib/python3.14/site-packages')
frozen = json.loads(FREEZE.read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def fact(path):
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': sha(path)}


def guard():
    actual = {name: sha(SOURCE / name) for name in frozen['source_files']}
    assert actual == frozen['source_files'], 'Frozen source410 changed'
    head = subprocess.check_output(['git', '-C', str(SOURCE), 'rev-parse', 'HEAD'], text=True).strip()
    assert head == frozen['commit']
    assert not subprocess.check_output(['git', '-C', str(SOURCE), 'status', '--porcelain'], text=True)
    return {'head': head, 'source410_sha256': frozen['source410_sha256'],
            'all410_byte_hashes_match': True}


attempt = OUT / 'attempt-01'
attempt.mkdir()
before = guard()
argv = ['python3', str(SOURCE / 'tools/check_protected_entity_ast.py'),
        '--build-dir', str(BUILD), '--libclang', str(LIB),
        '--bindings-dir', str(BINDINGS), '--self-test',
        '--clang-argument=-resource-dir',
        '--clang-argument=/Library/Developer/CommandLineTools/usr/lib/clang/21',
        '--clang-argument=-isysroot',
        '--clang-argument=/Library/Developer/CommandLineTools/SDKs/MacOSX.sdk',
        '--clang-argument=-isystem',
        '--clang-argument=/Library/Developer/CommandLineTools/SDKs/MacOSX.sdk/usr/include/c++/v1',
        '--report', str(attempt / 'ast-report.json')]
inputs = [fact(path) for path in [FREEZE, Path(argv[1]),
          SOURCE / 'docs/engineering/c4-protected-paths.json',
          BUILD / 'compile_commands.json', LIB, BINDINGS / 'clang/cindex.py',
          Path(__file__).resolve()]]
(attempt / 'planned.json').write_text(json.dumps({'argv': argv, 'before': before,
                                                'inputs': inputs}, indent=2) + '\n')
started = time.time()
with (attempt / 'stdout.log').open('wb') as stdout, (attempt / 'stderr.log').open('wb') as stderr:
    result = subprocess.run(argv, cwd=SOURCE, stdout=stdout, stderr=stderr)
after = guard()
assert inputs == [fact(Path(item['path'])) for item in inputs], 'Method input changed'
outputs = [fact(path) for path in sorted(attempt.iterdir()) if path.is_file()]
receipt = {'kind': 'actual_current_source_AST_gate', 'actual_exit_code': result.returncode,
           'elapsed_seconds': time.time() - started, 'argv': argv,
           'before': before, 'after': after, 'inputs': inputs, 'outputs': outputs,
           'scope': 'Original protected AST + unsaved forbidden-type self-test; no full SK/P0 claim.'}
(attempt / 'complete.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'actual_exit_code': result.returncode, 'elapsed_seconds': receipt['elapsed_seconds']}))
raise SystemExit(result.returncode)
