"""Bounded final readonly review record; no imports of executable project code."""
from pathlib import Path
import difflib
import hashlib
import json
import os
import subprocess
import time

HERE = Path(__file__).resolve().parent
ROOT = Path('/private/tmp/qcae-framework-delivery80')
CPP = ROOT / 'tests/schema_rejection_sqlite_tests.cpp'
EXPECTED = 'c77a07559f1ca11ee2412094dab991228d89423c6d2fdae637c9a9deab297892'


def fact(path):
    path = Path(path).resolve()
    return {'path': str(path), 'bytes': path.stat().st_size,
            'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}


def write(path, row):
    with path.open('x') as stream:
        json.dump(row, stream, ensure_ascii=False, indent=2)
        stream.write('\n')


def main():
    started = time.time()
    before = fact(CPP)
    assert before['sha256'] == EXPECTED and before['bytes'] == 25505
    source = CPP.read_text()
    assert len(source.splitlines()) == 502
    old = (HERE / 'candidate-first-read.cpp').read_text()
    method_diff = ''.join(difflib.unified_diff(old.splitlines(True), source.splitlines(True),
                         fromfile='108-first-read-be03.cpp', tofile='author-ready-c77.cpp'))
    with (HERE / 'first-to-final-candidate.diff').open('x') as stream:
        stream.write(method_diff)
    lines_added = sum(line.startswith('+') and not line.startswith('+++') for line in method_diff.splitlines())
    lines_removed = sum(line.startswith('-') and not line.startswith('---') for line in method_diff.splitlines())
    assert lines_added - lines_removed == 23
    assert 'first_id == retry_id' in source and 'allocated = allocate();' in source
    assert 'expired.error->code == ErrorCode::document_epoch_expired' in source
    assert 'unchanged(recovered, capture(*app, *store));' in source
    # Check only readonly CMake bytes against its committed parent; do not configure/run it.
    argv = ['git', '-C', str(ROOT), 'show', 'HEAD:CMakeLists.txt']
    start = time.time()
    result = subprocess.run(argv, capture_output=True)
    assert result.returncode == 0
    cmake_before = result.stdout.decode()
    cmake_after = (ROOT / 'CMakeLists.txt').read_text()
    cmake_diff = ''.join(difflib.unified_diff(cmake_before.splitlines(True), cmake_after.splitlines(True),
                        fromfile='committed-parent/CMakeLists.txt', tofile='candidate/CMakeLists.txt'))
    added = [line[1:] for line in cmake_diff.splitlines() if line.startswith('+') and not line.startswith('+++')]
    removed = [line for line in cmake_diff.splitlines() if line.startswith('-') and not line.startswith('---')]
    assert len(added) == 4 and not removed
    assert added == [
        '    add_executable(qcae_schema_rejection_sqlite_tests tests/schema_rejection_sqlite_tests.cpp)',
        '    target_link_libraries(qcae_schema_rejection_sqlite_tests PRIVATE qcae_geometry_features qcae_mesh_generation qcae_nastran qcae_sqlite)',
        '    qcae_warnings(qcae_schema_rejection_sqlite_tests)',
        '    add_test(NAME schema_rejection_sqlite COMMAND qcae_schema_rejection_sqlite_tests)']
    with (HERE / 'CMake-four-line-registration.diff').open('x') as stream:
        stream.write(cmake_diff)
    cases = [
      ('missing-required', 'missing_input', 'Required record field is missing', 'name', 'decode'),
      ('wrong-field-type', 'invalid_input', 'Wrong record field type', 'position', 'decode'),
      ('missing-unit', 'invalid_unit', 'Required field unit is missing', 'position', 'decode'),
      ('unknown-unit', 'invalid_unit', 'Unknown or incompatible field unit', 'position', 'decode'),
      ('out-of-range', 'invalid_input', 'Field is outside its allowed range', 'young_modulus_mpa', 'decode'),
      ('wrong-reference-type', 'invalid_input', 'Reference is missing or has the wrong record type', 'M-section.3', 'candidate validation'),
      ('dangling-reference', 'invalid_input', 'Reference is missing or has the wrong record type', 'M-section.3', 'candidate validation'),
      ('future-record-version', 'schema_unsupported', 'Unsupported future record version', '', 'decode')]
    inputs = ['tests/runtime_test_support.hpp', 'modules/application/include/qcae/record_application.hpp',
      'modules/application/src/core.cpp', 'modules/document/src/record_registry.cpp',
      'modules/document/src/edit_session.cpp', 'modules/document/src/document_view.cpp',
      'modules/contracts/include/qcae/document_info.hpp', 'modules/contracts/include/qcae/application_types.hpp',
      'modules/contracts/include/qcae/record_store.hpp', 'adapters/storage_sqlite/include/qcae/sqlite_store.hpp',
      'features/geometry/src/geometry_features.cpp', 'features/mesh_generation/src/line_mesh_task.cpp',
      'schemas/entities/entities.json', 'tools/generate_entities.py']
    final = fact(CPP)
    assert before == final
    row = {'kind': '108 final bounded QG02/readability source review; no runtime acceptance claim',
      'reviewed_unix': time.time(), 'author_ready_sha256': EXPECTED, 'candidate_before': before,
      'candidate_after': final, 'candidate_unchanged_during_final_review': True,
      'CMake': fact(ROOT / 'CMakeLists.txt'), 'CMake_scope': 'Only four additive test-target/link/warnings/register lines under QCAE_BUILD_STORAGE && BUILD_TESTING; no timeout/cap/product API/guard change',
      'original_preparation_preserved': fact(HERE / 'preparation-checklist.json'),
      'original_first_read_preserved': fact(HERE / 'first-candidate-review.json'),
      'source_diff': fact(HERE / 'first-to-final-candidate.diff'),
      'CMake_diff': fact(HERE / 'CMake-four-line-registration.diff'),
      'source_diff_added_lines': lines_added, 'source_diff_removed_lines': lines_removed,
      'source_diff_net_lines': 23, 'blocking_source_or_readability_findings': [],
      'resolved_suggestions': [
        {'id': 'SC108-01', 'location': 'tests/schema_rejection_sqlite_tests.cpp:364,383,441',
         'resolution': 'retain actual EntityId from planner; exact two same-Epoch rejected calls return equal IDs, proving failed planning did not consume the local allocation'},
        {'id': 'SC108-02', 'location': 'tests/schema_rejection_sqlite_tests.cpp:466',
         'resolution': 'after each explicit recovery execute using prior WriteContext; require conflict/document_epoch_expired before callback, then all model/current/history/store bytes/generation unchanged'}],
      'exact_eight_cases': [{'case': n, 'error_code': c, 'message': m, 'field': f, 'stage': s} for n,c,m,f,s in cases],
      'expected_case_denominator': 8, 'planned_schema_rejections': 24,
      'planned_extra_expired_epoch_rejections': 8, 'count_scope': 'Original8 categories;3 schema attempts per category;8 extra fencing checks counted separately. All are source assertions, not actual executed outcomes.',
      'entry_path': [
        {'file': 'tests/schema_rejection_sqlite_tests.cpp', 'line': 364, 'behavior': 'public app.execute with current caller/document/epoch/revision/signature/key and planner callback'},
        {'file': 'modules/application/src/core.cpp', 'line': 618, 'behavior': 'single-writer execute; doc/epoch admission; existing idempotency lookup; private prepare'},
        {'file': 'modules/application/src/core.cpp', 'line': 377, 'behavior': 'private allocation counter and candidate; caught RecordError becomes exact failed diagnostic without authority publication'},
        {'file': 'modules/document/src/record_registry.cpp', 'line': 263, 'behavior': 'real encoded record decode/from_input verifies fields/type/unit/version and generated range bounds'},
        {'file': 'modules/document/src/edit_session.cpp', 'line': 67, 'behavior': 'candidate preparation, reference validation via DocumentView::validate'},
        {'file': 'modules/document/src/document_view.cpp', 'line': 157, 'behavior': 'wrong-type/dangling reference errors'},
        {'file': 'adapters/storage_sqlite/include/qcae/sqlite_store.hpp', 'line': 25, 'behavior': 'actual SQLite store owns full durable row images; failed preparation reaches no commit_rows'}],
      'invariants_reviewed': [
        'Actual production line_mesh_task creates11nodes/10beams with geometry/mesh references; complete M33 asserted including fixed physics/organization/analysis/profile',
        'Every rejection and retry compares all DocumentInfo fields, complete canonical record bytes, complete HistorySnapshot entries/cursor/revision, every LoadedRows StoreKey/full string payload and generation',
        'Real redo tail survives:4 transactions,cursor3,revision5; failure cannot truncate branch or change staged Material description',
        'Each callback temporarily allocates and stages a valid local Material edit before bad record; only the two reference cases decode successfully and reject during candidate validation',
        'Exact same-key failures re-enter callback2 times, then3 after recovery; absent action_outcome success fact proves no recorded successful replay',
        'Application destroyed before SQLite handles; reopen exact stored rows/generation; explicit recovery keepsDocId/model/history/revision but changesEpoch; intentional host/epoch metadata excluded only from cross-recovery comparison',
        'Read helper T references remain owned by its DocumentView; synchronous execute captures stack inputs safely; task scope destroyed before rejection loop; saved/full row shared payloads outlive DB handles independently'],
      'readability': 'Clear one-role helpers and visible eight-row table; deterministic staging/state capture/recovery separated; diagnostic failures include actual status/code/message/field. No identified compressed/ambiguous control flow blocker in this bounded review.',
      'limited_review_conclusion': 'No blocking source/readability findings in the final candidate and four-line CMake registration; ready for ROOT actual validation',
      'not_claimed': ['New test compiled or executed', 'New ASan/UBSan result', '8 malformed persistent records via IPC endpoint', 'Full source audited line by line anew', 'All SK03/06/P0 completed'],
      'existing_evidence_scope': '86 full378 and88 fault220+F17x10 remain actual source85 production records without this new test. New test/full regression receipts belong to105 and must be reported separately.',
      'compiler_CTest_guard_engine_GUI_executions': 0, 'source_edits': 0,
      'input_facts': [fact(ROOT / name) for name in inputs],
      'actual_readonly_git_receipt': {'actual_argv': argv, 'actual_exit_code': result.returncode,
        'started_unix': start, 'finished_unix': time.time(), 'stdout_bytes': len(result.stdout),
        'stdout_sha256': hashlib.sha256(result.stdout).hexdigest(), 'stderr': result.stderr.decode()},
      'started_unix': started, 'finished_unix': time.time()}
    write(HERE / 'final-candidate-review.json', row)
    with (HERE / 'final-candidate-review.md').open('x') as stream:
        stream.write('''# Final105 schema test: bounded QG02 review108\n\nNo blocking source/readability findings in final schema_rejection_sqlite_tests.cpp,25505 bytes/502 lines,SHA c77a07559f1ca11ee2412094dab991228d89423c6d2fdae637c9a9deab297892. The final source remained unchanged during this review. CMake adds only four test registration/link/warnings lines under storage and BUILD_TESTING. No production/API/timeout/cap change is implied. Build/runtime/SAN outcomes remain pending ROOT evidence.\n\nEntry is test public RecordApplication::execute(core.cpp618), through private State::prepare(core.cpp377), actual registry encoded-record decode/from_input(record_registry.cpp263), EditSession::prepare(edit_session.cpp67) and candidate reference validation(document_view.cpp157). Six cases reject during decoding; the two bad-reference cases decode and reject the candidate. Exact eight code/message/field expectations match current schema/generated guards. This is in-process production application+SQLite validation, not a claim of raw RecordInput IPC reachability.\n\nThe fixture uses actual production TaskService line meshing and complete33-record M. Real history has four transactions,cursor3,revision5 and one redo item. Before/after each rejection, complete current/model/history and actual SQLite generation/all StoreKey payload bytes match. The candidate first stages a valid Material description and allocates a temporary ID, so atomic failure protects existing local work as well as the bad input. Same-key callbacks re-execute; no success fact is recorded.\n\nThe two first-read suggestions are resolved in the author-ready23-line delta: first and second same-Epoch failed planners must return the same actual allocated ID; each recovery also tests old-context execute rejection as conflict/document_epoch_expired before callback and full-state change. Application/store destruction order releases the old SQLite lease before reopen. Explicit recovery keeps DocId/model/history/revision but changes Epoch; host/epoch metadata is deliberately excluded only across this intentional recovery write. Rejection-time complete row equality remains strict.\n\nThe original denominator stays8 categories:24 schema rejections (three per category) and eight extra old-Epoch checks are separate source assertions. Existing86/88 actual records do not count as execution of this new test. This readonly review ran no compiler/CTest/guard/engine/GUI and made no candidate edits.\n''')
    print(json.dumps({'review': fact(HERE / 'final-candidate-review.json'),
                      'md': fact(HERE / 'final-candidate-review.md'),
                      'candidate': final, 'blocking_findings': [],
                      'compiler_product_executions': 0}))


if __name__ == '__main__':
    main()
