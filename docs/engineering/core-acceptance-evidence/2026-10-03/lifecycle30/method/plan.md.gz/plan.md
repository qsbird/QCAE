# Private complete tool lifecycle30 preparation

SK10 requires the fixed tool lifecycle script30/30; BP13 defines10 ordered steps across cancel and apply. The source85 original line-create30 has no formal pick/leave, and99 proved one complete pair. This104 successor adds30 complete pairs and30 actual production GUI Undo resets on the same engine/window. It retains the original line30 and99 raw unchanged.

1. Copy the sealed99 private methods into new104 paths. Retain actual QVTK viewport picks, StandardKey SelectAll keyboard input with physical Y text1, original30000ms step waits, full M11/10 and complete entity.fields images.
2. Freeze a30-sample/10-step JSON fixture and SHA compiled into the private peer. Keep all original cancel/apply/empty-leave/extra-Apply checks. After each pair trigger the existing production historyUndoAction, restore the complete initial physical model and context except revision, verify13 history prefix+one exact redo, and prove next Apply truncates old redo at cursor13 with a globally unique new transaction.
3. Parse Python AST, format the private C++ with repo .clang-format/formatter21, inspect the method diff, seal minimal inputs and root-only readiness commands. No guard, build, engine, GUI or actual validator execution during preparation.

Actual source85/stock86 and guard88 before/after checks run only when ROOT explicitly schedules build/native. Every actual attempt uses fresh paths, all raw nonzero receipts remain failures, and owned engine cleanup stays literal SIGTERM -15 without force kill. This is bounded lifecycle evidence; other SK10 fields, fullSK/P0, real solver/AI and performance acceptance remain separate.
