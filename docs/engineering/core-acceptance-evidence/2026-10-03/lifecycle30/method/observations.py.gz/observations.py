"""Pure validation of a future actual representative BP13 trace; no product imports."""
from __future__ import annotations

import copy

STEPS = ('cancel.enter', 'cancel.pick', 'cancel.preview', 'cancel.cancel', 'cancel.leave',
         'apply.enter', 'apply.pick', 'apply.preview', 'apply.apply', 'apply.leave')


def need(condition, message):
    if not condition:
        raise ValueError(message)


def revision(row):
    text = row['current']['revision']
    need(isinstance(text, str) and text.isdecimal() and str(int(text)) == text,
         'Exact authoritative decimal revision required')
    return int(text)


def same_model(row, golden):
    need(all(row[key] == golden[key] for key in ('current', 'history', 'model')),
         'Model/context/history changed during a non-writing stage')


def cleared(row):
    need(row['selected_label'] == 'No selection' and row['preview_id'] == '' and
         row['cancel_enabled'] is False, 'Selection/preview/Cancel cleanup missing')
    fields = row['property_fields']
    need(len(fields) == 4 and all(field == {'text': '', 'enabled': False} for field in fields),
         'All four draft fields must be cleared and disabled')


def mouse(row, expected):
    observed = row['actual_input']
    need(observed['picked_ids'] == expected and observed['through'] is False and
         observed['picked_signal_count'] == 1, 'Actual visible mouse pick differs from stable-ID golden')
    pixel = observed['logical_pixel']
    need(isinstance(pixel, list) and len(pixel) == 2 and
         all(type(value) is int and value >= 0 for value in pixel) and
         observed['device_pixel_ratio'] > 0 and
         observed['trigger'] == 'QTest::mouseClick on actual QVTKOpenGLNativeWidget; no emitted/invoked fake signal',
         'Real viewport input facts missing')


def paired_observations(actual, commit, tree, target, settings_root):
    need(actual['kind'] == 'actual-BP13-node-move-lifecycle' and
         actual['source_commit'] == commit and actual['source_tree_sha256'] == tree and
         actual['observation_status'] == 'paired_lifecycle_observed' and actual['actual_exit_code'] == 0,
         'Actual report is failed/incomplete or belongs to another source')
    need(actual['qt_platform'] == 'cocoa' and actual['qt_version'] == '6.11.1' and
         isinstance(actual['process_id'], str) and actual['process_id'].isdecimal() and
         int(actual['process_id']) > 0 and actual['observer_model_writes'] == 0,
         'Native current Qt/PID/read-only observer scope differs')
    isolation = actual['settings_isolation']
    need(isolation == {'format': 'IniFormat', 'user_scope': 'UserScope', 'system_scope': 'SystemScope',
                       'root': settings_root, 'user_file': settings_root + '/QCAE/Desktop.ini',
                       'system_file': settings_root + '/system/QCAE/Desktop.ini',
                       'initial_user_empty': True, 'initial_system_empty': True,
                       'production_default_format_respected': True} and
         actual['settings_file'] == isolation['user_file'],
         'Actual private User/System Ini settings identities differ')
    setup = actual['setup']
    need(setup['node_id'] == target and setup['node_position_mm'] == [500, 0, 0] and
         setup['M_nodes'] == 11 and setup['M_beams'] == 10,
         'Original M/node5 identity or physical fixture differs')
    need(setup['view_isolation'] == 'Existing tree selection + Display/Isolate selected; only selected node remains pickable',
         'Preparatory view-only isolation method missing')
    golden = setup['golden']
    cleared(golden)
    need(target in golden['model'] and golden['model'][target]['kind'] == 'node' and
         golden['model'][target]['fields']['position'] == [500, 0, 0], 'Golden node5 geometry differs')
    need(sum(item['kind'] == 'node' for item in golden['model'].values()) == 11 and
         sum(item['kind'] == 'beam' for item in golden['model'].values()) == 10,
         'Actual model snapshot must retain all original11 nodes/10 beams')
    steps = actual['steps']
    need(len(steps) == 10 and [row['name'] for row in steps] == list(STEPS),
         'Exact original two-branch ordered lifecycle required')
    rows = {row['name']: row['observed'] for row in steps}
    doc_epoch = {key: golden['current'][key] for key in ('document_id', 'document_epoch')}
    for row in [golden, *rows.values(), actual['cancel_leave_apply_noop'], actual['apply_leave_apply_noop']]:
        need(all(row['current'][key] == value for key, value in doc_epoch.items()),
             'Original document/epoch fence differs')
        need(row['pipeline_idle'] is True and row['pipeline_diagnostics']['idle'] is True and
             row['pipeline_diagnostics']['tree_revision'] == row['current']['revision'] and
             row['pipeline_diagnostics']['revision'] == row['current']['revision'],
             'Unchanged public desktop pipeline/display fence did not settle')
        need(row['history']['revision'] == row['current']['revision'], 'History revision differs')
        items = row['history']['items']
        cursor = row['history']['cursor']
        need(type(cursor) is int and 0 <= cursor <= len(items), 'History cursor is outside actual items')
        need(isinstance(items, list) and all(item['transaction_id'] and item['applied'] is (index < cursor)
                                            for index, item in enumerate(items)) and
             len({item['transaction_id'] for item in items}) == len(items),
             'Persistent history is duplicate/incomplete/unapplied')
    for name in STEPS[:8]:
        same_model(rows[name], golden)
    for branch in ('cancel', 'apply'):
        mouse(next(row for row in steps if row['name'] == branch + '.pick'), [target])
        mouse(next(row for row in steps if row['name'] == branch + '.leave'), [])
        picked = rows[branch + '.pick']
        previewed = rows[branch + '.preview']
        need(picked['selected_label'] == target and picked['property_fields'][1]['enabled'] is True,
             'Real selected node must enable its physical Y field')
        need(previewed['selected_label'] == target and isinstance(previewed['preview_id'], str) and
             bool(previewed['preview_id']) and previewed['cancel_enabled'] is True and
             previewed['property_fields'][1] == {'text': '1', 'enabled': True},
             'Actual node.move preview token/physical input differs')
        cleared(rows[branch + '.leave'])
    need(rows['cancel.preview']['preview_id'] != rows['apply.preview']['preview_id'],
         'Separate preview must have a fresh actual admission token')
    need(rows['cancel.cancel']['preview_id'] == '' and rows['cancel.cancel']['cancel_enabled'] is False,
         'Actual Cancel must clear token and disable Cancel')
    cleared(actual['cancel_leave_apply_noop'])
    same_model(actual['cancel_leave_apply_noop'], golden)
    applied = rows['apply.apply']
    need(revision(applied) == revision(golden) + 1 and applied['preview_id'] == '',
         'Actual Apply must commit exactly one revision and consume preview')
    old = golden['history']
    new = applied['history']
    need(new['cursor'] == old['cursor'] + 1 and len(new['items']) == old['cursor'] + 1,
         'Actual Apply must add exactly one persistent transaction')
    old_ids = {item['transaction_id'] for item in old['items']}
    new_items = [item for item in new['items'] if item['transaction_id'] not in old_ids]
    need(len(new_items) == 1 and new['items'][:old['cursor']] == old['items'][:old['cursor']] and
         new['items'][-1] == new_items[0],
         'Exact applied prefix retained, old redo truncated, one new transaction only')
    expected_model = copy.deepcopy(golden['model'])
    expected_model[target]['fields']['position'] = [500, 1, 0]
    need(applied['model'] == expected_model, 'Only node5 physical position may change')
    same_model(rows['apply.leave'], applied)
    cleared(actual['apply_leave_apply_noop'])
    same_model(actual['apply_leave_apply_noop'], applied)
    need(actual['cancel_revision_delta'] == '0' and actual['apply_revision_delta'] == '1',
         'Original BP13 exact0/1 revision deltas required')
    reads = actual['observer_reads']
    need(reads and all(item['operation'] in ('project.current', 'history.list', 'entity.query', 'entity.fields') and
                      item['request_id'] and item['response']['request_id'] == item['request_id'] and
                      item['response']['status'] == 'success' for item in reads),
         'Observer actual request identity/read-only response transcript differs')
    need(actual['leave_binding'] == 'Release node edit by actual blank viewport pick -> empty engine selection -> property draft clear; no dock-hide/close/Escape claim' and
         actual['representative'] == 'Existing node.move property tool; original create-line30 remains separate evidence',
         'Exact bounded representative/leave mapping required')
    return {'representative': 'existing production node.move property tool', 'contract_steps': list(STEPS),
            'cancel_revision_delta': 0, 'apply_revision_delta': 1, 'new_persistent_transactions': 1,
            'actual_transaction_id': new_items[0]['transaction_id'], 'formal_target_viewport_picks': 2,
            'formal_empty_viewport_leaves': 2, 'post_leave_apply_extra_writes': 0,
            'M_population': {'nodes': 11, 'beams': 10}, 'node5': target,
            'after_position_mm': [500, 1, 0], 'all_other_entity_fields_unchanged': True,
            'observer_model_writes': 0, 'leave_scope': 'release by empty selection; dock-close/Escape unmeasured',
            'full_SK_P0': 'unknown'}


def observations(actual, commit, tree, target, settings_root, fixture):
    need(actual['kind'] == 'actual-SK10-BP13-node-move-lifecycle30' and
         actual['observation_status'] == 'complete_lifecycle30_observed' and
         actual['actual_exit_code'] == 0,
         'Future actual complete30 report failed/incomplete')
    need(fixture['samples'] == 30 and fixture['steps_per_sample'] == 10 and
         fixture['steps'] == list(STEPS) and fixture['wait_per_step_ms'] == 30000 and
         len(fixture['runs']) == 30, 'Frozen fixed30/10step/30s fixture differs')
    initial = actual['setup']['golden']
    need(revision(initial) == 13 and initial['history']['cursor'] == 13 and
         len(initial['history']['items']) == 13, 'Full original M must start with13 applied history entries')
    prefix = initial['history']['items']
    seen_transactions = {item['transaction_id'] for item in prefix}
    need(len(seen_transactions) == 13 and all(item['applied'] is True for item in prefix),
         'Initial prefix13 must be complete/unique/applied')
    runs, flattened, comparisons, run_ids = actual['runs'], [], [], set()
    need(len(runs) == actual['passed_samples'] == 30, 'All30 actual full lifecycles required')
    previous = initial
    for index, run in enumerate(runs):
        expected = fixture['runs'][index]
        run_id = expected['run_id']
        need(run['run_id'] == run_id and run_id not in run_ids, 'Fixed actual run ID missing/duplicate')
        run_ids.add(run_id)
        golden = run['golden']
        same_model(golden, previous)
        cleared(golden)
        need(revision(golden) == 13 + 2 * index == int(expected['start_revision']) and
             golden['model'] == initial['model'] and golden['history']['cursor'] == 13 and
             golden['history']['items'][:13] == prefix and
             len(golden['history']['items']) == (13 if index == 0 else 14),
             'Per-run reset/prefix/model/exact2-revision advance differs')
        normalized = dict(golden['current'], revision='13')
        need(normalized == initial['current'], 'Original complete document/epoch/physical context changed')
        need(len(run['steps']) == 10 and all(step['run_id'] == run_id for step in run['steps']),
             'Every complete run must own exact10 formal steps')
        flattened.extend(run['steps'])
        pair = dict(actual, kind='actual-BP13-node-move-lifecycle',
                    observation_status='paired_lifecycle_observed', steps=run['steps'],
                    setup=dict(actual['setup'], golden=golden),
                    cancel_leave_apply_noop=run['cancel_leave_apply_noop'],
                    apply_leave_apply_noop=run['apply_leave_apply_noop'],
                    cancel_revision_delta=run['cancel_revision_delta'],
                    apply_revision_delta=run['apply_revision_delta'])
        comparison = paired_observations(pair, commit, tree, target, settings_root)
        transaction = comparison['actual_transaction_id']
        need(transaction == run['transaction_id'] and transaction not in seen_transactions,
             'New transaction must be globally unique across all30 runs and initial prefix')
        seen_transactions.add(transaction)
        applied = run['steps'][8]['observed']
        need(revision(applied) == int(expected['apply_revision']) and
             applied['history']['items'][:13] == prefix and
             len(applied['history']['items']) == applied['history']['cursor'] == 14,
             'Apply must truncate old redo and keep exactly13prefix+one new item')
        undo = run['undo']
        need(undo['actual_input'] == 'Production historyUndoAction.trigger -> original history.undo handler; observer writes0' and
             undo['revision_delta'] == '1', 'Actual production GUI Undo binding/delta differs')
        restored = undo['observed']
        cleared(restored)
        need(revision(restored) == int(expected['undo_revision']) == 15 + 2 * index and
             restored['model'] == initial['model'] and
             dict(restored['current'], revision='13') == initial['current'],
             'Actual Undo must restore every original entity/context field and exact revision')
        redo = dict(applied['history']['items'][-1], applied=False)
        need(undo['redo_entry'] == redo and restored['history'] ==
             {'cursor': 13, 'items': prefix + [redo], 'revision': str(revision(restored))},
             'Undo full redo entry/prefix/cursor/revision differs')
        need(restored['pipeline_idle'] is True and restored['pipeline_diagnostics']['idle'] is True and
             restored['pipeline_diagnostics']['revision'] == restored['current']['revision'] and
             restored['pipeline_diagnostics']['tree_revision'] == restored['current']['revision'],
             'GUI Undo/display pipeline did not settle')
        comparisons.append(dict(run_id=run_id, start_revision=expected['start_revision'],
                                apply_revision=expected['apply_revision'], undo_revision=expected['undo_revision'],
                                transaction_id=transaction, complete_steps=10,
                                cancel_revision_delta=0, apply_revision_delta=1, undo_revision_delta=1,
                                model_reset_exact=True, prefix13_exact=True, redo_entry_exact=True))
        previous = restored
    need(actual['steps'] == flattened and len(flattened) == 300 and len(run_ids) == 30 and
         len(seen_transactions) == 43, 'Actual formal300/30unique runs/transactions differ')
    need(actual['terminal_reset'] == previous and actual['initial_revision'] == '13' and
         actual['final_revision'] == '73' and revision(previous) == 73 and
         actual['formal_target_viewport_picks'] == 60 and actual['formal_empty_viewport_leaves'] == 60,
         'Actual terminal13->73/60formal picks/60leaves differ')
    return {'kind': 'actual bounded SK10 fixed complete node.move lifecycle30', 'samples': 30,
            'passed_samples': 30, 'formal_ordered_steps': 300, 'formal_target_viewport_picks': 60,
            'formal_empty_viewport_leaves': 60, 'GUI_undo_resets': 30,
            'initial_revision': '13', 'final_revision': '73', 'cancel_revision_delta_each': 0,
            'apply_revision_delta_each': 1, 'undo_revision_delta_each': 1,
            'unique_new_persistent_transactions': 30, 'original_prefix_items': 13,
            'final_history_cursor': 13, 'final_history_items': 14,
            'all_original_entity_fields_restored_each': True, 'post_leave_apply_extra_writes': 0,
            'observer_model_writes': 0, 'same_GUI_process': actual['process_id'],
            'M_population': {'nodes': 11, 'beams': 10}, 'node5': target,
            'after_every_reset_position_mm': [500, 0, 0], 'runs': comparisons,
            'leave_scope': 'release by actual empty selection; dock-close/Escape unmeasured',
            'other_SK10_picking_cases_layout_and_full_SK_P0': 'not inferred from this collector'}
