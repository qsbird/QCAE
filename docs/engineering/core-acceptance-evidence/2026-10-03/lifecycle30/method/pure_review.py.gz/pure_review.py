"""Pure local review only: AST, private formatter, readonly facts/Git, no executable imports."""
from pathlib import Path
import ast
import difflib
import hashlib
import json
import os
import re
import subprocess
import time

HERE = Path(__file__).resolve().parent
OLD = Path('/private/tmp/qcae-framework-BP13-peer99')


def fact(path):
    path = Path(path).resolve()
    return {'path': str(path), 'bytes': path.stat().st_size,
            'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}


def write(name, row):
    with (HERE / name).open('x') as stream:
        json.dump(row, stream, ensure_ascii=False, indent=2)
        stream.write('\n')


def main():
    started = time.time()
    manifest = json.loads((HERE / 'prepared-inputs.json').read_text())
    old_names = ('peer/peer.cpp', 'peer/CMakeLists.txt', 'execute.py', 'native.py',
                 'observations.py', 'prepared-inputs.json', 'immutable-index.json')
    old_paths = [OLD / name for name in old_names] + [
        Path('/private/tmp/qcae-framework-BP13-runtime99/native-02/BP13-node-move-lifecycle.json'),
        Path(manifest['existing_create30']['report_path']),
        Path(manifest['existing_create30']['full_raw_log_path'])]
    old_before = [fact(path) for path in old_paths]
    commands, checks = [], []

    def pure(argv, data=None):
        start = time.time()
        result = subprocess.run(argv, input=data, capture_output=True)
        commands.append({'actual_argv': argv, 'actual_exit_code': result.returncode,
                         'started_unix': start, 'finished_unix': time.time(),
                         'stdout_bytes': len(result.stdout),
                         'stdout_sha256': hashlib.sha256(result.stdout).hexdigest(),
                         'stderr': result.stderr.decode(errors='replace'),
                         'kind': 'pure formatter/readonly Git; no product'})
        assert result.returncode == 0, (argv, result.returncode, result.stderr)
        return result.stdout

    for name in ('execute.py', 'native.py', 'observations.py', 'pure_review.py'):
        ast.parse((HERE / name).read_text(), filename=str(HERE / name))
        checks.append({'Python_AST': name, 'result': 'parsed without import'})
    fixture = json.loads((HERE / 'fixed-lifecycle30.json').read_text())
    assert fixture['samples'] == len(fixture['runs']) == 30
    assert len(fixture['steps']) == 10 and fixture['final_revision'] == '73'
    assert len({row['run_id'] for row in fixture['runs']}) == 30
    formatter = '/Library/Developer/CommandLineTools/usr/bin/clang-format'
    assert b'clang-format version 21.' in pure([formatter, '--version'])
    pure([formatter, '--dry-run', '--Werror', str(HERE / 'peer/peer.cpp')])
    reference = pure([formatter, '--assume-filename=' + str(HERE / 'peer/peer.cpp')],
                     (OLD / 'peer/peer.cpp').read_bytes()).decode()
    source = (HERE / 'peer/peer.cpp').read_text()
    assert reference.split('namespace {', 1)[1].split('int main(', 1)[0] == \
        source.split('namespace {', 1)[1].split('int main(', 1)[0]
    assert 'elapsed.elapsed() < 30000' in source
    assert 'QKeySequence(QKeySequence::SelectAll)' in source
    assert 'QTest::keyClicks(&field, "1")' in source
    assert 'setText(' not in source and 'selectAll(' not in source
    # Original real picker/helper body is exactly unchanged; diagnostic strings may say "emit".
    checks.append({'CPP_original_helpers': 'byte-identical after formatter normalization',
                   'real_QVTK_pick_StandardKey_text1_wait30000': True})
    old_native, native = (OLD / 'native.py').read_text(), (HERE / 'native.py').read_text()
    start_marker, end_marker = '            finally:\n                if process is not None:', '    engine_images ='
    assert old_native[old_native.index(start_marker):old_native.index(end_marker)] == \
        native[native.index(start_marker):native.index(end_marker)]
    checks.append({'owned_engine_cleanup': 'original99 finally/reap/no-kill/literal -15 byte-identical'})
    assert 'old_cursor + 1' in source
    assert 'old_history.value("items").toArray().size() + 1' not in source
    assert 'for (int sample = 0; sample < 30; ++sample)' in source
    assert 'historyUndoAction' in source
    assert '"golden", initial_golden' in source
    assert manifest['fixed_script_fixture']['sha256'] in (HERE / 'peer/CMakeLists.txt').read_text()
    assert manifest['fixed_script_fixture'] == fact(HERE / 'fixed-lifecycle30.json')
    root = manifest['source_root']
    head = pure(['git', '-C', root, 'rev-parse', 'HEAD']).decode().strip()
    status = pure(['git', '-C', root, 'status', '--porcelain=v1']).decode()
    assert head == manifest['source_commit'] and not status
    assert manifest['configured_tool_and_sdk_pins'] == \
        json.loads((OLD / 'prepared-inputs.json').read_text())['configured_tool_and_sdk_pins']
    byte_diff, method_diff = [], []
    for name in ('peer/peer.cpp', 'peer/CMakeLists.txt', 'execute.py', 'native.py', 'observations.py'):
        before, after = (OLD / name).read_text(), (HERE / name).read_text()
        byte_diff.extend(difflib.unified_diff(before.splitlines(True), after.splitlines(True),
                                             fromfile='sealed99/' + name, tofile='prepared104/' + name))
        method_before = reference if name == 'peer/peer.cpp' else before
        method_diff.extend(difflib.unified_diff(method_before.splitlines(True), after.splitlines(True),
                                               fromfile='sealed99-format-normalized/' + name,
                                               tofile='prepared104/' + name))
    (HERE / '99-to104-byte.diff').write_text(''.join(byte_diff))
    (HERE / '99-to104-method.diff').write_text(''.join(method_diff))
    old_after = [fact(path) for path in old_paths]
    assert old_before == old_after
    write('old-inputs-preservation.json', {'before': old_before, 'after': old_after,
          'before_after_equal': True, 'meaning': 'Read/hash only; old actual observations do not count as104'})
    write('pure-review.json', {'kind': 'Actual pure AST/formatter/static method review only',
          'actual_pure_exit_code': 0, 'pid': os.getpid(), 'started_unix': started,
          'finished_unix': time.time(), 'commands': commands, 'checks': checks,
          'source_root': root, 'source_commit': head, 'source410_sha256': manifest['source410_sha256'],
          'source_clean': True, 'source_verification_scope': 'Frozen85 fact pinned; complete410/build/SDK guard only in future ROOT execution',
          'configured_tool_and_sdk_pins_unchanged99': True, 'old_method_and_raw_unchanged': True,
          'guard_build_engine_GUI_executions': 0,
          'actual_guard_exit': None, 'actual_build_exit': None, 'actual_native_exit': None,
          'risks_pending_actual': ['Private CPP not compiled',
            'Repeated isolation/actual target pick after GUI Undo/render refresh needs execution',
            'Complete model/current equality after every GUI Undo needs actual execution'],
          'full_SK10_picking12_layout_fullSK_P0': 'Not inferred',
          'preserved_pure_failure': 'Attempt01 lexical scan rejected original diagnostic string containing emit; false-positive pure check, not product execution'})
    print(json.dumps({'actual_pure_exit_code': 0, 'guard_build_engine_GUI_executions': 0,
                      'review': fact(HERE / 'pure-review.json')}))


if __name__ == '__main__':
    main()
