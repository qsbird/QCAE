# SK10 complete tool lifecycle30 private successor104

Prepared against immutable source85 `ef0df3bdd8c1b27330d71a596f16098cb6b6410a` / source410 `15d20f20fef88ed6d1b8637b97edf77143887728cb9c42427620b25429e65c03`, using stock86 tools/SDK and unchanged sealed88 guard/command methods. Product and99 inputs were read only.

The fixed script has30 samples, each the original10 ordered cancel.enter/pick/preview/cancel/leave and apply.enter/pick/preview/apply/leave steps, followed by a separate actual GUI `historyUndoAction` reset. Actual picks use QVTK mouse input; actual Y input uses StandardKey SelectAll then keyboard text1; all step waits stay30000ms. Preparatory tree isolation is separate from the60 formal target picks and60 empty leaves. The complete M11nodes/10beams and every entity.fields image are compared, not reduced to the node count.

Each cancel and empty-leave extra Apply writes0; each formal Apply revision+1 and one globally unique TransactionID. Each GUI Undo revision+1 restores the initial physical model/current except revision. The initial13 complete history entries stay exact. With a prior redo item, the next Apply retains prefix through cursor13 and truncates that redo, then appends one fresh complete item; Undo leaves that same item as the sole redo with applied=false. Final revision must be73, with cursor13 and14 items.

`99-to104-method.diff` compares old C++ normalized in memory with the same existing formatter21, plus exact Python/CMake differences. `99-to104-byte.diff` is the raw original-byte diff. The original helper bodies and native owned-process cleanup, including literal engine -15 without force kill, compare byte equal. No API/CMake/product/ledger/cap changes or new dependencies.

The fixed JSON SHA is compiled into the private peer, supplied explicitly by wrapper, reported at runtime, and checked again by the pure actual-observation validator. The immutable input index binds all new executable methods; root must pass its explicit SHA from `delivery.json`.

Root readiness (planned only, NOT RUN here):

1. Invoke pinned Python on `execute.py build --input-index-sha256 <delivery.index_sha256> --attempt 01`. This uses new `/private/tmp/qcae-tool-lifecycle30-builds104/peer-01` and runtime `/private/tmp/qcae-tool-lifecycle30-runtime104/build-01`. Original all7 full86/source410/stock SDK guards apply before/after.
2. After actual build0, invoke the same Python on `execute.py native --input-index-sha256 <delivery.index_sha256> --peer-build-attempt /private/tmp/qcae-tool-lifecycle30-runtime104/build-01 --attempt 01`. This creates one fresh durable engine/workspace, one actual GUI process, and30 complete runs. Every command has actual argv/PID/start/end/exit/stdout/stderr facts; nonzero raw is kept and stops. New attempts require unused IDs and directories.

Actual build, guard, engine and GUI execution counts during preparation:0. Actual CPP behavior and repeat picking/Undo remain unverified pending ROOT execution. Original line30 and99 one-pair raw are separate immutable evidence; they do not supply104 passes. This collector covers the fixed lifecycle slice only; picking12, layout, performance, real solver/AI and full SK/P0 completion remain outside this result.
