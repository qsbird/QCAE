#!/usr/bin/env python3
"""Commit only the frozen, executed lookup slice and fast-forward its workspace."""
import hashlib
import json
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).resolve().parent
SOURCE = Path('/private/tmp/qcae-framework-delivery80')
MAIN = Path('/Users/qs/Documents/ChatGPT/QCAE')
MATRIX = Path('/private/tmp/qcae-lookup187-regression/attempt-01')
BASE = 'a15159d58f13b68d1f6b477e99477c8b9496ad2a'
AGENTS = 'eaa469194e6952cc8e7a73859f8023216379fa65085ccd8bfd7efc075fe9eaa9'
FILES = ['adapters/engine_api/src/ipc_api.cpp', 'apps/mcp/bridge.py',
         'schemas/operations/operation_lookup.json', 'tests/host_controls_ipc_tests.py',
         'tests/mcp_bridge_tests.py', 'tests/mcp_protocol_tests.py', 'tests/typed_host_tests.cpp']


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(cwd, *args):
    return subprocess.check_output(['git', *args], cwd=cwd, text=True)


def dump(path, value):
    with path.open('x') as output:
        json.dump(value, output, indent=2)
        output.write('\n')


def command(name, cwd, argv):
    start = time.time()
    result = subprocess.run(argv, cwd=cwd, capture_output=True, text=True)
    (ROOT / (name + '.stdout.log')).write_text(result.stdout)
    (ROOT / (name + '.stderr.log')).write_text(result.stderr)
    dump(ROOT / (name + '.json'), {'argv': argv, 'cwd': str(cwd),
         'actual_exit_code': result.returncode, 'started_unix': start,
         'elapsed_seconds': time.time() - start})
    print(json.dumps({'command': name, 'actual_exit_code': result.returncode}), flush=True)
    assert result.returncode == 0


candidate = json.loads((MATRIX / 'candidate.json').read_text())
completed = json.loads((MATRIX / 'complete.json').read_text())
assert completed['actual_exit_code'] == 0 and completed['total_test_executions'] == 261
inputs = candidate['candidate_files']
assert len(inputs) == 421 and all(sha(SOURCE / name) == digest for name, digest in inputs.items())
review = json.loads(Path('/private/tmp/qcae-lookup186-review/review.json').read_text())
assert not review['unresolved_blockers']
assert review['final_source_sha256'] == {name: inputs[name] for name in FILES}
assert read(SOURCE, 'rev-parse', 'HEAD').strip() == BASE
assert read(MAIN, 'rev-parse', 'HEAD').strip() == BASE
assert read(MAIN, 'status', '--porcelain') == ' M AGENTS.md\n'
assert sha(MAIN / 'AGENTS.md') == AGENTS
assert not read(SOURCE, 'diff', '--cached', '--name-only')
actual = {line[3:] for line in read(SOURCE, 'status', '--porcelain').splitlines()}
assert actual == set(FILES), actual
manifest = MAIN / 'out/local-delivery138-02/QCAE-manifest.json'
manifest_sha = sha(manifest)
assert manifest_sha == '8d5fdd2df0a77aefa4fdc06ef53ae6ceb2155e65c1065745792efc787920af64'
message = '''Complete conditional outcome lookup contracts through the existing authority

operations.get had retained host/document facts but no installed input version or
truthful conditional context discovery. Generate its semantic string DTO, project
only ignored raw mode values away, and publish bounded parameter/argument unions.
MCP validates and forwards the complete engine schema without decoding business
inputs. Preserve caller namespaces, retained facts, and existing response envelopes.

Constraint: One RecordApplication remains authoritative; no registry, Value, generator, storage, application, dependency or performance change.
Rejected: Tightening ignored JSON modes or making host lookup require a document would break existing requests.
Directive: Core framework quality and speed first; keep measured budgets and all previously open acceptance gates.
Tested: Five frozen configurations 40/55/87/78/1, 261 actual CTest executions passed; strict C++20 and zero compiler warnings.
Tested: Five existing baseline cases passed before the slice; actual SQLite ON/OFF state/recovery and two-MCP/CLI lookup scenarios passed.
Tested: Design, clang-format21, diff checks; independent QG-02 source review.
Not-tested: Current GUI cumulative gate, LSan, refreshed local bundle, real solver/full external AI/performance/full SK or P0 acceptance.
Confidence: High within executed non-graphical scope; source and product hashes retained.
Scope-risk: Low; generated adapter input and discovery preserve existing application calls and output return paths.
'''
(ROOT / 'message.txt').write_text(message)
command('stage', SOURCE, ['git', 'add', '--', *FILES])
assert set(read(SOURCE, 'diff', '--cached', '--name-only').splitlines()) == set(FILES)
command('commit', SOURCE, ['git', 'commit', '--file', str(ROOT / 'message.txt')])
head = read(SOURCE, 'rev-parse', 'HEAD').strip()
assert not read(SOURCE, 'status', '--porcelain')
assert all(sha(SOURCE / name) == digest for name, digest in inputs.items())
command('main-fast-forward', MAIN, ['git', 'merge', '--ff-only', head])
assert read(MAIN, 'rev-parse', 'HEAD').strip() == head
assert read(MAIN, 'status', '--porcelain') == ' M AGENTS.md\n'
assert sha(MAIN / 'AGENTS.md') == AGENTS and sha(manifest) == manifest_sha
assert all(sha(MAIN / name) == digest for name, digest in inputs.items())
dump(ROOT / 'complete.json', {'implementation_commit': head, 'committed_files': FILES,
     'actual_ctest_passed': 261, 'main_private_compiled_source_equal': True,
     'unknown_AGENTS_preserved': AGENTS, 'old_bundle_manifest_unchanged': manifest_sha})
print(json.dumps({'implementation_commit': head, 'main_fast_forwarded': True}), flush=True)
