# operations.get cross-file static review186

**QG-02 static conclusion: no unresolved blockers in the final reviewed source after two test defects were fixed before execution.** Root confirmed all seven source files frozen after formatting the two C++ files. The observed C++ hashes below match root's final freeze. This review focuses independently on the MCP and root-owned test changes; the reviewer authored the earlier lookup schema/IPC product and does not claim independent runtime validation of that work.

## Findings corrected before execution

1. **REVIEW186-01 — test variable pollution.** The newly added lookup refusal loop reused the function-local `parameters`, overwriting the real preview_id arguments later passed to changes.commit replay. Final `tests/host_controls_ipc_tests.py:178` uses `lookup_parameters`; the earlier preview/commit binding and the later replay call remain intact. Root made this correction before starting execution.
2. **REVIEW186-02 — lifecycle mismatch.** The new saved-project normal-open continuation followed keep_recovery close. Existing `RecordApplication::close_document` retains `Data.document` for that policy, while ordinary open refuses any retained document; the planned test would necessarily receive DOCUMENT_ALREADY_OPEN. Final `tests/host_controls_ipc_tests.py:314` uses discard before normal-open at327. The earlier independent-process recovery remains. Root corrected the test rather than changing application semantics, before execution.

No source file was edited by this review task. No unresolved static blocker remains.

## MCP metadata and invocation authority

`apps/mcp/bridge.py:134,199` uses the existing bounded metadata subset to validate an optional complete arguments_schema. The schema must be a closed root object; every schema node stays within the existing supported keywords/types, depth16 and128-node bounds. The new branch also requires recognized QCAE root argument names, an explicit parameters_schema and structural equality between that schema and the root parameters property. It returns the supplied complete schema unchanged. Tools without the key retain their existing generic tool_schema path. Discovery validates all candidates before assigning `self.catalog`, so failure does not install partly validated contracts.

The operations.get descriptor supplies a closed three-way raw parameter union and a closed two-way context union. Host-open accepts only omitted/normal/recover mode; other host and document modes remain `{}` and therefore accept ignored arbitrary JSON. Host needs parameters only, allowing ignored optional document identity/context JSON. Document also needs nonempty document_id/document_epoch. Unused revision/top-level key are `{}`; requested_version stays optional positive uint32; expected_profile is excluded. The root parameters property is precisely parameters_schema. Static source accounting gives20 parameter-schema nodes,48 argument-schema nodes and maximum depth3, comfortably within the advertised validator bounds; this is source accounting, not a run result.

Invocation remains `Bridge.invoke` → `Engine.call`: outer argument names/object shape and parameters-object shape are checked, while business parameter values/context/version are forwarded to the authoritative engine. No operations.get literal, mode parser or discriminator logic was added to MCP. The compatibility adapter validates old raw field/scope/host-name/used-mode/key checks before generated semantic decoding and strips ignored original_mode only; null never needs to enter Value. Version refusal precedes outcome services. Existing envelope/expected_profile precedence stays earlier; selection/model dispatch return without service calls for this operation.

## Tests and lifecycle consistency

`tests/mcp_protocol_tests.py:25,46` supplies valid complete schemas and malformed root properties/closure/requirements/depth/nodes/parameter equality/keywords. The fake peer checks exact schema/capability metadata pass-through and raw argument values, including nested null and ignored outer context. Those scenarios establish metadata/transport behavior only: their peer has no application model or SQLite authority.

`tests/mcp_bridge_tests.py:110,169,194` extends the same real-engine fixture shared by two MCP clients and CLI. Discovery checks actual symbolic labels, raw union, conditional context and exact schema pass-through. Lookup comparisons include complete omit/v1 envelopes except request_id, direct-return versus mapped-history revision presence, ignored raw mode/context/key values and used-mode/version/context refusals. Existing action/history receipts plus one shared preview commit and undo/redo populate retained facts; after ending clients, reconnecting clients query host create/close facts without an active document. This fixture's state comparisons cover current/status/model/history, not complete SQLite rows.

`tests/host_controls_ipc_tests.py` explicitly opens the production SQLite workspace. It retains one populated saved model, full logical SQLite row snapshots including generation/payloads, document metadata and history around refusal/read/replay batches. Recovery uses a second process and the same workspace, preserves document ID/revision/history/records and assigns a new epoch; stale context refusals stay separate. Corrected discard close clears the retained document before ordinary open, which receives fresh document ID/epoch and the saved entity set. Lookup does not change current/saved/dirty state, cursor, rows or operation facts. The close-after-recovery host lookup uses only raw SQLite rows after no active document remains, avoiding an invalid current-document snapshot.

Production engine (`apps/engine/engine_host.cpp:270`) supplies trusted Caller `local-user` to both MCP clients and CLI. They do **not** prove different-principal isolation. `tests/typed_host_tests.cpp` separately passes explicit different trusted callers to host/mapped-action lookup. Its `retained_outcome_without_handler` at2005 uses a reduced TypedHost without the contributor, verifies refusal of new invocation, and queries retained outcomes with omitted/v1, ignored JSON mode, stale scope refusals and undo/redo; the handler is never reinstalled. These are source-reviewed scenarios awaiting root results.

The product's host/arbitrary-action calls keep their direct result_json return; mapped commit/undo/redo still pass through outer current-revision insertion. Host and document namespace mapping, caller scoping and retained-fact application authority remain unchanged. Ordinary open's existing history/operation reset is not replaced by fault recovery's retention semantics. Old C++ key/context argument evaluation did not define a portable priority when both were malformed; no such priority is claimed.

## Frozen source hashes

| Source | SHA256 |
|---|---|
| `schemas/operations/operation_lookup.json` | `1bb29046685907b3d1fb694875ca3a2c4766b7ba3cf2ba1bfdcd6f8fe1198ee7` |
| `adapters/engine_api/src/ipc_api.cpp` | `252409df3721da662b9585cae8b1657b0f296ebaf5435c8312e96dcfdc657e25` |
| `apps/mcp/bridge.py` | `6b3f94d2605b4aae81b3bc4c6e84e61262401a8532ba1631e70de426ff6da257` |
| `tests/mcp_protocol_tests.py` | `75e0a948dd43e8a31743111edf39844e8fa0ff71a6fd56655e8ebb7710d13aed` |
| `tests/mcp_bridge_tests.py` | `920799449a187200cdc84f99dbe9a58371c1e65e88bb7f32acccc623704d7041` |
| `tests/typed_host_tests.cpp` | `ac21252f9fab87799c4b9cdcfded1a9e362a41fd4e2c5a418ea1db75c9de7000` |
| `tests/host_controls_ipc_tests.py` | `b8c48aa2be4a55d09db006398014c42d0ee722b8a9b76a3361119204becb838d` |

## Execution and acceptance boundary

This worker ran **NO generator, compiler, check, test, product or Git command during review186**. Source/doc reads and SHA256 inspection only; the two review files are the only writes and are outside the checkout. Root owns the actual five-configuration matrix and required gates; its execution had been announced but no result is attested here. QG-02 static review is recorded; QG-01/QG-03, freshness and runtime acceptance remain dependent on root's actual evidence. No complete REQ-16/SK-04/P0 or graphical/solver/AI/performance acceptance is claimed.
