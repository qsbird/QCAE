# operations.get source product 182

Status: **SOURCE FROZEN — STATIC REVIEW ONLY**. Based on plan177 in `/private/tmp/qcae-operations-get177-plan/plan.md` and observed starting HEAD `a15159d58f13b68d1f6b477e99477c8b9496ad2a` in `/private/tmp/qcae-framework-delivery80`. This worker edited only the new lookup schema and `ipc_api.cpp`. The primary workspace was not touched.

## Source hashes

| Owned source | SHA256 |
|---|---|
| `schemas/operations/operation_lookup.json` | `1bb29046685907b3d1fb694875ca3a2c4766b7ba3cf2ba1bfdcd6f8fe1198ee7` |
| `adapters/engine_api/src/ipc_api.cpp` | `4c79c887ebae253118c19f4908e566fe6024c9b10f85d92e7b6ce7a15e33d327` |

## Contract and metadata

The generated definition is `OperationsGetInput`, operations.get version1/schema `qcae.operation.operations.get.v1`, read_only, with all five unconditional context flags false. Stable fields1–3 are required nonempty lookup_scope/original_operation/idempotency_key strings; field4 original_mode is an optional nonempty semantic string. The local adapter validates the old field/scope/known-host-operation/used-mode/key conditions before generated decoding, retains mode only for host project.open and projects ignored mode away. Ignored arbitrary JSON, including null and nested null, never enters Value.

Discovery retains symbolic types/effect/scope/availability and unconditional flags. It adds installed-version metadata and the generated input label. Raw original_mode advertises json_value with the host-open condition in its description; the inapplicable allow_empty string flag is omitted. Existing result serializers are described by wire_output_types [DocumentInfo, ChangeReceipt] and output_by_lookup_scope. The singular wire_output_type is removed.

parameters_schema is a closed root with three required common nonempty strings and optional original_mode {}. Three disjoint closed oneOf branches select host-open, other-host lifecycle and document. Host-open restricts optional mode to normal/recover; other-host and document keep {}. Document original_operation stays unrestricted nonempty and does not consult handler availability.

arguments_schema is a complete closed object with exactly parameters/document_id/document_epoch/expected_revision/idempotency_key/requested_version. Its root requires parameters; that property equals parameters_schema. Closed host/document branches repeat recognized names and narrow parameters.lookup_scope. Host requires parameters only and leaves optional document identities {}; document also requires the two nonempty string identities. Optional revision/top-level key remain {}. requested_version is an optional integer1–4294967295; expected_profile is absent. No unsupported schema keyword was added. Static source accounting estimates20 parameter schema nodes,48 argument schema nodes and maximum schema depth3; runtime validation belongs to root.

## Readability and behavior review

The authority path remains dispatch envelope checks → installed version admission/refusal → compatibility projection → generated InputTraits decoder → existing host/mapped-document/arbitrary-action outcome application calls → unchanged serializers. All lookup paths remain reads of retained caller-scoped facts. This slice introduces no application/history/store/core mutation path, registry handler or handler-availability requirement. Host service mappings remain create/open/recover/save/close; document mappings remain commit/undo/redo, with arbitrary contributed actions still sent to RecordApplication.action_outcome.

Allowed-field/scope/host-name/open-mode errors keep the previous message and lack of field tag; independent key and document-context errors remain unchanged. Version refusal precedes lookup input checks and services; envelope/API/operation/parameters-object and expected_profile checks stay earlier. Key is validated before semantic decoding. Old relative evaluation of DocumentRef and key arguments was unspecified; no portable priority is claimed for simultaneously malformed context and key.

Host and arbitrary action lookup return result_json directly. Mapped commit/undo/redo keep the final outer revision insertion. No new output union serializer or generated output schema is claimed. Existing retained outcomes can still be queried with an unavailable contributor.

## Execution boundary

Generation/freshness, compiler/builds, tests, design/format/diff checks, products and Git mutations: **NOT RUN** by this worker. Root owns all execution. The new DTO references require root generation before compilation. QG-02 static review is recorded above; QG-01 and QG-03 remain unverified pending root checks and regression results. No complete REQ-16/SK-04/P0 acceptance or graphical/solver/AI/performance closure is claimed.
