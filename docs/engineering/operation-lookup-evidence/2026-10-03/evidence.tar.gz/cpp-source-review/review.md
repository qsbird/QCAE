# operations.get typed-host tests — worker 184

Status: source frozen for root formatting and integration. Only `tests/typed_host_tests.cpp` was edited in `/private/tmp/qcae-framework-delivery80`; observed starting HEAD was `a15159d58f13b68d1f6b477e99477c8b9496ad2a`. This is static review evidence, not a test result.

The lookup assertions reuse `OpenContractStore`, `project_open_contract_and_lifecycle`, `host_read_and_history_contracts` and `retained_outcome_without_handler`. A shared dispatch helper round-trips raw JSON and compares the complete observed lifecycle/store state and active `DocumentView` before and after every successful or rejected lookup. This covers saved/dirty metadata, history/cursor, persisted rows and retained facts, project payloads, generation, commits, publications and project reads. The store is a fake persisting actual application rows; this worker does not claim SQLite I/O evidence.

The grouped descriptor check covers the generated four-string semantic DTO, all unconditional context flags false, installed v1 policy, symbolic labels, scope-specific output labels, four raw field descriptors, the three closed raw parameter branches and the two conditional argument branches. Generated `to_value`/decoder assertions concern semantic projected strings only; they do not claim ignored raw JSON/null roundtrip through `Value`.

The populated history scenario compares complete mapped commit/undo/redo lookup envelopes, including the existing outer current revision, after undo and redo. It checks omitted/v1, all irrelevant mode JSON types including empty values and nested null, ignored write revision/top-level key, missing context, old document/epoch, caller scope and unrecorded keys. The scenario adds save-as and close once, then checks create/save/save-as/close facts without an active document. Existing normal-open/recovery fixtures supply host-open facts, omitted normal defaults, explicit normal/recover and namespace-specific refusal. The version/error table rejects malformed/future versions before bad branch/mode/key/context/extra fields while preserving earlier parameter-object and expected-profile rejection. Existing raw input diagnostics retain exact complete envelopes. It does not assert a portable priority for simultaneous malformed context/key function arguments.

The retained contributor fixture now uses `OpenContractStore`. Its reduced host never registers the removed contributor. Complete direct-return receipts omit an outer revision and remain readable with omitted/v1, ignored modes, caller/document/epoch protections and subsequent undo/redo. Unknown action names return retained-fact refusal independently of handler availability. Obsolete `operations.get` v1 refusal expectations were replaced by the unchanged legacy `changes.preview` version rejection or the exact new lookup contract.

QG-02 static review: IPC is the boundary under test; `MemoryApplication`/`RecordApplication` retain outcome and history authority; the fake store records persistence effects. Helpers centralize state preservation and version equivalence, while existing scenarios own lifecycle/history mutations. No production implementation, application/registry/Value/TypedHost interface, generator, CMake or dependency changes were made by this worker.

Execution boundaries: generation/freshness, compiler/builds, formatter, design/format/diff checks, tests/CTest, products and Git mutations were **NOT RUN** by this worker. Read-only Git status, HEAD and owned-file diff inspection were performed. Root owns formatting and all integration execution. Full REQ-16/SK-04/P0, SQLite IPC/MCP execution, real solver/AI, graphics and performance acceptance are not claimed.

Frozen source hashes before root formatting:

| Path | SHA256 |
|---|---|
| `tests/typed_host_tests.cpp` | `942cca05a922c680aba84b442192933c4167f52c26205cc99bdb281ed7d20845` |
| `adapters/engine_api/src/ipc_api.cpp` inspected product | `4c79c887ebae253118c19f4908e566fe6024c9b10f85d92e7b6ce7a15e33d327` |
| `schemas/operations/operation_lookup.json` inspected product | `1bb29046685907b3d1fb694875ca3a2c4766b7ba3cf2ba1bfdcd6f8fe1198ee7` |
| `/private/tmp/qcae-operations-get177-plan/plan.md` | `a7378c497ed69a3ccc5fe540740ee98e4e63403a4af32b7aea8985117926ab33` |
| `/private/tmp/qcae-operations-get177-plan/plan.json` | `51bacce8492708649e409334fdac397df4350ab450e2fc75192176002b57a530` |
