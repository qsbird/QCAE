#!/usr/bin/env python3
"""Archive actual lookup results and update current documentation without rewriting old evidence."""
import copy
import datetime
import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

SOURCE = Path('/private/tmp/qcae-framework-delivery80')
MAIN = Path('/Users/qs/Documents/ChatGPT/QCAE')
ROOT = Path(__file__).resolve().parent
MATRIX = Path('/private/tmp/qcae-lookup187-regression')
BUILD = Path('/private/tmp/qcae-lookup187-builds')
COMMIT = Path('/private/tmp/qcae-lookup189-commit')
DEST = SOURCE / 'docs/engineering/operation-lookup-evidence/2026-10-03'
REPORT = SOURCE / 'docs/engineering/operation-lookup-contract-2026-10-03.md'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def fact(path):
    return {'bytes': path.stat().st_size, 'sha256': sha(path)}


def dump(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def insert(path, marker, text):
    previous = path.read_text()
    assert previous.count(marker) == 1, (path, marker)
    path.write_text(previous.replace(marker, text + '\n\n' + marker))


assert not DEST.exists() and not REPORT.exists()
candidate = json.loads((MATRIX / 'attempt-01/candidate.json').read_text())
completed = json.loads((MATRIX / 'attempt-01/complete.json').read_text())
head = json.loads((COMMIT / 'complete.json').read_text())['implementation_commit']
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=SOURCE, text=True).strip() == head
assert completed['actual_exit_code'] == 0 and completed['total_test_executions'] == 261
inputs = candidate['candidate_files']
assert len(inputs) == 421 and all(sha(SOURCE / name) == digest and sha(MAIN / name) == digest
                                 for name, digest in inputs.items())
assert sha(MAIN / 'AGENTS.md') == 'eaa469194e6952cc8e7a73859f8023216379fa65085ccd8bfd7efc075fe9eaa9'
DEST.mkdir(parents=True)
dump(ROOT / 'freeze.json', {'implementation_commit': head, 'source_files': inputs,
     'source_files_count': len(inputs), 'source_dictionary_sha256': candidate['source_dictionary_sha256'],
     'source_hash_algorithm': 'canonical sorted relative-path to file-SHA256 JSON; not C4-source-v1',
     'main_private_compiled_source_equal': True})
products = {}
for configuration in ('core', 'local', 'sqlite-on', 'sqlite-off', 'sanitized'):
    for name in ('qcae_typed_host_tests', 'qcae-engine', 'qcae-cli', 'qcae-mcp', 'qcae_mcp_bridge.py'):
        path = BUILD / configuration / name
        if path.is_file():
            products[str(path)] = fact(path)
dump(ROOT / 'tested-products.json', products)
members = {}


def add_tree(prefix, directory):
    assert directory.exists(), directory
    for path in sorted(directory.rglob('*')):
        if path.is_file():
            assert path.suffix in {'.py', '.json', '.md', '.txt', '.log', '.cpp', '.hpp'}, path
            name = str(Path(prefix) / path.relative_to(directory))
            assert name not in members
            members[name] = path


for prefix, directory in (
        ('matrix', MATRIX), ('baseline', Path('/private/tmp/qcae-lookup185-baseline')),
        ('implementation-commit', COMMIT), ('product-source-review', Path('/private/tmp/qcae-lookup182-product')),
        ('mcp-source-review', Path('/private/tmp/qcae-lookup183-mcp')),
        ('cpp-source-review', Path('/private/tmp/qcae-lookup184-cpp')),
        ('final-independent-source-review', Path('/private/tmp/qcae-lookup186-review'))):
    add_tree(prefix, directory)
for configuration in ('sqlite-on', 'sqlite-off'):
    add_tree('actual-sqlite/' + configuration, BUILD / configuration / 'host-controls-evidence')
for name in ('freeze.json', 'tested-products.json'):
    members[name] = ROOT / name
members['archive-method.py'] = Path(__file__)
index = {name: {'origin': str(path), **fact(path)} for name, path in sorted(members.items())}
archive = DEST / 'evidence.tar.gz'
with archive.open('xb') as raw, gzip.GzipFile(fileobj=raw, mode='wb', mtime=0) as compressed:
    with tarfile.open(fileobj=compressed, mode='w') as tar:
        for name, path in sorted(members.items()):
            data = path.read_bytes()
            info = tarfile.TarInfo(name)
            info.size, info.mode, info.mtime = len(data), 0o644, 0
            tar.addfile(info, io.BytesIO(data))
with tarfile.open(archive, 'r:gz') as tar:
    assert set(tar.getnames()) == set(index)
    for name, record in index.items():
        data = tar.extractfile(name).read()
        assert len(data) == record['bytes'] and hashlib.sha256(data).hexdigest() == record['sha256']
        assert fact(members[name]) == {key: record[key] for key in ('bytes', 'sha256')}
dump(DEST / 'archive-index.json', {'member_count': len(index), 'archive': fact(archive), 'members': index})
sqlite = {}
for configuration in ('sqlite-on', 'sqlite-off'):
    paths = list((BUILD / configuration / 'host-controls-evidence').glob('run-*/observations.json'))
    assert len(paths) == 1
    observations = json.loads(paths[0].read_text())
    counts = {name: len(observations[name]) for name in
              ('lookup_reads', 'lookup_refusals', 'refusals', 'reads', 'history_writes', 'replays')}
    assert counts == {'lookup_reads': 35, 'lookup_refusals': 31, 'refusals': 101,
                      'reads': 5, 'history_writes': 8, 'replays': 6}, counts
    assert observations['engine_exit_codes'] == [-15, -15]
    sqlite[configuration] = {**counts, 'engine_exit_codes': observations['engine_exit_codes'],
        'logical_rows_document_history_generation_preserved_by_lookup': True,
        'independent_recovery_preserves_original_facts': True,
        'discard_then_normal_open_fresh_document_identity': True}
review = json.loads(Path('/private/tmp/qcae-lookup186-review/review.json').read_text())
assert not review['unresolved_blockers']
validation = {'schema_version': 1, 'status': 'bounded_lookup_contract_validated_graphical_and_full_acceptance_open',
    'implementation_commit': head, 'tested_source_count': 421,
    'tested_source_dictionary_sha256': candidate['source_dictionary_sha256'],
    'source_hash_algorithm': 'canonical sorted relative-path to file-SHA256 JSON; not C4-source-v1',
    'configuration_counts': {item['configuration']: item['executed_count'] for item in completed['configurations']},
    'actual_ctest_executions': 261, 'actual_ctest_passed': 261, 'actual_ctest_failed': 0,
    'compiler_warnings': 0, 'strict_cpp20': True, 'asan_ubsan_scope': 'typed_host only', 'lsan': 'NOT RUN',
    'baseline': {'existing_cases_passed': 5, 'not_in_261_ctest_denominator': True,
                 'copied_interpreted_bridge_identified_separately': True},
    'actual_SQLite': sqlite, 'independent_source_review_blockers': 0,
    'pre_execution_test_defects_found_and_fixed': review['findings'],
    'archive': {**fact(archive), 'member_count': len(index), 'all_members_and_origins_reverified': True},
    'docs_only_frozen_input_delta': ['adapters/engine_api/README.md'],
    'limits': ['Current GUI cumulative failures and graphical gate remain open; no GUI executed in this matrix',
               'Old f2d local bundle is unrefreshed; package evidence keeps its original source scope',
               'No real solver/full external AI/performance/full SK or P0 acceptance',
               'Unknown SDK copy coverage remains deferred only from C4 startup; measured budgets and original material14/30 failures retained',
               'Output labels describe existing serializers, without a new generated output union',
               'Actual MCP/CLI share fixed trusted caller local-user; distinct-caller isolation tested in C++',
               'Other legacy contracts and complete SK-04 remain unclosed']}
dump(DEST / 'validation.json', validation)
REPORT.write_text(f'''# 原操作结果查询的条件契约

实现提交 `{head}` 已补齐既有 `operations.get` 的输入版本与真实参数/上下文发现。统一421输入的五配置实际261/261通过；原图形累计失败、本机旧包与完整SK/P0验收仍未关闭。

`OperationsGetInput` 为生成的版本1语义字符串DTO，schema为 `qcae.operation.operations.get.v1`。三个必需非空字段为lookup_scope、original_operation及原操作idempotency_key；original_mode仅在host/project.open查询中有效，省略选择normal，也支持recover。其他宿主或任意文档动作原来忽略的模式仍接受全部JSON值，适配器仅投影掉该字段再解码；未扩展Value或生成器。未知原始字段仍拒绝，原scope/operation/used-mode/key诊断保留。

闭合parameters_schema使用三个互斥分支：host-open、其他五类宿主映射中的非open入口、document。完整arguments_schema复用相同参数schema，以两个分支描述上下文：宿主仅需parameters，文档还需非空document_id/document_epoch；未使用的revision及顶层key保持可忽略，宿主文档上下文也保持可忽略。requested_version可省略，或为正uint32；非法值返回INVALID_INPUT/requested_version，其他安装外版本返回SCHEMA_UNSUPPORTED/requested_version，先于查询分支调用。

MCP复用现有16层/128节点schema验证器，检查完整根对象闭合、参数名已识别、parameters与原描述严格相等，再原样公布inputSchema。没有新增业务解码或操作名字分支；原工具路径保持。符号OperationLookup/OperationOutcome、query效果和无无条件上下文要求保留；wire_output_types和output_by_lookup_scope仅说明既有DocumentInfo/ChangeReceipt序列化，不是新增输出合同。

查询继续调用同一RecordApplication的宿主、commit/undo/redo或任意贡献动作保留事实；不要求原handler仍安装，不产生事务或新写键。宿主与任意动作直接返回，mapped history/commit保留顶层revision的原差异。应用、存储、registry、TypedHost、核心公开接口、依赖和性能机制均未修改。

| 配置 | 实际执行/通过 |
|---|---:|
| 纯核心Release | 40/40 |
| 本地Debug | 55/55 |
| SQLite/Nastran ON，无桌面 | 87/87 |
| SQLite/Nastran OFF，无桌面 | 78/78 |
| ASan/UBSan typed_host专项 | 1/1 |
| 合计 | 261/261 |

所有构建严格C++20、零编译警告；生成一致性及公共头消费者保留于对应构建/CTest。修改前五项既有C++/IPC/MCP/协议基线均通过，单列于归档，不计入261分母。ASan/UBSan只执行typed_host一项，LSan未测；五配置均关闭桌面，没有新图形通过证据。

C++复用原生命周期、历史与停用handler场景，逐次比较完整DocumentView、持久假存储、generation、history与caller事实，并校验语义投影、原诊断顺序和完整返回包。两个真实SQLite场景各新增35次查回、31次拒绝，保留原101次拒绝、5组读取、8次历史写及6次重放；实际全逻辑行/BLOB/generation/document/history比较不变。独立进程恢复保留原身份与事实、更新epoch；discard后normal-open恢复保存模型并建立新身份。两engine均SIGTERM退出-15，无强杀或物理WAL字节相等主张。

真实两个MCP客户端及CLI验证完整发现schema/说明透传、省略/版本1包相等、忽略JSON值、文档上下文与版本拒绝、原action/commit/undo/redo及关闭后的宿主事实。协议替身33场景只验证metadata/transport边界，不充当真实模型验收。运行入口固定trusted caller local-user；不同调用者隔离由C++可信Caller测试证明，不伪造JSON actor。

独立QG-02审查发现两处测试问题，参数变量覆盖与keep_recovery后直接normal-open均在运行前修复，最终无静态阻塞。它们不是实际测试失败或应用行为修改。设计、clang-format21与diff门禁实际通过；收尾文档门禁单列。

[机器结果](operation-lookup-evidence/2026-10-03/validation.json)、[索引](operation-lookup-evidence/2026-10-03/archive-index.json)和[原始归档](operation-lookup-evidence/2026-10-03/evidence.tar.gz)保留方法、命令/日志、源码/产品及实际复制桥脚本hash、SQLite观察/请求、格式前后源码和独立审查。归档{len(index)}成员、{archive.stat().st_size}字节，SHA256 `{sha(archive)}`，所有成员与原来源回读相等；没有数据库、二进制或构建树。冻结字典SHA256 `{candidate['source_dictionary_sha256']}`，算法为canonical排序相对路径→文件SHA256 JSON，非C4-source-v1。

说明阶段仅engine_api README属于冻结输入中的文档差异，其他420输入与执行产品保持；没有为文档重跑产品。其余legacy合同与核心正式验收继续推进；原图形180秒累计失败、旧二进制隔离诊断、旧f2d包、真实求解/完整AI、性能、未知SDK覆盖与已测预算失败仍保持各自来源边界。此切片不完成全部REQ-16、SK-04、C3/C4或P0；不追加非必要性能优化。
''')
short = head[:7]
latest = f'2026-10-03，`{short}` 已完成 `operations.get` 生成语义输入、条件参数/上下文发现、兼容投影及MCP原样schema适配；统一421输入五配置261/261实际通过，见[验证](../engineering/operation-lookup-contract-2026-10-03.md)。宿主不需文档，文档查回只需ID/epoch，原caller事实、停用handler与忽略JSON兼容均保留。继续其余同质legacy合同与核心正式验收；原图形失败、旧包、真实环境、性能及完整SK/P0范围不变。'
insert(SOURCE / 'docs/baseline/README.md', '2026-10-03，`8924149`', latest)
insert(SOURCE / 'docs/baseline/development-plan.md', '2026-10-03，`8924149`', latest)
insert(SOURCE / 'docs/README.md', '[七个读取与历史入口契约]', f'[原结果查询条件契约](engineering/operation-lookup-contract-2026-10-03.md)：`{short}` 五配置261/261通过，真实SQLite状态/恢复及两个MCP/CLI一致，原图形失败及完整验收范围保留。')
for path, link in ((SOURCE / 'README.md', 'docs/engineering/operation-lookup-contract-2026-10-03.md'),
                   (SOURCE / 'docs/implementation/core-local-handoff.md', '../engineering/operation-lookup-contract-2026-10-03.md')):
    previous = path.read_text()
    old = next(line for line in previous.splitlines() if line.startswith('最新源码 `8924149`'))
    path.write_text(previous.replace(old, f'最新源码 `{short}` 已补齐 `operations.get` 条件输入、上下文及版本发现，五配置261/261实际通过，见[本轮证据]({link})。宿主、文档及停用handler的原事实查询保持单一权威，真实SQLite与两个MCP/CLI流程已验证。本机包仍为 `f2d2e7f`，未刷新；原累计图形失败与完整图形门禁未关闭。继续剩余同质legacy合同及核心正式验收，真实求解/完整AI、性能、原已测约束与完整SK/P0保持未验收范围。'))
path = SOURCE / 'adapters/engine_api/README.md'
previous = path.read_text().replace('version. Other legacy operations keep their existing request shape and reject the new context fields.', 'version. `operations.get` also accepts it with conditional context as described below.\nOther legacy operations keep their existing request shape and reject the new context fields.')
section = '''### Versioned outcome lookup

`operations.get` uses generated semantic `OperationsGetInput`, schema
`qcae.operation.operations.get.v1`, with the same omitted/v1 and version refusal rules.
Closed raw parameters require nonempty `lookup_scope`, `original_operation` and the original
operation's `idempotency_key`. Only host `project.open` uses optional `original_mode`:
omission means `normal`, with `recover` also supported. Other host/document lookups ignore
any JSON mode value; the adapter projects only that unused field before string decoding.

Three disjoint parameter branches describe host-open, other known host lifecycle names and
any nonempty document action name. Complete `arguments_schema` reuses that parameter schema
and two conditional context branches: host needs parameters only; document also needs
nonempty document_id/epoch. Unused revision/top-level key and host document context are
ignored. Optional requested_version remains positive uint32, without const. MCP validates
bounded complete schema metadata then publishes it unchanged; business admission remains
in the engine. `wire_output_types` and `output_by_lookup_scope` label existing DocumentInfo
and ChangeReceipt serializers, not a new generated output union.

All calls read existing caller-scoped facts from the same application. Handler removal does
not prevent action lookup. Host/action direct-return envelopes and mapped-history outer
revision remain distinct. [Actual scope](../../docs/engineering/operation-lookup-contract-2026-10-03.md).

'''
marker = '### C3 versioned display resources and events'
assert previous.count(marker) == 1
path.write_text(previous.replace(marker, section + marker))
path = SOURCE / 'docs/contracts/README.md'
previous = path.read_text().replace('及七个读取/历史入口同样接受操作版本', '、七个读取/历史入口及 `operations.get` 同样接受操作版本')
previous += '\n## 原结果查询条件输入\n\n`operations.get` 使用生成版本1语义输入与闭合原始三分支参数schema，模式仅用于host/project.open的normal/recover，其他查询继续忽略任意JSON模式。完整arguments_schema以宿主/文档两个分支描述最小上下文；宿主无文档要求，文档要求ID/epoch，原参数中的key是被查询操作的键。MCP有界验证后原样公布，版本/参数与caller事实仍由engine/应用校验；停用handler仍能查回原事实。现有结果wire标签与原返回包保留，实际范围见[验证](../engineering/operation-lookup-contract-2026-10-03.md)，其他legacy及完整SK/P0未验收。\n'
path.write_text(previous)
path = SOURCE / 'docs/engineering/execution-status.json'
state = json.loads(path.read_text())
previous = state['current_core_framework']
assert 'historical_core_framework_before_operation_lookup' not in state
state['historical_core_framework_before_operation_lookup'] = copy.deepcopy(previous)
current = copy.deepcopy(previous)
current.update(status='lookup_conditional_contract_validated_non_graphical_full_graphical_gate_open',
    tested_implementation_commit=head, source_files_count=421,
    source_dictionary_sha256=candidate['source_dictionary_sha256'],
    manifest='docs/engineering/operation-lookup-evidence/2026-10-03/validation.json',
    report='docs/engineering/operation-lookup-contract-2026-10-03.md',
    versioned_existing_host_inputs=previous['versioned_existing_host_inputs'] + ['operations.get'],
    bounded_operation_lookup_SQLite=sqlite,
    next_core_interface='Group remaining homogeneous legacy contracts, then applicable formal core acceptance; not implemented',
    limits=validation['limits'] + ['ASan/UBSan typed_host only; LSan unmeasured',
        'Earlier seven-route results retained under historical_core_framework_before_operation_lookup'])
state['current_core_framework'] = current
state['updated_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
dump(path, state)
delta = [name for name, digest in inputs.items() if sha(SOURCE / name) != digest]
assert delta == ['adapters/engine_api/README.md'], delta
assert all(fact(Path(name)) == record for name, record in products.items())
dump(ROOT / 'post-doc-source.json', {'frozen_input_documentation_delta': delta,
     'other420_inputs_unchanged': True, 'compiled_products_before_after_equal': True,
     'documentation_product_rerun': 'NOT RUN; only README within frozen inputs changed',
     'archive': fact(archive), 'member_count': len(index)})
print(json.dumps({'implementation_commit': head, 'archive': fact(archive), 'member_count': len(index),
                  'actual_SQLite': sqlite, 'frozen_input_documentation_delta': delta}))
