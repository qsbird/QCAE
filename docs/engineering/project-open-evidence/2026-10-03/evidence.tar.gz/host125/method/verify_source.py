#!/usr/bin/env python3
"""Read-only byte verification of the immutable e2207ed Git source snapshot."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent


def verify(source):
    source = Path(source).resolve()
    manifest = json.loads((HERE / 'source412-manifest.json').read_text())
    digest = hashlib.sha256(b'QCAE-C4-SOURCE-SHA256-v1\0')
    expected = set(manifest['files'])
    actual = set()
    for name in manifest['source_roots']:
        root = source / name
        if root.is_file():
            actual.add(name)
        elif root.is_dir():
            actual.update(str(p.relative_to(source)) for p in root.rglob('*') if p.is_file())
    if expected != actual:
        raise RuntimeError('Frozen source inventory mismatch: ' + repr(sorted(expected ^ actual)))
    for name, entry in sorted(manifest['files'].items()):
        path = source / name
        if path.is_symlink() or not path.is_file():
            raise RuntimeError('Source path is missing/replaced: ' + name)
        value = path.read_bytes()
        actual_sha = hashlib.sha256(value).hexdigest()
        if len(value) != entry['bytes'] or actual_sha != entry['sha256']:
            raise RuntimeError('Source bytes differ from exact e2207ed Git blob: ' + name)
        encoded = name.encode()
        digest.update(len(encoded).to_bytes(8, 'big') + encoded + entry['mode'].encode())
        digest.update(bytes.fromhex(actual_sha))
    if len(expected) != 412 or digest.hexdigest() != manifest['source412_sha256']:
        raise RuntimeError('Frozen source denominator/digest differs')
    dictionary = {name: entry['sha256'] for name, entry in manifest['files'].items()}
    dictionary_sha = hashlib.sha256(json.dumps(dictionary, sort_keys=True,
                                              separators=(',', ':')).encode()).hexdigest()
    if dictionary_sha != manifest['candidate_files_sha256']:
        raise RuntimeError('Frozen candidate-files dictionary digest differs')
    return {'source_root': str(source), 'source_commit': manifest['commit'],
            'source_files': len(expected), 'source412_sha256': digest.hexdigest(),
            'candidate_files_sha256': dictionary_sha}


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--source-root', required=True)
    args = parser.parse_args()
    print(json.dumps(verify(args.source_root), sort_keys=True))
