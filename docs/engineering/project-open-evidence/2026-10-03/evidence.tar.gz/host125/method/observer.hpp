#pragma once
#ifndef QCAE_PRIVATE_HOST_BINDING125
#error "This header is exclusively for the private instrumented host"
#endif
#include "qcae/ipc_api.hpp"
#include "qcae/nastran_contribution.hpp"
#include "qcae/nastran_package.hpp"

namespace qcae::binding125 {
void constructed_codec(const NastranCodec&);
ipc::EngineContribution contribution(ipc::EngineContribution,
                                     const std::shared_ptr<ipc::NastranArtifactCoordinator>&);
QJsonObject dispatch(MemoryApplication&, const QJsonObject&, const Caller&,
                     const IModelCodec*, const ProfileDefinition*, SelectionService*,
                     ipc::TypedHost*, bool);
Result<ArtifactPlan> validate_export(const DocumentView&, const EntityId&, const NastranCodec&);
NastranUiContribution ui(const NastranCodec&);
RenderContributions nastran_render();
RenderContributions generic_render();
RenderContributions selected_render(RenderContributions);
} // namespace qcae::binding125
