#!/usr/bin/env python3
"""Prepared root-only commands; never imports a previous acceptance runner."""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tarfile
import time
sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
COMMIT = 'e2207ed629c629452bac78dac2c3a4f21abccf4e'
TREE = '6b6bf34fe1829619aeafd7a4812616e3917913d805dc331a38e8753ab46102e5'
CANDIDATE = 'd2b507a1bf1c19336731a2a1014baa554d66210ba269dea09b96793fc427c41e'
SOURCE = HERE / 'source-e220-01'
REPO = Path('/private/tmp/qcae-framework-delivery80')
PYTHON = '/Library/Frameworks/Python.framework/Versions/3.14/bin/python3.14'
CMAKE = '/opt/homebrew/Cellar/cmake/4.3.0/bin/cmake'

def fact(path):
    path = Path(path).resolve()
    return {'path': str(path), 'bytes': path.stat().st_size,
            'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}

def write(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')

def require(value, message):
    if not value:
        raise RuntimeError(message)

def inputs(expected):
    index = HERE / 'immutable-index.json'
    require(fact(index)['sha256'] == expected, 'Prepared immutable index differs')
    for entry in json.loads(index.read_text())['entries']:
        actual = fact(HERE / entry['relative_path'])
        require(actual['bytes'] == entry['bytes'] and actual['sha256'] == entry['sha256'],
                'Sealed private input changed: ' + entry['relative_path'])
    for entry in json.loads((HERE / 'environment-inputs.json').read_text())['byte_facts']:
        require(fact(entry['path']) == entry, 'Prepared tool/Qt/SQLite bytes differ: ' + entry['path'])

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--action', choices=('snapshot', 'build-on', 'build-off', 'observe-on', 'observe-off'), required=True)
    parser.add_argument('--attempt-id', required=True)
    parser.add_argument('--input-index-sha256', required=True)
    parser.add_argument('--execute', action='store_true', required=True)
    args = parser.parse_args()
    require(args.attempt_id.isdigit(), 'Attempt ID must be numeric')
    mode = 'OFF' if args.action.endswith('off') else 'ON'
    output = HERE / 'actions' / (args.action + '-' + args.attempt_id)
    require(not output.exists(), 'Never overwrite an actual action')
    output.mkdir(parents=True)
    build = HERE / ('build-' + mode.lower() + '-' + args.attempt_id)
    env = {key: value for key, value in os.environ.items()
           if not key.startswith(('DYLD_', 'LD_', 'QT_', 'QCAE_')) and
           key not in ('PYTHONPATH', 'PYTHONHOME', 'ASAN_OPTIONS', 'UBSAN_OPTIONS')}
    env.update(PYTHONDONTWRITEBYTECODE='1', PATH='/opt/homebrew/bin:/Library/Developer/CommandLineTools/usr/bin:/usr/bin:/bin:/usr/sbin:/sbin')
    receipts = []
    write(output / 'action-start.json', {'actual_argv': sys.argv, 'process_id': os.getpid(),
          'started_unix': time.time(), 'source_commit': COMMIT, 'source_tree_sha256': TREE,
          'candidate_files_sha256': CANDIDATE, 'private_instrumented_derivative': True})
    def command(identity, argv, cwd):
        receipt = {'command_id': identity, 'actual_argv': argv, 'cwd': str(cwd),
                   'started_unix': time.time(), 'environment_PATH': env['PATH']}
        write(output / (identity + '-start.json'), receipt)
        with (output / (identity + '.stdout.log')).open('xb') as stdout, (output / (identity + '.stderr.log')).open('xb') as stderr:
            process = subprocess.Popen(argv, cwd=cwd, env=env, stdout=stdout, stderr=stderr)
            receipt['process_id'] = process.pid
            receipt['actual_exit_code'] = process.wait()
        receipt.update(ended_unix=time.time(), stdout=fact(output / (identity + '.stdout.log')),
                       stderr=fact(output / (identity + '.stderr.log')))
        write(output / (identity + '.json'), receipt)
        receipts.append(receipt)
        require(receipt['actual_exit_code'] == 0, 'Actual nonzero command; stopped: ' + identity)
    error = None
    try:
        inputs(args.input_index_sha256)
        if args.action == 'snapshot':
            require(not SOURCE.exists(), 'Exact source snapshot must be new')
            archive = output / 'source-e220.tar'
            command('git-archive-e220', ['/usr/bin/git', '-C', str(REPO), 'archive', '--format=tar',
                    '--output=' + str(archive), COMMIT], HERE)
            SOURCE.mkdir()
            with tarfile.open(archive) as stream:
                stream.extractall(SOURCE, filter='data')
            from verify_source import verify
            write(output / 'source-verified.json', verify(SOURCE))
            for path in SOURCE.rglob('*'):
                if path.is_file(): path.chmod(0o444)
            for path in sorted((p for p in SOURCE.rglob('*') if p.is_dir()), key=lambda p: len(p.parts), reverse=True): path.chmod(0o555)
            SOURCE.chmod(0o555)
            write(output / 'archive-seal.json', fact(archive))
        else:
            from verify_source import verify
            before = verify(SOURCE)
            write(output / 'source-before.json', before)
            if args.action.startswith('build-'):
                require(not build.exists(), 'Actual build must start in a new directory')
                argv = [CMAKE, '-S', str(HERE), '-B', str(build), '-G', 'Ninja',
                        '-DCMAKE_BUILD_TYPE=Release', '-DCMAKE_EXPORT_COMPILE_COMMANDS=ON',
                        '-DCMAKE_CXX_COMPILER=/Library/Developer/CommandLineTools/usr/bin/c++',
                        '-DCMAKE_MAKE_PROGRAM=/opt/homebrew/bin/ninja', '-DPython3_EXECUTABLE=' + PYTHON,
                        '-DQt6_DIR=/opt/homebrew/Cellar/qtbase/6.11.1/lib/cmake/Qt6',
                        '-DSQLite3_INCLUDE_DIR=/opt/homebrew/Cellar/sqlite/3.53.4/include',
                        '-DSQLite3_LIBRARY=/opt/homebrew/Cellar/sqlite/3.53.4/lib/libsqlite3.3.53.4.dylib',
                        '-DQCAE_BINDING125_SOURCE_ROOT=' + str(SOURCE), '-DQCAE_BINDING125_COMMIT=' + COMMIT,
                        '-DQCAE_BINDING125_SOURCE_TREE_SHA256=' + TREE,
                        '-DQCAE_BINDING125_CANDIDATE_FILES_SHA256=' + CANDIDATE,
                        '-DQCAE_ENABLE_NASTRAN_PACKAGE=' + mode]
                command('configure-' + mode.lower(), argv, HERE)
                command('build-' + mode.lower(), [CMAKE, '--build', str(build), '--clean-first',
                        '--parallel', '2', '--verbose', '--target', 'qcae-engine'], HERE)
                command('dependency-list', ['/usr/bin/otool', '-L', str(build / 'qcae-engine')], HERE)
                command('load-commands', ['/usr/bin/otool', '-l', str(build / 'qcae-engine')], HERE)
                write(output / 'compiled-artifact-seal.json', {'engine': fact(build / 'qcae-engine'),
                      'cache': fact(build / 'CMakeCache.txt'), 'compile_commands': fact(build / 'compile_commands.json'),
                      'actual_successful_command_ids': [r['command_id'] for r in receipts],
                      'source_before': before, 'private_instrumented_derivative': True})
            else:
                prior = HERE / 'actions' / ('build-' + mode.lower() + '-' + args.attempt_id) / 'complete.json'
                require(json.loads(prior.read_text())['actual_wrapper_exit_code'] == 0, 'Actual same-mode fresh build receipt absent/nonzero')
                target = HERE / 'results' / (mode.lower() + '-' + args.attempt_id)
                command('observe-' + mode.lower(), [PYTHON, '-B', str(HERE / 'native.py'),
                        '--source-root', str(SOURCE), '--build', str(build), '--mode', mode,
                        '--output', str(target), '--input-index-sha256', args.input_index_sha256, '--execute'], HERE)
                require(json.loads((target / 'complete.json').read_text())['actual_wrapper_exit_code'] == 0,
                        'Actual native completion was not zero')
            after = verify(SOURCE)
            require(before == after, 'Archived product source changed')
            write(output / 'source-after.json', after)
        inputs(args.input_index_sha256)
    except BaseException as failure:
        error = type(failure).__name__ + ': ' + str(failure)
    write(output / 'complete.json', {'actual_wrapper_exit_code': 0 if error is None else 1, 'error': error,
          'source_commit': COMMIT, 'source_tree_sha256': TREE, 'candidate_files_sha256': CANDIDATE,
          'actual_command_receipts': receipts, 'full_SK_BP10_R5_C3_C4_P0_pass_claim': False})
    return 0 if error is None else 1

if __name__ == '__main__':
    raise SystemExit(main())
