#include "observer.hpp"
#include <QFile>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QCoreApplication>
#include <map>
#include <mutex>
#include <stdexcept>
#include <cstdint>

namespace qcae::binding125 {
namespace {
QString text(std::string_view value) {
    return QString::fromUtf8(value.data(), static_cast<qsizetype>(value.size()));
}
QString pointer(const void* value) {
    return QString::number(reinterpret_cast<std::uintptr_t>(value), 16);
}
QJsonObject profile(const ProfileRef& value) {
    return {{"profile_id", text(value.profile_id)}, {"profile_version", text(value.profile_version)},
            {"definition_digest", text(value.definition_digest)}};
}
QJsonArray entries(const RenderContributions& value) {
    QJsonArray result;
    for (const auto& [type, item] : value.entries())
        result.append(QJsonObject{{"type_id", static_cast<qint64>(type.value)},
                                  {"topology", text(item.topology)},
                                  {"project_callable", static_cast<bool>(item.project)},
                                  {"registration_owner", QJsonValue::Null}});
    return result;
}
struct RegisteredOwner {
    QString id;
    bool operations_registered{};
};
struct State {
    QFile output;
    std::mutex mutex;
    std::map<const NastranCodec*, RegisteredOwner> owners;
    const IModelCodec* host_codec{};
    const ProfileDefinition* host_profile{};
    std::uint64_t sequence{};
    State() : output(qEnvironmentVariable("QCAE_PRIVATE_HOST_BINDING_TRACE")) {
        if (output.fileName().isEmpty() || !output.open(QIODevice::WriteOnly | QIODevice::NewOnly))
            throw std::runtime_error("Private host observer requires a fresh owned trace path");
    }
};
State& state() {
    static State value;
    return value;
}
thread_local QString request_id, operation;
void record(const char* event, QJsonObject value) {
    auto& current = state();
    std::lock_guard lock(current.mutex);
    value.insert("event", event);
    value.insert("sequence", QString::number(++current.sequence));
    value.insert("process_id", QString::number(QCoreApplication::applicationPid()));
    value.insert("source_commit", QCAE_BINDING125_SOURCE_COMMIT);
    value.insert("source_tree_sha256", QCAE_BINDING125_SOURCE_TREE_SHA256);
    value.insert("candidate_files_sha256", QCAE_BINDING125_CANDIDATE_FILES_SHA256);
    value.insert("observer_enabled", true);
    value.insert("request_id", request_id);
    value.insert("operation", operation);
    const auto line = QJsonDocument(value).toJson(QJsonDocument::Compact) + '\n';
    if (current.output.write(line) != line.size() || !current.output.flush())
        throw std::runtime_error("Private host observer trace write failed");
}
QJsonObject owner(const NastranCodec& codec) {
    auto& current = state();
    std::lock_guard lock(current.mutex);
    const auto found = current.owners.find(&codec);
    return {{"codec_address", pointer(&codec)},
            {"observed_contribution_id", found == current.owners.end() ? QJsonValue(QJsonValue::Null)
                                                                       : QJsonValue(found->second.id)},
            {"actual_operation_callback_registered", found != current.owners.end() &&
                                                       found->second.operations_registered}};
}
struct RequestScope {
    QString previous_id{request_id}, previous_operation{operation};
    explicit RequestScope(const QJsonObject& request) {
        request_id = request.value("request_id").toString();
        operation = request.value("operation").toString();
    }
    ~RequestScope() {
        request_id = previous_id;
        operation = previous_operation;
    }
};
} // namespace

void constructed_codec(const NastranCodec& codec) {
    auto& current = state();
    {
        std::lock_guard lock(current.mutex);
        current.host_codec = static_cast<const IModelCodec*>(&codec);
        current.host_profile = &codec.definition();
    }
    record("actual.host.codec.constructed", {{"concrete_codec_address", pointer(&codec)},
           {"IModelCodec_address", pointer(static_cast<const IModelCodec*>(&codec))},
           {"IProfileProvider_address", pointer(static_cast<const IProfileProvider*>(&codec))},
           {"profile_definition_address", pointer(&codec.definition())},
           {"profile", profile(codec.definition().reference)}});
}
ipc::EngineContribution contribution(
    ipc::EngineContribution value, const std::shared_ptr<ipc::NastranArtifactCoordinator>& coordinator) {
    const auto* codec = &coordinator->codec();
    const QString identity = text(value.id);
    {
        auto& current = state();
        std::lock_guard lock(current.mutex);
        current.owners.emplace(codec, RegisteredOwner{identity, false});
    }
    record("actual.contribution.returned", {{"observed_contribution_id", identity},
           {"coordinator_address", pointer(coordinator.get())}, {"codec_address", pointer(codec)}});
    auto original = std::move(value.operations);
    value.operations = [identity, codec, original = std::move(original)](
        operations::OperationRegistry& registry, RecordApplication& app,
        std::function<TaskService&()> tasks) {
        const auto result = original(registry, app, std::move(tasks));
        {
            auto& current = state();
            std::lock_guard lock(current.mutex);
            current.owners.at(codec).operations_registered = result.ok();
        }
        QJsonArray descriptors;
        for (const auto& item : registry.descriptors())
            descriptors.append(QJsonObject{{"operation", text(item.definition.operation_id)},
                                           {"available", item.available}});
        record("actual.contribution.operation_callback.returned",
               {{"observed_contribution_id", identity}, {"codec_address", pointer(codec)},
                {"status", status_name(result.status)}, {"actual_registry_descriptors", descriptors}});
        return result;
    };
    return value;
}
QJsonObject dispatch(MemoryApplication& app, const QJsonObject& request, const Caller& caller,
                     const IModelCodec* codec, const ProfileDefinition* definition,
                     SelectionService* selections, ipc::TypedHost* typed, bool display_services) {
    const RequestScope scope(request);
    bool codec_matches{}, profile_matches{};
    {
        auto& current = state();
        std::lock_guard lock(current.mutex);
        codec_matches = codec && codec == current.host_codec;
        profile_matches = definition && definition == current.host_profile;
    }
    record("actual.host.dispatch.arguments",
           {{"codec_bound", codec != nullptr}, {"profile_bound", definition != nullptr},
            {"codec_address", pointer(codec)}, {"profile_definition_address", pointer(definition)},
            {"matches_constructed_host_codec", codec_matches},
            {"matches_constructed_host_profile", profile_matches},
            {"profile", definition ? QJsonValue(profile(definition->reference)) : QJsonValue(QJsonValue::Null)}});
    const auto result = ipc::dispatch(app, request, caller, codec, definition, selections, typed, display_services);
    record("actual.host.dispatch.returned", {{"status", result.value("status")},
           {"error", result.value("error")}});
    return result;
}
Result<ArtifactPlan> validate_export(const DocumentView& view, const EntityId& analysis,
                                    const NastranCodec& codec) {
    auto actual = owner(codec);
    actual.insert("analysis_id", text(analysis.value));
    actual.insert("revision", QString::number(view.version().revision));
    record("actual.coordinator.export_validator.enter", actual);
    const auto result = validate_nastran_export(view, analysis, codec);
    actual.insert("status", status_name(result.status));
    actual.insert("error_code", result.error ? error_name(result.error->code) : "none");
    record("actual.coordinator.export_validator.returned", actual);
    return result;
}
NastranUiContribution ui(const NastranCodec& codec) {
    auto actual = owner(codec);
    record("actual.coordinator.ui.enter", actual);
    auto result = nastran_ui_contribution(codec);
    actual.insert("action_id", text(result.action_id));
    actual.insert("target_operation", text(result.operation));
    actual.insert("profile", profile(result.profile));
    record("actual.coordinator.ui.returned", actual);
    return result;
}
RenderContributions nastran_render() {
    auto result = ipc::nastran_render_contributions();
    record("actual.render.factory.returned", {{"actual_called_factory", "qcae::ipc::nastran_render_contributions"},
           {"registry_frozen", result.frozen()}, {"actual_entries", entries(result)}});
    return result;
}
RenderContributions generic_render() {
    auto result = default_render_contributions();
    record("actual.render.factory.returned", {{"actual_called_factory", "qcae::default_render_contributions"},
           {"registry_frozen", result.frozen()}, {"actual_entries", entries(result)}});
    return result;
}
RenderContributions selected_render(RenderContributions actual) {
    record("actual.host.RenderService.argument", {{"registry_frozen", actual.frozen()},
           {"actual_entries", entries(actual)}, {"owner_metadata_available", false}});
    return actual;
}
} // namespace qcae::binding125
