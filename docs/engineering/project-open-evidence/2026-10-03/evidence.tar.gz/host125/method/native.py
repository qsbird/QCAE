#!/usr/bin/env python3
"""Root-owned private host trace exercise; fresh compiled ON/OFF derivatives only."""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
COMMIT = 'e2207ed629c629452bac78dac2c3a4f21abccf4e'
TREE = '6b6bf34fe1829619aeafd7a4812616e3917913d805dc331a38e8753ab46102e5'
CANDIDATE = 'd2b507a1bf1c19336731a2a1014baa554d66210ba269dea09b96793fc427c41e'


def require(value, message):
    if not value:
        raise RuntimeError(message)


def fact(path):
    path = Path(path).resolve()
    return {'path': str(path), 'bytes': path.stat().st_size,
            'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}


def write(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def own_inputs(expected_index):
    index = HERE / 'immutable-index.json'
    require(fact(index)['sha256'] == expected_index, 'Private input index differs')
    for entry in json.loads(index.read_text())['entries']:
        actual = fact(HERE / entry['relative_path'])
        require(actual['bytes'] == entry['bytes'] and actual['sha256'] == entry['sha256'],
                'Private instrumented input changed: ' + entry['relative_path'])
    for entry in json.loads((HERE / 'environment-inputs.json').read_text())['byte_facts']:
        require(fact(entry['path']) == entry, 'Prepared tool/Qt/SQLite bytes differ: ' + entry['path'])


def compilation(build, mode, source):
    cache = {}
    for line in (build / 'CMakeCache.txt').read_text().splitlines():
        if line and not line.startswith(('#', '//')) and ':' in line and '=' in line:
            name, value = line.split(':', 1)
            cache[name] = value.split('=', 1)[1]
    expected = {'QCAE_ENABLE_NASTRAN_PACKAGE': mode, 'QCAE_BUILD_STORAGE': 'ON',
                'QCAE_BUILD_IPC': 'ON', 'QCAE_BUILD_DESKTOP': 'OFF',
                'QCAE_ENABLE_SANITIZERS': 'OFF', 'CMAKE_BUILD_TYPE': 'Release',
                'QCAE_BINDING125_SOURCE_ROOT': str(source), 'QCAE_BINDING125_COMMIT': COMMIT,
                'QCAE_BINDING125_SOURCE_TREE_SHA256': TREE,
                'QCAE_BINDING125_CANDIDATE_FILES_SHA256': CANDIDATE}
    require(all(cache.get(key) == value for key, value in expected.items()),
            'Actual private build cache/source/ON-OFF flags differ')
    commands = json.loads((build / 'compile_commands.json').read_text())
    paths = [HERE / 'derived/engine_host.cpp', HERE / 'derived/nastran_contribution.cpp', HERE / 'observer.cpp']
    compiled = []
    for path in paths:
        matches = [entry for entry in commands if Path(entry['file']).resolve() == path]
        require(len(matches) == 1 and '-DQCAE_PRIVATE_HOST_BINDING125=1' in matches[0]['command'],
                'Actual enabled private observation CPP compile command missing')
        require('-std=c++20' in matches[0]['command'], 'Private derivative requires strict C++20')
        compiled.append(matches[0])
    assembly = [entry for entry in commands if Path(entry['file']).resolve() ==
                source / 'adapters/engine_api/src/engine_contributions.cpp']
    require(len(assembly) == 1 and '-DQCAE_NASTRAN_PACKAGE_ENABLED=' +
            ('1' if mode == 'ON' else '0') in assembly[0]['command'],
            'Real production package definition is absent/wrong')
    return {'cache': fact(build / 'CMakeCache.txt'), 'compile_commands': fact(build / 'compile_commands.json'),
            'actual_observer_compile_commands': compiled, 'actual_assembly_compile_command': assembly[0]}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--source-root', required=True, type=Path)
    parser.add_argument('--build', required=True, type=Path)
    parser.add_argument('--mode', choices=('ON', 'OFF'), required=True)
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--input-index-sha256', required=True)
    parser.add_argument('--execute', action='store_true', required=True)
    args = parser.parse_args()
    source, build, output = args.source_root.resolve(), args.build.resolve(), args.output.resolve()
    require(not output.exists() and output.is_relative_to(HERE), 'Owned fresh output must be below private125')
    output.mkdir(parents=True)
    process, client, error = None, None, None
    engine = build / 'qcae-engine'
    cleanup = {'process_id': None, 'precleanup_exit_code': None, 'owner_terminated': False,
               'owner_killed': False, 'reaped': False, 'actual_exit_code': None}
    result = {'mode': args.mode, 'source_commit': COMMIT, 'source_tree_sha256': TREE,
              'candidate_files_sha256': CANDIDATE, 'private_instrumented_derivative': True,
              'full_six_registry_owner_metadata_proven': False, 'render_registration_owner': None}
    write(output / 'action-start.json', {'actual_argv': sys.argv, 'process_id': os.getpid(),
          'started_unix': time.time(), **result})
    try:
        own_inputs(args.input_index_sha256)
        from verify_source import verify
        source_before = verify(source)
        compiled = compilation(build, args.mode, source)
        engine_before = fact(engine)
        write(output / 'inputs-before.json', {'source': source_before, 'engine': engine_before, **compiled})
        # Use exact archived production fixture methods; never execute their main entry points.
        sys.path.insert(0, str(source / 'tests'))
        from analysis_check_ipc_tests import Client
        from result_fixture_ipc_tests import create_m
        endpoint = str(output / 'engine.sock')
        require(len(endpoint.encode()) < 104, 'Owned socket path exceeds macOS limit')
        argv = [str(engine), '--socket', endpoint, '--workspace', str(output / 'workspace.sqlite')]
        env = {key: value for key, value in os.environ.items()
               if not key.startswith(('DYLD_', 'LD_', 'QT_', 'QCAE_')) and
               key not in ('PYTHONPATH', 'PYTHONHOME', 'ASAN_OPTIONS', 'UBSAN_OPTIONS')}
        env.update(PYTHONDONTWRITEBYTECODE='1', QCAE_SOURCE_TREE_SHA256=TREE,
                   QCAE_PRIVATE_HOST_BINDING_TRACE=str(output / 'trace.jsonl'), DYLD_PRINT_LIBRARIES='1')
        client = Client(str(engine), '', endpoint, 'python')
        with (output / 'engine.stdout.log').open('xb') as stdout, (output / 'engine.stderr.log').open('xb') as stderr:
            process = subprocess.Popen(argv, cwd=source, env=env, stdout=stdout, stderr=stderr)
            cleanup['process_id'] = process.pid
            write(output / 'engine-start.json', {'actual_argv': argv, 'process_id': process.pid,
                  'cwd': str(source), 'trace_path': env['QCAE_PRIVATE_HOST_BINDING_TRACE'],
                  'private_environment': {key: env[key] for key in
                     ('QCAE_SOURCE_TREE_SHA256', 'QCAE_PRIVATE_HOST_BINDING_TRACE', 'DYLD_PRINT_LIBRARIES')}})
            deadline = time.monotonic() + 20
            while True:
                require(process.poll() is None, 'Private owned engine exited before startup')
                try:
                    capabilities = client.call('capabilities.list')
                    break
                except (OSError, AssertionError, json.JSONDecodeError):
                    require(time.monotonic() < deadline, 'Private engine startup timeout')
                    time.sleep(.05)
            profiles = capabilities['declared_solver_profiles']
            require((len(profiles) == 1) if args.mode == 'ON' else profiles == [], 'ON/OFF profiles differ')
            profile = profiles[0]['profile_ref'] if profiles else None
            nodes, beams, material, part, analysis = create_m(client, profile)
            require(len(nodes) == 11 and len(beams) == 10, 'Real original M fixture population differs')
            before = client.current()
            history_before = client.call('history.list', context=before)
            existing_directory = output / 'existing-export-directory'
            existing_directory.mkdir()
            ui = client.call('nastran.ui', context=before,
                             expected='success' if args.mode == 'ON' else 'failed')
            preview = client.call('model.export_preview', {
                'analysis_id': analysis or 'absent-off-analysis125',
                'expected_profile_ref': profile or {}}, before,
                expected='success' if args.mode == 'ON' else 'failed')
            export = client.call('model.export', {'analysis_id': analysis or 'absent-off-analysis125',
                                                 'output_directory': str(existing_directory)},
                                 before, 'existing-directory125', expected='failed', profile=profile)
            require(export['error']['code'] == ('INVALID_INPUT' if args.mode == 'ON' else 'UNSUPPORTED_CAPABILITY'),
                    'Expected post-validator existing-directory refusal or OFF unavailability differs')
            if args.mode == 'OFF':
                require(ui['error']['code'] == preview['error']['code'] == 'UNSUPPORTED_CAPABILITY',
                        'OFF UI/codec entry is available')
            require(client.current() == before and client.call('history.list', context=before) == history_before,
                    'Read-only/rejected probes changed document/history')
            require(not list(existing_directory.iterdir()), 'Validation-only refused export published files')
            result.update(actual_profiles=profiles, real_M_nodes=len(nodes), real_M_beams=len(beams),
                          actual_UI_response=ui, actual_preview_response=preview,
                          actual_export_refusal=export, probe_revision=before['revision'],
                          document_history_unchanged=True, no_export_files_published=True)
    except BaseException as failure:
        error = type(failure).__name__ + ': ' + str(failure)
    finally:
        if process is not None:
            cleanup['precleanup_exit_code'] = process.poll()
            try:
                if process.poll() is None:
                    process.terminate()
                    cleanup['owner_terminated'] = True
                try:
                    process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    process.kill()
                    cleanup['owner_killed'] = True
                    process.wait(timeout=5)
                cleanup.update(reaped=process.returncode is not None, actual_exit_code=process.returncode)
            except BaseException as failure:
                cleanup['cleanup_error'] = repr(failure)
        write(output / 'engine-process.json', cleanup)
        if client is not None:
            write(output / 'transcript.json', client.transcript)
    try:
        require(error is None, error or 'Actual observation failed')
        require(cleanup['precleanup_exit_code'] is None and cleanup['owner_terminated'] is True and
                cleanup['owner_killed'] is False and cleanup['reaped'] is True and
                type(cleanup['actual_exit_code']) is int and cleanup['actual_exit_code'] == -15,
                'Owned engine was not reaped/unforced SIGTERM -15')
        trace = [json.loads(line) for line in (output / 'trace.jsonl').read_text().splitlines()]
        require(trace and all(row['source_commit'] == COMMIT and row['source_tree_sha256'] == TREE and
                row['candidate_files_sha256'] == CANDIDATE and int(row['process_id']) == cleanup['process_id'] and
                row['observer_enabled'] is True for row in trace), 'Actual trace source/PID/observer identity differs')
        require([int(row['sequence']) for row in trace] == list(range(1, len(trace) + 1)), 'Trace sequence has a gap')
        def events(name): return [row for row in trace if row['event'] == name]
        require(len(events('actual.host.codec.constructed')) == 1, 'Actual constructed host codec observation missing')
        contributions = events('actual.contribution.returned')
        registrations = events('actual.contribution.operation_callback.returned')
        require(len(contributions) == len(registrations) == (1 if args.mode == 'ON' else 0),
                'Actual contribution construction/registration population differs')
        if contributions:
            require(contributions[0]['observed_contribution_id'] == registrations[0]['observed_contribution_id'] ==
                    'qcae.nastran' and contributions[0]['codec_address'] == registrations[0]['codec_address'] and
                    registrations[0]['status'] == 'success', 'Real contribution callback association differs')
        arguments = events('actual.host.dispatch.arguments')
        require(arguments and all(row['codec_bound'] is (args.mode == 'ON') and
                                  row['profile_bound'] is (args.mode == 'ON') for row in arguments),
                'Real dispatch injected arguments do not match ON/OFF')
        if args.mode == 'ON':
            require(all(row['matches_constructed_host_codec'] and row['matches_constructed_host_profile'] and row['profile'] == profile
                        for row in arguments), 'ON dispatch does not use the observed actual host codec/profile')
        for name in ('actual.coordinator.export_validator.enter', 'actual.coordinator.export_validator.returned',
                     'actual.coordinator.ui.enter', 'actual.coordinator.ui.returned'):
            rows = events(name)
            require(len(rows) == (1 if args.mode == 'ON' else 0), 'Actual handler-path call population differs: ' + name)
            if rows:
                require(rows[0]['observed_contribution_id'] == 'qcae.nastran' and
                        rows[0]['actual_operation_callback_registered'] is True and rows[0]['request_id'],
                        'Actual validator/UI codec owner was not registered by the real contribution')
        if args.mode == 'ON':
            require(events('actual.coordinator.export_validator.returned')[0]['status'] == 'success',
                    'Actual export validator did not succeed before directory refusal')
        factory, selected = events('actual.render.factory.returned'), events('actual.host.RenderService.argument')
        require(len(factory) == len(selected) == 1 and factory[0]['actual_entries'] == selected[0]['actual_entries'],
                'Actual selected render factory result differs from actual RenderService argument')
        require(factory[0]['actual_called_factory'] == ('qcae::ipc::nastran_render_contributions' if args.mode == 'ON'
                                                      else 'qcae::default_render_contributions'),
                'Observed actual factory origin differs from ON/OFF')
        require(selected[0]['registry_frozen'] is True and selected[0]['actual_entries'] and
                all(row['project_callable'] is True for row in selected[0]['actual_entries']),
                'Real selected render registry is empty/unfrozen/unusable')
        require(all(row['registration_owner'] is None for row in selected[0]['actual_entries']) and
                selected[0]['owner_metadata_available'] is False, 'Do not invent render owner metadata')
        loaded = []
        expression = re.compile(r'^dyld\[(\d+)\]: <[^>]+> (/.+)$')
        for line in (output / 'engine.stderr.log').read_text(errors='replace').splitlines():
            match = expression.match(line)
            if match and int(match.group(1)) == cleanup['process_id']:
                loaded.append(str(Path(match.group(2)).resolve()))
        loaded = sorted(set(loaded))
        required_images = json.loads((HERE / 'environment-inputs.json').read_text())['required_loaded_images']
        for entry in required_images:
            require(entry['path'] in loaded and fact(entry['path']) == entry,
                    'Owned actual engine did not load the exact pinned Qt/SQLite image: ' + entry['path'])
        require(all(Path(path).is_file() or path.startswith(('/System/Library/', '/usr/lib/'))
                    for path in loaded), 'Non-system loaded image cannot be byte-sealed')
        images = [fact(path) if Path(path).is_file() else
                  {'path': path, 'bytes': None, 'sha256': None, 'scope': 'macOS shared-cache image path only'}
                  for path in loaded]
        write(output / 'actual-loaded-images.json', {'owned_process_id': cleanup['process_id'],
              'actual_DYLD_log': fact(output / 'engine.stderr.log'), 'images': images,
              'required_Qt_SQLite_exact_hash_equality': True, 'full_SDK_internal_copy_coverage': None})
        require(verify(source) == source_before and fact(engine) == engine_before and
                compilation(build, args.mode, source) == compiled, 'Source/binary/cache/compile inputs changed')
        own_inputs(args.input_index_sha256)
        result.update(actual_contribution_ids=[row['observed_contribution_id'] for row in contributions],
                      actual_render_factory=factory[0]['actual_called_factory'],
                      actual_selected_render_entries=selected[0]['actual_entries'],
                      required_loaded_image_hashes_match=True, actual_trace_rows=len(trace), actual_callee_and_argument_checks_passed=True,
                      all_source_binary_compile_inputs_before_after_equal=True, checks_passed=True)
    except BaseException as failure:
        error = error or type(failure).__name__ + ': ' + str(failure)
    result.update(error=error, actual_wrapper_exit_code=0 if error is None else 1,
                  full_SK11_BP10_R5_C3_C4_P0_pass_claim=False,
                  SDK_internal_owned_copy_coverage=None, native_GUI_or_solver_or_external_AI_claim=False)
    write(output / 'complete.json', result)
    return result['actual_wrapper_exit_code']


if __name__ == '__main__':
    raise SystemExit(main())
