# 最终六文件 QG-02 静态审查 132

结论：本切片未发现阻塞项；源码责任和权威状态可定位。未修改源码或原封存证据，未运行编译、生成器、guard、产品或产品测试。运行结果由 root 的最终四配置与 native 证据另外登记，此记录不标运行 PASS。

入口仍为 GUI/CLI/MCP → 既有 IPC dispatch → 生成 ProjectOpenInput → MemoryApplication 门面 → 同一 RecordApplication 的生命周期、host outcome、候选状态及原子持久行提交。正常打开建立新 document/epoch、清空活动文档历史；恢复保留 document/model/revision/history/操作事实并更新 epoch。现有宿主 caller+内部 operation+key 重放、normal 异 path 冲突和保存快照边界不变；omit/1 使用同一应用签名。没有新增注册业务链。

oneOf 两分支均为完整闭合 object，以不同单值 mode enum 保证互斥；normal 必须 mode/path，recover 仅允许 mode。MCP 原样发布这个 schema。version 校验发生在应用调用之前；profile 独立按显式 requires_expected_profile 元数据公布：false 可选、true 必填、缺失不公布。project.open 不公布已被宿主拒绝的 profile，material.create 保留可选 profile。

拒绝测试比较实际应用生成的持久行、generation、工程 token/payload、读写计数、RAM、历史与恢复状态，另覆盖 normal/recover 和 omit/1 重放。替身不证明 SQLite、锁或崩溃耐久性。MCP 保留原 framing/未知结果不重试检查，并新增 oneOf 有效透传、非法形状、过深、总节点超额和未知关键词回归。

MCP walker 只新增 oneOf；非空 list 最多128分支，分支同 properties/items 共用 root=0 的 depth≤16 和总 schema 节点≤128。所有既有 properties/required/type/bound/enum 和顶层闭合规则保留，参数元数据仍拒绝 const/not。128分支上限不是独立节点预算。

最终六源码 SHA-256 如下；完整行号和范围见 review.json。

| 文件 | SHA-256 |
|---|---|
| adapters/engine_api/src/ipc_api.cpp | 58dd39276c8a304b4c31eb11c41f0e7dc851281fdce52c1288b44a966036eb61 |
| apps/mcp/bridge.py | 586c2ed9ab01b8b3eb0001f954209aebaa4046edbab147cdd5f1120c171c8fa8 |
| schemas/operations/host_lifecycle.json | de0b70670e981232c2ac10cc3cc5df85d7c07238ffe6b151c7c86d0c77d6e596 |
| tests/typed_host_tests.cpp | 0bdb49b56820fce05b24d4aeaec2e5a50fb7c6b037f64480fc0cc68cc94d9005 |
| tests/mcp_protocol_tests.py | 9674affce9c9eec397ae088f6de8e1475efe88f8fe87383507b7d0eb73a63039 |
| tests/mcp_bridge_tests.py | 26330e10a6255b27b8202cf94b40cd3335591d0cf4c88cfed2f73d59db4dfc98 |

仅此六文件切片的 QG-02 结论；不宣称完整 SK-04/SK/P0、真实 solver/AI 或性能验收。
