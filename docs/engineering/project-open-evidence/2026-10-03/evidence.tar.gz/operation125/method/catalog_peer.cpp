#include "qcae/core.hpp"
#include "qcae/engine_contributions.hpp"
#include "qcae/event_stream.hpp"
#include "qcae/ipc_api.hpp"
#include "qcae/nastran_codec.hpp"
#include "qcae/nastran_contribution.hpp"
#include "qcae/operations.hpp"
#include "qcae/render_service.hpp"
#include "qcae/sqlite_store.hpp"
#include <QCoreApplication>
#include <QJsonDocument>
#include <iostream>
#include <set>
#include <stdexcept>

int main(int argc, char** argv) {
    QCoreApplication process(argc, argv);
    try {
        if (argc != 2)
            throw std::runtime_error("Expected a fresh private SQLite path");
        const auto contributions = qcae::ipc::default_engine_contributions();
        auto assembly = qcae::ipc::assemble_engine(contributions);
        const qcae::NastranCodec codec;
        const auto supports_profile = [&codec](const qcae::ProfileRef& profile) {
            return qcae::ipc::nastran_package_enabled() && profile == codec.definition().reference;
        };
        auto rows = assembly.owned_rows;
        rows.push_back(qcae::task_row_handler());
        auto store = std::make_shared<qcae::SqliteWorkspaceStore>(argv[1]);
        qcae::MemoryApplication app({}, store, supports_profile, std::move(rows), assembly.records);
        QJsonArray registered;
        const auto observe = [contribute = assembly.operations, &registered](
                                 qcae::operations::OperationRegistry& registry,
                                 qcae::RecordApplication& application,
                                 std::function<qcae::TaskService&()> tasks) {
            const auto result = contribute(registry, application, std::move(tasks));
            if (result.ok()) {
                for (const auto& descriptor : registry.descriptors()) {
                    const auto& definition = descriptor.definition;
                    registered.append(QJsonObject{
                        {"name", QString::fromStdString(definition.operation_id)},
                        {"handler_present", descriptor.available},
                        {"schema_id", QString::fromStdString(definition.schema_id)},
                        {"version", static_cast<qint64>(definition.version)},
                        {"unavailable_reason", QString::fromStdString(descriptor.unavailable_reason)}});
                }
            }
            return result;
        };
        qcae::ipc::TypedHost typed(app.record_application(), supports_profile, observe, assembly.publisher_factory);
        qcae::SelectionService selections;
        qcae::ipc::ResourceStore resources;
        qcae::ipc::RenderService render(app.record_application(), selections, resources,
                                      qcae::ipc::nastran_package_enabled()
                                          ? qcae::ipc::nastran_render_contributions()
                                          : qcae::default_render_contributions());
        qcae::ipc::EventStream events(app.record_application(), "private-introspection125");
        const QJsonObject request{{"api_version", "1.1"}, {"request_id", "public-catalog125"},
                                 {"operation", "capabilities.list"}, {"parameters", QJsonObject{}}};
        const auto capabilities = qcae::ipc::dispatch(
            app, request, {"local-user"}, qcae::ipc::nastran_package_enabled() ? &codec : nullptr,
            qcae::ipc::nastran_package_enabled() ? &codec.definition() : nullptr,
            &selections, &typed, true);
        if (capabilities.value("status") != "success")
            throw std::runtime_error("Private public catalog dispatch failed");
        std::set<QString> names;
        for (const auto& descriptor : qcae::operation_catalog)
            names.insert(QString::fromUtf8(descriptor.name.data(), static_cast<qsizetype>(descriptor.name.size())));
        for (const auto& descriptor : typed.capabilities())
            names.insert(descriptor.toObject().value("name").toString());
        QJsonArray support;
        for (const auto& name : names) {
            support.append(QJsonObject{{"name", name},
                                       {"legacy_supported", qcae::ipc::compatibility_operation_supported(name.toStdString())},
                                       {"typed_supported", typed.supports(name.toStdString())},
                                       {"render_supported", render.supports(name)},
                                       {"event_supported", events.supports(name)}});
        }
        const QJsonObject output{{"kind", "public default-assembly introspection; separate process from stock engine"},
                                 {"catalog", capabilities.value("data").toObject().value("operations")},
                                 {"registered", registered}, {"support", support},
                                 {"typed_capabilities", typed.capabilities()},
                                 {"protocol_entrypoint", "runtime.handshake"},
                                 {"solver_configuration_supplied", false}};
        std::cout << QJsonDocument(output).toJson(QJsonDocument::Compact).constData() << '\n';
        return 0;
    } catch (const std::exception& error) {
        std::cerr << error.what() << '\n';
        return 1;
    }
}
