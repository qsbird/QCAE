"""Root-only actual collector. Preparation does not run this script."""
import argparse
import hashlib
import json
from pathlib import Path
import signal
import sqlite3
import subprocess
import time
import traceback

from compare import compare

HERE = Path(__file__).resolve().parent
MANIFEST = json.loads((HERE / 'inputs.json').read_text())

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def pins():
    for item in MANIFEST['pinned_inputs']:
        assert Path(item['path']).stat().st_size == item['bytes'] and digest(item['path']) == item['sha256'], item['path']
    source = Path(MANIFEST['source_root'])
    for relative, expected in MANIFEST['source_files'].items():
        assert digest(source / relative) == expected, relative

def dump(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--peer', required=True, type=Path)
    parser.add_argument('--run-dir', required=True, type=Path)
    args = parser.parse_args()
    args.run_dir.mkdir(exist_ok=False)
    pins()
    transcript = []
    engine = None
    failure = None
    summary = None
    cleanup = None
    sock = args.run_dir / 'engine.sock'
    database = args.run_dir / 'engine.sqlite'
    log = (args.run_dir / 'engine.log').open('xb')
    def command(label, argv, stdin=None):
        started = time.time()
        monotonic = time.monotonic()
        result = subprocess.run(argv, input=stdin, capture_output=True, timeout=30, cwd=args.run_dir)
        stdout = args.run_dir / (label + '.stdout.log')
        stderr = args.run_dir / (label + '.stderr.log')
        stdout.write_bytes(result.stdout)
        stderr.write_bytes(result.stderr)
        receipt = dict(argv=argv, started_unix=started, elapsed_seconds=time.monotonic()-monotonic,
                       actual_exit=result.returncode, stdout=str(stdout), stderr=str(stderr))
        dump(args.run_dir / (label + '.json'), receipt)
        return result
    def call(operation, parameters=None, context=None, extra=None, expected_status='success', expected_code=None):
        request = dict(api_version='1.1', request_id=f'coverage125-{len(transcript)}',
                       operation=operation, parameters=parameters or {})
        if context:
            request.update(document_id=context['document_id'], document_epoch=context['document_epoch'], expected_revision=context['revision'])
        if extra:
            request.update(extra)
        label = f'ipc-{len(transcript):03}'
        result = command(label, [MANIFEST['cli'], '--socket', str(sock), '--no-start'], (json.dumps(request)+'\n').encode())
        response = json.loads(result.stdout)
        transcript.append(dict(request=request, response=response, actual_cli_exit=result.returncode))
        assert response['request_id'] == request['request_id'] and response['status'] == expected_status, response
        assert result.returncode == (0 if expected_status == 'success' else 2), result.returncode
        if expected_code:
            assert response['error']['code'] == expected_code, response
        return response.get('data', response)
    def persisted():
        with sqlite3.connect(database.as_uri()+'?mode=ro', uri=True) as connection:
            names = [row[0] for row in connection.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name")]
            return {name: connection.execute('SELECT * FROM "'+name.replace('"','""')+'"').fetchall() for name in names}
    try:
        peer_result = command('public-introspection', [str(args.peer.resolve()), str(args.run_dir / 'peer.sqlite')])
        assert peer_result.returncode == 0, 'Public introspection failed; retain raw receipt'
        peer = json.loads(peer_result.stdout)
        started = time.time()
        engine = subprocess.Popen([MANIFEST['engine'], '--socket', str(sock), '--workspace', str(database)], stdout=log, stderr=log)
        deadline = time.monotonic()+15
        while not (sock.exists() and b'QCAE engine ready:' in (args.run_dir / 'engine.log').read_bytes()):
            assert engine.poll() is None, 'Engine exited before readiness'
            assert time.monotonic() < deadline, 'Original startup15s bound exceeded'
            time.sleep(.05)
        catalog = call('capabilities.list')['operations']
        joined = compare(catalog, peer)
        info = call('project.create', {'name':'Operation coverage125'}, extra={'idempotency_key':'coverage125-create'})
        before_rows = persisted()
        before_info = call('project.current')
        before_history = call('history.list', context=info)
        call('coverage125.unregistered', context=info, expected_status='failed', expected_code='UNSUPPORTED_CAPABILITY')
        assert persisted() == before_rows and call('project.current') == before_info and call('history.list', context=info) == before_history
        material = next(row for row in catalog if row['name'] == 'material.create' and row['available'])
        assert material['version'] < 4294967295
        rejected = call('material.create', {'name':'Rejected','young_modulus':{'value':210000,'unit':'MPa'}}, info,
                        {'requested_version':4294967295,'idempotency_key':'coverage125-bad-version'},
                        expected_status='failed', expected_code='SCHEMA_UNSUPPORTED')
        assert rejected['error']['field'] == 'requested_version'
        assert persisted() == before_rows and call('project.current') == before_info and call('history.list', context=info) == before_history
        summary = dict(status='ACTUAL_CATALOG_AND_PUBLIC_BINDING_JOIN_COMPLETE', source_commit=MANIFEST['source_commit'],
                       source410=MANIFEST['source410'], joined=joined, negative_checks=2,
                       every_handler_semantic_behavior_tested=False, all_type_contracts_or_full_SK04=False,
                       current_e220_candidate_full_matrix_relabelled=False, source85_stock86_binary_scope=True)
    except BaseException as error:
        failure = dict(error=repr(error), traceback=traceback.format_exc())
    finally:
        if engine:
            alive = engine.poll() is None
            if alive:
                engine.send_signal(signal.SIGTERM)
            reaped = False
            try:
                engine.wait(timeout=10)
                reaped = True
            except subprocess.TimeoutExpired:
                pass
            cleanup = dict(pid=engine.pid, argv=engine.args, owned=True, alive_before_cleanup=alive,
                           reaped=reaped, forced_kill=False, literal_exit=engine.poll(), expected_exit=-15)
            dump(args.run_dir / 'engine-process.json', cleanup)
            if not (alive and reaped and engine.returncode == -15):
                failure = failure or dict(error='Owned engine cleanup postcondition failed')
        log.close()
        dump(args.run_dir / 'transcript.json', transcript)
        try:
            pins()
        except BaseException as error:
            failure = failure or dict(error=repr(error), scope='after source/input pin check')
        if failure:
            dump(args.run_dir / 'failure.json', failure)
        elif summary:
            dump(args.run_dir / 'complete.json', summary)
    return 1 if failure else 0

if __name__ == '__main__':
    raise SystemExit(main())
