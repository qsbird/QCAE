"""Pure catalog join; import does not execute engine, compiler or any product."""
def unique(rows, name):
    result = {}
    for row in rows:
        identity = row.get("name")
        if not isinstance(identity, str) or not identity or identity in result:
            raise ValueError(f"{name}: missing/duplicate operation identity")
        result[identity] = row
    return result


def compare(actual_catalog, peer):
    actual = unique(actual_catalog, "actual IPC")
    public = unique(peer["catalog"], "public peer")
    if actual != public:
        raise ValueError("Actual IPC catalog differs from independently instantiated default host")
    registered = unique(peer["registered"], "actual public registry descriptors")
    supports = unique(peer["support"], "public support predicates")
    typed = unique(peer["typed_capabilities"], "actual TypedHost catalog")
    result = []
    for name, declaration in actual.items():
        route = supports.get(name)
        if route is None:
            raise ValueError(f"No introspection route for {name}")
        binding = registered.get(name)
        available = declaration.get("available")
        if not isinstance(available, bool):
            raise ValueError(f"Availability is not boolean: {name}")
        if binding is not None:
            if binding["handler_present"] != available:
                raise ValueError(f"Declared availability disagrees with real handler bool: {name}")
            if binding["version"] != declaration.get("version") or binding["schema_id"] != declaration.get("schema_id"):
                raise ValueError(f"Installed registry contract disagrees with IPC: {name}")
        bound = (route["event_supported"] or route["render_supported"] or
                 route["legacy_supported"] or
                 (route["typed_supported"] and name in typed and
                  (binding is None or binding["handler_present"])))
        if available and not bound:
            raise ValueError(f"Declared available operation has no observed public host binding: {name}")
        result.append({"name": name, "available": available, "public_binding_observed": bool(bound),
                       "registered_generated_contract": binding is not None,
                       "schema_id": declaration.get("schema_id"), "version": declaration.get("version"),
                       "parameters_schema_present": "parameters_schema" in declaration,
                       "legacy_symbolic_input_type": declaration.get("input_type")})
    available = [row for row in result if row["available"]]
    return {"scope": "Actual catalog/public binding join; not execution of every handler or full SK04",
            "operations": result, "declared_population": len(result),
            "available_population": len(available),
            "available_generated_registry_contracts": sum(row["registered_generated_contract"] for row in available),
            "available_without_observed_binding": 0,
            "protocol_entrypoint_separate": peer["protocol_entrypoint"],
            "full_registered_type_contract_ratio": "NOT_ESTABLISHED_FOR_HANDWRITTEN_ROUTES"}
