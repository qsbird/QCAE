#!/usr/bin/env python3
"""Actual ROOT commands for sealed source85 catalog introspection inputs."""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import time

PREP = Path('/private/tmp/qcae-operation-coverage125')
OUT = Path(__file__).resolve().parent
BUILD = Path('/private/tmp/qcae-operation-coverage125-build')
ATTEMPT = OUT / 'attempt-01'
ATTEMPT.mkdir()
assert not BUILD.exists()
index = json.loads((PREP / 'immutable-index.json').read_text())
commands = json.loads((PREP / 'root-commands.json').read_text())
manifest = json.loads((PREP / 'inputs.json').read_text())
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def fact(path):
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': sha(path)}
def write(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')
index_fact = fact(PREP / 'immutable-index.json')
def guard():
    assert fact(PREP / 'immutable-index.json') == index_fact
    for row in index['entries']:
        path = PREP / row['name']
        assert path.stat().st_size == row['bytes'] and sha(path) == row['sha256'], row['name']
    for name, expected in manifest['source_files'].items():
        assert sha(Path(manifest['source_root']) / name) == expected, name
    for row in manifest['pinned_inputs']:
        path = Path(row['path'])
        assert path.stat().st_size == row['bytes'] and sha(path) == row['sha256'], row['path']
guard()
method = fact(Path(__file__).resolve())
environment = os.environ.copy()
for key in ['ASAN_OPTIONS', 'UBSAN_OPTIONS', 'LSAN_OPTIONS', 'DYLD_INSERT_LIBRARIES', 'DYLD_LIBRARY_PATH', 'DYLD_PRINT_LIBRARIES', 'QT_QPA_PLATFORM']:
    environment.pop(key, None)
BUILD.mkdir()
for label in ['configure', 'build', 'collect']:
    guard()
    started = time.time()
    stdout, stderr = ATTEMPT / (label + '.stdout.log'), ATTEMPT / (label + '.stderr.log')
    with stdout.open('xb') as out, stderr.open('xb') as err:
        result = subprocess.run(commands[label], env=environment, stdout=out, stderr=err)
    guard()
    write(ATTEMPT / (label + '.json'), {
        'actual_exit_code': result.returncode, 'argv': commands[label],
        'started_unix': started, 'finished_unix': time.time(),
        'stdout': fact(stdout), 'stderr': fact(stderr), 'source_and_sealed_inputs_unchanged': True})
    print(json.dumps({'command': label, 'actual_exit_code': result.returncode}), flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)
    if label == 'build':
        assert not re.findall(r'(?m)^.*\bwarning:.*$', stdout.read_text(errors='replace') + stderr.read_text(errors='replace'))
compile_commands = json.loads((BUILD / 'compile_commands.json').read_text())
assert all('-std=c++20' in row['command'] and '-std=gnu++20' not in row['command'] for row in compile_commands)
guard()
write(ATTEMPT / 'complete.json', {
    'actual_exit_code': 0, 'method': method, 'prepared_inputs_index': index_fact,
    'compiler_warnings': [], 'strict_cpp20': True,
    'scope': 'Fresh public introspection peer and stock86 actual IPC catalog join from immutable source85; no whole-handler or full SK04 acceptance.'})
