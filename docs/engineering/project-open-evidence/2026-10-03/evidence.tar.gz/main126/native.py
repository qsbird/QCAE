#!/usr/bin/env python3
"""ROOT-run current-binary project.open contract checks with real SQLite IPC."""
import hashlib
import json
from pathlib import Path
import signal
import sqlite3
import subprocess
import time
import traceback

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'native-01'
ENGINE = Path('/private/tmp/qcae-project-open-checks126-successor02-builds/sqlite-ipc/qcae-engine')
CLI = ENGINE.with_name('qcae-cli')
SOURCE = Path('/private/tmp/qcae-framework-delivery80')
CANDIDATE = ROOT / 'attempt-01/candidate.json'
DATABASE = OUT / 'workspace.sqlite'
OUT.mkdir()
candidate = json.loads(CANDIDATE.read_text())
transcript, processes = [], []
row_snapshots, binary_inputs = [], None
process, log, socket = None, None, None
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def fact(path):
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': sha(path)}
def dump(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True)+'\n')
def guard():
    assert candidate['candidate_files'] == {name:sha(SOURCE/name) for name in candidate['candidate_files']}
    if binary_inputs is not None:
        assert binary_inputs == {'engine':fact(ENGINE), 'cli':fact(CLI)}, 'Native binaries changed'
def rows():
    with sqlite3.connect(DATABASE.as_uri()+'?mode=ro', uri=True) as database:
        names = [row[0] for row in database.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name")]
        result = {name:database.execute('SELECT * FROM "'+name.replace('"','""')+'"').fetchall() for name in names}
    encoded = {name:[[{'blob_hex':value.hex()} if isinstance(value, bytes) else value for value in row]
                     for row in values] for name,values in result.items()}
    row_snapshots.append({'ordinal':len(row_snapshots), 'after_requests':len(transcript), 'tables':encoded})
    dump(OUT/'row-snapshots.json',row_snapshots)
    return result
def call(operation, parameters=None, context=None, key=None, version=None, status='success', code=None):
    request = {'api_version':'1.1','request_id':f'project-open-native126-{len(transcript)}',
               'operation':operation,'parameters':parameters or {}}
    if context:
        request.update(document_id=context['document_id'], document_epoch=context['document_epoch'], expected_revision=context['revision'])
    if key:
        request['idempotency_key'] = key
    if version is not None:
        request['requested_version'] = version
    result = subprocess.run([str(CLI),'--socket',str(socket),'--no-start'], input=json.dumps(request)+'\n', text=True, capture_output=True, timeout=15)
    response = json.loads(result.stdout)
    transcript.append({'request':request,'response':response,'actual_cli_exit_code':result.returncode,'stdout':result.stdout,'stderr':result.stderr})
    dump(OUT/'transcript.json',transcript)
    assert response['request_id']==request['request_id'] and response['status']==status, response
    assert result.returncode==(0 if status=='success' else 2), result.returncode
    if code:
        assert response['error']['code']==code, response
    return response.get('data',response)
def stop():
    global process, log
    if process is not None:
        alive = process.poll() is None
        if alive:
            process.send_signal(signal.SIGTERM)
        process.wait(timeout=10)
        processes.append({'pid':process.pid,'argv':process.args,'owned':True,'alive_before_cleanup':alive,
                          'literal_exit_code':process.returncode,'reaped':True,'forced_kill':False})
        dump(OUT/'processes.json',processes)
        assert alive and process.returncode==-15
        process=None
    if log is not None:
        log.close()
        log=None
def start(number):
    global process, log, socket
    socket=OUT/f'engine-{number}.sock'
    log_path=OUT/f'engine-{number}.log'
    log=log_path.open('w+')
    process=subprocess.Popen([str(ENGINE),'--socket',str(socket),'--workspace',str(DATABASE)],stdout=log,stderr=log)
    deadline=time.monotonic()+15
    while not socket.exists():
        assert process.poll() is None and time.monotonic()<deadline
        time.sleep(.05)

failure=None
try:
    guard()
    assert (ROOT/'attempt-01/complete.json').is_file(), 'Fresh candidate regression must finish first'
    binary_inputs = {'engine':fact(ENGINE), 'cli':fact(CLI)}
    start(1)
    capabilities=call('capabilities.list')
    declaration=next(row for row in capabilities['operations'] if row['name']=='project.open')
    assert declaration['schema_id']=='qcae.operation.project.open.v1' and declaration['version']==1
    assert declaration['wire_input_type']=='ProjectOpenInput' and declaration['wire_output_type']=='DocumentInfo'
    assert declaration['available'] is True
    info=call('project.create',{'name':'Native project.open126'},key='native-create')
    call('material.create',{'name':'Steel','young_modulus':{'value':210000,'unit':'MPa'}},info,'native-material')
    info=call('project.current')
    original_entities=call('entity.query',{'kind':'material','limit':10},info)['entities']
    assert len(original_entities)==1
    file=OUT/'contract.qcae'
    saved=call('project.save',{'path':str(file)},info,'native-save')
    original_file=sha(file)
    call('project.close',{'policy':'keep_recovery'},saved,'native-keep')
    baseline=rows()
    bad_inputs=[
        ({'mode':'recover'},2,'SCHEMA_UNSUPPORTED'),
        ({'mode':'recover'},0,'INVALID_INPUT'),
        ({'mode':'recover'},'1','INVALID_INPUT'),
        ({'mode':'recover'},True,'INVALID_INPUT'),
        ({'mode':'recover'},1.5,'INVALID_INPUT'),
        ({'mode':'recover'},4294967296,'INVALID_INPUT'),
        ({'mode':'normal'},1,'INVALID_INPUT'),
        ({'mode':'recover','path':str(file)},1,'INVALID_INPUT'),
        ({'mode':'normal','path':''},1,'INVALID_INPUT'),
        ({'mode':'recover','unknown':True},1,'INVALID_INPUT'),
    ]
    for index,(parameters,version,code) in enumerate(bad_inputs):
        rejected=call('project.open',parameters,key=f'native-reject-{index}',version=version,status='failed',code=code)
        if code=='SCHEMA_UNSUPPORTED':
            assert rejected['error']['field']=='requested_version'
        assert rows()==baseline and sha(file)==original_file, 'Rejected contract mutated actual persistent state'
    recovered=call('project.open',{'mode':'recover'},key='native-reject-0',version=1)
    assert recovered['document_id']==info['document_id'] and recovered['document_epoch']!=info['document_epoch']
    assert call('entity.query',{'kind':'material','limit':10},recovered)['entities']==original_entities
    history=call('history.list',{},recovered)
    assert len(history['items'])==1
    recovered_rows=rows()
    assert call('project.open',{'mode':'recover'},key='native-reject-0')==recovered
    assert call('operations.get',{'lookup_scope':'host','original_operation':'project.open',
        'original_mode':'recover','idempotency_key':'native-reject-0'})==recovered
    assert rows()==recovered_rows, 'Recovered key replay/lookup mutated SQLite rows'
    call('project.close',{'policy':'discard'},recovered,'native-discard')
    reopened=call('project.open',{'mode':'normal','path':str(file)},key='native-reject-9',version=1)
    assert reopened['document_id']!=recovered['document_id'] and reopened['document_epoch']!=recovered['document_epoch']
    assert reopened['revision']=='0' and call('history.list',{},reopened)['items']==[]
    assert call('entity.query',{'kind':'material','limit':10},reopened)['entities']==original_entities
    reopened_rows=rows()
    assert call('project.open',{'mode':'normal','path':str(file)},key='native-reject-9')==reopened
    assert call('operations.get',{'lookup_scope':'host','original_operation':'project.open',
        'original_mode':'normal','idempotency_key':'native-reject-9'})==reopened
    assert rows()==reopened_rows, 'Normal key replay/lookup mutated SQLite rows'
    second_file=OUT/'other-contract.qcae'
    second_file.write_bytes(file.read_bytes())
    call('project.open',{'mode':'normal','path':str(second_file)},key='native-reject-9',version=1,
        status='conflict',code='IDEMPOTENCY_KEY_CONFLICT')
    assert rows()==reopened_rows, 'Same normal key with another path mutated SQLite rows'
    call('project.close',{'policy':'keep_recovery'},reopened,'native-keep-reopened')
    stop()
    start(2)
    after_restart=call('project.open',{'mode':'recover'},key='native-restart-recover',version=1)
    assert after_restart['document_id']==reopened['document_id'] and after_restart['document_epoch']!=reopened['document_epoch']
    assert call('entity.query',{'kind':'material','limit':10},after_restart)['entities']==original_entities
    assert after_restart['revision']=='0' and call('history.list',{},after_restart)['items']==[]
    assert sha(file)==original_file
    guard()
    stop()
    dump(OUT/'complete.json',{'actual_exit_code':0,'candidate':fact(CANDIDATE),
        'engine':fact(ENGINE),'cli':fact(CLI),'declaration':declaration,
        'binary_inputs_before_after_equal':True,'method':fact(Path(__file__).resolve()),
        'raw_row_snapshots':fact(OUT/'row-snapshots.json'),
        'rejected_input_cases':len(bad_inputs),'actual_request_count':len(transcript),
        'persistent_rows_unchanged_for_all_rejections':True,'same_key_valid_recovery_after_rejection':True,
        'omit_explicit_version_replays_and_host_lookups_keep_rows':True,
        'same_normal_key_other_path_conflict_keeps_rows':True,
        'normal_open_new_identity_empty_history':True,'real_engine_restart_sqlite_recovery':True,
        'engine_pids':[row['pid'] for row in processes],
        'scope':'Current candidate project.open real SQLite/native IPC contract and lifecycle; one material, not full M or historical migration.'})
    print('Actual project.open native126: passed input/version atomic rejection, normal/recover and real engine restart',flush=True)
except BaseException as error:
    failure={'actual_exit_code':1,'error':repr(error),'traceback':traceback.format_exc()}
finally:
    if process is not None:
        stop()
    if failure:
        dump(OUT/'failure.json',failure)
if failure:
    raise SystemExit(1)
