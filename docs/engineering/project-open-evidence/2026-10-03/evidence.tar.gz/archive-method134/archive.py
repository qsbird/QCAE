#!/usr/bin/env python3
"""Root-only deterministic text archive; no compiler, source guard or product execution."""
from __future__ import annotations

import argparse
import gzip
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import stat
import tarfile
import traceback

HERE = Path(__file__).resolve().parent
TMP = Path('/private/tmp')
DESTINATION = Path('docs/engineering/project-open-evidence/2026-10-03')
MAX_MEMBERS = 300  # Root explicitly authorized this ceiling after the initial 250 target.
CONFIGS = ('core', 'local', 'sqlite-ipc', 'sanitized-typed-host')
TEXT_SUFFIXES = {'.py', '.cpp', '.hpp', '.cmake', '.txt', '.md', '.json', '.jsonl',
                 '.log', '.diff', '.patch', '.csv'}


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def selection():
    """Explicit individual text files only; never enumerate or copy a build tree."""
    entries, commands, generated_headers = [], [], set()

    def add(group, root, relative, stored=None):
        origin = root / relative
        entries.append((origin, group + '/' + (stored or relative)))

    def names(group, root, relatives):
        for relative in relatives:
            add(group, root, relative)

    def triple(group, root, command):
        paths = [root / (command + suffix)
                 for suffix in ('.json', '.stdout.log', '.stderr.log')]
        for path in paths:
            add(group, root, path.name)
        commands.append(tuple(paths))

    def directory_command(group, root, relative):
        base = root / relative
        names(group + '/' + relative, base, ('receipt.json', 'stdout.log', 'stderr.log'))
        commands.append((base / 'receipt.json', base / 'stdout.log', base / 'stderr.log'))

    current = TMP / 'qcae-project-open-checks126-successor02'
    names('main126', current, ('run.py', 'native.py'))
    attempt = current / 'attempt-01'
    names('main126/attempt-01', attempt, ('candidate.json', 'complete.json'))
    for config in CONFIGS:
        for command in ('configure', 'build', 'inventory', 'ctest'):
            triple('main126/attempt-01', attempt, config + '-' + command)
        names('main126/attempt-01', attempt,
              (config + '-complete.json', config + '-LastTest.log'))
    names('main126/native-01', current / 'native-01',
          ('complete.json', 'transcript.json', 'processes.json', 'row-snapshots.json',
           'engine-1.log', 'engine-2.log'))

    for folder, group, commands_needed in (
            ('qcae-project-open-checks126', 'retained126', ('local-build',)),
            ('qcae-project-open-checks126-successor01', 'retained126-successor01',
             ('local-build', 'local-ctest'))):
        root = TMP / folder
        names(group, root, ('run.py',))
        names(group + '/attempt-01', root / 'attempt-01', ('candidate.json',))
        for command in commands_needed:
            triple(group + '/attempt-01', root / 'attempt-01', command)

    patch = TMP / 'qcae-project-open-contract125'
    names('original-patch125', patch,
          ('project-open-contract.patch', 'immutable-index.json', 'delivery.json', 'README.md',
           'candidate/schemas/operations/host_lifecycle.json',
           'candidate/adapters/engine_api/src/ipc_api.cpp',
           'candidate/tests/typed_host_tests.cpp'))

    op = TMP / 'qcae-operation-coverage125'
    names('operation125/method', op,
          ('catalog_peer.cpp', 'CMakeLists.txt', 'collect.py', 'compare.py', 'inputs.json',
           'static-map.json', 'immutable-index.json'))
    op_root = TMP / 'qcae-operation-coverage-root126'
    names('operation125/root126', op_root, ('run.py',))
    names('operation125/root126/attempt-01', op_root / 'attempt-01', ('complete.json',))
    for command in ('configure', 'build', 'collect'):
        triple('operation125/root126/attempt-01', op_root / 'attempt-01', command)
    op_actual = TMP / 'qcae-opcov125-run01'
    names('operation125/actual', op_actual,
          ('complete.json', 'transcript.json', 'engine-process.json', 'engine.log'))
    triple('operation125/actual', op_actual, 'public-introspection')
    for number in range(10):
        triple('operation125/actual', op_actual, f'ipc-{number:03d}')

    profile = TMP / 'qcae-profile-variants125'
    successor = TMP / 'qcae-profile-variants125-successor01'
    directory_command('profile125/retained-first-failure',
                      profile / 'attempts/compiled125-01', 'baseline-call')
    names('profile125/retained-method', profile,
          ('run.py', 'peer/peer.cpp', 'peer/CMakeLists.txt', 'format-only.diff',
           'semantic-only.diff', 'inputs.json', 'method.json', 'seal.json'))
    names('profile125/final-method', successor,
          ('run.py', 'peer/peer.cpp', 'peer/CMakeLists.txt', 'README.md',
           'expected-export-notes.json', 'final-peer.diff', 'final-runner.diff',
           'final-pure-checks.json', 'final-method.json', 'final-seal.json'))
    names('profile125/diagnostic-method', successor,
          ('diagnostic.cpp', 'diagnostic.py', 'diagnostic-inputs.json'))
    diagnostic = successor / 'diagnostic-01'
    for command in ('compile', 'link', 'call'):
        triple('profile125/diagnostic-01', diagnostic, command)
    names('profile125/diagnostic-01', diagnostic,
          ('result.json', 'observation/export-report.json'))
    profile_actual = successor / 'attempts/compiled125-successor01'
    names('profile125/actual', profile_actual, ('comparison.json',))
    for role in ('baseline', 'format', 'semantic'):
        for command in ('configure', 'build-command', 'call'):
            directory_command('profile125/actual', profile_actual, role + '-' + command)
        names('profile125/actual', profile_actual,
              (role + '-actual.json', role + '-observation/export-report.json'))
        header = (profile_actual / (role + '-build') /
                  'qcae/profiles/nastran/generated/qcae/nastran_digest.hpp')
        generated_headers.add(header)
        entries.append((header, 'profile125/actual/headers/' + role + '/nastran_digest.hpp'))

    host = TMP / 'qcae-host-binding125'
    names('host125/method', host,
          ('immutable-index.json', 'handoff-final.json', 'CMakeLists.txt',
           'prepared-originals.cmake', 'execute.py', 'native.py', 'verify_source.py',
           'observer.hpp', 'observer.cpp', 'static-whitelist.json', 'private-observer.patch',
           'source412-manifest.json', 'environment-inputs.json'))
    for mode in ('on', 'off'):
        build_action = host / 'actions' / ('build-' + mode + '-01')
        for command in ('configure-' + mode, 'build-' + mode):
            triple('host125/actions/build-' + mode + '-01', build_action, command)
        observe_action = host / 'actions' / ('observe-' + mode + '-01')
        triple('host125/actions/observe-' + mode + '-01', observe_action, 'observe-' + mode)
        names('host125/actual/' + mode + '-01', host / 'results' / (mode + '-01'),
              ('complete.json', 'trace.jsonl', 'transcript.json', 'inputs-before.json',
               'actual-loaded-images.json', 'engine-process.json', 'engine-start.json',
               'engine.stdout.log', 'engine.stderr.log'))

    for folder, group, markdown in (
            ('qcae-operation-review127', 'reviews/127', 'review.md'),
            ('qcae-profile-review130', 'reviews/130', 'review.md'),
            ('qcae-host-binding-runtime-review131', 'reviews/131', 'README.md'),
            ('qcae-project-open-final-review132', 'reviews/132', 'review.md')):
        names(group, TMP / folder, ('review.json', markdown))
    names('reviews/131', TMP / 'qcae-host-binding-runtime-review131',
          ('necessary-request-joins.csv',))
    entries.append((Path(__file__).resolve(), 'archive-method134/archive.py'))
    return entries, commands, generated_headers


def load_json(payloads, path):
    return json.loads(payloads[path].decode('utf-8'))


def read_inputs(entries, generated_headers):
    payloads, members = {}, []
    require(0 < len(entries) <= MAX_MEMBERS, 'Selected member limit exceeded')
    require(len({name for _, name in entries}) == len(entries), 'Duplicate stored member')
    require(len({path for path, _ in entries}) == len(entries), 'Duplicate origin')
    for path, stored in entries:
        require(path.is_absolute() and path.is_file() and not path.is_symlink(),
                'Origin must be an existing regular nonsymlink file: ' + str(path))
        require(stat.S_ISREG(path.stat().st_mode), 'Nonregular origin: ' + str(path))
        relative = PurePosixPath(stored)
        require(not relative.is_absolute() and '..' not in relative.parts, 'Unsafe tar name')
        require(path.suffix in TEXT_SUFFIXES or path.name == 'CMakeLists.txt',
                'Nontext origin: ' + str(path))
        require(not any(token in path.name.lower() for token in
                        ('.sqlite', '.qcae', '.sock', '.lock', '.dylib', '.tar', '.bin')),
                'Forbidden database/binary/archive/lock origin: ' + str(path))
        actual_host_build = any(path.is_relative_to(TMP / 'qcae-host-binding125' / name)
                                for name in ('build-on-01', 'build-off-01'))
        require(path in generated_headers or not (
            actual_host_build or any(part == 'CMakeFiles' or part.endswith(('-build', '-builds'))
                                     for part in path.parts)),
                'Build tree file outside three exact text headers')
        data = path.read_bytes()
        data.decode('utf-8')
        require(b'\0' not in data, 'NUL/nontext origin: ' + str(path))
        payloads[path] = data
        members.append({'origin_absolute': str(path), 'stored_relative': stored,
                        'raw_bytes': len(data), 'raw_sha256': digest(data)})
    return payloads, members


def validate_terminal_and_commands(payloads, commands):
    """Use only captured receipts; never import a runner or invoke a source guard."""
    main = TMP / 'qcae-project-open-checks126-successor02'
    complete = load_json(payloads, main / 'attempt-01/complete.json')
    require(complete.get('actual_exit_code') == 0, 'Main four-config run not terminal0')
    runtime = {}
    for config in CONFIGS:
        result = load_json(payloads, main / 'attempt-01' / (config + '-complete.json'))
        require(result.get('actual_exit_code') == 0, 'Configuration not terminal0: ' + config)
        runtime[config] = {'executed_count': result['executed_count'],
                           'executed_test_names': result['executed_test_names'],
                           'sanitizer_scope': result['sanitizer_scope']}
    native = load_json(payloads, main / 'native-01/complete.json')
    require(native.get('actual_exit_code') == 0, 'Current SQLite IPC run not terminal0')
    require(len(load_json(payloads, main / 'native-01/transcript.json')) ==
            native['actual_request_count'], 'Native transcript count differs')
    for row in load_json(payloads, main / 'native-01/transcript.json'):
        require('stdout' in row and 'stderr' in row and
                type(row.get('actual_cli_exit_code')) is int,
                'Native CLI transcript must retain literal stdout/stderr/exit')
    for row in load_json(payloads, main / 'native-01/processes.json'):
        require(row['owned'] and row['alive_before_cleanup'] and row['reaped'] and
                not row['forced_kill'] and row['literal_exit_code'] == -15,
                'Native owned process cleanup not unforced/reaped -15')
    require(load_json(payloads, TMP / 'qcae-operation-coverage-root126/attempt-01/complete.json')
            .get('actual_exit_code') == 0, 'Operation peer root run not terminal0')
    require(load_json(payloads, TMP / 'qcae-profile-variants125-successor01/attempts/'
                      'compiled125-successor01/comparison.json').get('actual_passed') is True,
            'Three profile variant comparison not terminal success')
    for mode in ('on', 'off'):
        base = TMP / 'qcae-host-binding125/results' / (mode + '-01')
        require(load_json(payloads, base / 'complete.json').get('actual_wrapper_exit_code') == 0,
                'Host observation not terminal0: ' + mode)
        process = load_json(payloads, base / 'engine-process.json')
        require(process['precleanup_exit_code'] is None and process['owner_terminated'] and
                not process['owner_killed'] and process['reaped'] and
                process['actual_exit_code'] == -15, 'Host cleanup not unforced/reaped -15')
    failed = {
        TMP / 'qcae-project-open-checks126/attempt-01/local-build.json',
        TMP / 'qcae-project-open-checks126-successor01/attempt-01/local-ctest.json',
        TMP / 'qcae-profile-variants125/attempts/compiled125-01/baseline-call/receipt.json',
        TMP / 'qcae-profile-variants125-successor01/diagnostic-01/call.json',
    }
    command_facts = []
    for receipt, stdout, stderr in commands:
        record = load_json(payloads, receipt)
        code = next((record[key] for key in ('actual_exit_code', 'actual_exit', 'exit_code')
                     if key in record), None)
        require(type(code) is int, 'Receipt missing literal exit: ' + str(receipt))
        if receipt in failed:
            require(code != 0, 'Retained historical failure was relabeled success')
        elif receipt.name.startswith('ipc-'):
            response = json.loads(payloads[stdout].decode('utf-8'))
            require(code == (0 if response.get('status') == 'success' else 2),
                    'CLI exit does not match its actual response')
            if code == 2:
                require(response.get('status') == 'failed' and response.get('error', {}).get('code')
                        in ('UNSUPPORTED_CAPABILITY', 'SCHEMA_UNSUPPORTED'),
                        'Unexpected negative operation-catalog response')
        else:
            require(code == 0, 'Required current command not exit0: ' + str(receipt))
        for key, origin in (('stdout', stdout), ('stderr', stderr)):
            raw = record.get(key)
            if isinstance(raw, dict):
                require(raw['path'] == str(origin) and raw['bytes'] == len(payloads[origin]) and
                        raw['sha256'] == digest(payloads[origin]),
                        'Raw stdio receipt hash differs: ' + str(origin))
            else:
                require(raw == str(origin), 'Raw stdio path differs: ' + str(origin))
        command_facts.append({'receipt_origin_absolute': str(receipt), 'literal_exit': code,
                              'historical_failure_retained': receipt in failed})
    return runtime, native, command_facts


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo-root', type=Path, required=True)
    parser.add_argument('--attempt-id', required=True)
    parser.add_argument('--execute', action='store_true', required=True)
    args = parser.parse_args()
    require(args.attempt_id.isdigit(), 'Use a numeric fresh attempt ID')
    receipt_path = HERE / ('execution-' + args.attempt_id + '.json')
    require(not receipt_path.exists(), 'Never overwrite an archive action receipt')
    repo = args.repo_root.resolve()
    destination = repo / DESTINATION
    archive_path = destination / 'evidence.tar.gz'
    index_path = destination / 'archive-index.json'
    require((repo / 'docs/engineering').is_dir(), 'Repository engineering directory missing')
    require(not archive_path.exists() and not index_path.exists(), 'Never overwrite an archive')
    error, result = None, {'product_or_guard_executions': 0}
    try:
        entries, commands, generated_headers = selection()
        payloads, members = read_inputs(entries, generated_headers)
        runtime, native, command_facts = validate_terminal_and_commands(payloads, commands)
        destination.mkdir(parents=True, exist_ok=True)
        with archive_path.open('xb') as raw:
            with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0, compresslevel=9) as zipped:
                with tarfile.open(fileobj=zipped, mode='w|', format=tarfile.USTAR_FORMAT) as archive:
                    for member in sorted(members, key=lambda item: item['stored_relative']):
                        data = payloads[Path(member['origin_absolute'])]
                        info = tarfile.TarInfo(member['stored_relative'])
                        info.size, info.mtime, info.mode = len(data), 0, 0o444
                        info.uid, info.gid, info.uname, info.gname = 0, 0, '', ''
                        archive.addfile(info, io.BytesIO(data))
        expected = {row['stored_relative']: row for row in members}
        with tarfile.open(archive_path, 'r:gz') as archive:
            actual = archive.getmembers()
            require(len(actual) == len(members) <= MAX_MEMBERS, 'Tar member count differs')
            for info in actual:
                require(info.isfile() and info.name in expected and info.mtime == 0 and
                        info.mode == 0o444 and info.uid == info.gid == 0, 'Tar metadata differs')
                row = expected[info.name]
                data = archive.extractfile(info).read()
                require(len(data) == row['raw_bytes'] and digest(data) == row['raw_sha256'],
                        'Archived raw bytes differ: ' + info.name)
        for row in members:
            data = Path(row['origin_absolute']).read_bytes()
            require(len(data) == row['raw_bytes'] and digest(data) == row['raw_sha256'],
                    'Original changed during archive: ' + row['origin_absolute'])
        aggregate = archive_path.read_bytes()
        index = {'kind': 'Selected original text evidence, not new runtime acceptance',
                 'archive': {'stored_relative': 'evidence.tar.gz', 'bytes': len(aggregate),
                             'sha256': digest(aggregate), 'gzip_mtime': 0, 'tar_mode': '0444',
                             'tar_mtime': 0, 'member_count': len(members)},
                 'member_ceiling': MAX_MEMBERS, 'members': sorted(members, key=lambda r: r['stored_relative']),
                 'all_selected_original_bytes_sha256_equal_before_after': True,
                 'actual_main_runtime_support': runtime,
                 'actual_main_native_request_count': native['actual_request_count'],
                 'actual_main_native_rejected_cases': native['rejected_input_cases'],
                 'literal_command_receipts': command_facts,
                 'scope_limits': ['Selective text archive; unselected referenced artifacts remain at their origins.',
                                  'No database, lock, socket, binary, object, source archive, build tree or solver output copied.',
                                  'Exactly three named generated profile headers are copied as text, not build trees.',
                                  'source85 stock op coverage, e220 instrumented host/profile and later current project.open source scopes remain distinct.',
                                  'Runtime completed before later README/docs changes; no old source guard called here.',
                                  'Private host derivative; render owner null; no independent validator registry.',
                                  'No full SK/BP/P0, GUI, solver, AI or performance conclusion is created by archiving.'],
                 'readability_quality_gate': 'Not executed or predicted by archiver; root retains actual separate review/gate outcomes.',
                 'product_or_guard_executions': 0}
        with index_path.open('x') as stream:
            json.dump(index, stream, indent=2)
            stream.write('\n')
        result.update(archive=str(archive_path), archive_sha256=digest(aggregate),
                      archive_bytes=len(aggregate), members=len(members), index=str(index_path),
                      index_sha256=digest(index_path.read_bytes()), originals_unchanged=True)
    except BaseException as failure:
        error = {'exception': repr(failure), 'traceback': traceback.format_exc()}
    result.update(actual_exit_code=0 if error is None else 1, error=error)
    with receipt_path.open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps(result, sort_keys=True))
    return result['actual_exit_code']


if __name__ == '__main__':
    raise SystemExit(main())
