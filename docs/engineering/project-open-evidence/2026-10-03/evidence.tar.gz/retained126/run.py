#!/usr/bin/env python3
"""ROOT-run fresh checks for the bounded project.open wire-contract change."""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import time

SOURCE = Path('/private/tmp/qcae-framework-delivery80')
OUT = Path(__file__).resolve().parent
BUILD = Path('/private/tmp/qcae-project-open-checks126-builds')
BASELINE = Path('/private/tmp/qcae-core-compatibility-checks120/attempt-01/candidate.json')
CMAKE = '/opt/homebrew/Cellar/cmake/4.3.0/bin/cmake'
CTEST = '/opt/homebrew/Cellar/cmake/4.3.0/bin/ctest'
PYTHON = '/Library/Frameworks/Python.framework/Versions/3.14/bin/python3.14'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def fact(path):
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': sha(path)}

def write(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')

assert not BUILD.exists(), 'Use a fresh build directory'
attempt = OUT / 'attempt-01'
attempt.mkdir()
baseline = json.loads(BASELINE.read_text())['candidate_files']
assert len(baseline) == 412
inputs = {name: sha(SOURCE / name) for name in baseline}
changed = {name for name in baseline if inputs[name] != baseline[name]}
assert changed == {'adapters/engine_api/src/ipc_api.cpp', 'tests/typed_host_tests.cpp'}, changed
new_file = 'schemas/operations/host_lifecycle.json'
inputs[new_file] = sha(SOURCE / new_file)
base_head = subprocess.check_output(['git', '-C', str(SOURCE), 'rev-parse', 'HEAD'], text=True).strip()
assert base_head == 'e2207ed629c629452bac78dac2c3a4f21abccf4e'
write(attempt / 'candidate.json', {
    'base_head': base_head, 'baseline412': fact(BASELINE),
    'changed_baseline_files': sorted(changed), 'new_source_file': new_file,
    'candidate_files': inputs, 'candidate_files_count': len(inputs),
    'candidate_files_sha256': hashlib.sha256(json.dumps(inputs, sort_keys=True, separators=(',', ':')).encode()).hexdigest(),
    'scope': 'Bounded project.open generated input and shared discovery/version decoder; no other product source changes.'})
method = fact(Path(__file__).resolve())

def guard():
    assert inputs == {name: sha(SOURCE / name) for name in inputs}, 'Candidate source changed'
    assert fact(Path(__file__).resolve()) == method, 'Method changed'
    assert subprocess.check_output(['git', '-C', str(SOURCE), 'rev-parse', 'HEAD'], text=True).strip() == base_head

def command(name, argv, environment=None):
    guard()
    env = os.environ.copy()
    for key in ['ASAN_OPTIONS', 'UBSAN_OPTIONS', 'LSAN_OPTIONS', 'DYLD_INSERT_LIBRARIES',
                'DYLD_LIBRARY_PATH', 'DYLD_PRINT_LIBRARIES', 'QT_QPA_PLATFORM']:
        env.pop(key, None)
    env.update(environment or {})
    start = time.time()
    stdout, stderr = attempt / (name + '.stdout.log'), attempt / (name + '.stderr.log')
    with stdout.open('xb') as out, stderr.open('xb') as err:
        result = subprocess.run(argv, cwd=SOURCE, env=env, stdout=out, stderr=err)
    guard()
    write(attempt / (name + '.json'), {'actual_exit_code': result.returncode, 'argv': argv,
        'cwd': str(SOURCE), 'started_unix': start, 'finished_unix': time.time(),
        'elapsed_seconds': time.time() - start, 'explicit_environment': environment or {},
        'stdout': fact(stdout), 'stderr': fact(stderr), 'candidate_before_after_equal': True})
    print(json.dumps({'command': name, 'actual_exit_code': result.returncode}), flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)
    if name.endswith('-build'):
        assert not re.findall(r'(?m)^.*\bwarning:.*$', stdout.read_text(errors='replace') + stderr.read_text(errors='replace')), 'Actual compiler warnings'

for config, ipc, storage, build_type, sanitized in [
    ('core', False, False, 'Release', False),
    ('local', True, False, 'Debug', False),
    ('sqlite-ipc', True, True, 'Release', False),
    ('sanitized-typed-host', True, False, 'Release', True),
]:
    directory = BUILD / config
    argv = [CMAKE, '-S', str(SOURCE), '-B', str(directory), '-G', 'Ninja',
        '-DBUILD_TESTING=ON', '-DQCAE_BUILD_DESKTOP=OFF', '-DQCAE_ENABLE_NASTRAN_PACKAGE=ON',
        '-DCMAKE_EXPORT_COMPILE_COMMANDS=ON', '-DCMAKE_CXX_EXTENSIONS=OFF',
        '-DCMAKE_CXX_COMPILER=/Library/Developer/CommandLineTools/usr/bin/c++',
        '-DPython3_EXECUTABLE=' + PYTHON, '-DCMAKE_BUILD_TYPE=' + build_type,
        '-DQCAE_BUILD_IPC=' + ('ON' if ipc else 'OFF'),
        '-DQCAE_BUILD_STORAGE=' + ('ON' if storage else 'OFF')]
    if ipc:
        argv.append('-DCMAKE_PREFIX_PATH=/opt/homebrew/opt/qt')
    if storage:
        argv += ['-DSQLite3_LIBRARY=/opt/homebrew/Cellar/sqlite/3.53.4/lib/libsqlite3.3.53.4.dylib',
                 '-DSQLite3_INCLUDE_DIR=/opt/homebrew/Cellar/sqlite/3.53.4/include']
    if sanitized:
        argv.append('-DQCAE_ENABLE_SANITIZERS=ON')
    command(config + '-configure', argv)
    command(config + '-build', [CMAKE, '--build', str(directory), '-j', '4',
        *(['--target', 'qcae_typed_host_tests'] if sanitized else [])])
    command(config + '-inventory', [CTEST, '--test-dir', str(directory), '--show-only=json-v1'])
    command(config + '-ctest', [CTEST, '--test-dir', str(directory), '--output-on-failure', '--verbose', '-j', '1',
        *(['-R', '^typed_host$'] if sanitized else [])],
        {'ASAN_OPTIONS': 'detect_leaks=0:halt_on_error=1',
         'UBSAN_OPTIONS': 'halt_on_error=1:print_stacktrace=1'} if sanitized else None)
    names = [row['name'] for row in json.loads((attempt / (config + '-inventory.stdout.log')).read_text())['tests']]
    executed = ['typed_host'] if sanitized else names
    assert all(name in names for name in executed)
    raw_log = attempt / (config + '-LastTest.log')
    raw_log.write_bytes((directory / 'Testing/Temporary/LastTest.log').read_bytes())
    compilation = json.loads((directory / 'compile_commands.json').read_text())
    assert all('-std=c++20' in row['command'] and '-std=gnu++20' not in row['command'] for row in compilation)
    write(attempt / (config + '-complete.json'), {
        'actual_exit_code': 0, 'configured_test_names': names, 'executed_test_names': executed,
        'executed_count': len(executed), 'raw_log': fact(raw_log),
        'compile_commands': fact(directory / 'compile_commands.json'),
        'strict_cpp20': True, 'compiler_warnings': [],
        'source_candidate': fact(attempt / 'candidate.json'),
        'sanitizer_scope': 'ASan+UBSan typed_host only; LSan not measured' if sanitized else 'normal'})
guard()
write(attempt / 'complete.json', {'actual_exit_code': 0, 'candidate_before_after_equal': True,
    'configs': ['core', 'local', 'sqlite-ipc', 'sanitized-typed-host'], 'method': method,
    'scope': 'Fresh mandatory core/local and full SQLite IPC regression plus targeted dual-sanitizer typed host.'})
