#!/usr/bin/env python3
"""ROOT-only private observer; original125 export assertion remains intact."""
import argparse
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
OLD = Path('/private/tmp/qcae-profile-variants125')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def fact(path):
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': sha(path)}


def write(path, value):
    with path.open('x') as file:
        json.dump(value, file, indent=2)
        file.write('\n')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root-authorized-diagnostic', action='store_true')
    args = parser.parse_args()
    if not args.root_authorized_diagnostic:
        print('Prepared only; diagnostic compilation/call NOT_RUN')
        return 0
    attempt = HERE / 'diagnostic-01'
    attempt.mkdir(exist_ok=False)
    inputs = json.loads((HERE / 'diagnostic-inputs.json').read_text())
    seal = json.loads((HERE / 'diagnostic-seal.json').read_text())
    spec = importlib.util.spec_from_file_location('immutable125', OLD / 'run.py')
    previous = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(previous)
    original_inputs = json.loads((OLD / 'inputs.json').read_text())
    original_method = json.loads((OLD / 'method.json').read_text())

    def guard():
        for name, expected in seal['files'].items():
            assert fact(HERE / name) == expected, name
        previous.guard(original_inputs, original_method)
        pins = inputs['reused_actual_baseline_archives'] + [inputs['compiler'],
                inputs['reused_generated_header'], inputs['reused_compile_inventory'],
                inputs['sealed125_inputs'], inputs['sealed125_method'], inputs['prior_failure']]
        for expected in pins:
            path = Path(expected['path'])
            assert path.stat().st_size == expected['bytes'] and sha(path) == expected['sha256'], path

    environment = {'PATH': '/Library/Developer/CommandLineTools/usr/bin:/opt/homebrew/bin:/usr/bin:/bin',
                   'DEVELOPER_DIR': '/Library/Developer/CommandLineTools',
                   'PYTHONDONTWRITEBYTECODE': '1', 'LC_ALL': 'C', 'LANG': 'C'}
    for name in ('HOME', 'TMPDIR'):
        if name in os.environ:
            environment[name] = os.environ[name]

    def command(name, argv, expected_exit):
        guard()
        out = attempt / (name + '.stdout.log')
        err = attempt / (name + '.stderr.log')
        start = datetime.datetime.now(datetime.timezone.utc).isoformat()
        clock = time.monotonic()
        with out.open('xb') as stdout, err.open('xb') as stderr:
            process = subprocess.Popen(argv, cwd=HERE, env=environment, stdout=stdout, stderr=stderr)
            actual_exit = process.wait()
        write(attempt / (name + '.json'), {'actual_argv': argv, 'cwd': str(HERE),
              'environment': environment, 'pid': process.pid, 'started_utc': start,
              'ended_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'elapsed_seconds': time.monotonic() - clock, 'actual_exit_code': actual_exit,
              'expected_diagnostic_exit_code': expected_exit, 'stdout': fact(out), 'stderr': fact(err)})
        guard()
        assert actual_exit == expected_exit, (name, actual_exit, expected_exit)

    try:
        guard()
        obj = str(attempt / 'diagnostic.o')
        binary = str(attempt / 'diagnostic')
        replace = lambda argv: [obj if arg == 'OBJECT_PLACEHOLDER' else binary
                               if arg == 'BINARY_PLACEHOLDER' else arg for arg in argv]
        command('compile', replace(inputs['compile_argv_template']), 0)
        command('link', replace(inputs['link_argv_template']), 0)
        for name in ('compile', 'link'):
            logs = (attempt / (name + '.stdout.log')).read_text() + (attempt / (name + '.stderr.log')).read_text()
            assert 'warning:' not in logs.lower(), 'Diagnostic compiler warning retained'
        output = attempt / 'observation'
        command('call', [binary, 'baseline', str(OLD / 'sources/baseline/tests/fixtures/nastran'),
                str(attempt / 'unused-baseline-definition.txt'), str(output), 'fixed125'], 1)
        report = json.loads((output / 'export-report.json').read_text())
        write(attempt / 'result.json', {'kind': 'actual_public_codec_export_observation_not_acceptance',
              'actual_compile_exit': 0, 'actual_link_exit': 0, 'actual_original_assertion_exit': 1,
              'original_failed_assertion_preserved': True, 'binary': fact(Path(binary)),
              'report_file': fact(output / 'export-report.json'), 'actual_report': report,
              'new_final_successor_ready': False, 'compiled_variant_acceptance': False})
        print(json.dumps(report, indent=2))
        return 0
    except BaseException as error:
        write(attempt / 'failed.json', {'actual_diagnostic_success': False, 'error': repr(error)})
        print(str(error), file=sys.stderr)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
