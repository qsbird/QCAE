#include "qcae/nastran_package.hpp"
#include "qcae/record_application.hpp"
#include "qcae/records.hpp"
#include "qcae/records_model_bridge.hpp"
#include <algorithm>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <iterator>
#include <map>
#include <stdexcept>
#include <string_view>
#include <tuple>

namespace {
using namespace qcae;
namespace fs = std::filesystem;
void need(bool condition, const char* message) {
    if (!condition)
        throw std::runtime_error(message);
}
template <class T> T good(Result<T> result) {
    need(result.ok() && result.value.has_value(), "Application call did not succeed");
    return std::move(*result.value);
}
std::string read(const fs::path& path) {
    std::ifstream file(path, std::ios::binary);
    need(bool(file), "Private input missing");
    return {std::istreambuf_iterator<char>(file), std::istreambuf_iterator<char>()};
}
void write(const fs::path& path, std::string_view bytes) {
    std::ofstream file(path, std::ios::binary);
    file.write(bytes.data(), static_cast<std::streamsize>(bytes.size()));
    need(bool(file), "Private output failed");
}

std::string quote(std::string_view text) {
    std::string result = "\"";
    const char* hex = "0123456789abcdef";
    for (const unsigned char value : text) {
        if (value == '"' || value == '\\') {
            result += '\\';
            result += static_cast<char>(value);
        } else if (value < 0x20) {
            result += "\\u00";
            result += hex[value >> 4];
            result += hex[value & 0xf];
        } else {
            result += static_cast<char>(value);
        }
    }
    return result + '"';
}
std::string export_report(const ExportOutcome& outcome) {
    std::string result = "{\"complete\":";
    result += outcome.report.complete ? "true" : "false";
    result += ",\"artifact_present\":";
    result += outcome.artifact ? "true" : "false";
    result += ",\"profile_id\":" + quote(outcome.report.profile.profile_id);
    result += ",\"profile_version\":" + quote(outcome.report.profile.profile_version);
    result += ",\"definition_digest\":" + quote(outcome.report.profile.definition_digest);
    result += ",\"issues\":[";
    bool first = true;
    for (const auto& item : outcome.report.issues) {
        if (!first)
            result += ',';
        first = false;
        result += "{\"code\":" + quote(item.code) + ",\"message\":" + quote(item.message);
        result +=
            ",\"resource\":" + quote(item.resource) + ",\"line\":" + std::to_string(item.line);
        result += ",\"blocking\":";
        result += item.blocking ? "true}" : "false}";
    }
    return result + "]}\n";
}

void append(std::string& out, std::string_view bytes) {
    out += std::to_string(bytes.size()) + ":";
    out.append(bytes);
}
std::string record_image(const DocumentView& view) {
    std::map<RecordKey, std::string> records;
    view.visit([&](const Record& record) { records.emplace(record->key(), record->encoded()); });
    std::string out;
    for (const auto& [key, bytes] : records) {
        (void)key;
        append(out, bytes);
    }
    return out;
}
std::string artifact_image(const ArtifactPlan& plan) {
    std::map<std::string, std::string> resources;
    for (const auto& resource : plan.resources)
        need(resources.emplace(resource.path, resource.text).second, "Duplicate artifact path");
    std::string out;
    append(out, plan.root_resource);
    for (const auto& [path, text] : resources) {
        append(out, path);
        append(out, text);
    }
    for (const auto& id : plan.identities) {
        append(out, id.entity.value);
        append(out, id.name_space);
        append(out, std::to_string(id.number));
    }
    return out;
}
bool issue(const std::vector<FormatIssue>& issues, std::string_view code) {
    return std::any_of(issues.begin(), issues.end(), [&](const auto& item) {
        return item.blocking && item.code == code;
    });
}
void replace_one(std::string& text, const std::string& before, const std::string& after) {
    const auto at = text.find(before);
    need(at != std::string::npos && text.find(before, at + before.size()) == std::string::npos,
         "Boundary fixture must have one exact replacement");
    text.replace(at, before.size(), after);
}
struct MemoryStore final : IRecordStore {
    std::uint64_t generation{};
    std::map<StoreKey, SharedStoreBytes> rows;
    LoadedRows load_rows() override {
        LoadedRows loaded;
        loaded.generation = generation;
        for (const auto& [key, value] : rows)
            loaded.rows.push_back({key, value});
        return loaded;
    }
    BatchReceipt commit_rows(const StoreBatch& batch) override {
        need(batch.expected_generation == generation, "Memory test store generation mismatch");
        auto next = rows;
        for (const auto& row : batch.mutations) {
            if (row.after)
                next[row.key] = row.after;
            else
                next.erase(row.key);
        }
        rows.swap(next);
        return {++generation, batch.mutations.size(), 0};
    }
};
void same_info(const DocumentInfo& left, const DocumentInfo& right) {
    need(left.document.id == right.document.id && left.document.epoch == right.document.epoch &&
             std::tie(left.revision,
                      left.content_state,
                      left.name,
                      left.project_id,
                      left.saved_path,
                      left.saved_content_state,
                      left.material_count,
                      left.dirty,
                      left.durable) == std::tie(right.revision,
                                                right.content_state,
                                                right.name,
                                                right.project_id,
                                                right.saved_path,
                                                right.saved_content_state,
                                                right.material_count,
                                                right.dirty,
                                                right.durable),
         "Rejected target changed document information");
}
void application_rejection(const Model& model, const NastranCodec& codec, const ProfileRef& old) {
    auto store = std::make_shared<MemoryStore>();
    RecordApplicationOptions options;
    options.registry = make_record_registry();
    options.records = store;
    RecordApplication app(std::move(options));
    const Caller caller{"private-profile125"};
    auto info = good(app.create_document(caller, "Compiled profile125", "create"));
    good(app.execute(
        caller,
        {info.document, info.revision},
        "test.seed",
        "seed-current",
        [model](const DocumentView& view, const RecordIdentityAllocator&) {
            auto candidate = records_from_model(model, view.registry(), view.version());
            PreparedRecordChange change{view.version(),
                                        std::move(candidate),
                                        record_changes_from_models({}, model, view.registry()),
                                        {}};
            return Result<RecordPreparedOperation>{
                Status::success,
                RecordPreparedOperation{std::move(change),
                                        "Seed current profile",
                                        model.analyses.front().id,
                                        "seed-current",
                                        0,
                                        false},
                {}};
        },
        "seed"));
    info = good(app.current_document());
    const auto before = good(app.snapshot(info.document));
    const auto history = good(app.history(info.document));
    const auto loaded = store->load_rows();
    const auto rows = encode_record_rows(loaded.rows);
    for (unsigned attempt = 0; attempt < 2; ++attempt) {
        const auto rejected = app.execute(
            caller,
            {info.document, info.revision},
            "test.old_target",
            "old-target",
            [&](const DocumentView& view,
                const RecordIdentityAllocator&) -> Result<RecordPreparedOperation> {
                EditSession edit(view);
                edit.update<records::AnalysisDefinition>(
                    model.analyses.front().id, [&](auto& value) { value.target.profile = old; });
                const auto change = edit.prepare();
                const auto validation =
                    validate_nastran_export(change.candidate, model.analyses.front().id, codec);
                need(!validation.ok() && validation.error &&
                         validation.error->code == ErrorCode::invalid_input &&
                         validation.error->message.find("target_mismatch") != std::string::npos,
                     "Production export validation silently accepted the old target");
                return {validation.status, {}, validation.error};
            },
            "old-target-same-key");
        need(!rejected.ok() && rejected.error && rejected.error->code == ErrorCode::invalid_input &&
                 rejected.error->message.find("target_mismatch") != std::string::npos,
             "Application silently accepted the old target");
        same_info(info, good(app.current_document()));
        need(record_image(before.records) ==
                 record_image(good(app.snapshot(info.document)).records),
             "Rejected target changed model bytes");
        const auto after = good(app.history(info.document));
        need(history.revision == after.revision && history.cursor == after.cursor &&
                 history.items.size() == after.items.size(),
             "Rejected target changed history");
        for (std::size_t index = 0; index < history.items.size(); ++index)
            need(history.items[index].transaction == after.items[index].transaction &&
                     history.items[index].label == after.items[index].label &&
                     history.items[index].applied == after.items[index].applied,
                 "Rejected target changed history item");
        const auto current = store->load_rows();
        need(current.generation == loaded.generation && encode_record_rows(current.rows) == rows,
             "Rejected target changed complete logical test-store rows");
    }
}
void run(const std::string& role,
         const fs::path& fixture,
         const fs::path& baseline,
         const fs::path& output) {
    need(role == "baseline" || role == "format" || role == "semantic", "Unknown role");
    need(fs::create_directory(output), "Private output directory must be fresh");
    NastranCodec codec;
    const auto definition = codec.definition();
    const auto installed = definition.reference;
    need(installed.definition_digest.starts_with("sha256:") &&
             definition.implementation_fingerprint.starts_with("sha256:"),
         "Compiled public profile identity missing");
    ProfileRef previous = installed;
    if (role != "baseline") {
        std::ifstream input(baseline);
        need(bool(input), "Actual compiled baseline profile missing");
        std::getline(input, previous.profile_id);
        std::getline(input, previous.profile_version);
        std::getline(input, previous.definition_digest);
        need(role == "format" ? previous == installed : previous != installed,
             "Compiled profile semantic identity relation is wrong");
    }
    ImportRequest request{"cantilever.bdf", {}, installed, "profile-variants125", "mm-N-MPa"};
    for (const auto* name :
         {"cantilever.bdf", "mesh/nodes.bdf", "mesh/beams.bdf", "properties.bdf"})
        request.resources.push_back({name, read(fixture / name)});
    const auto imported = codec.decode(request);
    need(imported.report.complete && imported.candidate && imported.report.issues.empty(),
         "Fixed BDF import failed");
    const auto& model = *imported.candidate;
    need(model.nodes.size() == 2 && model.beams.size() == 1 && model.analyses.size() == 1,
         "Fixed BDF population changed");
    const auto encoded = codec.encode(model, model.analyses.front().id, installed);
    const auto diagnostic = export_report(encoded);
    write(output / "export-report.json", diagnostic);
    std::cout << diagnostic << std::flush;
    need(encoded.report.complete && encoded.artifact && encoded.report.issues.empty(),
         "Fixed BDF export failed");
    verify_nastran_readback(*encoded.artifact, encoded.artifact->resources, codec);
    auto boundary = request;
    for (auto& resource : boundary.resources) {
        if (resource.path == "mesh/nodes.bdf")
            replace_one(resource.text, "GRID,1,,", "GRID,99999999,,");
        if (resource.path == "mesh/beams.bdf")
            replace_one(resource.text, "CBAR,1,1,1,2,", "CBAR,1,1,99999999,2,");
        if (resource.path == "cantilever.bdf")
            replace_one(resource.text, "SPC1,20,123456,1", "SPC1,20,123456,99999999");
    }
    const auto changed = codec.decode(boundary);
    if (role == "semantic") {
        need(!changed.report.complete && !changed.candidate &&
                 issue(changed.report.issues, "invalid_number"),
             "Compiled changed max_number did not reject the boundary");
        auto old_source = request;
        old_source.source_profile = previous;
        const auto old_import = codec.decode(old_source);
        need(!old_import.report.complete && !old_import.candidate &&
                 issue(old_import.report.issues, "profile_mismatch"),
             "Old source profile accepted");
        const auto old_expected = codec.encode(model, model.analyses.front().id, previous);
        need(!old_expected.report.complete && !old_expected.artifact &&
                 issue(old_expected.report.issues, "profile_mismatch"),
             "Old expected profile accepted");
        auto old_model = model;
        old_model.analyses.front().target.profile = previous;
        const auto old_target = codec.encode(old_model, old_model.analyses.front().id, installed);
        need(!old_target.report.complete && !old_target.artifact &&
                 issue(old_target.report.issues, "target_mismatch"),
             "Old target accepted");
        application_rejection(model, codec, previous);
    } else {
        need(changed.report.complete && changed.candidate,
             "Baseline/format codec rejected the unchanged number boundary");
    }
    write(output / "definition.txt",
          installed.profile_id + "\n" + installed.profile_version + "\n" +
              installed.definition_digest + "\n" + definition.implementation_fingerprint + "\n");
    write(output / "fixed-model.bin",
          record_image(records_from_model(model, make_record_registry())));
    write(output / "fixed-artifact.bin", artifact_image(*encoded.artifact));
    write(output / "observation.json",
          std::string("{\"role\":\"") + role +
              "\",\"actual_exit_code\":0,\"fixed_nodes\":2,\"fixed_beams\":1,"
              "\"compiled_codec_decode_export_readback\":true,\"boundary_accepted\":" +
              (role == "semantic" ? "false" : "true") +
              ",\"semantic_old_source_expected_target_rejected\":" +
              (role == "semantic" ? "true" : "false") +
              ",\"shared_application_export_validator_rejection_attempts\":" +
              (role == "semantic" ? "2" : "0") + "}\n");
    std::cout << "PASS compiled profile125 " << role << " digest=" << installed.definition_digest
              << " build=" << definition.implementation_fingerprint << '\n';
}
} // namespace
int main(int argc, char** argv) {
    try {
        need(argc == 6, "role fixture baselineDefinition freshOutput reservedArg required");
        need(std::string(argv[5]) == "fixed125", "Wrong fixed private method");
        run(argv[1], argv[2], argv[3], argv[4]);
        return 0;
    } catch (const std::exception& error) {
        std::cerr << "FAIL compiled profile125: " << error.what() << '\n';
        return 1;
    }
}
