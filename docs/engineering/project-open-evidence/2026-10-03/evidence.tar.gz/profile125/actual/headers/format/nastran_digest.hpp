#pragma once
#include <string_view>
namespace qcae {
inline constexpr std::string_view nastran_definition_digest = "sha256:a6604ba3d6970cbbec955389578a0f2cfaf2da8bda400730a3b87f0e315958bc";
inline constexpr std::string_view nastran_implementation_fingerprint = "sha256:8642517ed8748761a4d3f9786b80b0814eed9ec859062b39a0b619c2c0181e48";
}
