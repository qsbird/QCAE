#pragma once
#include <string_view>
namespace qcae {
inline constexpr std::string_view nastran_definition_digest = "sha256:f8eff9573c8e082b86efb12c11c295bae3f22f0eec23f1cc94afb131774b9f29";
inline constexpr std::string_view nastran_implementation_fingerprint = "sha256:014bac82399c1bb92d0cb95c4d9512b081835ed7d46c55ee77a9ec3235756df9";
}
