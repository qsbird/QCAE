#pragma once
#include <string_view>
namespace qcae {
inline constexpr std::string_view nastran_definition_digest = "sha256:a6604ba3d6970cbbec955389578a0f2cfaf2da8bda400730a3b87f0e315958bc";
inline constexpr std::string_view nastran_implementation_fingerprint = "sha256:5f80cff1ec5e134e4dfa0df73dc7a125f4d7c6a274290d8fb5ad9cd267205ac3";
}
