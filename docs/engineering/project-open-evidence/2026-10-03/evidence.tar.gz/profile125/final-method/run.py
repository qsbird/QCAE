#!/usr/bin/env python3
"""ROOT-owned, append-only, compiled Nastran profile identity experiment."""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import subprocess
import sys
import time

BASE = Path(__file__).resolve().parent
SOURCE_BASE = Path("/private/tmp/qcae-profile-variants125")
ROLES = ("baseline", "format", "semantic")


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def fact(path: Path) -> dict:
    return {"path": str(path), "bytes": path.stat().st_size, "sha256": sha(path)}


def save(path: Path, value) -> None:
    with path.open("x") as file:
        json.dump(value, file, indent=2, sort_keys=True)
        file.write("\n")


def require(condition: bool, message: str) -> None:
    if not condition:
        raise RuntimeError(message)


def guard(inputs: dict, method: dict) -> dict:
    # The frozen private trees, not ROOT's later moving integration checkout,
    # are the actual compiled source. Each baseline file came from exact e220.
    for expected in method["referenced_inputs"]:
        path = Path(expected["path"])
        require(path.is_file() and path.stat().st_size == expected["bytes"] and
                sha(path) == expected["sha256"], "Referenced sealed input changed: " + str(path))
    for relative, expected in method["files"].items():
        path = BASE / relative
        require(path.is_file() and sha(path) == expected["sha256"], "Method changed: " + relative)
    for role in ROLES:
        source = SOURCE_BASE / "sources" / role
        table = inputs["clone_inputs"][role]
        actual = {str(path.relative_to(source)) for path in source.rglob("*") if path.is_file()}
        require(actual == set(table), "Private source membership changed: " + role)
        for relative, expected in table.items():
            path = source / relative
            require(path.stat().st_size == expected["bytes"] and sha(path) == expected["sha256"],
                    "Private source bytes changed: " + role + "/" + relative)
    for name, expected in inputs["tools"].items():
        path = Path(expected["path"])
        require(str(path.resolve()) == expected["resolved_path"] and
                path.stat().st_size == expected["bytes"] and sha(path) == expected["sha256"],
                "Pinned tool/SDK changed: " + name)
    require(inputs["original_candidate_count"] == 412, "Wrong frozen source denominator")
    baseline = inputs["clone_inputs"]["baseline"]
    for relative, expected in inputs["candidate_files"].items():
        require(baseline[relative]["sha256"] == expected, "Frozen candidate mismatch: " + relative)
    codec = inputs["only_variant_file"]
    for role in ("format", "semantic"):
        changed = [name for name in baseline
                   if baseline[name]["sha256"] != inputs["clone_inputs"][role][name]["sha256"]]
        require(changed == [codec], "Variant changed more than the sole codec input")
    return {"matched": True, "actual_compiled_source": "private exact Git e220 baseline and one-file variants",
            "frozen_head": inputs["frozen_head"], "original_candidate_count": 412,
            "source_sha256": inputs["original_candidate_source_sha256"],
            "inputs_per_clone": inputs["input_count_per_clone"]}


def command(attempt: Path, name: str, argv: list[str], environment: dict,
            inputs: dict, method: dict) -> dict:
    directory = attempt / name
    directory.mkdir()
    save(directory / "guard-before.json", guard(inputs, method))
    stdout = directory / "stdout.log"
    stderr = directory / "stderr.log"
    started = dt.datetime.now(dt.timezone.utc).isoformat()
    clock = time.monotonic()
    pid = None
    returncode = None
    exception = None
    try:
        with stdout.open("xb") as out, stderr.open("xb") as err:
            process = subprocess.Popen(argv, cwd=BASE, env=environment, stdout=out, stderr=err)
            pid = process.pid
            returncode = process.wait()
    except BaseException as error:
        exception = repr(error)
    receipt = {"command_id": name, "actual_argv": argv, "cwd": str(BASE),
               "explicit_environment": environment, "pid": pid, "started_utc": started,
               "ended_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
               "elapsed_seconds": time.monotonic() - clock, "actual_exit_code": returncode,
               "exception": exception,
               "stdout": fact(stdout) if stdout.exists() else None,
               "stderr": fact(stderr) if stderr.exists() else None}
    save(directory / "receipt.json", receipt)
    save(directory / "guard-after.json", guard(inputs, method))
    require(exception is None and returncode == 0, "Actual command failed: " + name)
    return receipt


def compile_inventory(build: Path, source: Path) -> dict:
    entries = json.loads((build / "compile_commands.json").read_text())
    require(bool(entries), "Missing actual compilation inventory")
    files = []
    for entry in entries:
        argv = entry.get("arguments") or shlex.split(entry["command"])
        require("-std=c++20" in argv and not any(arg.startswith("-std=gnu") for arg in argv),
                "Actual compile does not use strict C++20")
        require("-Werror" in argv and all(arg in argv for arg in ("-Wall", "-Wextra", "-Wpedantic")),
                "Actual compile lost warning guards")
        files.append(entry["file"])
    require(str(source / "profiles/nastran/src/nastran_codec.cpp") in files,
            "Nastran source missing from actual build inventory")
    require(str(BASE / "peer/peer.cpp") in files, "Private peer missing from actual build inventory")
    return {"translation_units_configured": len(files), "strict_cpp20": True,
            "warnings_are_errors": True, "compile_commands": fact(build / "compile_commands.json"),
            "scope": "Configured source inventory; actual build exit and log establish executed target build"}


def definition(path: Path) -> list[str]:
    values = path.read_text().splitlines()
    require(len(values) == 4 and all(values), "Incomplete compiled public identity")
    return values


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root-authorized-build-and-call", action="store_true")
    parser.add_argument("--attempt", default="compiled125-01")
    args = parser.parse_args()
    if not args.root_authorized_build_and_call:
        print("PREPARED ONLY; configure/build/product call NOT_RUN. ROOT must supply explicit action flag.")
        return 0
    require(bool(re.fullmatch(r"[A-Za-z0-9_-]+", args.attempt)), "Unsafe attempt name")
    attempt = BASE / "attempts" / args.attempt
    attempt.mkdir(parents=True, exist_ok=False)
    inputs = json.loads((SOURCE_BASE / "inputs.json").read_text())
    method = json.loads((BASE / "final-method.json").read_text())
    environment = {"PATH": "/Library/Developer/CommandLineTools/usr/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin",
                   "PYTHONDONTWRITEBYTECODE": "1", "LC_ALL": "C", "LANG": "C",
                   "DEVELOPER_DIR": "/Library/Developer/CommandLineTools"}
    # HOME/TMPDIR are inherited only when present and recorded explicitly;
    # no secret-bearing inherited build flags or full environment are copied.
    for name in ("HOME", "TMPDIR"):
        if name in os.environ:
            environment[name] = os.environ[name]
    save(attempt / "start.json", {"method": fact(BASE / "final-method.json"), "inputs": fact(SOURCE_BASE / "inputs.json"),
                                 "argv": sys.argv, "status": "STARTED_NOT_PASS"})
    completed = []
    try:
        save(attempt / "guard-before.json", guard(inputs, method))
        tools = inputs["tools"]
        cmake = tools["cmake"]["path"]
        baseline = attempt / "baseline-observation/definition.txt"
        for role in ROLES:
            source = SOURCE_BASE / "sources" / role
            build = attempt / (role + "-build")
            configure = [cmake, "-S", str(BASE / "peer"), "-B", str(build), "-G", "Ninja",
                         "-DQCAE_SOURCE_ROOT=" + str(source), "-DCMAKE_CXX_COMPILER=" + tools["compiler"]["path"],
                         "-DPython3_EXECUTABLE=" + tools["python"]["path"],
                         "-DCMAKE_MAKE_PROGRAM=" + tools["ninja"]["path"],
                         "-DCMAKE_OSX_SYSROOT=/Library/Developer/CommandLineTools/SDKs/MacOSX.sdk",
                         "-DCMAKE_BUILD_TYPE=Release", "-DCMAKE_EXPORT_COMPILE_COMMANDS=ON",
                         "-DQCAE_BUILD_IPC=OFF", "-DQCAE_BUILD_STORAGE=OFF", "-DQCAE_BUILD_DESKTOP=OFF",
                         "-DQCAE_BUILD_SOLVER_LOCAL=OFF", "-DQCAE_ENABLE_SANITIZERS=OFF",
                         "-DQCAE_ENABLE_NASTRAN_PACKAGE=ON", "-DBUILD_TESTING=OFF"]
            command(attempt, role + "-configure", configure, environment, inputs, method)
            command(attempt, role + "-build-command", [cmake, "--build", str(build),
                    "--target", "qcae_profile_variants125", "--parallel", "2", "--verbose"], environment, inputs, method)
            log = (attempt / (role + "-build-command/stdout.log")).read_text() + \
                  (attempt / (role + "-build-command/stderr.log")).read_text()
            require(not re.search(r"\bwarning:", log, flags=re.I), "Actual compiler emitted warning")
            inventory = compile_inventory(build, source)
            generated = build / "qcae/profiles/nastran/generated/qcae/nastran_digest.hpp"
            require(generated.is_file(), "Actual generated profile header missing")
            executable = build / "qcae_profile_variants125"
            require(executable.is_file(), "Actual private linked executable missing")
            output = attempt / (role + "-observation")
            command(attempt, role + "-call", [str(executable), role,
                    str(source / "tests/fixtures/nastran"), str(baseline), str(output), "fixed125"],
                    environment, inputs, method)
            values = definition(output / "definition.txt")
            header = generated.read_text()
            require(re.search(r'nastran_definition_digest\s*=\s*"' + re.escape(values[2]) + '"', header) is not None and
                    re.search(r'nastran_implementation_fingerprint\s*=\s*"' + re.escape(values[3]) + '"', header) is not None,
                    "Compiled public definition differs from actual generated build header")
            export_report = json.loads((output / "export-report.json").read_text())
            expected_notes = json.loads((BASE / "expected-export-notes.json").read_text())
            require(export_report["complete"] is True and export_report["artifact_present"] is True and
                    export_report["definition_digest"] == values[2] and
                    export_report["issues"] == expected_notes["expected_issues"],
                    "Actual full export notes differ from exactly observed nonblocking baseline notes")
            observation = json.loads((output / "observation.json").read_text())
            require(observation["role"] == role and observation["compiled_codec_decode_export_readback"] is True,
                    "Wrong compiled codec observation")
            require(observation["boundary_accepted"] == (role != "semantic"), "Wrong compiled semantic boundary")
            require(observation["shared_application_export_validator_rejection_attempts"] == (2 if role == "semantic" else 0),
                    "Wrong actual shared-application validator scope")
            require(observation["semantic_old_source_expected_target_rejected"] == (role == "semantic"),
                    "Wrong actual old-profile negative result")
            archive = build / "qcae/profiles/nastran/libqcae_nastran.a"
            require(archive.is_file(), "Actual corresponding Nastran library missing")
            summary = {"role": role, "compiled_public_identity": values, "binary": fact(executable),
                       "nastran_archive": fact(archive), "generated_header": fact(generated),
                       "cache": fact(build / "CMakeCache.txt"), "compile_inventory": inventory,
                       "observation": fact(output / "observation.json"),
                       "full_export_report": fact(output / "export-report.json"),
                       "model": fact(output / "fixed-model.bin"), "artifact": fact(output / "fixed-artifact.bin"),
                       "warnings": 0}
            save(attempt / (role + "-actual.json"), summary)
            completed.append(summary)
        base, formatted, semantic = completed
        bv, fv, sv = [entry["compiled_public_identity"] for entry in completed]
        require(bv[:3] == fv[:3] and bv[3] != fv[3], "Compiled formatting identity condition failed")
        require(bv[:2] == sv[:2] and bv[2] != sv[2] and bv[3] != sv[3], "Compiled semantic identity condition failed")
        require(base["model"]["sha256"] == formatted["model"]["sha256"] and
                base["artifact"]["sha256"] == formatted["artifact"]["sha256"],
                "Compiled formatting changed fixed BDF model/artifact bytes")
        require(base["artifact"]["sha256"] == semantic["artifact"]["sha256"],
                "Semantic limit variant changed ordinary in-range fixed BDF physical artifact")
        save(attempt / "guard-after.json", guard(inputs, method))
        save(attempt / "comparison.json", {"actual_passed": True, "three_fresh_builds": 3,
             "three_actual_calls": 3, "original_source_count": 412, "format_semantic_identity_unchanged": True,
             "format_build_identity_changed": True, "format_fixed_model_and_artifact_unchanged": True,
             "semantic_digest_changed": True, "semantic_actual_boundary_rejected": True,
             "exact_observed_nonblocking_export_notes_retained": True,
             "semantic_old_profiles_and_target_rejected": True,
             "application_scope": inputs["application_scope"],
             "application_failed_same_key_calls": 2, "shared_application_store_model_history_unchanged": True,
             "full_SK11_or_P0_acceptance": False, "actual_variants": completed})
        print("PASS bounded compiled profile125; no full SK11/P0 claim")
        return 0
    except BaseException as error:
        save(attempt / "failed.json", {"actual_passed": False, "error": repr(error),
                                      "completed_role_count": len(completed), "completed_roles": completed})
        print("FAIL bounded profile125: " + str(error), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
