# Profile125 successor01 — PREPARED, final variant calls NOT RUN

The original125 baseline configured and built at exit0, then its private consumer returned exit1 at the export assertion. All original methods, source clones and failure bytes remain unchanged. The separate diagnostic also compiled/linked at0 and preserved the original assertion's exit1; its actual public ExportReport is complete with an artifact and exactly two nonblocking notes: `name_loss` and `lexical_normalization`. Report SHA256: `f2d548d2480bf7b08fa9f691860240fcf36036f2e2a663cbd14db115227e505a`.

The final private consumer corrects the false empty-issues assumption. It still requires complete export, an artifact and no blocking issue, then requires exactly the observed two distinct note codes and their full exact messages, empty resources and zero line numbers. Every actual export report is retained before validation and readback. The recorder additionally compares every full issue field to the observed fixed baseline notes. This is a fixture-consumer correction, with no product, generator, schema, threshold or profile-version change.

The final method directly references original125's sealed baseline/format/semantic source trees: exact e2207ed's412 files,414 build/fixture inputs per tree. It does not read the later integration worktree or copy/rewrite any source tree. Format remains the single comment/blank-line change; semantic remains actual controlled max_number99999999→99999998. All other original format identity/model/artifact, semantic boundary/old-profile/target and application rejection checks remain. The application handler is private observer orchestration invoking production validate_nastran_export, not a registered production operation.

ROOT command, using a fresh new attempt:

```
/Library/Frameworks/Python.framework/Versions/3.14/bin/python3.14 -B /private/tmp/qcae-profile-variants125-successor01/run.py --root-authorized-build-and-call --attempt compiled125-successor01
```

It performs the original three sequential fresh pure C++ builds and three actual calls, retains strict C++20/Werror and actual compiler warning0 checks, and compares compiled public ProfileRef/buildFingerprint with each actual generated header. Qt/storage/desktop/solver remain OFF. Each actual command has separate receipt, raw stdout/stderr, argv/environment, PID/time/exit/hash and before/after input checks. Any nonzero is preserved before stopping; fresh attempt paths never overwrite original failures. Final variant outcomes, configure/build/call and guards are currently NOT_RUN. Pure Python AST, private formatting and method-difference checks alone have passed; this does not claim compiled acceptance or full SK11/P0.
