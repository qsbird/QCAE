#!/usr/bin/env python3
import hashlib,io,json,tarfile
from pathlib import Path
S=Path('/private/tmp/qcae-framework-delivery80');D=S/'docs/engineering/changes-commit-evidence/2026-10-03'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,v):p.write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
assert not D.exists();D.mkdir(parents=True)
roots={'baseline162':'/private/tmp/qcae-changes-commit162-baseline','implementation162':'/private/tmp/qcae-changes-commit162-implementation','tests162':'/private/tmp/qcae-changes-commit162-tests','format162':'/private/tmp/qcae-changes-commit162-format','review164':'/private/tmp/qcae-changes-commit164-review','initial165':'/private/tmp/qcae-changes-commit165-regression','fixed168':'/private/tmp/qcae-changes-commit168-recovery-followup','source168':'/private/tmp/qcae-changes-commit168-source','graphics161':'/private/tmp/qcae-desktop-selection-isolation161','graphics163':'/private/tmp/qcae-desktop-selection-contract163','graphics166':'/private/tmp/qcae-desktop-selection166-isolated','next167':'/private/tmp/qcae-core-contract-batch167'}
entries={}
for group,root in roots.items():
 for p in sorted(Path(root).rglob('*')):
  if not p.is_file():continue
  if '__pycache__' in p.parts:continue
  assert p.suffix in ['.json','.log','.md','.py','.cpp','.txt','.patch'] or p.name=='CMakeLists.txt',p
  name=group+'/'+p.relative_to(root).as_posix();assert name not in entries;entries[name]=(p,p.read_bytes())
for config in ['sqlite-on','sqlite-off']:
 root=Path('/private/tmp/qcae-changes-commit165-builds')/config/'changes-commit-evidence'
 folders=list(root.glob('run-*'));assert len(folders)==3
 for p in sorted(root.rglob('*')):
  if p.is_file():
   assert p.suffix in ['.json','.log'];entries['actual-SQLite/'+config+'/'+p.relative_to(root).as_posix()]=(p,p.read_bytes())
entries['archive-method/run.py']=(Path(__file__),Path(__file__).read_bytes())
archive=D/'evidence.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=9) as tf:
 for name,(origin,data) in sorted(entries.items()):
  info=tarfile.TarInfo(name);info.size=len(data);info.mtime=0;info.mode=0o644;tf.addfile(info,io.BytesIO(data))
with tarfile.open(archive,'r:gz') as tf:
 assert len(tf.getmembers())==len(entries)
 for name,(origin,data) in entries.items():assert tf.extractfile(name).read()==data==origin.read_bytes()
index={'schema_version':1,'implementation_commit':'88942c03da817110afa66675773f80dfc1bb2499','source_dictionary_sha256':'4b09296e5af3bd4fe1982b9858c22169c96b8d9b1bbdb52e88ea87d3d41acfe6','archive':{'path':'evidence.tar.gz','members':len(entries),'bytes':archive.stat().st_size,'sha256':sha(archive)},'verified_every_member_and_original':True,'runtime_DB_or_product_binary_included':False,'entries':[{'member':name,'origin':str(origin),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for name,(origin,data) in sorted(entries.items())],'limits':['Initial259 executions257PASS/2FAIL remain; final test-only recovery comparison correction had4 passing same-product repeats, no full matrix rerun','Retained151 Qt binary isolated23 functions/69 data rows/115 including init/cleanup passed within one180s; diagnostic only, original GUI failures and current full gate remain open','Old f2d bundle unrefreshed; real solver/full external AI/LSan/performance/full SK/P0 unvalidated']}
dump(D/'archive-index.json',index)
freeze=json.loads(Path('/private/tmp/qcae-changes-commit168-source/freeze.json').read_text());diag=json.loads(Path('/private/tmp/qcae-desktop-selection166-isolated/attempt-01/complete.json').read_text())
validation={'schema_version':1,'status':'generated_commit_contract_and_bounded_behavior_validated_full_graphical_gate_open','implementation_commit':index['implementation_commit'],'source':freeze,'initial_configuration_results':[{'name':name,'executed':count,'passed':count-failed,'failed':failed} for name,count,failed in [('core',40,0),('local',55,0),('sqlite_on',86,1),('sqlite_off',77,1),('asan_ubsan_typed_host',1,0)]],'initial_actual_executions':259,'initial_passed':257,'initial_failed':2,'failure_reason':'Test incorrectly compared post-recovery entity iteration order; three stable identities and full exposed fields actually equal in both failed transcripts','final_same_product_targeted_executions':4,'final_targeted_passed':4,'combined_actual_ctest_executions':263,'combined_actual_passed':261,'combined_actual_failed':2,'all_original_full_matrix_executions_passed':False,'complete_matrix_rerun':False,'post_full_source_delta':['tests/changes_commit_ipc_tests.py'],'source_and_actual181_products_unchanged_during_followup':True,'bounded_SQLite':{'real_engine':True,'per_run_refusals':18,'per_run_commit_replays':4,'successful_commits_per_run':2,'independent_engine_processes_per_run':2,'completed_final_runs':4,'engine_exit_codes_per_run':[-15,-15],'all_logical_rows_document_history_unchanged_around_refusals_and_replays':True,'recovery_record_identity_fields_and_history_equal':True,'stored_receipt_lookup_and_old_epoch_refusal':True,'physical_WAL_equivalence_claimed':False},'graphics_diagnostic':{'binary_scope':'Retained151 product; current contract implementation not compiled into it; three graphics sources byte-identical','actual_processes':24,'function_processes':23,'original_data_rows':69,'qt_pass_lines_with_init_cleanup':115,'elapsed_seconds':diag['elapsed_seconds'],'shared_bound_seconds':180,'all_functions_and_tags_exactly_matched':True,'old_full_suite_failures_remain':True,'root_cause_proven':False,'current_graphical_gate_closed':False},'before_existing_tests_passed':4,'source_QG02':{'reviewer_product_runs':False,'remaining_blockers':0,'initial_and_final_reviews_preserved':True},'archive':index['archive'],'archive_index_sha256':sha(D/'archive-index.json'),'limits':index['limits']+['No current GUI suite rerun or new bundle refresh; old f2d package remains valid only for its archived scope','Only three-record SQLite fixture, not complete M or real graphical selection through a headless engine','Full SDK copy coverage unknown/deferred from C4 startup only; measured budget constraints and original material14/30 failure remain']}
dump(D/'validation.json',validation)
print(json.dumps({'archive':index['archive'],'index_sha256':sha(D/'archive-index.json')}))
