166 方法有限静态复核未发现剩余阻塞。三处先前发现已修正，实际执行仍 NOT RUN。未执行方法、guard、枚举、测试或产品，未修改源码/Git。

本复核绑定 run.py（5951 B，SHA256 `bfdabf4faeb84525b88aadb2cc8e4a7ed9e6d0a1a999a757bfd257cf83658195`）。原审查字节 SHA `a2b3a774e7720196ba84d0c77c9d81772c20aab4c64bf12db6350a5bbf33939c` 的“起始预算晚于准备”和“TERM耗尽后额外kill等待”两项保留为历史发现；当前第6–7行提前开始全局180秒，第28–42行在普通超时路径预留7秒并使用剩余时间清理。

中间方法 SHA `24253db6b6ac7290625cc145de12309d3a95dd034b82d915553e3eee8a08dc0d` 曾仅捕获 TimeoutExpired，wait 的其他异常可跳过清理。当前第33–46行捕获 BaseException，finally 对仍存活的 owned PID 使用同一deadline终止/回收，保存实际PID/exit/caught_exception receipt后重新抛错。该修正未增加预算。历史发现保留在 JSON，先前 review.json SHA 为 `965d21eb02385571925070d5954cef3ab0c804b556a398714416578f2ff8f1b9`。

其余有限方法检查吻合：枚举严格匹配23个唯一函数及顺序；函数调用不筛data tag，原69行完整保留；每个进程精确核 init + 原tag + cleanup，共115条Qt PASS；Totals要求零failure/skip/blacklisted，拒绝FAIL!/SKIP/XFAIL/XPASS/BFAIL/BPASS并要求唯一Finished标志。BLACKLIST字面前缀未单列，但Qt原生黑名单由BFAIL/BPASS及Totals约束拒绝，未据此推断实际误通过。

普通执行/超时保留独立stdout/stderr、PID、实际exit、时长与文件哈希；三GUI源、原151 binary及方法本身均有前后guard。文件均排他新建。hash漂移会失败，但失败JSON没有另存变化后的具体fact。Popen及文件I/O不能被Python deadline强制中断；清理中的再次中断、OS错误或kill后回收超时也可能中断receipt创建。这些属于失败路径限度，不是已观察到的运行失败；任何超预算仍不得记录为通过。

该方法只诊断 retained151 binary。原累计压力失败仍保留，当前GUI gate、驱动根因和完整SK/P0均不得由本准备复核推定通过。上述结论仅适用于所列SHA；后继修改另需复核。
