#!/usr/bin/env python3
"""Diagnostic successor: all original functions/data, one shared180s budget.

Retained151 binary only. Never replaces old full-suite failures or a current gate.
"""
import time
started=time.monotonic();deadline=started+180
import hashlib,json,os,re,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'attempt-01';SOURCE=Path('/private/tmp/qcae-framework-delivery80')
BINARY=Path('/private/tmp/qcae-package-contributions151-builds/desktop/qcae_desktop_selection_tests')
PLAN=Path('/private/tmp/qcae-desktop-selection-isolation161/plan.json')
PRIOR=Path('/private/tmp/qcae-package-contributions151-successor01/attempt-01/candidate.json')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def fact(p):p=Path(p);return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
def dump(p,v):
 with Path(p).open('x') as f:json.dump(v,f,indent=2,sort_keys=True);f.write('\n')
assert not OUT.exists();OUT.mkdir()
plan=json.loads(PLAN.read_text());functions=plan['fixture_audit']['functions'];names=[f['name'] for f in functions]
assert len(names)==len(set(names))==23 and sum(f['original_data_row_count'] for f in functions)==69
source={f['path']:f['sha256'] for f in plan['selected_readonly_source_facts']};binary=fact(BINARY);method=fact(__file__)
def guard():
 assert source=={p:sha(p) for p in source};assert binary==fact(BINARY);assert method==fact(__file__)
guard();dump(OUT/'candidate.json',{'retained_binary':binary,'original_product_candidate':fact(PRIOR),'graphics_source_subset':source,'functions_and_rows':functions,'plan':fact(PLAN),'method':method,'original_bound_seconds':180,'current_source_scope':'Current non-graphical contract work is not compiled into this retained151 binary. Graphics sources in this subset are byte-identical. This is diagnostic only.','old_full_suite_failure_remains':True,'root_cause_proven':False})
receipts=[];env=os.environ.copy()
for key in ['ASAN_OPTIONS','UBSAN_OPTIONS','LSAN_OPTIONS','DYLD_INSERT_LIBRARIES','DYLD_LIBRARY_PATH','DYLD_PRINT_LIBRARIES','QT_QPA_PLATFORM']:env.pop(key,None)
def command(label,argv):
 guard();remaining=deadline-time.monotonic();assert remaining>7,'Shared budget exhausted before next process'
 out=OUT/(label+'.stdout.log');err=OUT/(label+'.stderr.log');at=time.monotonic();timed=False;killed=False
 caught=None
 with out.open('xb') as o,err.open('xb') as e:
  process=subprocess.Popen(argv,cwd=SOURCE,env=env,stdout=o,stderr=e)
  try:
   process.wait(timeout=max(.01,deadline-time.monotonic()-7))
  except BaseException as error:
   caught=error;timed=isinstance(error,subprocess.TimeoutExpired)
  finally:
   if process.poll() is None:
    process.terminate()
    try:process.wait(timeout=max(.01,min(5,deadline-time.monotonic()-2)))
    except subprocess.TimeoutExpired:
     process.kill();killed=True;process.wait(timeout=max(.01,min(1,deadline-time.monotonic()-1)))
 receipt={'label':label,'argv':argv,'cwd':str(SOURCE),'owning_pid':process.pid,'actual_exit_code':process.returncode,'started_elapsed_seconds':at-started,'elapsed_seconds':time.monotonic()-at,'whole_method_elapsed_seconds':time.monotonic()-started,'timed_out_in_original_shared_budget':timed,'required_kill':killed,'caught_exception':repr(caught) if caught else None,'stdout':fact(out),'stderr':fact(err)}
 dump(OUT/(label+'.json'),receipt);receipts.append(receipt);print(json.dumps({'label':label,'actual_exit_code':process.returncode,'elapsed_seconds':receipt['elapsed_seconds']}),flush=True)
 guard()
 if caught:raise caught
 assert process.returncode==0 and not timed and time.monotonic()<deadline,label+' failed; raw evidence preserved'
 return out.read_text()
try:
 enumeration=command('enumeration',[str(BINARY),'-functions']);actual=[line.strip() for line in enumeration.splitlines() if line.strip()]
 assert actual==[name+'()' for name in names],actual
 for index,function in enumerate(functions,1):
  name=function['name'];label=f'{index:02d}-'+name
  output=command(label,[str(BINARY),name,'-v1'])
  passes=re.findall(r'^PASS\s+: DesktopSelectionTests::([A-Za-z0-9_]+)\(([^\r\n]*)\)\s*$',output,re.M)
  expected=[('initTestCase','')]+[(name,tag) for tag in function['original_data_tags']]+[('cleanupTestCase','')]
  assert passes==expected,{'label':label,'expected':expected,'actual':passes}
  assert not re.search(r'^(?:FAIL!|SKIP|XFAIL|XPASS|BFAIL|BPASS)\s+:',output,re.M),'Unexpected test result'
  totals=re.findall(r'^Totals: (\d+) passed, (\d+) failed, (\d+) skipped, (\d+) blacklisted, (\d+)ms$',output,re.M)
  assert len(totals)==1 and tuple(map(int,totals[0][:4]))==(len(expected),0,0,0),totals
  assert output.count('********* Finished testing of DesktopSelectionTests *********')==1,'Truncated output'
  dump(OUT/(label+'-verified.json'),{'function':name,'actual_complete_pass_rows':passes,'original_function_data_rows':function['original_data_row_count'],'no_failure_skip_or_blacklist':True,'totals':totals[0]})
 guard();assert time.monotonic()<deadline
 dump(OUT/'complete.json',{'scope':'All original selection assertions in isolated function processes on retained151 binary; no current full gate or root-cause repair claim','actual_exit_code':0,'function_processes':23,'enumeration_processes':1,'original_function_data_rows':69,'qt_total_pass_rows_including_init_cleanup':115,'shared_budget_seconds':180,'elapsed_seconds':time.monotonic()-started,'all_sources_and_binary_before_after_equal':True,'all_functions_and_tags_exactly_matched':True,'old_full_suite_failure_remains':True,'root_cause_proven':False,'process_receipts':receipts})
 print(json.dumps({'diagnostic_original_rows_passed':69,'old_full_suite_failure_remains':True,'elapsed_seconds':time.monotonic()-started}),flush=True)
except BaseException as error:
 dump(OUT/'failure.json',{'exception':repr(error),'elapsed_seconds':time.monotonic()-started,'actual_process_receipts':receipts,'old_full_suite_failure_remains':True,'not_passed':True})
 raise
