#!/usr/bin/env python3
from concurrent.futures import ThreadPoolExecutor
import hashlib,json,os,subprocess,time
from pathlib import Path
S=Path('/private/tmp/qcae-framework-delivery80');R=Path(__file__).resolve().parent;B=Path('/private/tmp/qcae-changes-commit165-builds');OLD=Path('/private/tmp/qcae-changes-commit165-regression/attempt-01/candidate.json');P='/Library/Frameworks/Python.framework/Versions/3.14/bin/python3.14';CTEST='/opt/homebrew/Cellar/cmake/4.3.0/bin/ctest'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def fact(p):p=Path(p);return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
def dump(p,v):
 with Path(p).open('x') as f:json.dump(v,f,indent=2,sort_keys=True);f.write('\n')
assert not (R/'candidate.json').exists();prior=json.loads(OLD.read_text());inputs={n:sha(S/n) for n in prior['candidate_files']};delta=[n for n,h in prior['candidate_files'].items() if inputs[n]!=h];assert delta==['tests/changes_commit_ipc_tests.py']
products={str(path):sha(path) for path in sorted(B.rglob('qcae*')) if path.is_file() and os.access(path,os.X_OK)};assert products
originals={str(path):sha(path) for name in ['sqlite-on','sqlite-off'] for path in (B/name/'changes-commit-evidence').rglob('*') if path.is_file()}
method=fact(__file__);head=subprocess.check_output(['git','-C',str(S),'rev-parse','HEAD'],text=True).strip()
dump(R/'candidate.json',{'source':str(S),'head':head,'source_files':inputs,'source_files_count':len(inputs),'source_dictionary_sha256':hashlib.sha256(json.dumps(inputs,sort_keys=True,separators=(',',':')).encode()).hexdigest(),'first_full_candidate':fact(OLD),'post_full_source_delta':delta,'actual_products':products,'original_failure_evidence':originals,'method':method,'scope':'Test-only stable-ID recovery comparison correction; no compilation or other test reruns. Initial two failures retained, exact same products.'})
def guard():
 assert inputs=={n:sha(S/n) for n in inputs};assert products=={p:sha(p) for p in products};assert originals=={p:sha(p) for p in originals};assert method==fact(__file__);assert head==subprocess.check_output(['git','-C',str(S),'rev-parse','HEAD'],text=True).strip()
def command(name,argv):
 guard();start=time.time()
 with (R/(name+'.stdout.log')).open('xb') as out,(R/(name+'.stderr.log')).open('xb') as err:result=subprocess.run(argv,cwd=S,stdout=out,stderr=err)
 guard();receipt={'argv':argv,'actual_exit_code':result.returncode,'elapsed_seconds':time.time()-start,'stdout':fact(R/(name+'.stdout.log')),'stderr':fact(R/(name+'.stderr.log')),'all_sources_products_and_original_failure_evidence_unchanged':True};dump(R/(name+'.json'),receipt);print(json.dumps({'command':name,'actual_exit_code':result.returncode}),flush=True);assert result.returncode==0,name;return receipt
for n,argv in [('design',[P,'tools/check_design.py']),('format',[P,'tools/check_cpp_format.py']),('diff',['git','diff','--check'])]:command(n,argv)
def repeat(name):
 command(name,[CTEST,'--test-dir',str(B/name),'--output-on-failure','--verbose','-R','^changes_commit_ipc$','--repeat','until-fail:2'])
 (R/(name+'-LastTest.log')).write_bytes((B/name/'Testing/Temporary/LastTest.log').read_bytes())
 runs=[]
 for folder in sorted((B/name/'changes-commit-evidence').glob('run-*')):
  if str(folder/'observations.json') in originals:continue
  observations=json.loads((folder/'observations.json').read_text());assert len(observations['refusals'])==18 and len(observations['replays'])==4 and observations['engine_exit_codes']==[-15,-15]
  assert 'recovered_state' in observations and 'recovered_entities' in observations
  transcripts=json.loads((folder/'transcripts.json').read_text());assert len(transcripts)==2
  runs.append({'path':str(folder),'observations':fact(folder/'observations.json'),'transcript_entries':sum(len(t) for t in transcripts),'engine_exit_codes':observations['engine_exit_codes']})
 assert len(runs)==2,runs;dump(R/(name+'-runs.json'),runs);return {'configuration':name,'actual_passed_executions':2,'runs':runs}
with ThreadPoolExecutor(max_workers=2) as pool:results=list(pool.map(repeat,['sqlite-on','sqlite-off']))
guard();dump(R/'complete.json',{'actual_exit_code':0,'actual_successful_ctest_executions':4,'results':results,'same_products_and_original_failure_evidence_unchanged':True,'initial_full_matrix_two_test_assertion_failures_remain_archived':True,'no_complete_full_matrix_rerun':True})
print(json.dumps({'actual_successful_ctest_executions':4,'same_products_unchanged':True}),flush=True)
