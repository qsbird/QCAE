# changes.commit generated input implementation 162

Scope: core framework boundary-contract quality for the existing `changes.commit` compatibility route. Root supplied working directory `/private/tmp/qcae-framework-delivery80` and HEAD `43568193d7414c09aae4bbd0e6690e005305144f`; Git was **NOT RUN**, so this is supplied provenance, not an independently verified checkout claim. Executor: `/root/c4_ext01_frozen41`.

Only two owned product files were edited. No other product, generator, registry, generated output, build target, tests, application implementation or bridge was edited. Source editing was handed back to root after the hashes below were observed; subsequent root formatting/generation will have its own hashes.

| Path | Before SHA256 | Implementation snapshot SHA256 |
|---|---|---|
| `schemas/operations/document_changes.json` | absent | `1bb0d110afad54695020fae83145eb1105c4d4e38949af952a34e76de4790b08` |
| `adapters/engine_api/src/ipc_api.cpp` | `1ea5d9083c6655a05f18710015d1d01117c8c1fbc4e97dde1bb2db01a8b7eb29` | `44784184c18dd8c4e67c5a7eae0dcff4547b157dcd3681e7858fdf421fbf5bce` |

## Contract and discovery

The new one-operation schema declares `changes.commit`, version 1, schema ID `qcae.operation.changes.commit.v1`, generated type `ChangesCommitInput`, effect `document_write`, and the existing document/epoch/expected_revision/idempotency_key context requirements. Its only field is required string `preview_id`, field ID 1, `allow_empty: false`. No Profile requirement is introduced.

The existing schema membership glob in `modules/operations/CMakeLists.txt` already feeds `tools/generate_operation_contracts.py`; no CMake or generator edit is needed. The generated header itself was **NOT GENERATED** by this executor. Static inspection of the unchanged generator shows this schema will provide `InputTraits<ChangesCommitInput>::definition()` and `from_value`, with unknown-field rejection, required-field checks and nonempty string decoding.

The IPC route gets installed version from that definition, then decodes parameters through those InputTraits before calling the existing application. `capabilities.list` uses the same definition for version, schema ID, fields, required flags, `minLength: 1` and `additionalProperties: false`. It exposes `wire_input_type: ChangesCommitInput` and `wire_output_type: ChangeReceipt`. The existing domain descriptor's `input_type`/`output_type`, availability and implementation status are retained.

Three existing private helpers have generic names (`string_input`, `version_rejection`, `describe_string_input`) because the same string-only boundary contract now serves five lifecycle inputs plus commit. Existing lifecycle call sites retain their decode/version rules and `DocumentInfo` output default; commit explicitly supplies `ChangeReceipt`. This adds no framework or dispatch layer.

## Rejection ordering and preserved authority

| Input | Intended boundary result from static inspection |
|---|---|
| omitted requested_version | installed v1, accepts valid parameters |
| numeric integer 1 / 1.0 | installed v1, accepts valid parameters |
| null, boolean, string, fractional, zero, negative, non-finite or outside uint32 | `INVALID_INPUT`, field `requested_version` |
| supported uint32 integer other than 1 | `SCHEMA_UNSUPPORTED`, field `requested_version` |
| missing or empty preview_id | `INVALID_INPUT`, field `input.preview_id` |
| non-string preview_id | `INVALID_INPUT`, field `input.preview_id` |
| extra parameter | `INVALID_INPUT`, field `input.<extra>` |

Version rejection precedes generated shape decoding inside the route; both precede `MemoryApplication::commit`. Envelope/parameter-object and `expected_profile` rejection retain the original ordering. The generated decoder's missing-input status is translated through the existing adapter exception path to `INVALID_INPUT`, as for lifecycle inputs. No key/outcome, preview consumption or document mutation is introduced at the decoding boundary.

The authoritative call remains `app.commit(caller, context(request), PreviewId{input.preview_id}, existing idempotency_key)` followed by `receipt_json`. The façade in `features/legacy_api/src/core.cpp` continues forwarding those four arguments to its one RecordApplication. No application commit, caller namespace, context parsing, idempotency/history implementation, undo/redo, persistent rows, operation-outcome lookup or revision output code is changed. Valid calls therefore continue to use the existing coordinator; runtime preservation is **NOT VERIFIED** in this executor's turn.

TypedHost's compatibility reservation check remains untouched (`typed_host.cpp:247`), and `changes.commit` remains in `compatibility_operation_supported`. No operation registry registration is added. Existing generated direct operations still dispatch through TypedHost exactly as before.

## Static review inputs and boundaries

Read current `docs/baseline/README.md`, `requirements.md`, `acceptance.md`, architecture README and module dependency graph; inspected the five lifecycle methods, their schema, existing generator/wire decoder, compatibility reservation, application façade and schema glob. Relevant requirements are REQ-02/09/15/16; relevant acceptance boundaries include TST-F08 and the existing transaction/idempotency/history cases. No dependency edge or core public SDK type changes.

Read `/private/tmp/qcae-legacy-contract-survey153/survey.md` (SHA256 `d0f61f0dce1e7ce2feb1be77dd3f0cd61c42fdec2191704a370431f55d427471`). Its earlier candidate HEAD and old parser findings remain survey provenance, not this candidate's validation results. No previous pass was reused as evidence for this change.

Static before/after hashes remained equal for the inspected unchanged references:

| Reference | SHA256 |
|---|---|
| generator | `c9bfd4f9ead15951ba51ae49ee90e9565bc1974fb83a7560296f9752c8444db2` |
| host_lifecycle.json | `a0395bf158a06605be765504d5eda06f6947fafd6054bdb50f0eafe1af49de51` |
| typed_host.cpp | `39b7478957cd45f6f1d7593c0df83dda67a85f023eaaf445712a81ce32700c98` |

## Execution status and root handoff

**NOT RUN:** generation, configure, compiler/build, tests/CTest, format/design/diff gates, engine/CLI/MCP/desktop or any product process, all Git commands. Static `rg`/file-range reads and SHA256 hashing were performed. No performance optimization or performance acceptance is claimed. QG-01 and QG-03 remain pending root execution; this file supplies only a scoped static QG-02 review.

Root owns execution and final Git delivery. The other test executor owns typed_host_tests.cpp and MCP metadata tests; input naming/version diagnostics were sent to root before implementation. Suggested meaningful checks are rejection leaving full state/store generation/history/preview unchanged, valid commit reusing a rejected request's key, omitted/v1 single commit, post-commit and post-undo same-key replay, changed-preview key conflict, existing stale revision/Epoch/history/outcome tests, exact engine-generated metadata and MCP metadata forwarding. These are pending checks, not results.

No other-file implementation recommendation is needed: existing CMake schema membership handles the new input, and TypedHost's reserved route is the intended compatibility boundary. Remaining legacy operations, performance, solver/AI environment and complete SK/P0 acceptance are outside this slice.
