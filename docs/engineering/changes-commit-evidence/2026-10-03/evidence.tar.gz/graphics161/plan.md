# 图形选择测试函数隔离：只读方案161

**建议有条件采用逐函数独立进程作为明确的方法后继；不是驱动修复，也不覆盖原失败。** 本代理仅审现有源码与实际日志，没有修改Git/源码、编译、执行Qt枚举/CTest/GUI或engine。

## 实际依据

158 PID54390在107.9506秒进入latestTree…，109.0047秒打印idle=true；150秒采样主线程87/87均在原生鼠标释放→VtkView→vtkHardwareSelector→glReadPixels→AppleMetalOpenGLRenderer→dispatch_group_wait。采样还报告dispatch soft limit64在87/87次达到、多条NSAnimation阻塞worker及5.8GiB footprint（峰值5.9GiB）。180.14秒按原界限SIGTERM，exit-15、无kill。stderr显示该函数72.124秒/整进程179.941秒。现在有实际证据排除“只是整个套件正常累计跑满”；确有长期同步图形等待。仍不能确定负责保留资源的组件或驱动根因。

156只跑同binary该slot，PID46084、exit0、1.7964秒，是诊断成功而非全套通过。上述旧事实绑定151候选，不能改标为当前commit6eab0ca的新实测。

## Fixture核对

源码708–1908有**23个测试函数、69个原测试/数据行**。每个函数（每次Qt数据行调用）各有局部SelectionEngine、Window；测试类无共享engine/window成员、static状态或自定义init/cleanup，原负例、迟到响应、相机/隐藏/资源/selection竞争都在同一函数内部完成。完整函数与tag清单在JSON。

main1910–1922为所有函数共享一个QApplication、一个私有Ini QSettings目录及QSurfaceFormat。selection文件对QSettings仅有main初始化，没有读写布局/跨slot断言，未发现必须跨slot顺序运行的契约。desktop本身550–552读布局、688–694的closeEvent写布局；不能据此假定整个Qt/驱动没有共享状态。BP17布局保存/重启/golden是独立要求，必须保留其原验证。

单函数进程仍是真实桌面/Qt/VTK与真实原生pick，含全部data行、hold/reorder/timeout断言。符合独立fixture与正常单桌面进程的用法。但它减少了原来同QApplication连续64个窗口的压力，**不与旧执行拓扑完全等价，不证明长期多窗口稳定性**。最大函数仍含13次窗口建立。

## 最小后继方法（NOT RUN/未实现）

只保留一个CTest `desktop_selection`、原TIMEOUT180。Python从开始设置一个monotonic180秒截止；实际binary的`-functions`枚举、23次顺序启动、所有等待/结果解析/cleanup都在同一个剩余预算里，不能每个函数重获180秒，也不能拆成23个各180秒测试。

实际`-functions`必须精确匹配冻结23个唯一函数及顺序。逐项调用同binary和函数名，不带`:tag`过滤，完整执行数据。每进程要求exit0、完整Totals、init/cleanup各1、原69行对应tag/顺序/次数精确吻合、FAIL/SKIP/BLACKLIST/XFAIL/XPASS为0，无额外函数、缺行或截断。其115条原始PASS包含23×2次init/cleanup；逻辑分母仍69行为行，不能造115案例。任一步失败先落actual receipt/raw后停止，整个剩余180秒不足即失败。

保持原main的私有QSettings、真实native后端和pick，不改HOME、不覆盖用户设置，不清空已有raw。每个owned PID记录argv/起止/实际退出、stdout/stderr及source/binary前后hash；超时保留真实terminal，不能自动重试或把未知视为PASS。新方法来源单列，151/157/158超时一直保持失败。

## 修复优先级与反对意见

1. 先做以上小型方法后继：依据是fixture独立和单slot真实成功，实施只需test调度，不动renderer。能否23/69在180秒完成仍未知。
2. 若继续修产品context，先实际证明销毁后的QObject/OpenGL上下文、worker/footprint存活情况，再定位native deferred cleanup。当前Window为unique_ptr销毁，VtkView默认析构、Impl移除observer，stock QVTK管理上下文；没有证明缺Finalize。盲目加close会触发layout写入，也不是零行为变化。
3. 只有owner/lifetime证据后才改有界fixture清理或Qt/VTK teardown。不得因堆栈直接加renderer Finalize、强制GPU同步、禁硬件pick、改动画/图形后端/SDK或增timeout。

反对点明确：隔离绕开了未解决的累计native生命周期压力；13行同函数仍可能挂；23次QApplication启动可能超过原180秒；QSettings跨函数持久状态变为新目录，虽无本套依赖断言也须公开。原整套失败与真实产品长期稳定性问题均保留，任何方法成功不等于驱动根因修复或完整SK/P0通过。
