# 图形选择累计窗口压力与验收合同：有限只读判断163

**明确结论：69行在同一QApplication中累计创建/销毁独立窗口，是目前selection测试的跨fixture进程耦合；未发现任何基线要求把这个特定累计窗口序列作为P0/核心的固定验收工作流。建议有条件隔离函数，不据此修renderer。原累计压力失败是真实未解决风险，不能删除或改标通过。**

## 原文与真实生命周期

REQ01/05/06要求主视口、准确选择、基础显示；REQ11控制任务/缓冲/历史等可计量资源；REQ17及runtime-and-data第1节要求唯一engine、GUI关闭/重连不取消已提交任务。TST-A07/11/12分别覆盖选择、配额、重连，不要求同一GUI QApplication连续69次销毁主窗口。

SK10要求30工具固定脚本、12拾取案例、旧选择拒绝及布局往返；BP13工具enter/pick/preview/cancel/apply/leave、BP16十二goldens、BP17真正重启GUI恢复设置、BP20 worker/queue配额。SK14仍要求不漏回归/适用失败0；因此不能只换PASS标签绕过原失败，必须明确后继方法及保留的压力风险。

`run_desktop`（desktop.cpp2706–2745）是一个QApplication、一个stack DesktopWindow、show/app.exec，没有循环创建主窗。selection的23函数/69行各建局部SelectionEngine+Window，没有跨slot共享fixture和设置断言；函数内最大13行完整保留。main仅给原同进程设置一个私有Ini目录；BP17重启/golden属于独立测试，不能由selection代替。

**单主窗不等于生产不产生其他native window。** desktop.cpp1243/1318/1351/1630有真实QFileDialog，1449创建Nastran导出QDialog并于1451设WA_DeleteOnClose。因此fixture压力虽非规定工作流，却提示可能影响真实长会话/反复对话框的风险；目前未证明这些生产路径触发158的问题。

## 现有验证保护什么

- c3_tool_lifecycle_tests.cpp154–156在循环外建一个窗口，186–273同窗口30轮真实engine工具/undo。它保护持续窗口内的工具/模型/history行为；原line30并非formalpick/leave压力证明，104补证保持独立来源。
- desktop_tests.cpp223–380的冻结pick矩阵保护真实点/线/Tri3 goldens；455保护reply中销毁client；916–966三档VtkView各20个局部delta保护数组/块界限。这些没有验证69次native shell销毁后的AppKit资源归还。
- resource_tests.cpp49–117的4MiB/lease/cap、skeleton_fault_tests.cpp764后的实体/history配额、representative_tests.cpp429–454的2worker+8queue拒绝是真正有界资源验证；它们不证明Qt/AppleMetal context配额。

## 158实际native信号和候选owner

按thread header解析四份sample，停在NSAnimation _runBlocking的线程数分别**14、35、58、64**（15/45/90/150秒）；footprint为1.5G、3.2G、5.2G、5.8G，末次峰5.9G。150秒还显示dispatch软上限64在87/87采样达到。主线程87/87沿真实mouse release→vtkHardwareSelector→glReadPixels→AppleMetalOpenGLRenderer→dispatch_group_wait。它进入slot107.95秒、idle109.00秒，最后slot耗时72.124秒，整进程原180秒终止；156新进程单slot1.796秒成功。这已不是只有正常累计等待，但尚不是组件归责证据。

有依据的**候选**为：Qt/Cocoa show/resize/layout/close的native动画生命周期；重复QVTK context/renderwindow释放阶段；native worker饱和后pixel-readback依赖不能完成。都只是推断。没有NSAnimation创建/完成owner、对应native window pointer、QtGL/VTK对象实际残留或任务依赖图。线程数不是live窗口数，footprint不是context数；不能把Finalization缺失或驱动bug写成事实。

## 图形功能gate如何解释

建议保留一个CTest及原**180秒整套**上限（枚举、全部23启动/cleanup都计入），在实际binary完整枚举后逐函数调用、不带tag过滤；全部69原行、hardwarepick、负例、held/reordered回复和步内wait原样。逐项要求真实exit0、exacttags/完整Totals无fail/skip/blacklist；不因分进程重新分配180秒。新增init/cleanup不扩行为分母。

若实际通过，可称“desktop_selection全部既有功能断言在函数进程隔离方法下通过”。不能称原单进程压力通过、驱动修复、完整图形P0或SK14/P0。完整既有图形功能gate还需当前source绑定的独立pick矩阵、持续单窗口工具/工作流和BP17设置重启证据。原151/157/158失败及新方法差异必须公开；若正常同窗口功能仍失败，它仍是阻塞。

若要修cleanup，先在根调度的有界诊断中关联fixture销毁与QObject/QWindow/QtGL/QVTK/VTK weak owner及NSAnimation创建/结束事件，证明实际owner哪里未释放，再改那个边界。当前default VtkView析构+stock QVTK集成及Impl observer removal没有证明漏资源。盲目close会写布局，不能视为无行为变化。不增180秒、不禁硬件pick、不改SDK/backend，不添加猜测renderer Finalize。

本次只有只读原文/源码/旧sample处理；未执行编译、产品、Qt枚举、GUI、测试或Git命令，未修改仓库/旧证据。新方案仍NOT RUN。
