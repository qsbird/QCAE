# changes.commit 保护测试 162

已完成两个授权测试文件的聚焦修改，审查者 **NOT RUN**；没有编译、生成、测试、产品/guard运行或 Git 操作。实际 MCP 路径是 `tests/mcp_bridge_tests.py`，不是 `tests/test_mcp_bridge.py`。

`typed_host_tests.cpp` 新增独立 omitted/v1 变体，复用原 OpenContractStore 和状态快照，额外比较整个 DocumentView 的版本与记录差量。两次重试每种版本/shape/schema拒绝后，仍用同一 preview/key 合法提交，检查只产生一份事务/持久批次/历史项。提交后和真实 undo 后切换版本写法重放，比较完整原 receipt（仅 current 状态与 replay 标记更新），并检查无第二次状态或持久写入。不同真实 preview 同键冲突、旧 revision/Epoch 继续走原应用路径。没有复制提交算法。

实际 engine descriptor 的 version/schema/context/field 与 generated ChangesCommitInput 比较，闭合 schema 仅有 required 非空 preview_id；保留历史 input_type，新增发现使用 wire_input_type，输出仍为 ChangeReceipt。MCP tools/list 检查 engine schema 透传、可选 uint32 requested_version、所需上下文/key、无 expected_profile；没有改 bridge 的语义解析。

根代理负责新 schema 的生成构建、C++ clang-format21、typed_host/MCP 及真实 SQLite 回归。当前 source hashes 记录于 review.json，阶段为本代理停止编辑后、根格式化前，不能替代最终冻结摘要。FakeStore 不能证明 SQLite I/O 或进程恢复；根另拥有 changes_commit_ipc_tests.py。原 lookup/命名空间/recovery 保护保持，运行与完整 SK/P0 不在本记录中宣称通过。
