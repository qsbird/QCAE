# Next core contract batch 167 — seven empty-input host routes

Recommend one bounded batch for **capabilities.list, project.current, project.status, model.summary, history.list, history.undo and history.redo**. These seven routes share the same empty object input and existing adapter pattern, so implement and validate them together. Do not spend one build/test cycle per empty operation. Keep **operations.get** outside this batch because it has conditional lookup semantics rather than an empty input.

This is a read-only plan against `/private/tmp/qcae-framework-delivery80` while root owns frozen candidate 165 execution. Source, Git, generation, compilation, tests and product execution: **NOT RUN / NOT MODIFIED**. No running 165 result or earlier pass is claimed here.

## Current source evidence

All eight inspected routes are in the supported compatibility catalog and have real application/adaptor code. Current `generated_input` admits five project lifecycle inputs and changes.commit; these eight still reject every supplied requested_version with INVALID_INPUT while omission is accepted. Their discovered entries have the original catalog types/context flags, but no generated operation version/schema ID/wire DTO metadata. Existing business functionality is present.

| Route / ipc_api.cpp location | Parameters and current metadata | Actual call / unchanged result | Context to preserve |
|---|---|---|---|
| capabilities.list / 337 | `{}`; no parameter schema; supported_scope=global_catalog_only | Existing catalog assembly, storage/recovery/profile/package discovery; CapabilityCatalog JSON | No document, epoch, revision or key |
| project.current / 429 | `{}`; no parameter schema | app.current_document() → info_json(DocumentInfo) | No document, epoch, revision or key; existing no-active-document result |
| project.status / 498 | `{}`; already has correct closed empty parameter schema | app.snapshot(DocumentRef) → info_json plus existing geometry/mesh counts | Document and epoch; no revision or key |
| model.summary / 498 | `{}`; already has correct closed empty parameter schema | Same snapshot plus current materials/counts JSON | Document and epoch; no revision or key |
| history.list / 578 | `{}`; no parameter schema | app.history(DocumentRef) → items/cursor/revision from HistorySnapshot | Document and epoch; no revision or key |
| history.undo / 570 | `{}`; no parameter schema | app.undo(caller, WriteContext, key) → receipt_json(ChangeReceipt) | Document, epoch, expected revision, key |
| history.redo / 570 | `{}`; no parameter schema | app.redo(caller, WriteContext, key) → receipt_json(ChangeReceipt) | Document, epoch, expected revision, key |
| operations.get / 591 | lookup_scope, original_operation, lookup key; optional original_mode; no parameter schema; supported_scope=host_lifecycle_and_document_change_outcomes | Host app.host_operation → DocumentInfo; document app.operation or RecordApplication.action_outcome → ChangeReceipt | Host requires no DocRef; document branch requires document+epoch; no write revision/key |

Static call-chain check: the MemoryApplication façade forwards current/history/undo/redo/outcome calls into its one RecordApplication. Snapshot conversion retains the existing immutable committed source. TypedHost reserves compatibility operation names. None of these readings demonstrates a missing handler or coordinator bypass.

Observed source SHA256:

| Path | SHA256 |
|---|---|
| adapters/engine_api/src/ipc_api.cpp | a36cc9db72eab5631802f1542efad07265a8e3567e672e43bee4ac86f2b2f0ec |
| schemas/operations/document_changes.json | 1bb0d110afad54695020fae83145eb1105c4d4e38949af952a34e76de4790b08 |
| tools/generate_operation_contracts.py | c9bfd4f9ead15951ba51ae49ee90e9565bc1974fb83a7560296f9752c8444db2 |
| docs/contracts/operations.json | 1f4edc5eff997ae37780d8d6c2216e2442bd6dad2a8744bc86558ad2729d27cd |
| adapters/engine_api/src/typed_host.cpp | 39b7478957cd45f6f1d7593c0df83dda67a85f023eaaf445712a81ce32700c98 |
| survey153/survey.md | d0f61f0dce1e7ce2feb1be77dd3f0cd61c42fdec2191704a370431f55d427471 |

The survey's 29 manual catalog parsers become 28 after changes.commit is generated. **28 describes hand-decoding style, not 28 missing functions, unsafe writers or failed acceptance cases.** This plan rechecked the eight named routes, not a new whole-catalog census. Survey153's old changes.commit finding is superseded by implemented 162 source; 165 runtime acceptance remains root-owned.

## Bounded implementation

Use seven v1 generated definitions, all `fields: []`, with schema IDs `qcae.operation.<operation>.v1`:

| Input type | Effect | document / epoch / revision / idempotency |
|---|---|---|
| CapabilitiesListInput | read_only | false / false / false / false |
| ProjectCurrentInput | read_only | false / false / false / false |
| ProjectStatusInput | read_only | true / true / false / false |
| ModelSummaryInput | read_only | true / true / false / false |
| HistoryListInput | read_only | true / true / false / false |
| HistoryUndoInput | document_write | true / true / true / true |
| HistoryRedoInput | document_write | true / true / true / true |

No expected_profile requirement. Add one `schemas/operations/host_reads.json` for the five reads; append the two writes to existing document_changes.json without changing changes.commit. In ipc_api.cpp, reuse 162's string_input, version_rejection and describe_string_input with each InputTraits definition. Version and generated empty-object decoding precede the existing route's application call. Extend only the generated version admission set; leave other legacy version rejection alone.

The current generator explicitly accepts an empty fields list, emits zero-sized allowed/required arrays, validates object_fields and constructs the empty typed input. String and optional-string support also exists, but no generator change is needed for these seven. Generated output types are **not** new application output DTOs: this generator defines inputs and OperationDefinition only. Do not invent generated serializers or promise additional output fields.

Keep catalog domain input/output labels and actual response serializers unchanged. For wire metadata, use the actual existing result names: CapabilityCatalog, DocumentInfo for current, ProjectStatus, ModelSummary, HistorySnapshot, and ChangeReceipt for undo/redo. Document explicitly that these labels describe existing results, not newly generated output schemas. Preserve all saved/dirty/count/history/replayed/current_revision fields, top-level revision insertion, supported_scope, availability and package discovery data.

For project.status/model.summary, remove only their obsolete manual empty-schema override when the generated descriptor becomes authoritative. Their current closed hand schema is already sufficient to describe input shape; converting it supplies a common schema/version source, not missing business functionality. Keep entity.query/entity.references handwritten schemas untouched because they already describe actual bounds/shape. Do not modify application/history/store/TypedHost/registry or bridge code. No handler registration, dependency, new mechanism, performance change or output-policy change.

Product scope is three paths: new host_reads.json, document_changes.json, ipc_api.cpp. Keep one owner for this boundary set so concurrent agents never edit the same IPC file. Independent tests and review can proceed in parallel.

## Why operations.get is excluded

It is implemented and caller-scoped. Host lookups resolve project.create/open/save/save_as/close through the existing host namespace; project.open defaults omitted original_mode to normal and accepts recover explicitly. Document lookups map commit/undo/redo and can resolve retained generated action facts even after a contributor is removed. The result is DocumentInfo or ChangeReceipt depending on scope.

The `idempotency_key` **parameter is an outcome lookup key**, not an idempotency requirement for this read request. A global generated context with required document/epoch would break host lookup. Currently original_mode is only interpreted in host project.open; other branches may ignore a provided value, including a non-string value. A single optional-string InputTraits decoder would tighten those accepted irrelevant-field cases. The current generator cannot express branch-dependent presence/context/enums by itself, and the discovery helper cannot describe this union automatically.

Keep that route for a subsequent bounded parameterized-lookup slice after its compatibility policy is explicit. Do not turn its semantics into generic registry dispatch, forbid lookups for unavailable original handlers, require write revision, change caller namespace or weaken preserved action facts. This is a concrete reason to exclude it from the seven-route batch, not a missing-implementation claim.

## Shared meaningful checks, executed once after integration

1. Table-driven engine discovery and decoder checks for all seven: one available descriptor each, exact generated schema ID/version/type/context, fields=[], closed empty parameters schema; omit or numeric integer v1 accepts, malformed versions return INVALID_INPUT/requested_version, valid future uint32 versions return SCHEMA_UNSUPPORTED/requested_version. Extra string/numeric/null parameters reject. Compare complete resulting JSON shape with existing serializers; the version addition must not change effect/availability.
2. Five read operations leave the full document snapshot, saved/dirty state, persistent store generation and history unchanged. capabilities.list works before project creation; current preserves its no-active-document result. Document reads still require only document+epoch and reject old epoch, without acquiring a mutation key or revision requirement.
3. Two history writes in a populated real application: invalid shape/version leaves snapshot, store generation, revision, items/cursor and available undo/redo unchanged. Reuse the exact rejected mutation key for a valid operation to prove no key was consumed. Valid omitted/v1 undo and redo each commit exactly once; retries return the original transaction without moving history again. Keep stale revision, stale epoch, actor scope and unavailable undo/redo outcomes.
4. Meaningful replay sequence: undo key U, redo key R, retry U using its original context/key; return U's original outcome and retain the redone model. operations.get must still resolve U/R and the original changes.commit outcome; cross-caller and unrecorded-key lookup remains rejected. This covers existing behavior without converting operations.get.
5. Test the same boundary through production IPC with explicit SQLite: save/normal-open/recovery retains bounded history and the existing distinction between document identity and epoch. Reuse relevant existing recovery coverage; avoid seven duplicate lifecycle workflows. Extend actual MCP metadata assertions for all seven in one existing two-client/CLI fixture, requiring engine parameter schemas/context/version to reach the tool schemas unchanged. MCP continues forwarding operations rather than parsing business semantics.

Primary places: tests/typed_host_tests.cpp for table/actual coordinator/store assertions; tests/mcp_bridge_tests.py for engine-to-MCP metadata and actual calls; a grouped real IPC scenario alongside changes_commit_ipc_tests.py or existing ipc_tests.py/m23_ipc_tests.py where their fixtures fit. Existing record_application_tests.cpp protects core history semantics. Generated input/build/public-header and format/design/diff checks are required by root's final batch validation; no tests are run in this plan.

Parallel ownership: boundary implementer owns the three product paths; test implementer owns typed_host_tests.cpp plus one grouped IPC fixture; MCP/review implementer owns mcp_bridge_tests.py and readonly review. Root alone performs generation/build/tests/Git after one combined source freeze. Do not split the shared product file among workers or run seven independent full rebuilds.

## Actual SK-04 / REQ-16 boundary

REQ-16's concrete discovery gap here is that five empty-input routes lack the closed parameter schema already enforced by their server; the MCP fallback is an unrestricted object, so discovery and server acceptance differ. The two existing hand schemas correctly describe project.status/model.summary and are not absent contracts. All seven also lack the installed per-operation version/schema metadata added by 162's pattern. Closing these input/discovery inconsistencies is the next framework slice.

SK-04 additionally requires typed-contract coverage for the actual catalog, zero advertised missing handlers, zero coordinator bypass and the specified three-entry evidence. Generated DTO counts alone cannot establish it. This inspection found real implementations and authority-preserving calls for the eight routes; it did not establish missing handlers or bypasses. The seven-route slice still needs post-change common runtime evidence, and the wider catalog coverage remains scoped/unproven. Handwritten correct schemas, typed application arguments, existing intrinsic version checks and implemented contributors must count as their real contracts rather than being relabeled defects solely because parsing is manual.

Nothing here reopens performance, real AI/solver environment, six-category contribution implementation or placeholder future operations. No complete SK/REQ-16/P0 pass is claimed. Status: **PLAN ONLY; all execution NOT RUN**.
