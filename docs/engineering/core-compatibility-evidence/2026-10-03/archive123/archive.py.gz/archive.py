import gzip, hashlib, json, pathlib, re, time
repo=pathlib.Path('/private/tmp/qcae-framework-delivery80')
out=repo/'docs/engineering/core-compatibility-evidence/2026-10-03'
out.mkdir(parents=True,exist_ok=True)
entries=[]
def sha(b):return hashlib.sha256(b).hexdigest()
def add(prefix,path,base):
    raw=path.read_bytes()
    target=out/prefix/(str(path.relative_to(base))+'.gz')
    target.parent.mkdir(parents=True,exist_ok=True)
    packed=gzip.compress(raw,compresslevel=9,mtime=0)
    if target.exists():assert target.read_bytes()==packed, 'Archived original input drift: '+str(path)
    else:target.write_bytes(packed)
    entries.append({'path':str(target.relative_to(repo)),'origin':str(path),'raw_bytes':len(raw),'raw_sha256':sha(raw),'archive_bytes':len(packed),'archive_sha256':sha(packed),'encoding':'gzip'})
selected={
'legacy-physical117':('/private/tmp/qcae-legacy-physical117',['source-freeze.json','build_legacy.py','configure.json','configure.stdout.log','configure.stderr.log','build.json','build.stdout.log','build.stderr.log','build-result.json','actual-binary-comparison.json','physical-M-subset.bdf','capture_old.py','capture_old118.py','migrate_current118.py','post-run-readonly-review.json']),
}
for prefix,(directory,names) in selected.items():
    base=pathlib.Path(directory)
    for name in names:add(prefix,base/name,base)
    for folder in ['old-native-01','old-native-02','current-native-01']:
        for path in sorted((base/folder).iterdir()):
            if path.is_file() and path.suffix in ['.json','.log']:add(prefix,path,base)
for prefix,folder in [('compatibility120','/private/tmp/qcae-core-compatibility-checks120'),('v1-preparation117','/private/tmp/qcae-record-v1-prep117'),('interface-preparation117','/private/tmp/qcae-interface-bindings117'),('review121','/private/tmp/qcae-core-compat-review121'),('v1-review122','/private/tmp/qcae-record-v1-review122'),('off117','/private/tmp/qcae-package-off-prep117')]:
    base=pathlib.Path(folder)
    assert base.exists(),base
    for path in sorted(base.rglob('*')):
        if path.is_file() and path.suffix in ['.json','.log','.md','.txt','.py','.cpp'] and not any(part == '__pycache__' or part == 'CMakeFiles' or part == 'build' for part in path.relative_to(base).parts[:-1]):
            add(prefix,path,base)
base=pathlib.Path('/private/tmp/qcae-core-compatibility-checks120-builds')
for folder in ['sqlite','sanitized-v1','core','local']:
    for name in ['CMakeCache.txt','compile_commands.json']:
        add('compile120',base/folder/name,base)
add('archive123',pathlib.Path(__file__),pathlib.Path(__file__).parent)
add('archive123',pathlib.Path(__file__).with_name('validation.py'),pathlib.Path(__file__).parent)
for entry in entries:
    archive=repo/entry['path'];packed=archive.read_bytes();raw=gzip.decompress(packed)
    assert sha(packed)==entry['archive_sha256'] and sha(raw)==entry['raw_sha256']
index={'schema_version':'qcae-bounded-compatibility-evidence/1','created_unix':time.time(),'scope':'Original actual current412 test candidate and source85 OFF/legacy physical subset receipts remain distinct. Synthetic declared reader v1 is not a historical producer or a replacement of frozen R0 fixtures. No runtime databases, binaries, original source archive, credentials or solver runs archived.','files':entries,'archive_count':len(entries),'all_archives_decoded_and_SHA_verified':True}
(out/'archive-index.json').write_text(json.dumps(index,indent=2)+'\n')
print(json.dumps({'archive_count':len(entries),'archive_bytes':sum(e['archive_bytes'] for e in entries),'raw_bytes':sum(e['raw_bytes'] for e in entries),'index_sha256':sha((out/'archive-index.json').read_bytes())}))
