#!/usr/bin/env python3
"""Root-run mandatory core/local and SQLite checks plus targeted format1 reader compatibility sanitizer validation."""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import time

SOURCE = Path('/private/tmp/qcae-framework-delivery80')
OUT = Path(__file__).resolve().parent
BUILD = Path('/private/tmp/qcae-core-compatibility-checks120-builds')
FREEZE = Path('/private/tmp/qcae-framework-runtime86/frozen-candidate.json')
CMAKE = '/opt/homebrew/Cellar/cmake/4.3.0/bin/cmake'
CTEST = '/opt/homebrew/Cellar/cmake/4.3.0/bin/ctest'
PYTHON = '/Library/Frameworks/Python.framework/Versions/3.14/bin/python3.14'
frozen = json.loads(FREEZE.read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def fact(path):
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': sha(path)}


def write(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


assert not BUILD.exists(), 'Use a fresh build directory'
attempt = OUT / 'attempt-01'
attempt.mkdir()
inputs = {name: sha(SOURCE / name) for name in frozen['source_files']}
inputs['tests/schema_rejection_sqlite_tests.cpp'] = sha(SOURCE / 'tests/schema_rejection_sqlite_tests.cpp')
inputs['tests/record_project_v1_compatibility_tests.cpp'] = sha(SOURCE / 'tests/record_project_v1_compatibility_tests.cpp')
old_changes = [name for name in frozen['source_files'] if inputs[name] != frozen['source_files'][name]]
assert old_changes == ['CMakeLists.txt'], old_changes
base_head = subprocess.check_output(['git', '-C', str(SOURCE), 'rev-parse', 'HEAD'], text=True).strip()
write(attempt / 'candidate.json', {
    'base_head': base_head, 'original_source_commit': frozen['commit'],
    'original_source410_sha256': frozen['source410_sha256'],
    'old_source_files_changed': old_changes, 'candidate_files': inputs,
    'candidate_files_count': len(inputs),
    'candidate_files_sha256': hashlib.sha256(json.dumps(inputs, sort_keys=True,
        separators=(',', ':')).encode()).hexdigest(),
    'scope': 'Test-only registrations plus two tests versus original85; one new format1 reader test versus8b, all409 original non-CMake frozen files unchanged.'})
method = fact(Path(__file__).resolve())


def guard():
    assert inputs == {name: sha(SOURCE / name) for name in inputs}, 'Candidate source changed'
    assert fact(Path(__file__).resolve()) == method, 'Method changed'
    assert subprocess.check_output(['git', '-C', str(SOURCE), 'rev-parse', 'HEAD'], text=True).strip() == base_head


def command(name, argv, environment=None):
    guard()
    env = os.environ.copy()
    for key in ['ASAN_OPTIONS', 'UBSAN_OPTIONS', 'LSAN_OPTIONS', 'DYLD_INSERT_LIBRARIES',
                'DYLD_LIBRARY_PATH', 'DYLD_PRINT_LIBRARIES', 'QT_QPA_PLATFORM']:
        env.pop(key, None)
    if environment:
        env.update(environment)
    start = time.time()
    stdout, stderr = attempt / (name + '.stdout.log'), attempt / (name + '.stderr.log')
    with stdout.open('xb') as out, stderr.open('xb') as err:
        result = subprocess.run(argv, cwd=SOURCE, env=env, stdout=out, stderr=err)
    guard()
    write(attempt / (name + '.json'), {'actual_exit_code': result.returncode, 'argv': argv,
          'cwd': str(SOURCE), 'started_unix': start, 'finished_unix': time.time(),
          'elapsed_seconds': time.time() - start, 'explicit_environment': environment or {},
          'stdout': fact(stdout), 'stderr': fact(stderr), 'candidate_before_after_equal': True})
    print(json.dumps({'command': name, 'actual_exit_code': result.returncode}), flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)
    if name.endswith('-build'):
        text = stdout.read_text(errors='replace') + stderr.read_text(errors='replace')
        assert not re.findall(r'(?m)^.*\bwarning:.*$', text), 'Compiler warnings in actual build'


for config, flags, targets, selection in [
    ('sqlite', ['-DQCAE_BUILD_IPC=OFF', '-DQCAE_BUILD_STORAGE=ON', '-DCMAKE_BUILD_TYPE=Release'], [], []),
    ('sanitized-v1', ['-DQCAE_BUILD_IPC=OFF', '-DQCAE_BUILD_STORAGE=ON',
                         '-DQCAE_ENABLE_SANITIZERS=ON', '-DCMAKE_BUILD_TYPE=Release'],
     ['--target', 'qcae_record_project_v1_compatibility_tests'], ['-R', '^record_project_v1_compatibility$']),
    ('core', ['-DQCAE_BUILD_IPC=OFF', '-DQCAE_BUILD_STORAGE=OFF', '-DCMAKE_BUILD_TYPE=Release'], [], []),
    ('local', ['-DQCAE_BUILD_IPC=ON', '-DQCAE_BUILD_STORAGE=OFF', '-DCMAKE_BUILD_TYPE=Debug',
               '-DCMAKE_PREFIX_PATH=/opt/homebrew/opt/qt'], [], []),
]:
    directory = BUILD / config
    argv = [CMAKE, '-S', str(SOURCE), '-B', str(directory), '-G', 'Ninja',
            '-DBUILD_TESTING=ON', '-DQCAE_BUILD_DESKTOP=OFF', '-DQCAE_ENABLE_NASTRAN_PACKAGE=ON',
            '-DCMAKE_EXPORT_COMPILE_COMMANDS=ON', '-DCMAKE_CXX_EXTENSIONS=OFF',
            '-DCMAKE_CXX_COMPILER=/Library/Developer/CommandLineTools/usr/bin/c++',
            '-DPython3_EXECUTABLE=' + PYTHON, *flags]
    if '-DQCAE_BUILD_STORAGE=ON' in flags:
        argv += ['-DSQLite3_LIBRARY=/opt/homebrew/Cellar/sqlite/3.53.4/lib/libsqlite3.3.53.4.dylib',
                 '-DSQLite3_INCLUDE_DIR=/opt/homebrew/Cellar/sqlite/3.53.4/include']
    command(config + '-configure', argv)
    command(config + '-build', [CMAKE, '--build', str(directory), '-j', '4', *targets])
    command(config + '-inventory', [CTEST, '--test-dir', str(directory), '--show-only=json-v1'])
    command(config + '-ctest', [CTEST, '--test-dir', str(directory), '--output-on-failure',
                              '--verbose', '-j', '1', *selection],
            {'ASAN_OPTIONS': 'detect_leaks=0:halt_on_error=1',
             'UBSAN_OPTIONS': 'halt_on_error=1:print_stacktrace=1'} if selection else None)
    inventory = json.loads((attempt / (config + '-inventory.stdout.log')).read_text())
    names = [row['name'] for row in inventory['tests']]
    executed = ['record_project_v1_compatibility'] if selection else names
    log = directory / 'Testing/Temporary/LastTest.log'
    archived_log = attempt / (config + '-LastTest.log')
    archived_log.write_bytes(log.read_bytes())
    compilation = json.loads((directory / 'compile_commands.json').read_text())
    for row in compilation:
        assert '-std=c++20' in row['command'] and '-std=gnu++20' not in row['command']
    write(attempt / (config + '-complete.json'), {
          'actual_exit_code': 0, 'configured_test_names': names, 'executed_test_names': executed,
          'executed_count': len(executed), 'raw_log': fact(archived_log),
          'compile_commands': fact(directory / 'compile_commands.json'),
          'strict_cpp20': True, 'compiler_warnings': [],
          'source_candidate': fact(attempt / 'candidate.json'),
          'sanitizer_scope': 'ASan+UBSan new format1 compatibility test; LSan not measured' if selection else 'normal'})
guard()
write(attempt / 'complete.json', {'actual_exit_code': 0, 'candidate_before_after_equal': True,
      'configs': ['sqlite', 'sanitized-v1', 'core', 'local'], 'method': method,
      'scope': 'Mandatory core/local and SQLite regression; targeted dual-sanitizer format1 compatibility check.'})
