#!/usr/bin/env python3
"""Root-owned actual OFF86 IPC observation; no GUI and no copied host bindings."""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
SOURCE = Path('/private/tmp/qcae-framework-preference-fix85')
COMMIT = 'ef0df3bdd8c1b27330d71a596f16098cb6b6410a'
DIGEST = '15d20f20fef88ed6d1b8637b97edf77143887728cb9c42427620b25429e65c03'
PACKAGE_OPERATIONS = ('model.export', 'model.export_preview', 'artifact.get',
                      'artifact.reconcile', 'nastran.ui', 'project.migrate_profile',
                      'results.read_fixture', 'results.get')


def require(value, message):
    if not value:
        raise RuntimeError(message)


def write(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--engine', required=True)
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    output = Path(args.output)
    require(not output.exists(), 'Refuse reuse of an IPC attempt directory')
    output.mkdir(parents=True)
    inputs = json.loads((HERE / 'prepared-inputs.json').read_text())
    engine = Path(args.engine).resolve()
    expected_engine = inputs['stock_OFF86_engine']
    require(str(engine) == expected_engine['path'], 'IPC engine is not the original OFF86 engine')
    require(engine.stat().st_size == expected_engine['bytes'] and
            hashlib.sha256(engine.read_bytes()).hexdigest() == expected_engine['sha256'],
            'OFF86 engine byte drift')
    require(os.environ.get('QCAE_SOURCE_TREE_SHA256') == DIGEST,
            'This observer must run through the source-pinned root wrapper')
    # These helpers only frame/decode data. Their tracked bytes are guarded by collect88.
    sys.path.insert(0, str(SOURCE / 'tests'))
    from c3_sync_ipc_tests import IpcClient, decode_packet, fetch_resource, render_resource
    endpoint = str(output / 'engine.sock')
    workspace = str(output / 'workspace.sqlite')
    require(len(endpoint.encode()) < 104, 'Owned Unix socket path exceeds macOS bound')
    client = IpcClient(endpoint)
    argv = [str(engine), '--socket', endpoint, '--workspace', workspace]
    env = os.environ.copy()
    env['DYLD_PRINT_LIBRARIES'] = '1'
    process = None
    error = None
    started = time.time()
    observations = {'source_commit': COMMIT, 'source_tree_sha256': DIGEST,
                    'kind': 'actual-OFF86-IPC-observation117',
                    'full_six_category_private_host_binding_proven': False,
                    'scope': 'new actual calls to original source85 OFF86 production engine'}
    cleanup = {'process_id': None, 'precleanup_exit_code': None,
               'owner_terminated': False, 'owner_killed': False, 'reaped': False,
               'actual_exit_code': None, 'cleanup_error': None}
    with (output / 'engine.stdout.log').open('xb') as stdout, \
         (output / 'engine.stderr.log').open('xb') as stderr:
        try:
            process = subprocess.Popen(argv, cwd=SOURCE, env=env, stdout=stdout, stderr=stderr)
            cleanup['process_id'] = process.pid
            write(output / 'engine-start.json', {'argv': argv, 'process_id': process.pid,
                  'started_unix': started, 'cwd': str(SOURCE), 'engine': expected_engine,
                  'DYLD_PRINT_LIBRARIES': '1', 'socket': endpoint, 'workspace': workspace})
            deadline = time.monotonic() + 20
            last_error = None
            while True:
                require(process.poll() is None, 'Owned engine exited during startup')
                try:
                    capabilities = client.call('capabilities.list')
                    break
                except (OSError, AssertionError, json.JSONDecodeError) as failure:
                    last_error = str(failure)
                    require(time.monotonic() < deadline, 'Engine startup timeout: ' + last_error)
                    time.sleep(.05)
            operations = {row['name']: row for row in capabilities['operations']}
            profiles = capabilities['declared_solver_profiles']
            require(profiles == [], 'OFF engine advertised a solver profile')
            require(capabilities['durable'] is True and capabilities['storage_mode'] == 'sqlite',
                    'Actual OFF observer must own an explicit SQLite workspace')
            for name in PACKAGE_OPERATIONS:
                require(name not in operations or operations[name]['available'] is False,
                        'OFF engine advertised package operation: ' + name)
            for name in ('analysis.check', 'node.move', 'mesh.create_tri3',
                         'geometry.create_line', 'view.render_resource'):
                require(operations.get(name, {}).get('available') is True,
                        'Generic operation was removed: ' + name)
            document = client.call('project.create', {'name': 'OFF117 common services'}, key='create117')
            before = client.current()
            rejected = []
            for name in PACKAGE_OPERATIONS:
                reply = client.call(name, {}, before, expected='failed')
                require(reply.get('error', {}).get('code') == 'UNSUPPORTED_CAPABILITY',
                        'Package request did not fail as unsupported: ' + name)
                rejected.append({'operation': name, 'response': reply})
            require(rejected[1]['response']['error']['message'] == 'No model codec package is enabled',
                    'OFF codec/profile combined rejection differs from the real host dispatch path')
            analysis = client.call('analysis.check', {'analysis_id': 'unknown-analysis117'},
                                   before, key='invalid-common-analysis117', expected='failed')
            require(analysis.get('error', {}).get('code') != 'UNSUPPORTED_CAPABILITY',
                    'Generic analysis.check was disabled with the package')
            require(client.current() == before, 'Rejected/read-only probes changed the document')
            line = client.call('geometry.create_line', {'start_mm': [0, 0, 0],
                                                       'end_mm': [1000, 0, 0]}, before, 'line117')
            current = client.current()
            require(int(current['revision']) == int(document['revision']) + 1,
                    'Common geometry write did not use one actual transaction')
            entities = client.call('entity.query', {'kind': 'geometry'}, current)['entities']
            require([row['entity_id'] for row in entities] == [line['entity_id']],
                    'Common geometry query differs from the committed result')
            view = client.call('view.create', {'hidden_ids': [], 'camera_fingerprint': 'OFF117'}, current)
            rendered = render_resource(client, view, current)
            require(rendered['mode'] == 'full', 'First actual host render is not full')
            resource_bytes, resource_facts = fetch_resource(client, rendered['manifest'])
            packet = decode_packet(resource_bytes)
            require(packet['document_id'] == current['document_id'] and
                    packet['document_epoch'] == current['document_epoch'] and
                    int(packet['revision']) == int(current['revision']),
                    'Actual RenderService packet has a different document version')
            require(packet['geometry_lines'] == [{
                'entity_id': line['entity_id'], 'start_mm': [0.0, 0.0, 0.0],
                'end_mm': [1000.0, 0.0, 0.0], 'visible': True}],
                'Generic actual host geometry rendering was removed')
            client.call('history.undo', context=current, key='undo117')
            after_undo = client.current()
            require(client.call('entity.query', {'kind': 'geometry'}, after_undo)['entities'] == [],
                    'Common versioned history no longer undoes the geometry write')
            observations.update(declared_solver_profiles=profiles, actual_capabilities=capabilities,
                                rejected_package_requests=rejected,
                                generic_analysis_check_invalid_input_response=analysis,
                                initial_document=document, after_line=current,
                                after_undo=after_undo, geometry_query=entities,
                                actual_RenderService_packet=packet,
                                render_manifest=rendered['manifest'],
                                render_resource_facts=resource_facts,
                                render_bytes_sha256=hashlib.sha256(resource_bytes).hexdigest(),
                                actual_engine_instance_id=client.instance_id,
                                checks_passed=True)
        except BaseException as failure:
            error = type(failure).__name__ + ': ' + str(failure)
            observations['checks_passed'] = False
        finally:
            if process is not None:
                cleanup['precleanup_exit_code'] = process.poll()
                try:
                    if cleanup['precleanup_exit_code'] is None:
                        process.terminate()
                        cleanup['owner_terminated'] = True
                    try:
                        process.wait(timeout=5)
                    except subprocess.TimeoutExpired:
                        process.kill()
                        cleanup['owner_killed'] = True
                        process.wait(timeout=5)
                    cleanup['reaped'] = process.returncode is not None
                    cleanup['actual_exit_code'] = process.returncode
                except BaseException as failure:
                    cleanup['cleanup_error'] = type(failure).__name__ + ': ' + str(failure)
            write(output / 'engine-process.json', cleanup)
    cleanup_ok = (cleanup['reaped'] is True and cleanup['precleanup_exit_code'] is None and
                  cleanup['owner_terminated'] is True and cleanup['owner_killed'] is False and
                  type(cleanup['actual_exit_code']) is int and cleanup['actual_exit_code'] == -15 and
                  cleanup['cleanup_error'] is None)
    if not cleanup_ok:
        error = error or 'Owned engine cleanup did not prove unforced/reaped SIGTERM -15'
    observations.update(error=error, cleanup_postcondition_passed=cleanup_ok,
                        actual_exit_code=0 if error is None else 1,
                        actual_request_count=len(client.transcript),
                        private_host_owner_gaps=[
                            'No IPC endpoint enumerates the individual codec/profile injection pointers',
                            'No separate Nastran export-validator owner registry is exposed',
                            'Actual RenderService generic packet does not identify registration owner'])
    write(output / 'transcript.json', {'requests': client.transcript, 'frames': client.frames})
    write(output / 'observations.json', observations)
    return observations['actual_exit_code']


if __name__ == '__main__':
    raise SystemExit(main())
