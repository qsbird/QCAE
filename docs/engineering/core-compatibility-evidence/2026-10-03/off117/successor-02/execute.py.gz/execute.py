#!/usr/bin/env python3
"""Append-only root entry; original source85/86 receipts retain their own scope."""
from __future__ import annotations
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import sys
import time

sys.dont_write_bytecode = True
ENTRY = Path(__file__).resolve().parent
HERE = ENTRY.parent
PEER = ENTRY / 'peer'
SOURCE = Path('/private/tmp/qcae-framework-preference-fix85')
COMMIT = 'ef0df3bdd8c1b27330d71a596f16098cb6b6410a'
DIGEST = '15d20f20fef88ed6d1b8637b97edf77143887728cb9c42427620b25429e65c03'
PYTHON = '/Library/Frameworks/Python.framework/Versions/3.14/bin/python3.14'
CMAKE = '/opt/homebrew/Cellar/cmake/4.3.0/bin/cmake'
COLLECTOR = Path('/private/tmp/qcae-framework-reliability-collector88/collect.py')


def require(value, message):
    if not value:
        raise RuntimeError(message)


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            digest.update(block)
    return digest.hexdigest()


def fact(path):
    path = Path(path).resolve()
    require(path.is_file(), 'Required file is absent: ' + str(path))
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': sha(path)}


def read(path):
    return json.loads(Path(path).read_text())


def write(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def inputs(index_sha):
    index_path = ENTRY / 'immutable-index.json'
    require(sha(index_path) == index_sha, 'Private input index SHA differs from reviewed bytes')
    index = read(index_path)
    for entry in index['entries']:
        path = HERE / entry['relative_path']
        require(not path.is_symlink() and path.is_file(), 'Private indexed input replaced')
        require(path.stat().st_size == entry['bytes'] and sha(path) == entry['sha256'],
                'Private input bytes changed: ' + entry['relative_path'])
    metadata = read(HERE / 'prepared-inputs.json')
    for entry in metadata['external_inputs']:
        require(fact(entry['path']) == entry, 'Prepared external input drift: ' + entry['path'])
    require(metadata['source_commit'] == COMMIT and metadata['source410_sha256'] == DIGEST,
            'This method is exclusively pinned to source85, not the new delivery/test source')
    require(fact(COLLECTOR) == metadata['collector88'], 'collect88 bytes differ')
    spec = importlib.util.spec_from_file_location('qcae_collect88_for_OFF117', COLLECTOR)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return metadata, module


def verify_compilation(build, collector):
    cache = collector.cache_values(build / 'CMakeCache.txt')
    for name, expected in {'QCAE_ENABLE_NASTRAN_PACKAGE': 'OFF', 'QCAE_BUILD_IPC': 'ON',
                           'QCAE_BUILD_STORAGE': 'ON', 'QCAE_BUILD_DESKTOP': 'OFF',
                           'QCAE_ENABLE_SANITIZERS': 'OFF', 'CMAKE_BUILD_TYPE': 'Release',
                           'CMAKE_CXX_EXTENSIONS': 'OFF', 'CMAKE_CXX_STANDARD': '20'}.items():
        # Non-cache CMake variables are checked against the actual compile commands below.
        if name not in ('CMAKE_CXX_EXTENSIONS', 'CMAKE_CXX_STANDARD'):
            require(cache.get(name) == expected, 'Unexpected effective cache: ' + name)
    commands = read(build / 'compile_commands.json')
    peer = [entry for entry in commands if Path(entry['file']).resolve() == PEER / 'peer.cpp']
    assembly = [entry for entry in commands if Path(entry['file']).resolve() ==
                SOURCE / 'adapters/engine_api/src/engine_contributions.cpp']
    require(len(peer) == len(assembly) == 1, 'Actual peer/assembly compile command missing or duplicated')
    require('-std=c++20' in peer[0]['command'] and '-std=gnu++20' not in peer[0]['command'],
            'Independent peer was not compiled as strict C++20')
    require(re.search(r'(?:^|\s)-DQCAE_NASTRAN_PACKAGE_ENABLED=0(?:\s|$)', assembly[0]['command']),
            'Actual production assembly did not receive the private OFF macro')
    require(COMMIT in peer[0]['command'] and DIGEST in peer[0]['command'],
            'Actual consumer compile command omitted its source binding')
    return {'cache': fact(build / 'CMakeCache.txt'),
            'compile_commands': fact(build / 'compile_commands.json'),
            'actual_peer_compile_command': peer[0], 'actual_assembly_compile_command': assembly[0],
            'production_private_macro': 'QCAE_NASTRAN_PACKAGE_ENABLED=0',
            'peer_definitions': ['QCAE_OFF_SOURCE_COMMIT', 'QCAE_OFF_SOURCE_TREE_SHA256']}


def build(attempt, metadata, collector):
    directory = attempt / 'build'
    require(not directory.exists(), 'Fresh private build directory must not exist')
    argv = [CMAKE, '-S', str(PEER), '-B', str(directory), '-G', 'Ninja',
            '-DCMAKE_BUILD_TYPE=Release', '-DCMAKE_EXPORT_COMPILE_COMMANDS=ON',
            '-DCMAKE_CXX_COMPILER=/Library/Developer/CommandLineTools/usr/bin/c++',
            '-DCMAKE_MAKE_PROGRAM=' + metadata['ninja']['path'],
            '-DPython3_EXECUTABLE=' + PYTHON,
            '-DQCAE_SOURCE_ROOT=' + str(SOURCE), '-DQCAE_FINAL_SOURCE_ROOT=' + str(SOURCE),
            '-DQCAE_FINAL_COMMIT=' + COMMIT, '-DQCAE_FINAL_SOURCE_TREE_SHA256=' + DIGEST,
            '-DQt6_DIR=/opt/homebrew/Cellar/qtbase/6.11.1/lib/cmake/Qt6',
            '-DSQLite3_LIBRARY=/opt/homebrew/Cellar/sqlite/3.53.4/lib/libsqlite3.3.53.4.dylib',
            '-DSQLite3_INCLUDE_DIR=/opt/homebrew/Cellar/sqlite/3.53.4/include']
    collector.command(attempt, 'off117-peer-configure', argv,
                      [directory / 'CMakeCache.txt', directory / 'compile_commands.json'],
                      extra_inputs=metadata['external_inputs'])
    binary = directory / 'qcae_off_public_peer117'
    collector.command(attempt, 'off117-peer-build',
                      [CMAKE, '--build', str(directory), '--clean-first', '--parallel', '2',
                       '--verbose', '--target', 'qcae_off_public_peer117'], [binary],
                      extra_inputs=metadata['external_inputs'])
    compilation = verify_compilation(directory, collector)
    warnings = []
    for stream in ('stdout', 'stderr'):
        text = (attempt / 'logs' / ('off117-peer-build.' + stream + '.log')).read_text(errors='replace')
        warnings.extend(line for line in text.splitlines() if re.search(r'\bwarning:', line))
    require(not warnings, 'Actual private build emitted compiler warnings')
    binary_fact = fact(binary)
    for name, target in (('peer', binary_fact), ('stock-engine', metadata['stock_OFF86_engine'])):
        for option, suffix in (('-L', 'dependency-list'), ('-l', 'load-commands')):
            collector.command(attempt, 'off117-' + name + '-' + suffix,
                              ['/usr/bin/otool', option, target['path']], [],
                              extra_inputs=[*metadata['external_inputs'], target])
    complete = {'kind': 'actual fresh independent OFF117 peer build', 'actual_build_exit_code': 0,
                'source_commit': COMMIT, 'source410_sha256': DIGEST, 'binary': binary_fact,
                'compilation': compilation, 'actual_compiler_warning_count': len(warnings),
                'stock_engine_rebuilt': False, 'stock_engine': metadata['stock_OFF86_engine'],
                'no_new_CTest_or_full_skeleton_pass_claim': True}
    write(attempt / 'build-complete.json', complete)
    return complete


def images(log, pid, binary, metadata, required_names):
    text = Path(log).read_text(errors='replace')
    paths = sorted(set(re.findall(r'(?m)^dyld\[' + str(pid) + r'\]: <[0-9A-Fa-f-]+> (/.+)$', text)))
    require(paths and binary['path'] in paths, 'Owned PID actual loader image observation missing')
    configured = {entry['path']: entry for entry in metadata['configured_tool_and_sdk_pins']}
    actual, system = [], []
    for raw in paths:
        if raw.startswith(('/usr/lib/', '/System/Library/')):
            system.append(raw)
            continue
        entry = fact(raw)
        if entry['path'] == binary['path']:
            require(entry == binary, 'Owned binary changed during native observation')
        elif entry['path'] in configured:
            require(entry == configured[entry['path']], 'Actual SDK image differs from configured bytes')
        actual.append({'observed_path': raw, **entry,
                       'matches_configured86_pin': entry['path'] in configured})
    for name in required_names:
        matches = [entry for entry in actual if Path(entry['path']).name == name]
        require(len(matches) == 1 and matches[0]['matches_configured86_pin'] is True,
                'Required actual configured image absent/unsealed: ' + name)
    return {'observed_pid': pid, 'raw_log': fact(log), 'external_images': actual,
            'system_shared_cache_paths': system, 'system_shared_cache_bytes_unavailable': True,
            'SDK_internal_owned_copy_coverage': 'unknown',
            'Qt_prefix_aliases_do_not_override_exact_resolved_byte_hash_comparison': True}


def observe(attempt, metadata, collector, build_attempt):
    complete = read(build_attempt / 'build-complete.json')
    require(complete['actual_build_exit_code'] == 0 and complete['source_commit'] == COMMIT and
            complete['source410_sha256'] == DIGEST, 'Fresh private OFF117 build receipt differs')
    binary = complete['binary']
    require(fact(binary['path']) == binary, 'Fresh peer binary byte drift')
    require(verify_compilation(build_attempt / 'build', collector) == complete['compilation'],
            'Actual peer cache/compile command drift')
    public_output = attempt / 'public-observations.json'
    public = collector.command(attempt, 'off117-public-calls',
                               ['/usr/bin/env', 'DYLD_PRINT_LIBRARIES=1', binary['path'], str(public_output)],
                               [public_output], extra_inputs=[*metadata['external_inputs'], binary])
    public_data = read(public_output)
    require(public_data.get('actual_exit_code') == 0 and public_data.get('checks_passed') is True and
            public_data['source_commit'] == COMMIT and public_data['source_tree_sha256'] == DIGEST,
            'Actual public peer observation failed/mismatched')
    public_images = images(public['stderr']['path'], public['pid'], binary, metadata, ('QtCore',))
    write(attempt / 'public-loaded-images.json', public_images)
    ipc_dir = attempt / 'ipc'
    collector.command(attempt, 'off117-real-OFF-IPC-calls',
                      [PYTHON, '-B', str(ENTRY / 'observer.py'), '--engine',
                       metadata['stock_OFF86_engine']['path'], '--output', str(ipc_dir)],
                      [ipc_dir], extra_inputs=metadata['external_inputs'])
    ipc = read(ipc_dir / 'observations.json')
    engine = read(ipc_dir / 'engine-process.json')
    require(ipc['actual_exit_code'] == 0 and ipc['checks_passed'] is True and
            ipc['cleanup_postcondition_passed'] is True,
            'Actual OFF IPC observation/cleanup failed')
    engine_images = images(ipc_dir / 'engine.stderr.log', engine['process_id'],
                           metadata['stock_OFF86_engine'], metadata,
                           ('QtCore', 'QtNetwork', 'libsqlite3.3.53.4.dylib'))
    write(attempt / 'engine-loaded-images.json', engine_images)
    for observed in (*public_images['external_images'], *engine_images['external_images']):
        require(fact(observed['path']) == {key: observed[key] for key in ('path', 'bytes', 'sha256')},
                'Observed image bytes changed before final seal')
    write(attempt / 'observation-complete.json', {
        'actual_new_public_and_IPC_command_exit_codes': [0, 0],
        'source_commit': COMMIT, 'source410_sha256': DIGEST,
        'source_scope': 'source85; never source117/current delivery full regression',
        'public': fact(public_output), 'IPC': fact(ipc_dir / 'observations.json'),
        'owned_engine_cleanup': engine, 'full_six_category_private_host_binding_proven': False,
        'pending': ['individual host codec/profile bindings',
                    'separate Nastran export-validator owner identity',
                    'host RenderService registration-owner identity'],
        'no_full_SK11_BP10_R5_P0_pass_claim': True})


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=('build', 'observe'))
    parser.add_argument('--attempt', default='01')
    parser.add_argument('--build-attempt', type=Path)
    parser.add_argument('--input-index-sha256', required=True)
    parser.add_argument('--execute', action='store_true', required=True)
    args = parser.parse_args()
    require(re.fullmatch(r'[0-9]{2}', args.attempt), 'Attempt must be two decimal digits')
    attempt = HERE / 'results' / (args.action + '-' + args.attempt)
    require(not attempt.exists(), 'Attempt directory already exists; preserve it and choose a new attempt')
    attempt.mkdir(parents=True)
    (attempt / 'commands').mkdir()
    (attempt / 'logs').mkdir()
    code = 1
    error = None
    write(attempt / 'action-start.json', {'actual_argv': sys.argv, 'process_id': os.getpid(),
          'source_commit': COMMIT, 'source410_sha256': DIGEST, 'started_unix': time.time()})
    try:
        metadata, collector = inputs(args.input_index_sha256)
        before = collector.guard()
        write(attempt / 'source-and-seven-original86-gates-before.json', before)
        if args.action == 'build':
            build(attempt, metadata, collector)
        else:
            require(args.build_attempt is not None, 'Observation requires an actual fresh peer build attempt')
            build_attempt = args.build_attempt.resolve()
            require(build_attempt.parent == HERE / 'results' and
                    re.fullmatch(r'build-[0-9]{2}', build_attempt.name),
                    'Do not import another peer/source build as the new OFF117 build')
            observe(attempt, metadata, collector, build_attempt)
        after = collector.guard()
        require(before == after, 'Original source86 prerequisites changed during the bounded action')
        write(attempt / 'source-and-seven-original86-gates-after.json', after)
        inputs(args.input_index_sha256)
        code = 0
    except BaseException as failure:
        error = type(failure).__name__ + ': ' + str(failure)
    write(attempt / 'action-complete.json', {'action': args.action, 'actual_wrapper_exit_code': code,
          'error': error, 'finished_unix': time.time(), 'source_commit': COMMIT,
          'source410_sha256': DIGEST, 'acceptance_promotion': False})
    return code


if __name__ == '__main__':
    raise SystemExit(main())
