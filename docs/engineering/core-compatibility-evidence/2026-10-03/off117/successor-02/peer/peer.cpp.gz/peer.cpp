#include "qcae/core.hpp"
#include "qcae/engine_contributions.hpp"
#include "qcae/operation_registry.hpp"
#include "qcae/record_application.hpp"
#include "qcae/records.hpp"
#include "qcae/render_projector.hpp"
#include <QCoreApplication>
#include <QFile>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QSaveFile>
#include <limits>
#include <stdexcept>
#include <unistd.h>

namespace {
using namespace qcae;
void need(bool condition, const char* message) {
    if (!condition)
        throw std::runtime_error(message);
}
QString text(std::string_view value) {
    return QString::fromUtf8(value.data(), static_cast<qsizetype>(value.size()));
}
QJsonArray record_types(const RecordRegistry& registry) {
    QJsonArray result;
    for (auto type : registry.types()) {
        const auto* descriptor = registry.find(type);
        need(descriptor != nullptr, "Enumerated record has no descriptor");
        result.append(QJsonObject{{"type_id", static_cast<qint64>(type.value)},
                                  {"name", text(descriptor->name)},
                                  {"query_kind", text(descriptor->query_kind)},
                                  {"has_validator", static_cast<bool>(descriptor->validate)}});
    }
    return result;
}
QJsonArray operation_descriptors(const operations::OperationRegistry& registry) {
    QJsonArray result;
    for (const auto& descriptor : registry.descriptors())
        result.append(QJsonObject{{"operation", text(descriptor.definition.operation_id)},
                                  {"schema_id", text(descriptor.definition.schema_id)},
                                  {"version", static_cast<qint64>(descriptor.definition.version)},
                                  {"available", descriptor.available},
                                  {"unavailable_reason", text(descriptor.unavailable_reason)}});
    return result;
}
bool available(const operations::OperationRegistry& registry, std::string_view name) {
    for (const auto& descriptor : registry.descriptors())
        if (descriptor.definition.operation_id == name)
            return descriptor.available;
    return false;
}
template <class T> QJsonObject project(const RecordRegistry& registry,
                                      const RenderContributions& rendering, T value) {
    const auto* contribution = rendering.find(RecordTraits<T>::type_id);
    need(contribution != nullptr, "Generic render contribution was removed");
    const auto record = registry.make(std::move(value));
    const auto item = contribution->project(record);
    QJsonObject result{{"record_type", static_cast<qint64>(contribution->record_type.value)},
                       {"topology", text(contribution->topology)},
                       {"actual_variant_index", static_cast<qint64>(item.index())}};
    if (const auto* cell = std::get_if<RenderCellSource>(&item)) {
        result.insert("cell_kind", static_cast<int>(cell->kind));
        result.insert("node_count", static_cast<qint64>(cell->nodes.size()));
    }
    return result;
}
} // namespace

int main(int argc, char** argv) {
    QCoreApplication qt(argc, argv);
    if (argc != 2 || QFile::exists(QString::fromLocal8Bit(argv[1])))
        return 2;
    QJsonObject report{{"kind", "actual-OFF-public-assembly-observation117"},
                       {"source_commit", QCAE_OFF_SOURCE_COMMIT},
                       {"source_tree_sha256", QCAE_OFF_SOURCE_TREE_SHA256},
                       {"process_id", QString::number(getpid())},
                       {"qt_version", qVersion()},
                       {"active_document_writes", 0},
                       {"full_six_category_private_host_binding_proven", false}};
    int code = 0;
    try {
        const bool enabled = ipc::nastran_package_enabled();
        report.insert("actual_nastran_package_enabled", enabled);
        need(!enabled, "Consumer actually linked an ON engine API");
        const auto contributions = ipc::default_engine_contributions();
        const auto assembly = ipc::assemble_engine(contributions);
        need(assembly.records->frozen(), "Production record registry was not frozen");
        RecordApplicationOptions options;
        options.registry = assembly.records;
        RecordApplication application(std::move(options));
        need(!application.current_document().ok(), "Passive consumer owns an active document");
        const DocumentView empty(assembly.records);
        QJsonArray owners;
        bool nastran_owner = false, generic_owner = false;
        std::size_t requested_tasks = 0;
        const auto no_task = [&requested_tasks]() -> TaskService& {
            ++requested_tasks;
            throw std::runtime_error("Passive registration must not start a task");
        };
        for (const auto& owner : contributions) {
            nastran_owner = nastran_owner || owner.id == "qcae.nastran";
            generic_owner = generic_owner || owner.id == "qcae.model";
            QJsonObject actual{{"owner", text(owner.id)},
                               {"has_record_callback", static_cast<bool>(owner.records)},
                               {"has_operation_callback", static_cast<bool>(owner.operations)},
                               {"has_publisher_factory", static_cast<bool>(owner.publisher_factory)}};
            if (owner.records) {
                RecordRegistry registered;
                owner.records(registered);
                registered.freeze();
                actual.insert("record_descriptors", record_types(registered));
                std::size_t calls = 0;
                for (const auto& rule : registered.rules()) {
                    rule(empty);
                    ++calls;
                }
                actual.insert("actual_empty_document_rule_calls", static_cast<qint64>(calls));
            }
            if (owner.operations) {
                operations::OperationRegistry registered;
                const auto installed = owner.operations(registered, application, no_task);
                need(installed.ok(), "Actual owner operation registration failed");
                actual.insert("operation_descriptors", operation_descriptors(registered));
            }
            if (owner.owned_rows) {
                QJsonArray rows;
                for (const auto& row : owner.owned_rows())
                    rows.append(text(row.owner));
                actual.insert("actual_owned_row_owners", rows);
            }
            owners.append(actual);
        }
        need(generic_owner && !nastran_owner, "Real OFF contribution owners are incorrect");
        report.insert("actual_contributions", owners);
        report.insert("actual_nastran_owner_present", nastran_owner);
        report.insert("assembled_record_descriptors", record_types(*assembly.records));
        operations::OperationRegistry combined;
        need(assembly.operations(combined, application, no_task).ok(),
             "Actual assembled operation registration failed");
        report.insert("assembled_operation_descriptors", operation_descriptors(combined));
        need(available(combined, "analysis.check"), "Generic analysis.check was removed");
        need(available(combined, "node.move"), "Generic node.move was removed");
        need(available(combined, "mesh.create_tri3"), "Generic Tri3 operation was removed");
        need(!available(combined, "nastran.ui") && !available(combined, "model.export"),
             "OFF registry advertised package handlers");
        operations::OperationContext context;
        context.caller = Caller{"off-passive117"};
        context.request_id = "off-passive117-ui";
        const auto ui = combined.invoke("nastran.ui", context, operations::Value{});
        need(!ui.ok(), "Absent package UI handler was invoked successfully");
        report.insert("actual_ui_registry_invocation",
                      QJsonObject{{"status", status_name(ui.status)},
                                  {"error_code", ui.error ? error_name(ui.error->code) : "none"},
                                  {"scope", "assembled OperationRegistry; no GUI created"}});
        records::Node valid{EntityId{"n1"}, {0, 0, 0}, {}};
        const auto* node = assembly.records->find(RecordTraits<records::Node>::type_id);
        need(node && node->validate, "Generic Node validator missing");
        node->validate(&valid, empty);
        auto invalid = valid;
        invalid.position[1] = std::numeric_limits<double>::quiet_NaN();
        bool rejected = false;
        try {
            node->validate(&invalid, empty);
        } catch (const RecordError& error) {
            need(error.code() == ErrorCode::invalid_input, "Unexpected generic validation error");
            rejected = true;
        }
        need(rejected, "Generic Node validator accepted a nonfinite coordinate");
        report.insert("actual_generic_validator_calls",
                      QJsonObject{{"valid_Node_accepted", true}, {"nonfinite_Node_rejected", rejected},
                                  {"not_a_Nastran_export_validator_registration", true}});
        const auto rendering = default_render_contributions();
        need(rendering.frozen(), "Generic render registry was not frozen");
        QJsonArray render_entries;
        for (const auto& [type, entry] : rendering.entries())
            render_entries.append(QJsonObject{{"record_type", static_cast<qint64>(type.value)},
                                               {"topology", text(entry.topology)}});
        const auto point = project(*assembly.records, rendering, valid);
        const auto beam = project(*assembly.records, rendering,
                                  records::Beam{EntityId{"b1"}, {}, {EntityId{"n1"}, EntityId{"n2"}},
                                                {0, 1, 0}, {}});
        const auto triangle = project(*assembly.records, rendering,
                                      records::Tri3{EntityId{"t1"},
                                                    {EntityId{"n1"}, EntityId{"n2"}, EntityId{"n3"}},
                                                    records::MeshId{"m1"}});
        const auto line = project(*assembly.records, rendering,
                                  records::GeometryLine{records::GeometryId{"g1"},
                                                       {0, 0, 0}, {1, 0, 0}, 1});
        need(point["actual_variant_index"].toInteger() == 0, "Node projection changed type");
        need(beam["node_count"].toInteger() == 2 && beam["cell_kind"].toInt() == 0,
             "Generic Beam polyline projection was removed");
        need(triangle["node_count"].toInteger() == 3 && triangle["cell_kind"].toInt() == 1,
             "Generic Tri3 polygon projection was removed");
        report.insert("actual_public_render_registry", render_entries);
        report.insert("actual_public_render_calls", QJsonArray{point, beam, triangle, line});
        need(requested_tasks == 0 && !application.current_document().ok(),
             "Passive observation started a task/document");
        report.insert("task_service_requests", static_cast<qint64>(requested_tasks));
        report.insert("checks_passed", true);
        report.insert("private_host_owner_gaps", QJsonArray{
            "IModelCodec/IProfileProvider injection pointers are private; actual IPC checks combined behavior",
            "Nastran export validator has no separately enumerable host owner registry",
            "RenderService private registry has no owner metadata; public factory calls are separate scope"});
    } catch (const std::exception& error) {
        report.insert("checks_passed", false);
        report.insert("error", QString::fromUtf8(error.what()));
        code = 1;
    }
    report.insert("actual_exit_code", code);
    QSaveFile output(QString::fromLocal8Bit(argv[1]));
    if (!output.open(QIODevice::WriteOnly))
        return 3;
    const auto bytes = QJsonDocument(report).toJson(QJsonDocument::Indented);
    if (output.write(bytes) != bytes.size() || !output.commit())
        return 3;
    return code;
}
