import hashlib, io, json, os, pathlib, subprocess, tarfile, time
root=pathlib.Path('/private/tmp/qcae-legacy-physical117')
source=root/'source-62e2b1d'
build=root/'build-01'
repo='/private/tmp/qcae-framework-delivery80'
commit='62e2b1d804e025636caf8fc1d49cd207ee1f6677'
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,x): p.write_text(json.dumps(x,indent=2,sort_keys=True)+'\n')
def snapshot(): return {str(p.relative_to(source)):{'bytes':p.stat().st_size,'sha256':digest(p)} for p in sorted(source.rglob('*')) if p.is_file()}
if source.exists() or build.exists(): raise RuntimeError('Fresh legacy source/build required')
raw=subprocess.check_output(['git','archive','--format=tar',commit],cwd=repo)
(root/'source.tar').write_bytes(raw)
source.mkdir()
with tarfile.open(fileobj=io.BytesIO(raw)) as archive: archive.extractall(source,filter='data')
before=snapshot()
dump(root/'source-freeze.json',{'commit':commit,'git_tree':subprocess.check_output(['git','rev-parse',commit+'^{tree}'],cwd=repo,text=True).strip(),'archive_sha256':hashlib.sha256(raw).hexdigest(),'files':before,'historical_binary_reproduction_claim':False})
commands=[('configure',['/opt/homebrew/Cellar/cmake/4.3.0/bin/cmake','-S',str(source),'-B',str(build),'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DBUILD_TESTING=OFF','-DQCAE_BUILD_IPC=ON','-DQCAE_BUILD_STORAGE=ON','-DQCAE_BUILD_DESKTOP=OFF','-DCMAKE_EXPORT_COMPILE_COMMANDS=ON','-DCMAKE_CXX_EXTENSIONS=OFF','-DCMAKE_CXX_COMPILER=/Library/Developer/CommandLineTools/usr/bin/c++','-DPython3_EXECUTABLE=/Library/Frameworks/Python.framework/Versions/3.14/bin/python3.14','-DCMAKE_PREFIX_PATH=/opt/homebrew/opt/qt']),('build',['/opt/homebrew/Cellar/cmake/4.3.0/bin/cmake','--build',str(build),'--target','qcae-engine','qcae-cli','--parallel','3'])]
for name,argv in commands:
    started=time.time()
    proc=subprocess.run(argv,cwd=source,capture_output=True)
    out=root/(name+'.stdout.log'); err=root/(name+'.stderr.log')
    out.write_bytes(proc.stdout);err.write_bytes(proc.stderr)
    dump(root/(name+'.json'),{'argv':argv,'cwd':str(source),'started_unix':started,'finished_unix':time.time(),'actual_exit_code':proc.returncode,'source_unchanged':snapshot()==before,'stdout':{'path':str(out),'sha256':digest(out),'bytes':out.stat().st_size},'stderr':{'path':str(err),'sha256':digest(err),'bytes':err.stat().st_size}})
    print(name,proc.returncode,flush=True)
    if proc.returncode: raise SystemExit(proc.returncode)
dump(root/'build-result.json',{'actual_exit_code':0,'source_unchanged':snapshot()==before,'binaries':{n:{'path':str(build/n),'bytes':(build/n).stat().st_size,'sha256':digest(build/n)} for n in ['qcae-engine','qcae-cli']},'original_R0_fixtures_modified':False,'new_binary_hashes_not_original_R0_binary_hashes':True})
