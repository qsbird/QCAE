import hashlib, importlib.util, json, pathlib, sqlite3, sys, time, traceback
root=pathlib.Path('/private/tmp/qcae-legacy-physical117')
repo=pathlib.Path('/private/tmp/qcae-framework-delivery80')
spec=importlib.util.spec_from_file_location('capture',(repo/'tools/capture_legacy_fixtures.py'))
c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
folder=root/'old-native-02';folder.mkdir(exist_ok=False)
deck='SOL 101\nCEND\nSUBCASE 1\nSPC = 20\nLOAD = 10\nDISPLACEMENT = ALL\nSPCFORCES = ALL\nBEGIN BULK\n'
deck+='\n'.join(f'GRID,{i+1},,{i*100}.,0.,0.' for i in range(11))+'\n'
deck+='MAT1,1,210000.,,0.3\nPBAR,1,1,100.,833.333,833.333,1400.\n'
deck+='\n'.join(f'CBAR,{i+1},1,{i+1},{i+2},0.,0.,1.' for i in range(10))+'\n'
deck+='FORCE,10,11,0,1.,0.,-1.,0.\nSPC1,20,123456,1\nENDDATA\n'
(root/'physical-M-subset.bdf').write_text(deck)
s=None; info=None
try:
    s=c.Session(root/'build-01/qcae-engine',root/'build-01/qcae-cli',folder)
    profile=s.capabilities['declared_solver_profiles'][0]['profile_ref']
    info=s.call('project.create',{'name':'Actual old-producer physical M subset'},key='old-create')
    info,_=s.commit(info,'model.import',{'root_resource':'physical-M-subset.bdf','resources':[{'path':'physical-M-subset.bdf','text':deck}],'source_profile_ref':profile,'unit_system':'mm-N-MPa'},'old-import')
    entities=s.call('entity.query',{},info)['entities']
    nodes=sorted((e for e in entities if e['kind']=='node'),key=lambda e:e['position_mm'][0])
    beams=[e for e in entities if e['kind']=='beam']
    c.check(len(nodes)==11 and len(beams)==10,'Actual old M physical topology')
    info,part=s.commit(info,'part.upsert',{'name':'Beam part','members':[e['entity_id'] for e in nodes+beams]},'old-part')
    info,_=s.commit(info,'assembly.upsert',{'name':'Beam assembly','children':[part]},'old-assembly')
    info,_=s.commit(info,'set.upsert',{'name':'Fixed support','members':[nodes[0]['entity_id']]},'old-fixed-set')
    info,_=s.commit(info,'set.upsert',{'name':'Loaded tip','members':[nodes[-1]['entity_id']]},'old-tip-set')
    path=folder/'old-physical-M.qcae'
    info=s.call('project.save',{'path':str(path)},info,'old-save')
    before=s.snapshot(info)
    c.check(before['counts']['node']==11 and before['counts']['beam']==10 and before['counts']['set']==2,'Old saved counts')
    s.call('project.close',{'policy':'discard'},info,'old-close')
    info=s.call('project.open',{'mode':'normal','path':str(path)},key='old-reopen')
    after=s.snapshot(info)
    c.check(c.model_semantics(before)==c.model_semantics(after),'Old normal-reopen all fields/references/source IDs/export resources')
    s.stop(info)
    metadata=c.capture_closed_database(path,root/'actual-old-physical-M02.qcae','project')
    result={'actual_exit_code':0,'scope':'Actual rebuilt historical 62e2b1d producer via real public IPC/preview/commit/save/reopen, physical M subset; not complete current 33-record M or a replacement of frozen R0 six fixtures','producer':json.loads((root/'build-result.json').read_text())['binaries'],'input_sha256':hashlib.sha256(deck.encode()).hexdigest(),'before':before,'after_normal_reopen':after,'original_input_metadata':metadata,'source_file_sha256':c.sha256(root/'actual-old-physical-M02.qcae'),'GeometryLine_count':0,'LoadCase_count':0,'saved_path':'actual-old-physical-M.qcae'}
    c.write_json(folder/'result.json',result)
    print('old physical capture 0; 11 nodes / 10 beams; all-field reopen equal',flush=True)
except BaseException as e:
    c.write_json(folder/'failure.json',{'actual_exit_code':1,'exception':repr(e),'traceback':traceback.format_exc()})
    raise
finally:
    if s:
        c.write_json(folder/'transcript.json',s.transcript)
        s.stop()
        c.write_json(folder/'process.json',{'pid':s.process.pid,'owned':True,'started_argv':s.process.args,'literal_exit_code':s.process.poll(),'reaped':s.process.poll() is not None})
        s.stop()
