import collections, csv, hashlib, json, os, pathlib, sqlite3, struct, subprocess, time, traceback
root=pathlib.Path('/private/tmp/qcae-legacy-physical117')
repo=pathlib.Path('/private/tmp/qcae-framework-delivery80')
folder=root/'current-native-01';folder.mkdir(exist_ok=False)
engine=pathlib.Path('/private/tmp/qcae-framework86-builds/desktop/qcae-engine')
cli=engine.with_name('qcae-cli')
source=root/'actual-old-physical-M02.qcae'
old=json.loads((root/'old-native-02/result.json').read_text())['after_normal_reopen']
source_hash=hashlib.sha256(source.read_bytes()).hexdigest()
original_fixtures={str(p.relative_to(repo)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (repo/'tests/fixtures/legacy').rglob('*') if p.is_file()}
transcript=[]; process=None; log=None
serial=0

def check(ok,why):
    if not ok: raise AssertionError(why)
def dump(path,x):path.write_text(json.dumps(x,indent=2,sort_keys=True)+'\n')
def call(op,parameters=None,context=None,key=None,status='success',extra=None):
    global serial
    serial+=1
    request={'api_version':'1.1','request_id':f'actual-migration118-{serial}','operation':op,'parameters':parameters or {}}
    if context: request.update({k:context[k] for k in ['document_id','document_epoch']},expected_revision=context['revision'])
    if key:request['idempotency_key']=key
    if extra:request.update(extra)
    started=time.time()
    proc=subprocess.run([str(cli),'--socket',str(folder/'engine.sock'),'--no-start'],input=json.dumps(request)+'\n',text=True,capture_output=True,timeout=15)
    row={'request':request,'actual_cli_exit_code':proc.returncode,'started_unix':started,'finished_unix':time.time(),'stdout':proc.stdout,'stderr':proc.stderr}
    transcript.append(row);dump(folder/'transcript.json',transcript)
    response=json.loads(proc.stdout);row['response']=response
    check(response['request_id']==request['request_id'],'Response request identity')
    check(response['status']==status,f'{op} expected {status}, got {response}')
    check(proc.returncode==(0 if status=='success' else 2),f'{op} CLI exit')
    return response['data'] if status=='success' else response

def persisted():
    with sqlite3.connect(f'{(folder/"workspace.sqlite").as_uri()}?mode=ro',uri=True) as db:
        return {n: db.execute('SELECT * FROM '+n+' ORDER BY 1,2').fetchall() for (n,) in db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name")}

def snapshot(info,profile):
    entities=call('entity.query',{'limit':1000},info)['entities']
    refs=[]
    for e in entities:refs.extend(call('entity.references',{'entity_id':e['entity_id'],'direction':'outgoing'},info)['references'])
    analysis=next(e['entity_id'] for e in entities if e['kind']=='analysis')
    export=call('model.export_preview',{'analysis_id':analysis,'expected_profile_ref':profile},info)
    return {'document':info,'history':call('history.list',{},info),'entities':entities,'references':refs,'export':export,'counts':dict(collections.Counter(e['kind'] for e in entities))}

def rewrite_profile(x,installed):
    if isinstance(x,dict):
        if set(x)=={'profile_id','profile_version','definition_digest'}:return installed
        return {k:rewrite_profile(v,installed) for k,v in x.items()}
    if isinstance(x,list):return [rewrite_profile(v,installed) for v in x]
    return x

def engineering(old_snapshot,actual,installed):
    expected=rewrite_profile(old_snapshot,installed)
    actual_by={e['entity_id']:e for e in actual['entities']}
    additions={};compared=0
    for e in expected['entities']:
        got=actual_by.get(e['entity_id']);check(got is not None,'Lost old identity '+e['entity_id'])
        for k,v in e.items():check(got.get(k)==v,f'Old field mismatch {e["entity_id"]}.{k}: {got.get(k)} vs {v}');compared+=1
        additions[e['entity_id']]={k:v for k,v in got.items() if k not in e}
    old_ids={e['entity_id'] for e in expected['entities']}
    old_refs=sorted(expected['references'],key=lambda v:json.dumps(v,sort_keys=True))
    current_old_refs=sorted([v for v in actual['references'] if v['from'] in old_ids and v['to'] in old_ids],key=lambda v:json.dumps(v,sort_keys=True))
    check(old_refs==current_old_refs,'Old cross-entity physical/organization reference changed')
    added=[e for e in actual['entities'] if e['entity_id'] not in old_ids]
    check(len(added)==1 and added[0]['kind']=='mesh','Only documented imported Mesh may be added')
    check(actual['counts'].get('geometry',0)==0 and actual['counts'].get('load_case',0)==0,'Do not pretend GeometryLine/LoadCase migrated')
    return {'old_entity_fields_compared':compared,'old_entity_count':len(old_ids),'old_references_compared':len(old_refs),'added_records_query_visible':added,'new_fields_on_old_entities':additions}

def cards(export):
    out=collections.defaultdict(list)
    for r in export['resources']:
        for line in r['text'].splitlines():
            line=line.split('$')[0].strip()
            if not line or ',' not in line:continue
            vals=next(csv.reader([line]))
            if vals[0] in ['GRID','CBAR','MAT1','PBAR','FORCE','SPC1']:
                clean=[]
                for x in vals[1:]:
                    x=x.strip()
                    try:clean.append(float(x.replace('D','E')))
                    except ValueError:clean.append(x)
                out[vals[0]].append(clean)
    return {k:sorted(v,key=lambda x:x[0]) for k,v in out.items()}

try:
    log=(folder/'engine.log').open('w+')
    process=subprocess.Popen([str(engine),'--socket',str(folder/'engine.sock'),'--workspace',str(folder/'workspace.sqlite')],stdout=log,stderr=log)
    deadline=time.time()+15
    while not (folder/'engine.sock').exists():
        check(process.poll() is None,'Current engine exited before listen')
        check(time.time()<deadline,'Current startup original 15s cap')
        time.sleep(.05)
    capabilities=call('capabilities.list')
    installed=capabilities['declared_solver_profiles'][0]['profile_ref']
    old_profile=old['profile_ref']
    before_rows=persisted()
    plain=call('project.open',{'mode':'normal','path':str(source)},key='plain-old',status='failed')
    check(plain['error']['code']=='SCHEMA_UNSUPPORTED','Stock current ordinary open must reject old semantic profile')
    check(persisted()==before_rows,'Failed normal open persisted anything')
    params={'source_path':str(source),'old_profile_id':old_profile['profile_id'],'old_profile_version':old_profile['profile_version'],'old_definition_digest':old_profile['definition_digest']}
    wrong=call('project.migrate_profile',{**params,'old_definition_digest':params['old_definition_digest']+'-wrong'},key='wrong-digest',status='failed',extra={'expected_profile':installed})
    check(wrong['error']['code']=='SCHEMA_UNSUPPORTED','Wrong old profile semantic digest must reject')
    check(persisted()==before_rows,'Wrong migration persisted anything')
    info=call('project.migrate_profile',params,key='actual-migrate',extra={'expected_profile':installed})
    info=call('project.current')
    check(info['dirty'] and info['saved_path']=='','Explicit migration protects original save path')
    migrated=snapshot(info,installed)
    compared=engineering(old,migrated,installed)
    original_cards=cards(old['exports'][0]);current_cards=cards(migrated['export'])
    check(original_cards==current_cards,'Independent CSV card value/connectivity/number readback changed')
    check(len(current_cards['GRID'])==11 and len(current_cards['CBAR'])==10,'Independent exported topology readback')
    check(current_cards['GRID'][5][2:5]==[500.,0.,0.],'Independent midpoint coordinate')
    check(current_cards['MAT1'][0][1]==210000. and current_cards['MAT1'][0][3]==.3,'Independent elastic constants')
    check(current_cards['PBAR'][0][2:6]==[100.,833.333,833.333,1400.],'Independent section properties')
    check(current_cards['FORCE'][0][1:]==[11.,0.,1.,0.,-1.,0.],'Independent tip nodal force')
    check(current_cards['SPC1'][0][1:]==[123456.,1.],'Independent fully fixed support')
    replay=call('project.migrate_profile',params,key='actual-migrate',extra={'expected_profile':installed})
    check(replay['document_id']==info['document_id'],'Migration idempotent replay creates a second document')
    conflict=call('project.migrate_profile',{**params,'old_definition_digest':params['old_definition_digest']+'-wrong'},key='actual-migrate',status='conflict',extra={'expected_profile':installed})
    check(call('project.current')==info,'Migration key conflict changed current document')
    call('project.close',{'policy':'keep_recovery'},info,'keep-migrated')
    recovered=call('project.open',{'mode':'recover'},key='recover-migrated')
    check(recovered['document_id']==info['document_id'] and recovered['document_epoch']!=info['document_epoch'],'Recovery identity/epoch semantics')
    recovered_snapshot=snapshot(recovered,installed)
    check(recovered_snapshot['entities']==migrated['entities'] and recovered_snapshot['references']==migrated['references'],'Recovery loses migrated physical identities/fields/ref')
    destination=folder/'current-physical-M.qcae'
    saved=call('project.save',{'path':str(destination)},recovered,'save-new')
    check(not saved['dirty'] and pathlib.Path(saved['saved_path'])==destination,'New save path/dirty semantics')
    call('project.close',{'policy':'discard'},saved,'discard-current')
    reopened=call('project.open',{'mode':'normal','path':str(destination)},key='reopen-current')
    check(reopened['document_id']!=recovered['document_id'] and reopened['document_epoch']!=recovered['document_epoch'] and reopened['revision']=='0','Normal open identity/history distinction')
    final=snapshot(reopened,installed)
    check(final['entities']==migrated['entities'] and final['references']==migrated['references'],'New current-format file loses migrated fields')
    check(final['history']['items']==[],'Normal reopen must have empty history')
    check(hashlib.sha256(source.read_bytes()).hexdigest()==source_hash,'Original old input bytes changed')
    check({str(p.relative_to(repo)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (repo/'tests/fixtures/legacy').rglob('*') if p.is_file()}==original_fixtures,'Original R0 golden fixture changed')
    dump(folder/'result.json',{'actual_exit_code':0,'scope':'Real historical QCAE-PROJECT1 physical M subset, explicit current profile migration, real SQLite lifecycle and independent old/new BDF card engineering readback; not complete33-record M or changed R0 denominator','actual_current_source':'ef0df3bdd8c1b27330d71a596f16098cb6b6410a','canonical410_sha256':'15d20f20fef88ed6d1b8637b97edf77143887728cb9c42427620b25429e65c03','current_binaries':{n:{'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for n,p in [('engine',engine),('cli',cli)]},'old_source_file_sha256':source_hash,'original_R0_fixtures_unchanged':True,'old_profile':old_profile,'installed_profile':installed,'plain_rejection':plain,'wrong_digest_rejection':wrong,'idempotency_conflict':conflict,'physical_comparison':compared,'independent_cards':current_cards,'migrated':migrated,'recovered':recovered_snapshot,'reopened_current':final,'GeometryLine_and_LoadCase_not_in_old_source':True})
    print('actual old-to-current physical migration 0; complete old fields/ref/source numbers, BDF readback and SQLite lifecycle passed',flush=True)
except BaseException as e:
    dump(folder/'failure.json',{'actual_exit_code':1,'exception':repr(e),'traceback':traceback.format_exc()})
    raise
finally:
    if process:
        if process.poll() is None:process.terminate();process.wait(timeout=10)
        dump(folder/'process.json',{'pid':process.pid,'owned':True,'started_argv':process.args,'literal_exit_code':process.returncode,'reaped':process.poll() is not None})
    if log:log.close()
    dump(folder/'transcript.json',transcript)
