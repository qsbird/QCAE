from __future__ import annotations

from collections import Counter
import gzip
import hashlib
import json
from pathlib import Path

ROOT = Path('/private/tmp/qcae-framework-delivery80')
OUT = Path('/private/tmp/qcae-interface-bindings117')
FRAMEWORK = 'docs/engineering/core-framework-evidence/2026-10-02'
FOLLOWUP = 'docs/engineering/core-acceptance-evidence/2026-10-03'
CENTRAL = 'docs/engineering/core-interface-evidence-bindings-2026-10-03.json'
FIELD = 'actual_evidence_binding_2026_10_03'


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def load(rel: str):
    return json.loads((ROOT / rel).read_text())


v = load(FRAMEWORK + '/validation.json')
f = load(FOLLOWUP + '/validation.json')
old_index = load(FRAMEWORK + '/archive-index.json')['records']
new_index = load(FOLLOWUP + '/archive-index.json')['files']
proofs = {}
decoded = {}


def add_old(name: str, record):
    rel = FRAMEWORK + '/' + record['archive']['relative_path']
    raw = (ROOT / rel).read_bytes()
    body = gzip.decompress(raw) if record['encoding'] == 'gzip' else raw
    assert len(raw) == record['archive']['bytes'] and sha(raw) == record['archive']['sha256'], name
    assert len(body) == record['original']['bytes'] and sha(body) == record['original']['sha256'], name
    assert record in old_index, name
    proofs[name] = {
        'path': rel, 'archive_bytes': len(raw), 'archive_sha256': sha(raw),
        'decoded_bytes': len(body), 'decoded_sha256': sha(body),
        'index_path': FRAMEWORK + '/archive-index.json', 'encoding': record['encoding'],
    }
    decoded[name] = body


def add_old_path(name: str, path: str):
    matches = [x for x in old_index if x['original']['path'] == path]
    assert len(matches) == 1, (name, matches)
    add_old(name, matches[0])


def add_new(name: str, record):
    rel = FOLLOWUP + '/' + record['archive_path']
    raw = (ROOT / rel).read_bytes()
    body = gzip.decompress(raw)
    assert sha(raw) == record['archive_sha256'] and sha(body) == record['decoded_sha256'], name
    matches = [x for x in new_index if x['archive_path'] == record['archive_path']]
    assert len(matches) == 1, name
    indexed = matches[0]
    assert indexed['original_sha256'] == sha(body) and indexed['archive_sha256'] == sha(raw), name
    assert indexed['original_bytes'] == len(body) and indexed['archive_bytes'] == len(raw), name
    proofs[name] = {
        'path': rel, 'archive_bytes': len(raw), 'archive_sha256': sha(raw),
        'decoded_bytes': len(body), 'decoded_sha256': sha(body),
        'index_path': FOLLOWUP + '/archive-index.json', 'encoding': 'gzip',
    }
    decoded[name] = body


for name in ['source85_frozen', 'public86_compile74', 'public86_inventory0', 'typed90_20_106',
             'representatives90_validation', 'package90_complete', 'package90_observations',
             'BP20_98_compact', 'BP17_96_complete', 'BP17_96_comparison',
             'BP13_99_complete', 'BP13_99_comparison', 'BP13_99_raw', 'workflow88_comparison']:
    add_old(name, v['evidence'][name])
for matrix in ['desktop', 'core', 'sqlite_headless', 'package_disabled']:
    add_old_path('LastTest86_' + matrix,
                 '/private/tmp/qcae-framework-runtime86/full-regression-' + matrix + '-diagnostics/LastTest.log')
add_old_path('representatives90_raw',
             '/private/tmp/qcae-framework-supplement90/attempts/supplement90-01/representatives/evidence/M-representatives.jsonl')
for name, key in [('lifecycle104_receipt', 'receipt'), ('lifecycle104_comparison', 'comparison'),
                  ('lifecycle104_raw', 'raw'), ('lifecycle104_fixed_script', 'fixed_successor_script')]:
    add_new(name, f['lifecycle30'][key])
add_new('candidate112', f['tested_candidate']['receipt'])
for config in ['core', 'local', 'sqlite', 'sanitized-schema']:
    add_new('candidate112_' + config, f['configs'][config]['receipt'])
audit103 = next(x for x in new_index if x['archive_path'] == 'audit103/facts.json.gz')
add_new('boundary103', {'archive_path': audit103['archive_path'],
                        'archive_sha256': audit103['archive_sha256'],
                        'decoded_sha256': audit103['original_sha256']})
facts = json.loads(decoded['boundary103'])
assert facts == json.loads(Path('/private/tmp/qcae-core-boundary-next103/facts.json').read_text())

source = {'commit': 'ef0df3bdd8c1b27330d71a596f16098cb6b6410a',
          'canonical_source_files': 410,
          'canonical_source_sha256': '15d20f20fef88ed6d1b8637b97edf77143887728cb9c42427620b25429e65c03',
          'proof': 'source85_frozen'}
public = json.loads(decoded['public86_compile74'])
typed = json.loads(decoded['typed90_20_106'])
compact = json.loads(decoded['BP20_98_compact'])
bp_rows = {x['BP']: x for x in compact['cases']}
assert len(bp_rows) == 20 and len(facts['AP_bindings']) == 20
assert public['source_commit'] == typed['source_commit'] == source['commit']
assert public['source410_sha256'] == typed['source410_sha256'] == source['canonical_source_sha256']
assert public['consumer_count'] == 74 and typed['actual_independent_typed_consumers'] == 20
assert typed['actual_static_assertions_compiled'] == 106
public_bins = {Path(x['path']).name: x for x in public['consumer_binaries']}
typed_bins = {Path(x['path']).name: x for x in typed['binaries']}

bindings = []
before = {}
snapshot = OUT / 'original-AP'
snapshot.mkdir()
for ap in facts['AP_bindings']:
    rel = 'docs/engineering/module-contracts/' + ap['AP'] + '.json'
    original = (ROOT / rel).read_bytes()
    before[rel] = original
    (snapshot / Path(rel).name).write_bytes(original)
for ap in facts['AP_bindings']:
    ap_id = ap['AP']
    rel = 'docs/engineering/module-contracts/' + ap_id + '.json'
    raw = (ROOT / rel).read_bytes()
    old = json.loads(raw)
    assert before[rel] == raw
    assert FIELD not in old['public_contracts']['implemented_subset']
    assert ap['header_consumer'] in public_bins and ap['typed_consumer'] in typed_bins
    bp = bp_rows[ap['BP']]
    ctest = []
    for row in bp.get('current86_raw_cases', []):
        lines = decoded['LastTest86_desktop'].decode().splitlines()
        at = row['line'] - 1
        assert row['case'] in '\n'.join(lines[max(0, at-2):at+6]), (ap_id, row)
        # Do not infer assertion counts from an occurrence of a named CTest case.
        ctest.append({'case': row['case'], 'proof': 'LastTest86_desktop', 'raw_start_line': row['line']})
    counts = {'named_current86_CTest_cases': len(ctest), 'runtime_assertion_count': None}
    runtime = {
        'BP': ap['BP'], 'state': 'CURRENT_SOURCE_BOUNDED_MECHANISM_EVIDENCE',
        'actual_source': source,
        'observed_scope': [x['scope'] for x in bp['source_assertions']],
        'counts': counts, 'mapping_proof': 'BP20_98_compact',
        'named_actual_cases': ctest,
        'limits': bp.get('limits', []) + ['This binding does not promote the full BP acceptance contract.'],
    }
    if 'actual90_six_case_record' in bp:
        item = bp['actual90_six_case_record']
        counts.update({'distinct_actual_runs': 1, 'runtime_assertion_count': item['actual_assertion_count']})
        runtime['representative90'] = {'run_id': item['run_id'], 'raw_jsonl_line': item['jsonl_line'],
                                     'literal_source_field': item['literal_source_field'],
                                     'proofs': ['representatives90_validation', 'representatives90_raw']}
    if 'actual_mechanism_record' in bp:
        item = bp['actual_mechanism_record']
        counts['runtime_assertion_count'] = item['actual_assertion_count']
        runtime['mechanism86'] = {
            'run_id': item['run_id'], 'intrinsic_source_field': item['intrinsic_source_field'],
            'source_binding_scope': item['source_binding_scope'],
            'actual_small_values': item['actual_small_values'],
            'raw_proof': 'LastTest86_desktop',
            'raw_source_tag_unchanged': True,
        }
    if ap_id == 'AP-10':
        runtime['package90'] = {
            'actual_categories': ['core', 'operations', 'codecs', 'validation', 'ui', 'render'],
            'category_count': 6, 'actual_peer_exit': 0,
            'passive_peer': True, 'active_document_created': False,
            'SQLite_linked': False, 'engineering_solver_run': False,
            'proofs': ['package90_complete', 'package90_observations'],
            'OFF_six_observer_rows': 'NOT_PROVEN; package_disabled common-service tests are a separate scope',
        }
    if ap_id == 'AP-13':
        runtime['native99'] = {
            'actual_wrapper_exit': 0, 'ordered_steps': 10,
            'formal_target_picks': 2, 'empty_viewport_leaves': 2,
            'cancel_revision_delta': 0, 'apply_revision_delta': 1,
            'persistent_transactions': 1, 'observer_writes': 0, 'post_leave_apply_writes': 0,
            'proofs': ['BP13_99_complete', 'BP13_99_comparison', 'BP13_99_raw'],
        }
        runtime['native104'] = {
            'actual_source': source, 'actual_wrapper_exit': 0,
            'samples': 30, 'ordered_steps': 300, 'formal_target_picks': 60,
            'empty_viewport_leaves': 60, 'GUI_undo_resets': 30,
            'initial_revision': '13', 'final_revision': '73',
            'cancel_revision_delta_each': 0, 'apply_revision_delta_each': 1,
            'undo_revision_delta_each': 1, 'unique_persistent_transactions': 30,
            'all_entity_fields_restored_each': True, 'observer_writes': 0,
            'original_prefix_items': 13, 'final_history_cursor': 13, 'final_history_items': 14,
            'proofs': ['lifecycle104_receipt', 'lifecycle104_comparison', 'lifecycle104_raw',
                       'lifecycle104_fixed_script'],
            'scope': '104 fixed successor, separate from original line30; leave is actual blank viewport selection. Dock-close/Escape and full SK10 remain unmeasured.',
        }
    if ap_id == 'AP-16':
        counts['PICK_named_cases'] = bp['PICK_actual_count']
    if ap_id == 'AP-17':
        runtime['native96'] = {
            'actual_peer_exits': [0, 0], 'independent_GUI_processes': 2,
            'process_ids': ['34865', '34885'],
            'exact_dimensions': {'modelViewsDock_width': 280, 'selectionPropertiesDock_width': 360,
                                 'historyDock_height': 170},
            'revision_before': '0', 'revision_after': '0',
            'state_geometry_raw_preferences_shortcut_and_history_exact': True,
            'settings_format': 'explicit private Ini UserScope and SystemScope paths',
            'proofs': ['BP17_96_complete', 'BP17_96_comparison'],
            'scope': 'Separate fresh-process proof; original86 same-process recreation remains supporting evidence only.',
        }
    if ap_id == 'AP-18':
        runtime['comparison88'] = {
            'workflows': 9, 'mode_counts': {'CLI': 3, 'GUI': 3, 'MIX': 3},
            'checkpoint_comparisons': 72, 'semantic_differences': 0,
            'GUI_MIX_origin': 'original current86 native6 byte-preserved; not a rerun or old68 import',
            'proof': 'workflow88_comparison', 'real_external_AI': False,
        }
    binding = {
        'date': '2026-10-03', 'state': 'ACTUAL_IMPLEMENTED_SUBSET_EVIDENCE_BOUND; NO_ACCEPTANCE_PROMOTION',
        'actual_source': source, 'portable_proof_registry': CENTRAL,
        'public_header_compile_link': {
            'consumer': ap['header_consumer'], 'target': ap['actual_target'], 'header': ap['header'],
            'actual_build_exit': 0, 'population': 74, 'AP_distinct_header_consumers': 18,
            'dialect': 'GNU C++20 for the original public consumers', 'CTest_registered': 0,
            'binary_sha256': public_bins[ap['header_consumer']]['sha256'],
            'proofs': ['public86_compile74', 'public86_inventory0'],
            'scope': 'Independent public-header compile/link and usage requirements; not 74 executed CTest cases or all-ODR/runtime coverage.',
        },
        'declaration_types': {
            'consumer': ap['typed_consumer'], 'actual_configure_exit': 0, 'actual_build_exit': 0,
            'dialect': 'strict C++20', 'compiler_warnings': 0,
            'this_AP_function_assertions': ap['function_assertions'],
            'this_AP_member_assertions': ap['member_assertions'],
            'population_consumers': 20, 'population_static_assertions': 106,
            'population_function_assertions': 88, 'population_member_assertions': 18,
            'binary_sha256': typed_bins[ap['typed_consumer']]['sha256'],
            'proof': 'typed90_20_106',
            'scope': 'Unevaluated declaration-type assertions compiled; not a claim that every listed function was ODR-used or executed.',
        },
        'bounded_runtime': runtime,
        'remaining': {
            'original_status_fields_preserved': True,
            'future_interfaces_and_all_AP_runtime_L2': 'PENDING',
            'full_97_metrics_SK_C3_C4_P0': 'NOT_PASSED',
            'boundary': old['public_contracts']['implemented_subset']['implemented_boundary'],
        },
    }
    bindings.append({'AP': ap_id, 'owner': old['owner_module'], **binding})
    text = raw.decode()
    start = text.index('"implemented_subset":')
    open_at = text.index('{', start)
    depth = 0
    quoted = escaped = False
    close_at = None
    for pos in range(open_at, len(text)):
        char = text[pos]
        if quoted:
            if escaped: escaped = False
            elif char == '\\': escaped = True
            elif char == '"': quoted = False
        elif char == '"': quoted = True
        elif char == '{': depth += 1
        elif char == '}':
            depth -= 1
            if depth == 0:
                close_at = pos
                break
    assert close_at is not None
    insert_at = len(text[:close_at].rstrip())
    field_text = json.dumps({FIELD: binding}, ensure_ascii=False, indent=2)[2:-2]
    insertion = ',\n' + '\n'.join('    ' + line for line in field_text.splitlines())
    changed = text[:insert_at] + insertion + text[insert_at:]
    check = json.loads(changed)
    del check['public_contracts']['implemented_subset'][FIELD]
    assert check == old
    assert (changed[:insert_at] + changed[insert_at+len(insertion):]).encode() == raw
    (ROOT / rel).write_text(changed)

assert sum(x['declaration_types']['this_AP_function_assertions'] for x in bindings) == 88
assert sum(x['declaration_types']['this_AP_member_assertions'] for x in bindings) == 18

ext04_rel = 'docs/engineering/c3-closure-evidence/package/c4-independent41/EXT04/report.json'
ext04 = load(ext04_rel)
task_counts = {c['backend']: dict(Counter(x['case'] for x in c['observed_task_rows'])) for c in ext04['contracts']}
assert task_counts == {'memory': {'success': 10, 'cancel': 10, 'stale': 10},
                       'sqlite': {'success': 10, 'cancel': 10, 'stale': 10}}
new = {
    'schema_version': 'qcae.implemented-interface-evidence-binding/1', 'date': '2026-10-03',
    'scope': 'Dated evidence reconciliation inside implemented subsets, not an acceptance or reference-inventory promotion.',
    'actual_runtime_source85': source,
    'current_documentation_HEAD_at_preparation': '8bcec36874a92c80e273141e42263e4cbf67fd71',
    'current_test_candidate': {
        **f['tested_candidate'],
        'scope': '8b adds only four CMake test registration lines and one SQLite schema test; all other409 old source files are byte-equal. The original410 runtime results retain source85.',
        'proof': 'candidate112',
        'actual_new_regression_counts': {'core': 40, 'local': 54, 'sqlite': 48, 'sanitized-schema': 1},
        'schema_rejections_each_sqlite_and_sanitized': 24,
        'schema_categories': 8, 'old_epoch_checks_each_separate': 8,
        'actual_build_and_test_exits': 0, 'old378_relabelled_as_candidate411': False,
    },
    'denominators': {
        'AP_contracts': 20, 'distinct_AP_public_header_consumers': 18,
        'original_public_consumer_population': 74, 'public_consumer_CTest_registered': 0,
        'strict_typed_consumers': 20, 'typed_function_assertions': 88,
        'typed_member_assertions': 18, 'typed_static_assertions': 106,
        'bounded_BP_mechanisms': 20, 'original_six_BP_runs': 6, 'six_BP_assertions': 269,
        'reference_inventory_included': 6113, 'reference_inventory_self': 5854,
        'reference_inventory_SDK_boundary': 259, 'reference_level': 'L1 unchanged',
        'SK_metric_population': 97, 'R5_extension_trial_population': 5,
        'full_AP_L2_or_SK_or_P0': 'NOT_PASSED',
    },
    'portable_proofs': proofs, 'AP_bindings': bindings,
    'extension_evidence': {
        'EXT01_EXT02_EXT03': {
            'actual_source_scope': 'Original independent b740 baseline399 extension trials; not newly rerun under source85.',
            'trials': facts['extension_trials'], 'proof': 'boundary103',
            'protected_source_or_generator_change_not_inferred_from_type_consumers': True,
        },
        'EXT04': {
            'actual_source_commit': ext04['baseline_commit'],
            'actual_source_sha256': ext04['source_tree_sha256'],
            'historical_report': {'path': ext04_rel, 'bytes': (ROOT / ext04_rel).stat().st_size,
                                  'sha256': sha((ROOT / ext04_rel).read_bytes())},
            'task_counts_each_backend': task_counts,
            'history_rounds_each_backend': 100, 'history_revision_delta_each_backend': 201,
            'functional_semantic_differences': 0,
            'current86_functional_retest': {
                'actual_source': source,
                'core_case': 'geometry_mesh', 'sqlite_cases': ['geometry_mesh', 'geometry_mesh_sqlite'],
                'proofs': ['LastTest86_core', 'LastTest86_sqlite_headless'],
                'scope': 'Original same geometry_mesh translation-unit fixture with adapter selection, not full physical M or a new independent extension trial.',
            },
            'limits': [ext04['scope_limit'],
                       'The original final_integrated_release_retest_pending field remains unchanged; dated current86 evidence is recorded separately.'],
        },
        'EXT05': {
            'state': 'KNOWN_FAIL_AND_UNKNOWN; NOT_PASSED',
            'historical_source49_commit': 'c0182a65cba7400960aa7c8f396b31f9351c2b2e',
            'historical_source49_actual60': facts['historical_source49_known_copy_result'],
            'historical_frozen_baseline399': 'b740b374c934f3b4624a21247b9a5deeb2ca6bf4',
            'current_source85_performance_remeasurement': 'NOT_RUN',
            'whole_SDK_owned_copy_coverage': 'UNKNOWN', 'unknown_value': None,
            'phase_only_original_caps_unchanged': True,
            'proof': 'boundary103',
            'scope': 'Known copy-budget failures remain failures; no elapsed/RSS target substitution or double-counted bind saving. Performance optimization is paused.',
        },
        'R5': {'denominator': 5, 'all_five_passed': False, 'EXT05_excluded_from_denominator': False},
    },
    'unclosed': [
        'Future AP design interfaces, all runtime/ODR obligations and full L2 qualification.',
        'OFF six-category direct observation and a second actual format-only profile binary build.',
        'Full97 metric acceptance, complete SK/C3/C4/P0; original schema/legacy producer limitations remain.',
        'Real Nastran engineering validation, complete external AI scenarios and whole SDK/performance coverage.',
        'Blank viewport leave is bounded; dock-close/Escape and generic ToolSession are not proved by99/104.',
    ],
    'quality_scope': 'Documentation-only read/hash/link/JSON preservation checks; no product, compiler or tests run for this reconciliation.',
}
(ROOT / CENTRAL).write_text(json.dumps(new, ensure_ascii=False, indent=2) + '\n')
(OUT / 'before-AP-bytes.json').write_text(json.dumps({k: {'bytes': len(x), 'sha256': sha(x)} for k,x in before.items()}, indent=2) + '\n')
(OUT / 'binding-preparation.json').write_text(json.dumps({
    'state': 'ACTUAL_PURE_DOCUMENT_EDIT', 'AP_count': len(bindings),
    'portable_proof_count': len(proofs), 'old_AP_values_preserved': True,
    'old_AP_bytes_preserved_by_insertion_only': True,
    'product_validation_run_for_this_edit': False,
}, indent=2) + '\n')
print(json.dumps({'edited_AP': len(bindings), 'proofs_verified': len(proofs), 'central': CENTRAL}))
