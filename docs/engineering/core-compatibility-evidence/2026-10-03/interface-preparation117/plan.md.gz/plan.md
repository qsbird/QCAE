# 117: dated interface evidence bindings

1. Read frozen AP ownership, canonical architecture and acceptance; decode existing portable evidence and verify its original and stored hashes.
2. Add one dated field inside each AP implemented_subset, without rewriting original bytes or changing pending/reference statuses. Create the named central JSON and Markdown only.
3. Check all old AP values and byte content survive, all selected portable proofs resolve and hash, source85 retains its actual identity, and documentation design/diff checks pass. Do not run product validation or commit.

Scope: compilation, bounded mechanisms and supplemental GUI evidence remain separate; no complete L2/97/SK/P0 or performance promotion.
