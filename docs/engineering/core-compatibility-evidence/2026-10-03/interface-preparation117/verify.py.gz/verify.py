from __future__ import annotations

import gzip
import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT = Path('/private/tmp/qcae-framework-delivery80')
OUT = Path('/private/tmp/qcae-interface-bindings117')
FIELD = 'actual_evidence_binding_2026_10_03'
CENTRAL = 'docs/engineering/core-interface-evidence-bindings-2026-10-03'


def sha(data):
    return hashlib.sha256(data).hexdigest()


central = json.loads((ROOT / (CENTRAL + '.json')).read_text())
proofs = central['portable_proofs']
results = []
for n in range(1, 21):
    name = f'AP-{n:02}.json'
    old_raw = (OUT / 'original-AP' / name).read_bytes()
    new_raw = (ROOT / 'docs/engineering/module-contracts' / name).read_bytes()
    old = json.loads(old_raw)
    new = json.loads(new_raw)
    binding = new['public_contracts']['implemented_subset'].pop(FIELD)
    assert old == new, name
    assert central['AP_bindings'][n-1]['AP'] == name[:-5]
    central_binding = dict(central['AP_bindings'][n-1])
    del central_binding['AP']
    del central_binding['owner']
    assert binding == central_binding, name
    # Assert the exact old bytes remain, not only parsed JSON values.
    a, b = 0, 0
    while a < len(old_raw) and b < len(new_raw) and old_raw[a] == new_raw[b]:
        a += 1
        b += 1
    suffix = old_raw[a:]
    assert new_raw.endswith(suffix), name
    insertion = new_raw[b:len(new_raw)-len(suffix)]
    assert insertion.startswith(b',\n') and FIELD.encode() in insertion, name
    assert old_raw[:a] + new_raw[len(new_raw)-len(suffix):] == old_raw, name
    results.append({'path': 'docs/engineering/module-contracts/' + name,
                    'old_bytes': len(old_raw), 'old_sha256': sha(old_raw),
                    'new_bytes': len(new_raw), 'new_sha256': sha(new_raw),
                    'insertion_bytes': len(insertion),
                    'original_fields_and_bytes_retained': True})
for name, proof in proofs.items():
    path = ROOT / proof['path']
    assert path.resolve().is_relative_to(ROOT), name
    raw = path.read_bytes()
    body = gzip.decompress(raw) if proof['encoding'] == 'gzip' else raw
    assert len(raw) == proof['archive_bytes'] and sha(raw) == proof['archive_sha256'], name
    assert len(body) == proof['decoded_bytes'] and sha(body) == proof['decoded_sha256'], name
    assert (ROOT / proof['index_path']).is_file(), name
md = ROOT / (CENTRAL + '.md')
for link in re.findall(r'\]\(([^)]+)\)', md.read_text()):
    assert (md.parent / link).resolve().is_relative_to(ROOT), link
    assert (md.parent / link).is_file(), link
assert sum(x['declaration_types']['this_AP_function_assertions'] for x in central['AP_bindings']) == 88
assert sum(x['declaration_types']['this_AP_member_assertions'] for x in central['AP_bindings']) == 18
assert central['extension_evidence']['R5']['denominator'] == 5
assert not central['extension_evidence']['R5']['all_five_passed']
for name in ['geometry_mesh', 'geometry_mesh_sqlite']:
    proof = proofs['LastTest86_sqlite_headless']
    text = gzip.decompress((ROOT / proof['path']).read_bytes()).decode()
    pattern = re.compile(r'\d+/\d+ Testing: ' + name + r'\n.*?(?=\n\d+/\d+ Testing: |\Z)', re.S)
    matches = pattern.findall(text)
    assert len(matches) == 1 and 'Test Passed.' in matches[0], name

diff = subprocess.run(['git', 'diff', '--check'], cwd=ROOT, capture_output=True)
assert diff.returncode == 0, diff.stderr.decode() + diff.stdout.decode()
paths = [x['path'] for x in results] + [CENTRAL + '.json', CENTRAL + '.md']
facts = [{'path': rel, 'bytes': (ROOT / rel).stat().st_size,
          'sha256': sha((ROOT / rel).read_bytes())} for rel in paths]
review = {
    'kind': 'documentation-only limited QG-02 review', 'date': '2026-10-03',
    'actual_original_AP_preservation_count': 20,
    'actual_portable_proofs_hash_checked': len(proofs),
    'new_document_count': 2, 'authorized_document_paths': paths,
    'blocking': [],
    'QG02_scope': 'Actual source identity, consumer/type/runtime denominators, per-AP scope, portable raw hashes, original status/reference data preservation; no new whole-code review.',
    'QG01_scope': 'JSON parsed, Markdown local links and whitespace diff checked; no C++ change in this task.',
    'QG03_scope': 'No product behavior change; existing original86 and candidate112 runs are referenced separately. No product test run for this documentation task.',
    'remaining': central['unclosed'],
    'AP_preservation': results, 'delivery': facts,
    'no_compiler_CTest_product_GUI_or_engine_executed': True,
}
(OUT / 'review.json').write_text(json.dumps(review, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'AP_preserved': len(results), 'portable_proofs': len(proofs), 'blocking': []}))
