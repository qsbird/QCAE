from pathlib import Path
import collections, csv, datetime, gzip, hashlib, json, re, subprocess

ROOT = Path('/private/tmp/qcae-framework-delivery80')
OUT = Path('/private/tmp/qcae-core-compat-review121')
LEGACY = Path('/private/tmp/qcae-legacy-physical117')
BASE = '8bcec36874a92c80e273141e42263e4cbf67fd71'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def load(path):
    return json.loads(Path(path).read_text())

def fact(path):
    path = Path(path)
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=sha(data))

def write(name, value):
    with (OUT / name).open('x') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')

central = ROOT / 'docs/engineering/core-interface-evidence-bindings-2026-10-03.json'
binding = load(central)
ap_checks = []
for entry in binding['AP_bindings']:
    relative = 'docs/engineering/module-contracts/' + entry['AP'] + '.json'
    original = json.loads(subprocess.check_output(['git', 'show', BASE + ':' + relative], cwd=ROOT))
    current = load(ROOT / relative)
    added = current['public_contracts']['implemented_subset'].pop('actual_evidence_binding_2026_10_03')
    assert current == original
    assert added == {key: value for key, value in entry.items() if key not in ('AP', 'owner')}
    ap_checks.append(dict(AP=entry['AP'], original_logic_equal=True, dated_binding_equals_central_payload=True, source=fact(ROOT / relative)))

proof_checks = {}
proofs = {}
for identifier, descriptor in binding['portable_proofs'].items():
    path = ROOT / descriptor['path']
    data = path.read_bytes()
    decoded = gzip.decompress(data) if descriptor['encoding'] == 'gzip' else data
    assert len(data) == descriptor['archive_bytes'] and sha(data) == descriptor['archive_sha256']
    assert len(decoded) == descriptor['decoded_bytes'] and sha(decoded) == descriptor['decoded_sha256']
    proof_checks[identifier] = dict(archive_and_decoded_facts_match=True, file=fact(path), decoded_sha256=sha(decoded))
    proofs[identifier] = json.loads(decoded) if path.name.endswith(('.json', '.json.gz')) else decoded.decode()

public, typed = proofs['public86_compile74'], proofs['typed90_20_106']
assert public['actual_build_exit_code'] == 0 and public['consumer_count'] == 74
assert proofs['public86_inventory0']['count'] == 0
assert typed['actual_configure_exit'] == typed['actual_build_exit'] == typed['warning_count'] == 0
assert (typed['actual_independent_typed_consumers'], typed['actual_static_assertions_compiled'], typed['function_assertions'], typed['data_assertions']) == (20, 106, 88, 18)
public_binaries = {Path(item['path']).name: item['sha256'] for item in public['consumer_binaries']}
typed_binaries = {Path(item['path']).name: item['sha256'] for item in typed['binaries']}
functions = members = named_cases = 0
for entry in binding['AP_bindings']:
    header, declaration, runtime = (entry[key] for key in ('public_header_compile_link', 'declaration_types', 'bounded_runtime'))
    assert public_binaries[header['consumer']] == header['binary_sha256']
    assert typed_binaries[declaration['consumer']] == declaration['binary_sha256']
    functions += declaration['this_AP_function_assertions']
    members += declaration['this_AP_member_assertions']
    assert runtime['counts']['named_current86_CTest_cases'] == len(runtime['named_actual_cases'])
    for case in runtime['named_actual_cases']:
        lines = proofs[case['proof']].splitlines()
        start = case['raw_start_line'] - 1
        assert lines[start].endswith('Testing: ' + case['case'])
        end = next((index for index in range(start + 1, len(lines)) if re.match(r'\d+/\d+ Testing:', lines[index])), len(lines))
        assert 'Test Passed.' in '\n'.join(lines[start:end])
        named_cases += 1
    assert runtime['actual_source'] == binding['actual_runtime_source85']
assert (functions, members) == (88, 18)
representatives = proofs['representatives90_validation']
assert representatives['actual_case_count'] == representatives['actual_passed_count'] == representatives['distinct_actual_run_ids'] == 6
assert sum(item['actual_assertions'] for item in representatives['assertion_counts'].values()) == 269
for entry in binding['AP_bindings']:
    runtime = entry['bounded_runtime']
    if 'representative90' in runtime:
        pointer = runtime['representative90']
        row = json.loads(proofs['representatives90_raw'].splitlines()[pointer['raw_jsonl_line'] - 1])
        assert row['run_id'] == pointer['run_id'] and pointer['literal_source_field'] in json.dumps(row)
        assert runtime['counts']['runtime_assertion_count'] == representatives['assertion_counts'][runtime['BP']]['actual_assertions']
for identifier, count in [('candidate112_core', 40), ('candidate112_local', 54), ('candidate112_sqlite', 48), ('candidate112_sanitized-schema', 1)]:
    actual = proofs[identifier]
    assert actual['actual_exit_code'] == 0 and actual['executed_count'] == len(actual['executed_test_names']) == count
    assert actual['strict_cpp20'] and not actual['compiler_warnings']
extensions = binding['extension_evidence']
descriptor = extensions['EXT04']['historical_report']
assert fact(ROOT / descriptor['path'])['sha256'] == descriptor['sha256']
assert fact(ROOT / descriptor['path'])['bytes'] == descriptor['bytes']
assert extensions['EXT05']['historical_source49_actual60']['material']['known_copy_failures'] == 14
assert extensions['R5']['denominator'] == 5 and not extensions['R5']['all_five_passed']

old, current = load(LEGACY / 'old-native-02/result.json'), load(LEGACY / 'current-native-01/result.json')
post = load(LEGACY / 'post-run-readonly-review.json')
comparison = load(LEGACY / 'actual-binary-comparison.json')
manifest = load(ROOT / 'tests/fixtures/legacy/manifest.json')
assert old['actual_exit_code'] == current['actual_exit_code'] == post['actual_exit_code'] == 0
old_snapshot, migrated = old['after_normal_reopen'], current['migrated']
for key in ('entities', 'references'):
    assert old_snapshot[key] == old['before'][key]

assert old_snapshot['document']['revision'] == '0' and old['before']['document']['revision'] == '5'
for old_export, reopened_export in zip(old['before']['exports'], old_snapshot['exports']):
    assert {key: value for key, value in old_export.items() if key != 'revision'} == {key: value for key, value in reopened_export.items() if key != 'revision'}

def migrated_profile(value):
    if isinstance(value, dict):
        if set(value) == {'profile_id', 'profile_version', 'definition_digest'}:
            return current['installed_profile']
        return {key: migrated_profile(item) for key, item in value.items()}
    if isinstance(value, list):
        return [migrated_profile(item) for item in value]
    return value

expected = migrated_profile(old_snapshot)
by_id = {entity['entity_id']: entity for entity in migrated['entities']}
field_count = 0
for entity in expected['entities']:
    for key, value in entity.items():
        assert by_id[entity['entity_id']].get(key) == value
        field_count += 1
old_ids = {entity['entity_id'] for entity in old_snapshot['entities']}
order = lambda item: json.dumps(item, sort_keys=True)
old_references = sorted(expected['references'], key=order)
new_references = sorted([item for item in migrated['references'] if item['from'] in old_ids and item['to'] in old_ids], key=order)
assert old_references == new_references
source_count = sum(len(entity.get('sources', [])) for entity in old_snapshot['entities'])
assert (field_count, len(old_references), source_count) == (185, 109, 25)
assert old_snapshot['source_identifier_count'] == 25
assert old_snapshot['counts']['node'] == 11 and old_snapshot['counts']['beam'] == 10
assert len(old_snapshot['entities']) == 31 and len(migrated['entities']) == 32
assert old['GeometryLine_count'] == old['LoadCase_count'] == 0
assert current['GeometryLine_and_LoadCase_not_in_old_source']
added = [entity for entity in migrated['entities'] if entity['entity_id'] not in old_ids]
assert len(added) == 1 and added[0]['kind'] == 'mesh'

def cards(export):
    result = collections.defaultdict(list)
    for resource in export['resources']:
        for line in resource['text'].splitlines():
            line = line.split('$')[0].strip()
            if not line or ',' not in line:
                continue
            values = next(csv.reader([line]))
            if values[0] not in ('GRID', 'CBAR', 'MAT1', 'PBAR', 'FORCE', 'SPC1'):
                continue
            row = []
            for item in values[1:]:
                item = item.strip()
                try:
                    row.append(float(item.replace('D', 'E')))
                except ValueError:
                    row.append(item)
            result[values[0]].append(row)
    return {key: sorted(rows, key=lambda row: row[0]) for key, rows in result.items()}

assert cards(old_snapshot['exports'][0]) == cards(migrated['export']) == current['independent_cards']
assert fact(LEGACY / 'actual-old-physical-M02.qcae')['sha256'] == old['source_file_sha256'] == current['old_source_file_sha256']
assert old['original_input_metadata']['payload_marker'] == 'QCAE-PROJECT' and old['original_input_metadata']['payload_version'] == 1
for relative in ('old-native-02/result.json', 'current-native-01/result.json'):
    assert post['input_proofs'][relative] == fact(LEGACY / relative)['sha256']
legacy_binaries = []
for name in ('qcae-engine', 'qcae-cli'):
    binary = fact(LEGACY / 'build-01' / name)
    recorded = comparison['actual_comparison'][name]
    assert binary['sha256'] == recorded['actual_sha256'] == recorded['original_producer_sha256'] and recorded['equal']
    assert recorded['original_producer_sha256'] in json.dumps(manifest)
    legacy_binaries.append(binary)
assert fact(LEGACY / 'build-result.json')['sha256'] == comparison['original_receipt_sha256']
for binary in current['current_binaries'].values():
    assert fact(binary['path'])['sha256'] == binary['sha256']
for run in ('old-native-02', 'current-native-01'):
    process = load(LEGACY / run / 'process.json')
    assert process['owned'] and process['reaped'] and process['literal_exit_code'] == -15
info, recovered, reopened = (current[key]['document'] for key in ('migrated', 'recovered', 'reopened_current'))
assert info['project_id'] == old_snapshot['document']['project_id'] == reopened['project_id']
assert info['document_id'] != old_snapshot['document']['document_id']
assert recovered['document_id'] == info['document_id'] and recovered['document_epoch'] != info['document_epoch']
assert reopened['document_id'] != recovered['document_id'] and reopened['document_epoch'] != recovered['document_epoch']
assert reopened['revision'] == '0' and not current['reopened_current']['history']['items']
for stage in ('recovered', 'reopened_current'):
    assert current[stage]['entities'] == migrated['entities'] and current[stage]['references'] == migrated['references']
transcript = load(LEGACY / 'current-native-01/transcript.json')
exit_counts = collections.Counter()
for row in transcript:
    response = json.loads(row['stdout'])
    assert response['request_id'] == row['request']['request_id']
    code = row['actual_cli_exit_code']
    assert code == (0 if response['status'] == 'success' else 2)
    exit_counts[code] += 1
first_failure = load(LEGACY / 'old-native-01/failure.json')
assert first_failure['actual_exit_code'] == 1 and 'Expected a non-empty string: mode' in first_failure['exception']

write('docs-review.json', dict(base=BASE, AP_checks=ap_checks, central=fact(central), markdown=fact(ROOT / 'docs/engineering/core-interface-evidence-bindings-2026-10-03.md'), portable_proof_count=29, portable_proofs=proof_checks, public_consumers=74, public_CTest=0, typed_consumers=20, typed_function_assertions=functions, typed_member_assertions=members, named_case_location_bindings=named_cases, six_representative_assertions=269, EXT04_scope='geometry_mesh fixture, memory heap reconstruction vs SQLite persistent reopen; not complete physical M', EXT05_scope='Historical source49 14 material failures; source85 NOT_RUN; SDK unknown; R5 still5'))
write('legacy-review.json', dict(old_source='62e2b1d804e025636caf8fc1d49cd207ee1f6677', current_source=current['actual_current_source'], current_source410=current['canonical410_sha256'], actual_exits=[0, 0], counts=dict(nodes=11, beams=10, old_entities=31, current_entities=32, old_top_level_fields=185, old_references=109, old_source_identifiers=25, geometry=0, load_case=0), binaries_exact_original_R0=legacy_binaries, current_CLI_exit_counts=dict(exit_counts), current_CLI_commands=len(transcript), owned_engine_cleanup=[-15, -15], old_file_sha256=old['source_file_sha256'], profile_migration_and_BDF_readback_verified=True, separate_from_synthetic_record_project1_complete33=True, limitations=['185 means top-level entity field bindings, not recursive scalar leaves.', 'No GeometryLine or LoadCase, so historical physical subset does not prove complete33 M.', 'Migration recover follows document keep_recovery inside same engine; explicit persistent SQLite is present but this method does not restart engine/store.', 'QCAE-PROJECT1 old producer and synthetic QCAE-RECORD-PROJECT1 current-record reader fixture are separate classes.'], preserved_failures=['build-result.json contains incorrect unverified binary-inequality expectation; actual-binary-comparison.json supplies actual matching hashes.', 'old-native-01 omitted required normal-open mode and failed INVALID_INPUT; original collector/raw remain.'], inputs=[fact(LEGACY / name) for name in ('old-native-02/result.json', 'current-native-01/result.json', 'post-run-readonly-review.json', 'actual-binary-comparison.json', 'capture_old118.py', 'migrate_current118.py', 'old-native-01/failure.json', 'capture_old.py')]))
write('review.json', dict(status='NO_BLOCKING_FINDINGS_IN_BOUNDED_SCOPE', blocking_findings=[], reviewed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), scope='Read/hash/JSON/raw comparisons only, no compiler/product/CTest/guard execution.', notes=['All20 AP original logical JSON including reference evidence is unchanged after removing exactly the dated key.', '29 compressed/raw/decoded proof descriptors match actual bytes and SHA.', 'Type assertions are compile evidence, not full runtime/ODR/L2; complete SK/P0 stays pending.', 'Keep-recovery+recover is not store-close/restart evidence in this particular actual legacy migration.', 'Own helper failures retained separately; no product failure derived from them.'], docs_report=fact(OUT / 'docs-review.json'), legacy_report=fact(OUT / 'legacy-review.json')))
print(json.dumps(dict(status='NO_BLOCKING_FINDINGS', review=fact(OUT / 'review.json'), portable_proofs=29, legacy_fields=185, legacy_references=109, legacy_sources=25)))
