#include "qcae/core.hpp"
#include "qcae/engine_contributions.hpp"
#include "qcae/nastran_contribution.hpp"
#include "qcae/nastran_package.hpp"
#include "qcae/operation_registry.hpp"
#include "qcae/record_application.hpp"
#include "qcae/records.hpp"
#include "qcae/records_model_bridge.hpp"

#include <QCoreApplication>
#include <QCryptographicHash>
#include <QFile>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QSaveFile>
#include <algorithm>
#include <filesystem>
#include <iostream>
#include <stdexcept>
#include <unistd.h>

namespace {
using namespace qcae;
void need(bool condition, const std::string& message) {
    if (!condition)
        throw std::runtime_error(message);
}
QString text(std::string_view value) {
    return QString::fromUtf8(value.data(), static_cast<qsizetype>(value.size()));
}
QJsonObject profile(const ProfileRef& value) {
    return {{"profile_id", text(value.profile_id)},
            {"profile_version", text(value.profile_version)},
            {"definition_digest", text(value.definition_digest)}};
}
QByteArray bytes(const QString& path) {
    QFile file(path);
    need(file.open(QIODevice::ReadOnly), "Cannot read immutable fixture: " + path.toStdString());
    return file.readAll();
}
QString sha(const QByteArray& value) {
    return QString::fromLatin1(QCryptographicHash::hash(value, QCryptographicHash::Sha256).toHex());
}
template <class T> T good(Result<T> value) {
    need(value.ok(), value.error ? value.error->message : "Missing successful result");
    return std::move(*value.value);
}
void append(QJsonArray& categories, const char* category, QJsonArray entries, QJsonObject actual) {
    need(!entries.isEmpty(), std::string("Empty registration category: ") + category);
    categories.append(QJsonObject{{"category", category},
                                  {"enumerated_items", entries},
                                  {"actual_calls", actual},
                                  {"observation_status", "enumerated_and_called"}});
}
} // namespace

int main(int argc, char** argv) {
    QCoreApplication app(argc, argv);
    if (argc != 2 || QFile::exists(QString::fromLocal8Bit(argv[1])))
        return 2;
    const QString output = QString::fromLocal8Bit(argv[1]);
    QJsonArray categories, fixture_facts;
    QJsonObject report{{"kind", "actual-six-category-static-package-consumer"},
                       {"source_commit", QCAE_BP10_SOURCE_COMMIT},
                       {"source_tree_sha256", QCAE_BP10_SOURCE_TREE_SHA256},
                       {"process_id", QString::number(getpid())},
                       {"qt_version", qVersion()},
                       {"scope", "readonly-public-library-consumer-with-immutable-cantilever-fixture"},
                       {"solver_processes_started", 0}};
    int exit_code = 0;
    try {
        need(ipc::nastran_package_enabled(), "Production Nastran package is disabled");
        NastranCodec codec;
        const auto installed = codec.definition().reference;
        const auto contributions = ipc::default_engine_contributions();
        QJsonArray contribution_ids;
        const ipc::EngineContribution* nastran = nullptr;
        for (const auto& item : contributions) {
            contribution_ids.append(text(item.id));
            if (item.id == "qcae.nastran") {
                need(!nastran, "Duplicate production Nastran registration");
                nastran = &item;
            }
        }
        need(nastran && nastran->records && nastran->operations,
             "Production package does not register core rules and operations");
        report.insert("engine_contribution_ids", contribution_ids);
        report.insert("installed_profile", profile(installed));

        ImportRequest request{"cantilever.bdf", {}, installed, "bp10-readonly-fixture", "mm-N-MPa"};
        for (const auto* relative :
             {"cantilever.bdf", "mesh/nodes.bdf", "mesh/beams.bdf", "properties.bdf"}) {
            const auto path = QString::fromUtf8(QCAE_BP10_SOURCE_ROOT) +
                              "/tests/fixtures/nastran/" + relative;
            const auto raw = bytes(path);
            fixture_facts.append(QJsonObject{{"path", path}, {"byte_length", raw.size()},
                                             {"sha256", sha(raw)}});
            request.resources.push_back({relative, raw.toStdString()});
        }
        const auto decoded = codec.decode(request);
        need(decoded.report.complete && decoded.candidate && decoded.candidate->analyses.size() == 1,
             "Registered codec did not decode immutable cantilever fixture");
        const Model fixture = *decoded.candidate;
        const auto fixture_view = records_from_model(fixture, make_record_registry());
        const auto analysis = fixture.analyses.front().id;

        // Registry construction and fixture decoding are passive test values. No active
        // engine document is created, imported, edited or persisted by this peer.
        RecordRegistry core_registration;
        nastran->records(core_registration);
        core_registration.freeze();
        need(!core_registration.rules().empty(), "Nastran core rule registry is empty");
        QJsonArray core_items;
        std::size_t ordinal = 0;
        for (const auto& rule : core_registration.rules()) {
            rule(fixture_view);
            core_items.append(QJsonObject{{"owner", "qcae.nastran"},
                                         {"registry", "RecordRegistry.rules"},
                                         {"ordinal", static_cast<qint64>(ordinal++)}});
        }
        Model incompatible = fixture;
        incompatible.analyses.front().target.analysis_kind = "bp10_test_incompatible_kind";
        const auto incompatible_view = records_from_model(incompatible, make_record_registry());
        bool rejected_core = false;
        for (const auto& rule : core_registration.rules()) {
            try {
                rule(incompatible_view);
            } catch (const RecordError& error) {
                need(error.code() == ErrorCode::invalid_input,
                     "Core rule used an unexpected incompatibility diagnostic");
                rejected_core = true;
            }
        }
        need(rejected_core, "Nastran core rules silently accepted an incompatible analysis kind");
        append(categories, "core", core_items,
               {{"valid_fixture_rule_calls", static_cast<qint64>(ordinal)},
                {"incompatible_analysis_kind_rejected", rejected_core}});

        const auto assembled = ipc::assemble_engine(contributions);
        RecordApplicationOptions options;
        options.registry = assembled.records;
        RecordApplication unopened_application(std::move(options));
        const auto inactive_before = unopened_application.current_document();
        need(!inactive_before.ok(), "Readonly consumer unexpectedly owns an active document");
        report.insert("active_document_before", QJsonObject{{"status", status_name(inactive_before.status)},
                      {"error_code", inactive_before.error ? error_name(inactive_before.error->code) : "none"}});
        operations::OperationRegistry operation_registry;
        good(nastran->operations(operation_registry, unopened_application, []() -> TaskService& {
            throw std::runtime_error("Readonly six-category peer must not start a task");
        }));
        QJsonArray operation_items;
        bool ui_registered = false, export_registered = false;
        for (const auto& descriptor : operation_registry.descriptors()) {
            operation_items.append(QJsonObject{{"operation", text(descriptor.definition.operation_id)},
                                               {"schema_id", text(descriptor.definition.schema_id)},
                                               {"version", static_cast<int>(descriptor.definition.version)},
                                               {"available", descriptor.available}});
            if (descriptor.definition.operation_id == "nastran.ui")
                ui_registered = descriptor.available;
            if (descriptor.definition.operation_id == "model.export")
                export_registered = descriptor.available;
        }
        need(ui_registered && export_registered, "Real Nastran operation registration is incomplete");
        operations::OperationContext context;
        context.caller = Caller{"bp10-readonly-consumer"};
        context.request_id = "bp10-operation-call";
        const auto invoked = good(operation_registry.invoke("nastran.ui", context, operations::Value{}));
        const auto& ui_output = std::get<operations::Value::Object>(invoked.data);
        need(std::get<std::string>(ui_output.at("operation").data) == "model.export",
             "Registered Nastran read-only handler returned a different real operation");
        append(categories, "operations", operation_items,
               {{"operation", "nastran.ui"}, {"status", "success"},
                {"canonical_result", text(good(operations::canonical_value(invoked)))}});

        const auto encoded = codec.encode(fixture, analysis, installed);
        need(encoded.report.complete && encoded.artifact && !encoded.artifact->resources.empty(),
             "Registered codec did not encode decoded fixture");
        verify_nastran_readback(*encoded.artifact, encoded.artifact->resources, codec);
        append(categories, "codecs",
               {QJsonObject{{"registry", "production-host-IModelCodec/IProfileProvider"},
                            {"profile", profile(installed)},
                            {"root_resource", text(request.root_resource)}}},
               {{"decode_complete", decoded.report.complete},
                {"decode_supported_records", static_cast<qint64>(decoded.report.supported_records)},
                {"encode_complete", encoded.report.complete},
                {"encoded_resources", static_cast<qint64>(encoded.artifact->resources.size())},
                {"semantic_readback", "success"}});

        const auto plan = good(validate_nastran_export(fixture_view, analysis, codec));
        auto wrong_profile = installed;
        wrong_profile.definition_digest += "-bp10-incompatible";
        const auto rejected_export = codec.encode(fixture, analysis, wrong_profile);
        need(!rejected_export.report.complete && !rejected_export.artifact,
             "Nastran export accepted incompatible profile semantics");
        auto corrupted = plan.resources;
        bool changed = false;
        for (auto& resource : corrupted)
            if (resource.path == "mesh/nodes.bdf") {
                const auto at = resource.text.find("100.0");
                need(at != std::string::npos, "Immutable fixture lacks expected coordinate");
                resource.text.replace(at, 5, "101.0");
                changed = true;
            }
        need(changed, "No independent readback negative fixture was prepared");
        bool rejected_readback = false;
        try {
            verify_nastran_readback(plan, corrupted, codec);
        } catch (const RecordError&) {
            rejected_readback = true;
        }
        need(rejected_readback, "Readback validation accepted a changed engineering coordinate");
        append(categories, "validation",
               {QJsonObject{{"owner", "qcae.nastran"},
                            {"registered_operation", "model.export"},
                            {"callable", "validate_nastran_export/verify_nastran_readback"},
                            {"profile", profile(installed)}}},
               {{"valid_export", "success"}, {"analysis", text(plan.analysis.value)},
                {"incompatible_profile_rejected", true},
                {"changed_coordinate_readback_rejected", rejected_readback}});

        const auto ui = nastran_ui_contribution(codec);
        need(ui.action_id == "nastran.export" && ui.operation == "model.export" &&
                 ui.profile == installed && ui.units == "mm-N-MPa" &&
                 ui.required_fields == std::vector<std::string>{"analysis_id", "output_directory"},
             "Real UI contribution fields differ from production export semantics");
        need(std::get<std::string>(ui_output.at("action_id").data) == ui.action_id,
             "Operation registry UI projection disagrees with actual contribution");
        QJsonArray required_fields;
        for (const auto& field : ui.required_fields)
            required_fields.append(text(field));
        append(categories, "ui",
               {QJsonObject{{"registered_operation", "nastran.ui"},
                            {"action_id", text(ui.action_id)}, {"label", text(ui.label)},
                            {"operation", text(ui.operation)}, {"units", text(ui.units)},
                            {"profile", profile(ui.profile)}, {"required_fields", required_fields}}},
               {{"callable", "nastran_ui_contribution"},
                {"actual_action_id", text(ui.action_id)},
                {"registered_handler_matches_contribution", true}});

        const auto rendering = ipc::nastran_render_contributions();
        need(rendering.frozen() && rendering.entries().size() == 3,
             "Real Nastran render registration must have three frozen entries");
        QJsonArray render_items, render_calls;
        for (const auto& [record_type, entry] : rendering.entries()) {
            const auto* descriptor = assembled.records->find(record_type);
            need(descriptor && entry.project, "Render registration is not backed by a real record type");
            render_items.append(QJsonObject{{"record_type", static_cast<qint64>(record_type.value)},
                                            {"record_name", text(descriptor->name)},
                                            {"topology", text(entry.topology)}});
            Record passive;
            if (record_type == RecordTraits<records::GeometryLine>::type_id)
                passive = assembled.records->make(records::GeometryLine{
                    records::GeometryId("bp10-passive-line"), {0, 0, 0}, {100, 0, 0}, 1});
            else
                fixture_view.visit(record_type, [&](const Record& image) {
                    if (!passive)
                        passive = image;
                });
            need(bool(passive), "Render entry has no passive fixture image");
            const auto projected = entry.project(passive);
            if (record_type == RecordTraits<records::Node>::type_id)
                need(std::get<RenderPoint>(projected).entity.value == passive->key().identity,
                     "Point contribution lost real identity");
            else if (record_type == RecordTraits<records::Beam>::type_id)
                need(std::get<RenderLine2>(projected).entity.value == passive->key().identity,
                     "Beam contribution lost real identity");
            else
                need(std::get<RenderGeometryLine>(projected).entity.value == passive->key().identity,
                     "Geometry contribution lost real identity");
            render_calls.append(QJsonObject{{"record_type", static_cast<qint64>(record_type.value)},
                                            {"entity", text(passive->key().identity)},
                                            {"projected_variant", static_cast<qint64>(projected.index())},
                                            {"status", "success"}});
        }
        append(categories, "render", render_items, {{"project_calls", render_calls}});
        const auto inactive_after = unopened_application.current_document();
        need(!inactive_after.ok() && inactive_after.status == inactive_before.status &&
                 inactive_before.error && inactive_after.error &&
                 inactive_before.error->code == inactive_after.error->code,
             "Readonly consumer created or changed an active document");
        report.insert("active_document_after", QJsonObject{{"status", status_name(inactive_after.status)},
                      {"error_code", error_name(inactive_after.error->code)}});
        need(categories.size() == 6, "Six-category observation incomplete");
        report.insert("observed_category_count", categories.size());
        report.insert("observation_status", "all_six_categories_enumerated_and_called");
    } catch (const std::exception& error) {
        report.insert("observation_status", "failed_actual_observation");
        report.insert("error", QString::fromUtf8(error.what()));
        std::cerr << error.what() << '\n';
        exit_code = 1;
    }
    report.insert("categories", categories);
    report.insert("immutable_fixture_inputs", fixture_facts);
    const auto raw = QJsonDocument(report).toJson(QJsonDocument::Indented);
    QSaveFile file(output);
    if (!file.open(QIODevice::WriteOnly) || file.write(raw) != raw.size() || !file.commit())
        return 2;
    std::cout << raw.constData();
    return exit_code;
}
