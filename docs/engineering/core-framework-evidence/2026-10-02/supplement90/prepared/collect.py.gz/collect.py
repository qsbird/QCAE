#!/usr/bin/env python3
"""Root-only append-only source85 signature/representative/package supplement."""
from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sys
import time

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
COLLECTOR88 = Path('/private/tmp/qcae-framework-reliability-collector88/collect.py')
ROOT = Path('/private/tmp/qcae-framework-preference-fix85')
RUNTIME = Path('/private/tmp/qcae-framework-runtime86')
BUILDS = Path('/private/tmp/qcae-framework86-builds')
NEW_BUILDS = Path('/private/tmp/qcae-framework90-builds')
COMMIT = 'ef0df3bdd8c1b27330d71a596f16098cb6b6410a'
TREE = '15d20f20fef88ed6d1b8637b97edf77143887728cb9c42427620b25429e65c03'
PYTHON = '/Library/Frameworks/Python.framework/Versions/3.14/bin/python3.14'
PREPARATION73 = Path('/private/tmp/qcae-framework-ap-signature-review73')
PREPARATION75 = Path('/private/tmp/qcae-framework-representatives75')
PEER78 = Path('/private/tmp/qcae-framework-package-peer78/peer')
INDEX73_SHA = '203ab08e02be033c7fc7533e7dc84e5552f0bbb37bea2c099df91c940f56f189'
CASES = ('BP-01', 'BP-04', 'BP-05', 'BP-08', 'BP-12', 'BP-15')
CATEGORIES = {'core', 'operations', 'codecs', 'validation', 'ui', 'render'}


class PreparationBlocked(RuntimeError):
    """Absent/drifted prerequisite; no inferred product failure or success."""


def require(value, message):
    if not value:
        raise PreparationBlocked(message)


def fact(path):
    path = Path(path).resolve()
    require(path.is_file(), 'Required immutable input absent: ' + str(path))
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1048576), b''):
            digest.update(chunk)
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': digest.hexdigest()}


def read(path):
    require(Path(path).is_file(), 'Required immutable input absent: ' + str(path))
    return json.loads(Path(path).read_text())


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def verify(item):
    require(fact(item['path']) == item, 'Immutable input changed: ' + item['path'])


# Original78 pure methods use these same semantics; no old Boundary is imported.
need = require


def preparation():
    path = HERE / 'prepared-inputs.json'
    prepared = read(path)
    require(prepared['wrapper'] == fact(__file__), 'Supplement wrapper changed')
    require(prepared['source_root'] == str(ROOT) and prepared['source_commit'] == COMMIT
            and prepared['source410_sha256'] == TREE, 'Wrong prepared source scope')
    for item in prepared['immutable_inputs']:
        verify(item)
    return prepared, [fact(path), prepared['wrapper'], *prepared['immutable_inputs']]


def load88():
    spec = importlib.util.spec_from_file_location('qcae_sealed88_for90', COLLECTOR88)
    require(spec is not None and spec.loader is not None, 'Sealed88 loader absent')
    boundary = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(boundary)
    require(boundary.ROOT == ROOT and boundary.RUNTIME == RUNTIME and boundary.BUILDS == BUILDS
            and boundary.COMMIT == COMMIT and boundary.TREE == TREE and boundary.PYTHON == PYTHON,
            'Imported sealed88 environment/source differs')
    return boundary


def signature_inputs():
    index = PREPARATION73 / 'immutable-index.json'
    require(fact(index)['sha256'] == INDEX73_SHA, 'Original reviewed73 index changed')
    result = [fact(index)]
    for item in read(index)['artifacts']:
        actual = fact(PREPARATION73 / item['path'])
        require(actual['bytes'] == item['bytes'] and actual['sha256'] == item['sha256'],
                'Original reviewed73 preparation changed: ' + item['path'])
        result.append(actual)
    return result


def make_action(attempt, name):
    action = attempt / name
    action.mkdir()
    (action / 'commands').mkdir()
    (action / 'logs').mkdir()
    return action


def signatures(attempt, build, boundary, prepared, inputs):
    action = make_action(attempt, 'signatures')
    facts = signature_inputs()
    require(not build.exists(), 'Signature supplement needs an entirely fresh build')
    old_plan = read(PREPARATION73 / 'prepared-execution-plan.json')
    old_source = '/private/tmp/qcae-framework-architecture-fix65'
    old_build = '/private/tmp/qcae-framework73-ap-builds/typed-01'
    argv_by_phase = {}
    for phase in ('configure', 'build'):
        argv_by_phase[phase] = [arg.replace(old_source, str(ROOT)).replace(old_build, str(build))
                               for arg in old_plan['planned_' + phase + '_argv']]
    write(action / 'current-planned-argv.json', {'source_commit': COMMIT, 'source410_sha256': TREE,
          'original_source65_plan': fact(PREPARATION73 / 'prepared-execution-plan.json'),
          'relocations_only': [old_source + ' -> ' + str(ROOT), old_build + ' -> ' + str(build)],
          'argv_by_phase': argv_by_phase, 'old_results_not_imported': True})
    for phase in ('configure', 'build'):
        print(json.dumps({'actual_action_started': 'signatures', 'phase': phase}), flush=True)
        boundary.command(action, phase, argv_by_phase[phase], [build] if phase == 'configure' else [],
                         extra_inputs=[*inputs, *facts])
        require(signature_inputs() == facts, 'Original preparation drifted during ' + phase)
    cache = boundary.cache_values(build / 'CMakeCache.txt')
    require(cache['CMAKE_CXX_EXTENSIONS'] == 'OFF' and cache['BUILD_TESTING'] == 'OFF',
            'Supplement dialect/testing scope changed')
    require(cache['QCAE_SOURCE_ROOT'] == str(ROOT), 'Signature product source differs')
    for key, value in prepared['signature_cache_requirements'].items():
        require(cache.get(key) == value, 'Signature cache differs: ' + key)
    require(fact(cache['CMAKE_MAKE_PROGRAM']) == prepared['package_binding']['additional_existing_build_tool'],
            'Signature Ninja differs from the existing pinned build launcher')
    commands = read(build / 'compile_commands.json')
    consumers = [row for row in commands if re.fullmatch(r'consumer_ap_\d{2}\.cpp', Path(row['file']).name)]
    expected = {f'consumer_ap_{index:02}' for index in range(1, 21)}
    require(len(consumers) == 20 and {Path(row['file']).stem for row in consumers} == expected,
            'Actual twenty-consumer inventory differs')
    for row in consumers:
        command = row.get('command', ' '.join(row.get('arguments', [])))
        require(Path(row['file']).parent == PREPARATION73 / 'typed-prepared/consumers',
                'Actual consumer source differs')
        require(all(flag in command for flag in ('-std=c++20', '-Wall', '-Wextra', '-Wpedantic', '-Werror'))
                and '-std=gnu++' not in command, 'Actual strict C++20/warning flags differ')
    assertions = sum(Path(row['file']).read_text().count('static_assert(') for row in consumers)
    require(assertions == 106 and (build / 'ap-typed-consumer-count.txt').read_text().strip() == '20',
            'Original consumer/assertion denominators changed')
    binaries = [fact(build / name) for name in sorted(expected)]
    receipt = read(action / 'commands/build.json')
    log = Path(receipt['stdout']['path']).read_text() + Path(receipt['stderr']['path']).read_text()
    require(not re.search(r'(?m)^.*warning:', log), 'Actual compile warnings remain')
    write(action / 'complete.json', {'source_commit': COMMIT, 'source410_sha256': TREE,
          'actual_configure_exit': read(action / 'commands/configure.json')['actual_exit_code'],
          'actual_build_exit': receipt['actual_exit_code'], 'actual_independent_typed_consumers': 20,
          'actual_static_assertions_compiled': assertions, 'function_assertions': 88, 'data_assertions': 18,
          'dialect': 'strict C++20', 'warning_count': 0, 'binaries': binaries,
          'configured_compile_command_entries': len(commands),
          'configured_typed_consumer_entries': len(consumers),
          'cache': fact(build / 'CMakeCache.txt'), 'compile_commands': fact(build / 'compile_commands.json'),
          'count_file': fact(build / 'ap-typed-consumer-count.txt'), 'prepared_inputs': facts,
          'original_public_header_gate_count': 74,
          'scope': 'Unevaluated declaration types and usage requirements, no all-ODR/runtime/AP-L2/BP/SK/P0 completion'})


def representatives(attempt, boundary, prepared, inputs):
    action = make_action(attempt, 'representatives')
    evidence = action / 'evidence'
    argv = [PYTHON, '-B', str(ROOT / 'tests/skeleton_representative_ipc_tests.py'),
            '--engine', str(BUILDS / 'desktop/qcae-engine'), '--cli', str(BUILDS / 'desktop/qcae-cli'),
            '--evidence-dir', str(evidence), '--source-tree-sha256', TREE]
    require('--only-case' not in argv, 'Original full six cases cannot use a filter')
    receipt = boundary.command(action, 'representative-six', argv, [evidence], extra_inputs=inputs)
    validation = validate_six(evidence, prepared['representative_contract'])
    write(action / 'six-case-validation.json', validation)
    write(action / 'complete.json', {'source_commit': COMMIT, 'source410_sha256': TREE,
          'actual_exit_code': receipt['actual_exit_code'], 'actual_argv': receipt['actual_argv'],
          'actual_cases': 6, 'actual_passed': 6, 'validation': fact(action / 'six-case-validation.json'),
          'raw_artifacts': boundary.files_under((evidence,)), 'old75_results_not_imported': True,
          'scope': 'Original six representatives only, no GUI/BP17/wholeSDK/performance/fullSK/P0'})


class PeerBoundary88:
    """Original78 pure image inspector, supplied the current88 mandatory fence."""
    def __init__(self, boundary, binding):
        self.boundary = boundary
        self.binding = binding

    def fence(self):
        return read(RUNTIME / 'prepared.json'), self.boundary.guard()


def package(attempt, build, boundary, prepared, inputs):
    action = make_action(attempt, 'package')
    require(not build.exists(), 'Package supplement needs an entirely fresh build')
    binding = prepared['package_binding']
    tools = binding['requested_tools']
    ninja = binding['additional_existing_build_tool']
    desktop = boundary.cache_values(BUILDS / 'desktop/CMakeCache.txt')
    require(fact(desktop['CMAKE_MAKE_PROGRAM']) == ninja, 'Current desktop Ninja differs')
    argv = [tools['cmake'], '-S', str(PEER78), '-B', str(build), '-G', 'Ninja',
            '-DQCAE_FINAL_SOURCE_ROOT=' + str(ROOT), '-DQCAE_FINAL_COMMIT=' + COMMIT,
            '-DQCAE_FINAL_SOURCE_TREE_SHA256=' + TREE, '-DCMAKE_BUILD_TYPE=Release',
            '-DCMAKE_EXPORT_COMPILE_COMMANDS=ON', '-DCMAKE_CXX_COMPILER=' + tools['compiler'],
            '-DPython3_EXECUTABLE=' + tools['python'], '-DCMAKE_MAKE_PROGRAM=' + ninja['path']]
    for key in ('Qt6_DIR', 'SQLite3_LIBRARY', 'SQLite3_INCLUDE_DIR', 'CMAKE_PREFIX_PATH'):
        if desktop.get(key):
            argv.append('-D' + key + '=' + desktop[key])
    boundary.command(action, 'peer-configure', argv, [build], extra_inputs=inputs)
    cache = boundary.cache_values(build / 'CMakeCache.txt')
    require(cache['QCAE_FINAL_SOURCE_ROOT'] == str(ROOT) and cache['QCAE_FINAL_COMMIT'] == COMMIT
            and cache['QCAE_FINAL_SOURCE_TREE_SHA256'] == TREE, 'Peer configured for another product source')
    expected = {'QCAE_BUILD_IPC': 'ON', 'QCAE_BUILD_STORAGE': 'ON', 'QCAE_BUILD_DESKTOP': 'OFF',
                'QCAE_ENABLE_NASTRAN_PACKAGE': 'ON', 'QCAE_ENABLE_SANITIZERS': 'OFF',
                'CMAKE_BUILD_TYPE': 'Release', 'BUILD_TESTING': 'OFF'}
    for key, value in expected.items():
        require(cache.get(key) == value, 'Wrong independent peer option: ' + key)
    for key in ('Qt6_DIR', 'SQLite3_LIBRARY', 'SQLite3_INCLUDE_DIR'):
        require(cache.get(key) == desktop[key], 'Peer configuration drift: ' + key)
    require(cache['CMAKE_CXX_COMPILER'] == tools['compiler'] and fact(cache['CMAKE_MAKE_PROGRAM']) == ninja,
            'Peer compiler/build tool differs')
    build_receipt = boundary.command(action, 'peer-build',
        [tools['cmake'], '--build', str(build), '--target', 'qcae_bp10_six_category_peer',
         '--clean-first', '-j', '2'], [], extra_inputs=inputs)
    peer_facts = [fact(build / name) for name in
                  ('qcae_bp10_six_category_peer', 'CMakeCache.txt', 'compile_commands.json')]
    def execute(name, command):
        return boundary.command(action, name, command, [], extra_inputs=[*inputs, *peer_facts])
    binary = peer_facts[0]
    symbols = execute('peer-symbols', [binding['inspection_tools']['nm']['path'], '-g', '-C', binary['path']])
    dependencies = inspect(binary, PeerBoundary88(boundary, binding), execute)
    require(dependencies['SQLite_consumer_scope']['linked_in_actual_recursive_load_commands'] is False,
            'Passive peer unexpectedly linked SQLite; cannot assert absence')
    write(action / 'dependencies.json', dependencies)
    raw_path = action / 'six-category-observations.json'
    runtime_receipt = boundary.command(action, 'six-category-calls', [binary['path'], str(raw_path)],
                                       [raw_path], extra_inputs=[*inputs, *peer_facts])
    actual = read(raw_path)
    checked = observations(actual, COMMIT, TREE)
    require(actual.get('solver_processes_started') == 0, 'Readonly peer claimed a solver launch')
    expected_fixtures = {row['path']: row for row in binding['immutable_peer_fixtures']}
    require({row['path'] for row in actual['immutable_fixture_inputs']} == set(expected_fixtures),
            'Actual peer fixture identities differ')
    for row in actual['immutable_fixture_inputs']:
        item = expected_fixtures[row['path']]
        require(row['sha256'] == item['sha256'] and row['byte_length'] == item['bytes'],
                'Actual peer immutable fixture bytes differ')
        verify(item)
    write(action / 'complete.json', {'source_commit': COMMIT, 'source410_sha256': TREE,
          'actual_build_exit': build_receipt['actual_exit_code'],
          'actual_peer_exit': runtime_receipt['actual_exit_code'], 'observed': checked,
          'raw_report': fact(raw_path), 'peer_facts': peer_facts, 'symbol_command': symbols,
          'dependency_report': fact(action / 'dependencies.json'),
          'SQLite_consumer_scope': dependencies['SQLite_consumer_scope'],
          'mandatory_production_SQLite_full': fact(RUNTIME / 'full-regression-sqlite_headless-complete.json'),
          'mandatory_OFF_full': fact(RUNTIME / 'full-regression-package_disabled-complete.json'),
          'old78_results_not_imported': True,
          'scope': 'Independent passive real six registry-category calls; no active document/storage/GUI/vendor solver/AI/fullSDK/fullSK/P0'})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root-authorized-run', action='store_true', required=True)
    parser.add_argument('--attempt-id', required=True)
    parser.add_argument('--action', choices=('all', 'signatures', 'representatives', 'package'), default='all')
    args = parser.parse_args()
    require(re.fullmatch(r'supplement90-[0-9]{2}', args.attempt_id), 'Use a fresh numeric attempt ID')
    attempt = HERE / 'attempts' / args.attempt_id
    attempt.mkdir(parents=True, exist_ok=False)
    started = time.time()
    completed = []
    boundary = None
    try:
        prepared, inputs = preparation()
        write(attempt / 'preparation-before.json', {'inputs': inputs})
        boundary = load88()
        before = boundary.guard()
        write(attempt / 'prerequisite-before.json', before)
        actions = ('signatures', 'representatives', 'package') if args.action == 'all' else (args.action,)
        for action in actions:
            print(json.dumps({'actual_action_started': action}), flush=True)
            if action == 'signatures':
                signatures(attempt, NEW_BUILDS / args.attempt_id / action, boundary, prepared, inputs)
            elif action == 'representatives':
                representatives(attempt, boundary, prepared, inputs)
            else:
                package(attempt, NEW_BUILDS / args.attempt_id / action, boundary, prepared, inputs)
            completed.append(action)
        _, after_inputs = preparation()
        require(after_inputs == inputs, 'Own supplement preparation drifted')
        after = boundary.guard()
        require(after == before, 'Seven current gate/source/build/SDK receipt facts drifted')
        write(attempt / 'preparation-after.json', {'inputs': after_inputs})
        write(attempt / 'prerequisite-after.json', after)
        write(attempt / 'complete.json', {'source_commit': COMMIT, 'source410_sha256': TREE,
              'started_unix': started, 'finished_unix': time.time(), 'actual_completed_actions': completed,
              'action_completions': [fact(attempt / action / 'complete.json') for action in completed],
              'all_before_after_match': True, 'original73_75_78_raw_unchanged': True,
              'bounded_supplement_no_global_or_performance_acceptance': True})
        return 0
    except BaseException as error:
        blocked = isinstance(error, PreparationBlocked) or (boundary is not None and isinstance(error, boundary.Blocked))
        write(attempt / 'failure.json', {'kind': 'blocked_prerequisite_or_proof' if blocked else 'actual_command_or_recorder_failure',
              'error': repr(error), 'source_commit': COMMIT, 'source410_sha256': TREE,
              'started_unix': started, 'finished_unix': time.time(), 'completed_actions': completed,
              'actual_outcomes': 'See actual per-command receipts; absent receipt never implies execution or success',
              'all_partial_outputs_and_nonzero_receipts_preserved': True})
        print(str(error), file=sys.stderr)
        return 1


# Original pure validation and dependency-inspection methods are appended verbatim.


def validate_six(evidence, prepared):
    raw_path = evidence / 'M-representatives.jsonl'
    report_path = evidence / 'M-representatives-report.json'
    rows = [json.loads(line) for line in raw_path.read_text().splitlines() if line.strip()]
    report = read(report_path)
    require(report.get('source_tree_sha256') == TREE and report.get('cases') == 6 and
            report.get('passed') == 6 and report.get('records') == rows,
            'Producer full report and original JSONL do not agree on six passed records')
    require(Counter(row.get('case_id') for row in rows) == Counter(CASES),
            'Expected six distinct representative BP cases are incomplete')
    require(len({row.get('run_id') for row in rows}) == 6 and all(row.get('run_id') for row in rows),
            'Representative actual run IDs are absent/duplicated')
    assertion_counts = {}
    for row in rows:
        case = row['case_id']
        assertions = row.get('assertions')
        require(row.get('source_tree_sha256') == TREE and row.get('passed') is True and
                not row.get('error') and row.get('input') and isinstance(row.get('actual'), dict) and
                row['actual'] and isinstance(row.get('transcript'), list) and row['transcript'],
                'Representative actual record is incomplete/failed/wrong source: ' + case)
        require(isinstance(assertions, list) and assertions and
                all(isinstance(item, dict) and item.get('passed') is True and
                    isinstance(item.get('expected'), str) and item['expected'] and 'actual' in item
                    for item in assertions), 'Original assertions are incomplete/failed: ' + case)
        contract = prepared['assertion_contract'][case]
        expected = Counter(contract['required_expected_counts'])
        if case == 'BP-15':
            files = row['actual'].get('manifest', {}).get('files')
            require(isinstance(files, list) and files,
                    'Actual published BP15 manifest file population is absent')
            expected[contract['one_per_actual_manifest_file']] = len(files)
        observed = Counter(item['expected'] for item in assertions)
        optional = contract.get('optional_pending_poll_assertion')
        optional_count = observed.pop(optional, 0) if optional else 0
        require(observed == expected, 'Full original source assertion population differs: ' + case)
        assertion_counts[case] = {'actual_assertions': len(assertions),
                                  'optional_pending_task_poll_assertions': optional_count}
    for name in ('M-golden.json', 'M-creation-transcript.json', 'M-transcript.json', 'M-engine.log',
                 'BP15-original-resources.json', 'BP15-duplicate-resources.json'):
        require((evidence / name).is_file(), 'Original producer evidence absent: ' + name)
    require(isinstance(read(evidence / 'M-golden.json'), list) and
            len(read(evidence / 'M-golden.json')) == 33, 'Original complete M golden differs')
    return {'kind': 'actual validation of original full representative evidence',
            'source_commit': COMMIT, 'source410_sha256': TREE,
            'cases': list(CASES), 'actual_case_count': 6, 'actual_passed_count': 6,
            'distinct_actual_run_ids': 6, 'assertion_counts': assertion_counts,
            'raw_records': fact(raw_path), 'raw_report': fact(report_path),
            'all_original_assertions_passed': True, 'no_raw_alias_or_source_label_rewrites': True,
            'scope': 'Six existing BP cases only; no BP17/GUI/wholeSDK/performance/fullSK/P0 claim'}


def inspect(binary, boundary, execute):
    prepared, _ = boundary.fence()
    approved = {row["path"]: row for row in
                (*prepared["configured_tool_and_sdk_pins"],
                 *boundary.binding["additional_existing_link_images"])}
    queue = [(Path(binary["path"]), Path(binary["path"]).parent, ())]
    visited, libraries, calls = set(), {}, []
    tool = boundary.binding["inspection_tools"]["otool"]["path"]
    while queue:
        image, executable_dir, inherited = queue.pop()
        identity = (str(image), str(executable_dir))
        if identity in visited:
            continue
        visited.add(identity)
        outputs = []
        for option, label in (("-L", "dependency-list"), ("-l", "load-commands")):
            receipt = execute(f"inspect-{len(visited):02}-{label}", [tool, option, str(image)])
            outputs.append(Path(receipt["stdout"]["path"]).read_text())
            calls.append(receipt)
        own = []
        lines = outputs[1].splitlines()
        for index, line in enumerate(lines):
            if line.strip() != "cmd LC_RPATH":
                continue
            for child in lines[index + 1:index + 5]:
                match = re.search(r"^\s*path (.+) \(offset \d+\)", child)
                if match:
                    own.append(match[1].replace("@loader_path", str(image.parent))
                               .replace("@executable_path", str(executable_dir)))
        search = tuple(own) + inherited
        for line in outputs[0].splitlines()[1:]:
            dependency = line.strip().split(" (compatibility version", 1)[0]
            if not dependency:
                continue
            if dependency.startswith(("/System/Library/", "/usr/lib/")):
                libraries[dependency] = {"path": dependency, "sha256": None,
                                         "status": "system dyld shared cache; image bytes unknown"}
                continue
            if dependency.startswith("@rpath/"):
                candidates = [Path(prefix) / dependency[len("@rpath/"):] for prefix in search]
            else:
                candidates = [Path(dependency.replace("@loader_path", str(image.parent))
                                   .replace("@executable_path", str(executable_dir)))]
            matching = [path.resolve() for path in candidates if path.is_file()]
            need(matching, "Unresolved actual dependency: " + dependency)
            resolved = str(matching[0])
            if resolved == str(image.resolve()):
                continue
            need(resolved in approved, "Dependency not frozen before execution: " + resolved)
            verify(approved[resolved])
            libraries[resolved] = approved[resolved]
            queue.append((Path(resolved), executable_dir, search))
    required = {str(Path(path).resolve()) for path in (
        "/opt/homebrew/Cellar/qtbase/6.11.1/lib/QtCore.framework/Versions/A/QtCore",
        "/opt/homebrew/Cellar/qtbase/6.11.1/lib/QtNetwork.framework/Versions/A/QtNetwork")}
    need(required <= set(libraries), "Peer does not link the frozen QtCore/QtNetwork images")
    sqlite = str(Path("/opt/homebrew/Cellar/sqlite/3.53.4/lib/libsqlite3.3.53.4.dylib").resolve())
    sqlite_linked = sqlite in libraries
    verify(binary)
    return {"binary": binary, "actual_inspection_commands": calls,
            "declared_dependency_images": list(libraries.values()),
            "required_actual_peer_images": sorted(required),
            "SQLite_consumer_scope": {
                "frozen_stock_image": sqlite,
                "linked_in_actual_recursive_load_commands": sqlite_linked,
                "storage_calls_in_peer": False,
                "active_document_in_peer": False,
                "scope": "Passive static package consumer configures storage but does not use/link the persistence adapter. Absence is recorded, never supplied as a fabricated loaded image. Production SQLite/IPC full gates remain mandatory in Boundary."},
            "scope": "Actual recursive Mach-O load commands and exact resolved image bytes; no Qt prefix inference or full SDK runtime/internal coverage claim."}


def observations(report, source_commit, source_tree):
    need(report.get("source_commit") == source_commit and report.get("source_tree_sha256") == source_tree,
         "Six-category report belongs to another source")
    need(report.get("observation_status") == "all_six_categories_enumerated_and_called",
         "Peer did not emit a successful six-category observation")
    need(re.fullmatch(r"[1-9][0-9]*", report.get("process_id", "")), "Missing actual peer PID")
    need(report.get("scope") == "readonly-public-library-consumer-with-immutable-cantilever-fixture",
         "Unexpected consumer scope")
    need(isinstance(report.get("active_document_before"), dict)
         and report.get("active_document_before") == report.get("active_document_after")
         and report["active_document_before"].get("status") != "success",
         "Readonly consumer unexpectedly owns an active document")
    rows = report.get("categories", [])
    need(len(rows) == 6 and report.get("observed_category_count") == 6,
         "Six actual category rows are required")
    need({row.get("category") for row in rows} == CATEGORIES, "Category names differ from frozen contract")
    for row in rows:
        need(row.get("observation_status") == "enumerated_and_called" and row.get("enumerated_items")
             and isinstance(row.get("actual_calls"), dict) and row["actual_calls"],
             "Category lacks actual enumeration and call data")
    need("qcae.nastran" in report.get("engine_contribution_ids", []), "Missing enabled production package")
    need(len(report.get("immutable_fixture_inputs", [])) == 4, "Missing immutable cantilever fixture inputs")
    by_name = {row["category"]: row for row in rows}
    need(by_name["core"]["actual_calls"].get("valid_fixture_rule_calls", 0) >= 1
         and by_name["core"]["actual_calls"].get("incompatible_analysis_kind_rejected") is True,
         "Core rule calls are incomplete")
    operations = by_name["operations"]
    catalog = {row.get("operation"): row for row in operations["enumerated_items"]}
    need(catalog.get("model.export", {}).get("available") is True
         and catalog.get("nastran.ui", {}).get("available") is True,
         "Required real typed registrations are missing")
    need(operations["actual_calls"].get("operation") == "nastran.ui"
         and operations["actual_calls"].get("status") == "success"
         and operations["actual_calls"].get("canonical_result"), "Registered operation was not called")
    codec = by_name["codecs"]["actual_calls"]
    need(codec.get("decode_complete") is True and codec.get("encode_complete") is True
         and codec.get("decode_supported_records", 0) > 0 and codec.get("encoded_resources", 0) > 0
         and codec.get("semantic_readback") == "success", "Codec call data is incomplete")
    validation = by_name["validation"]["actual_calls"]
    need(validation.get("valid_export") == "success" and validation.get("analysis")
         and validation.get("incompatible_profile_rejected") is True
         and validation.get("changed_coordinate_readback_rejected") is True,
         "Validation call data is incomplete")
    need(by_name["ui"]["actual_calls"].get("actual_action_id") == "nastran.export"
         and by_name["ui"]["actual_calls"].get("registered_handler_matches_contribution") is True,
         "UI contribution call differs")
    rendering = by_name["render"]
    calls = rendering["actual_calls"].get("project_calls", [])
    need(len(rendering["enumerated_items"]) == len(calls) == 3, "Three real render entries/calls are required")
    need({row.get("record_type") for row in rendering["enumerated_items"]}
         == {row.get("record_type") for row in calls} and len({row["record_type"] for row in calls}) == 3,
         "Render call identities do not match registry")
    need(all(row.get("status") == "success" and row.get("entity") for row in calls),
         "A real render contribution did not project an identity")
    return {"actual_peer_pid": report["process_id"], "observed_category_count": len(rows),
            "category_names": sorted(CATEGORIES),
            "scope": report["scope"],
            "registration_limit": "No generic unified codec/validation/UI category registry endpoint exists; actual existing host injection and typed operation bindings are named explicitly."}


if __name__ == '__main__':
    raise SystemExit(main())
