// Prepared AP signature consumer; compilation and runtime have not been executed.
#include "qcae/line_mesh_task.hpp"
#include <type_traits>
using namespace qcae;
using Signature1 = TaskRequest (*)(const RecordSnapshot&, Caller, records::MeshId, std::uint32_t, std::string, std::string);
static_assert(std::is_same_v<decltype(&regenerate_line_mesh_task), Signature1>);
static_assert(std::is_same_v<decltype(LineMeshInput::geometry), records::GeometryId>);
int main() { return 0; }
