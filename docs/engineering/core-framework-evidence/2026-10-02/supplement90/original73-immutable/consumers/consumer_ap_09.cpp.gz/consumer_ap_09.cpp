// Prepared AP signature consumer; compilation and runtime have not been executed.
#include "qcae/quantities.hpp"
#include <type_traits>
using namespace qcae;
using Signature1 = Result<Quantity> (*)(const Quantity&, parameters::Dimension, std::string_view);
static_assert(std::is_same_v<decltype(&parameters::convert_quantity), Signature1>);
using Signature2 = Result<parameters::Vector3> (*)(const parameters::CoordinateFrame&, const parameters::Vector3&);
static_assert(std::is_same_v<decltype(&parameters::local_to_global), Signature2>);
using Signature3 = Result<parameters::ScalarTable1D> (*)(parameters::Dimension, parameters::Dimension, std::vector<parameters::TablePoint>);
static_assert(std::is_same_v<decltype(&parameters::ScalarTable1D::create), Signature3>);
using Signature4 = Result<Quantity> (parameters::ScalarTable1D::*)(const Quantity&, parameters::OutsidePolicy) const;
static_assert(std::is_same_v<decltype(&parameters::ScalarTable1D::evaluate), Signature4>);
int main() { return 0; }
