// Prepared AP signature consumer; compilation and runtime have not been executed.
#include "qcae/vtk_view.hpp"
#include <type_traits>
using namespace qcae;
using Signature1 = void (VtkView::*)(const QStringList&, bool);
static_assert(std::is_same_v<decltype(&VtkView::picked), Signature1>);
using Signature2 = void (VtkView::*)(const RenderPreview&);
static_assert(std::is_same_v<decltype(&VtkView::setPreview), Signature2>);
using Signature3 = bool (VtkView::*)(const RenderDelta&);
static_assert(std::is_same_v<decltype(&VtkView::applyDelta), Signature3>);
using Signature4 = void (VtkView::*)();
static_assert(std::is_same_v<decltype(&VtkView::clearPreview), Signature4>);
int main() { return 0; }
