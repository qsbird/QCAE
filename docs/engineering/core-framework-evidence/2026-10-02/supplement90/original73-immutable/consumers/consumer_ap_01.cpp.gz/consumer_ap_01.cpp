// Prepared AP signature consumer; compilation and runtime have not been executed.
#include "qcae/record_application.hpp"
#include "qcae/operation_registry.hpp"
#include <type_traits>
using namespace qcae;
using Signature1 = Result<DocumentInfo> (RecordApplication::*)(const Caller&, const std::string&, const std::string&);
static_assert(std::is_same_v<decltype(&RecordApplication::create_document), Signature1>);
using Signature2 = Result<DocumentInfo> (RecordApplication::*)(const Caller&, const std::string&, const std::string&);
static_assert(std::is_same_v<decltype(&RecordApplication::open_document), Signature2>);
using Signature3 = Result<DocumentInfo> (RecordApplication::*)(const Caller&, const std::string&);
static_assert(std::is_same_v<decltype(&RecordApplication::recover_document), Signature3>);
using Signature4 = Result<DocumentInfo> (RecordApplication::*)(const Caller&, const WriteContext&, ClosePolicy, const std::string&);
static_assert(std::is_same_v<decltype(&RecordApplication::close_document), Signature4>);
using Signature5 = Result<DocumentInfo> (RecordApplication::*)() const;
static_assert(std::is_same_v<decltype(&RecordApplication::current_document), Signature5>);
using Signature6 = Result<RecordSnapshot> (RecordApplication::*)(const DocumentRef&) const;
static_assert(std::is_same_v<decltype(&RecordApplication::snapshot), Signature6>);
using Signature7 = std::vector<operations::OperationDescriptor> (operations::OperationRegistry::*)() const;
static_assert(std::is_same_v<decltype(&operations::OperationRegistry::descriptors), Signature7>);
int main() { return 0; }
