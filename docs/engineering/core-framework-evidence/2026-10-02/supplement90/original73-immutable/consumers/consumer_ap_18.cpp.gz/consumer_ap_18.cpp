// Prepared AP signature consumer; compilation and runtime have not been executed.
#include "qcae/desktop_client.hpp"
#include <type_traits>
using namespace qcae;
using Signature1 = QString (DesktopClient::*)(const QString&, const QJsonObject&, const QJsonObject&, DesktopClient::Reply, qsizetype);
static_assert(std::is_same_v<decltype(&DesktopClient::request), Signature1>);
using Signature2 = void (DesktopClient::*)(const QJsonObject&);
static_assert(std::is_same_v<decltype(&DesktopClient::eventReceived), Signature2>);
using Signature3 = void (DesktopClient::*)(const QString&);
static_assert(std::is_same_v<decltype(&DesktopClient::eventGap), Signature3>);
using Signature4 = void (DesktopClient::*)(const QString&, quint64);
static_assert(std::is_same_v<decltype(&DesktopClient::setEventCursor), Signature4>);
static_assert(std::is_same_v<decltype(DesktopClient::Options::request_timeout_ms), qint64>);
int main() { return 0; }
