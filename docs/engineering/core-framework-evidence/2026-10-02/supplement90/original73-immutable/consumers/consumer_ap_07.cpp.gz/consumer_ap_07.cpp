// Prepared AP signature consumer; compilation and runtime have not been executed.
#include "qcae/mesh_editing_operations.hpp"
#include <type_traits>
using namespace qcae;
using Signature1 = Result<features::mesh_editing::OperationPlan> (*)(const operations::NodeMoveInput&);
static_assert(std::is_same_v<decltype(&features::mesh_editing::prepare_move_node), Signature1>);
using Signature2 = Result<features::mesh_editing::OperationPlan> (*)(const operations::NodeTranslateBatchInput&);
static_assert(std::is_same_v<decltype(&features::mesh_editing::prepare_translate_nodes), Signature2>);
using Signature3 = Result<features::mesh_editing::OperationPlan> (*)(const operations::BeamAssignSectionInput&);
static_assert(std::is_same_v<decltype(&features::mesh_editing::prepare_assign_section), Signature3>);
using Signature4 = Result<features::mesh_editing::OperationPlan> (*)(const operations::MeshCreateTri3Input&);
static_assert(std::is_same_v<decltype(&features::mesh_editing::prepare_create_tri3), Signature4>);
using Signature5 = Result<bool> (*)(operations::OperationRegistry&, RecordApplication&);
static_assert(std::is_same_v<decltype(&features::mesh_editing::register_handlers), Signature5>);
static_assert(std::is_same_v<decltype(features::mesh_editing::OperationPlan::prepare), RecordPrepare>);
int main() { return 0; }
