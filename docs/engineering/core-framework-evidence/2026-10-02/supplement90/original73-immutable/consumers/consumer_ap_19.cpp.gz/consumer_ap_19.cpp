// Prepared AP signature consumer; compilation and runtime have not been executed.
#include "qcae/result_service.hpp"
#include <type_traits>
using namespace qcae;
using Signature1 = Result<features::results::StoredFixtureResult> (features::results::FixtureResultService::*)(const Caller&, const WriteContext&, std::string_view, const features::results::ResultFixture&, const std::string&);
static_assert(std::is_same_v<decltype(&features::results::FixtureResultService::read), Signature1>);
using Signature2 = Result<features::results::StoredFixtureResult> (features::results::FixtureResultService::*)(const Caller&, const DocumentRef&, std::string_view) const;
static_assert(std::is_same_v<decltype(&features::results::FixtureResultService::get), Signature2>);
static_assert(std::is_same_v<decltype(features::results::StoredFixtureResult::artifact_id), std::string>);
int main() { return 0; }
