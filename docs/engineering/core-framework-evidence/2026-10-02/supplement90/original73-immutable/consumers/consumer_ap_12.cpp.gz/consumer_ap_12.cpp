// Prepared AP signature consumer; compilation and runtime have not been executed.
#include "qcae/record_application.hpp"
#include "qcae/operation_registry.hpp"
#include <type_traits>
using namespace qcae;
using Signature1 = Result<bool> (operations::OperationRegistry::*)(operations::OperationDefinition, std::string);
static_assert(std::is_same_v<decltype(&operations::OperationRegistry::declare_unavailable), Signature1>);
using Signature2 = Result<operations::Value> (operations::OperationRegistry::*)(std::string_view, std::uint32_t, const operations::OperationContext&, const operations::Value&) const;
static_assert(std::is_same_v<decltype(static_cast<Signature2>(&operations::OperationRegistry::invoke)), Signature2>);
using Signature3 = std::vector<operations::OperationDescriptor> (operations::OperationRegistry::*)() const;
static_assert(std::is_same_v<decltype(&operations::OperationRegistry::descriptors), Signature3>);
using Signature4 = Result<ChangeReceipt> (RecordApplication::*)(const Caller&, const WriteContext&, const std::string&, const std::string&, const RecordPrepare&, const std::string&, const CommitOwnedRows&);
static_assert(std::is_same_v<decltype(&RecordApplication::execute), Signature4>);
using Signature5 = Result<ChangeReceipt> (RecordApplication::*)(const Caller&, const WriteContext&, const std::string&);
static_assert(std::is_same_v<decltype(&RecordApplication::undo), Signature5>);
using Signature6 = Result<ChangeReceipt> (RecordApplication::*)(const Caller&, const WriteContext&, const std::string&);
static_assert(std::is_same_v<decltype(&RecordApplication::redo), Signature6>);
using Signature7 = Result<HistorySnapshot> (RecordApplication::*)(const DocumentRef&) const;
static_assert(std::is_same_v<decltype(&RecordApplication::history), Signature7>);
int main() { return 0; }
