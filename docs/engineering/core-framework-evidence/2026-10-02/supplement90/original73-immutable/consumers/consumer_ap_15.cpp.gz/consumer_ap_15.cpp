// Prepared AP signature consumer; compilation and runtime have not been executed.
#include "qcae/record_application.hpp"
#include "qcae/nastran_codec.hpp"
#include <type_traits>
using namespace qcae;
using Signature1 = Result<DocumentInfo> (RecordApplication::*)(const Caller&, const WriteContext&, const std::string&, bool, const std::string&);
static_assert(std::is_same_v<decltype(&RecordApplication::save_document), Signature1>);
using Signature2 = Result<DocumentInfo> (RecordApplication::*)(const Caller&, const std::string&, const std::string&, const ProjectRecordMigration&);
static_assert(std::is_same_v<decltype(&RecordApplication::open_migrated_document), Signature2>);
using Signature3 = ImportOutcome (NastranCodec::*)(const ImportRequest&) const;
static_assert(std::is_same_v<decltype(&NastranCodec::decode), Signature3>);
using Signature4 = ExportOutcome (NastranCodec::*)(const Model&, const EntityId&, const ProfileRef&) const;
static_assert(std::is_same_v<decltype(&NastranCodec::encode), Signature4>);
int main() { return 0; }
