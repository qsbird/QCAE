// Prepared AP signature consumer; compilation and runtime have not been executed.
#include "qcae/analysis_features.hpp"
#include "qcae/analysis_input.hpp"
#include <type_traits>
using namespace qcae;
using Signature1 = Result<features::analysis::FrozenAnalysisInput> (*)(const DocumentView&, const EntityId&, const ProfileRef&, std::span<const ExportIdentifier>);
static_assert(std::is_same_v<decltype(&features::analysis::freeze_analysis_input), Signature1>);
using Signature2 = Result<features::analysis::OperationPlan> (*)(const operations::LoadCaseCreateInput&);
static_assert(std::is_same_v<decltype(&features::analysis::prepare_create_load_case), Signature2>);
using Signature3 = Result<features::analysis::OperationPlan> (*)(const operations::LoadCaseSetReferencesInput&);
static_assert(std::is_same_v<decltype(&features::analysis::prepare_set_references), Signature3>);
using Signature4 = Result<features::analysis::OperationPlan> (*)(const operations::AnalysisCreateInput&, const ProfileRef&);
static_assert(std::is_same_v<decltype(&features::analysis::prepare_create_analysis), Signature4>);
static_assert(std::is_same_v<decltype(features::analysis::FrozenAnalysisInput::input_signature), std::string>);
int main() { return 0; }
