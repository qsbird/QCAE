// Prepared AP signature consumer; compilation and runtime have not been executed.
#include "qcae/desktop.hpp"
#include <type_traits>
using namespace qcae;
using Signature1 = QMainWindow* (*)(DesktopClient::Options);
static_assert(std::is_same_v<decltype(&create_desktop_window), Signature1>);
using Signature2 = bool (*)(const QMainWindow&);
static_assert(std::is_same_v<decltype(&desktop_pipeline_idle), Signature2>);
using Signature3 = int (*)(int, char**);
static_assert(std::is_same_v<decltype(&run_desktop), Signature3>);
int main() { return 0; }
