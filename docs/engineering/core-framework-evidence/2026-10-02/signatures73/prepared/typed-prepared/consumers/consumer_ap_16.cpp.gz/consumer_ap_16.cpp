#include "qcae/vtk_view.hpp"
#include "qcae/resource_client.hpp"
#include "qcae/render_wire.hpp"
// Prepared AP signature consumer; compilation and runtime have not been executed.
#include "qcae/render_projector.hpp"
#include <type_traits>
using namespace qcae;
using Signature1 = void (RenderContributions::*)(RenderContribution);
static_assert(std::is_same_v<decltype(&RenderContributions::add), Signature1>);
using Signature2 = void (RenderContributions::*)();
static_assert(std::is_same_v<decltype(&RenderContributions::freeze), Signature2>);
using Signature3 = Result<RenderUpdate> (RenderProjector::*)(const DocumentView&, const ViewSession&, std::span<const DirectedRenderChange>, bool);
static_assert(std::is_same_v<decltype(&RenderProjector::update), Signature3>);
static_assert(std::is_same_v<decltype(RenderUpdate::full), std::optional<RenderPacket>>);
static_assert(std::is_same_v<decltype(RenderCellSource::nodes), std::vector<EntityId>>);
using Signature4 = Result<RenderDelta> (*)(const QByteArray&);
static_assert(std::is_same_v<decltype(&transport::decode_render_delta), Signature4>);
using Signature5 = void (ResourceClient::*)(const ResourceManifest&, ResourceClient::Reply);
static_assert(std::is_same_v<decltype(&ResourceClient::fetch), Signature5>);
using Signature6 = bool (VtkView::*)(const RenderDelta&);
static_assert(std::is_same_v<decltype(&VtkView::applyDelta), Signature6>);
int main() { return 0; }
