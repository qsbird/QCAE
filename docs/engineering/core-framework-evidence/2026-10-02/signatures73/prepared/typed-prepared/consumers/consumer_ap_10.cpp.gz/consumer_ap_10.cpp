// Prepared AP signature consumer; compilation and runtime have not been executed.
#include "qcae/engine_contributions.hpp"
#include "qcae/nastran_contribution.hpp"
#include "qcae/nastran_codec.hpp"
#include "qcae/nastran_package.hpp"
#include <type_traits>
using namespace qcae;
using Signature1 = std::vector<ipc::EngineContribution> (*)();
static_assert(std::is_same_v<decltype(static_cast<Signature1>(&ipc::default_engine_contributions)), Signature1>);
using Signature2 = ipc::EngineAssembly (*)(std::span<const ipc::EngineContribution>);
static_assert(std::is_same_v<decltype(&ipc::assemble_engine), Signature2>);
using Signature3 = bool (*)() noexcept;
static_assert(std::is_same_v<decltype(&ipc::nastran_package_enabled), Signature3>);
using Signature4 = void (*)(RecordRegistry&, const ProfileRef&);
static_assert(std::is_same_v<decltype(&register_nastran_core_rules), Signature4>);
using Signature5 = ImportOutcome (NastranCodec::*)(const ImportRequest&) const;
static_assert(std::is_same_v<decltype(&NastranCodec::decode), Signature5>);
using Signature6 = Result<ArtifactPlan> (*)(const DocumentView&, const EntityId&, const NastranCodec&);
static_assert(std::is_same_v<decltype(&validate_nastran_export), Signature6>);
using Signature7 = NastranUiContribution (*)(const NastranCodec&);
static_assert(std::is_same_v<decltype(&nastran_ui_contribution), Signature7>);
using Signature8 = RenderContributions (*)();
static_assert(std::is_same_v<decltype(&ipc::nastran_render_contributions), Signature8>);
using Signature9 = ipc::EngineContribution (*)(const std::shared_ptr<ipc::NastranArtifactCoordinator>&);
static_assert(std::is_same_v<decltype(&ipc::nastran_engine_contribution), Signature9>);
int main() { return 0; }
