// Prepared AP signature consumer; compilation and runtime have not been executed.
#include "qcae/task_service.hpp"
#include <type_traits>
using namespace qcae;
using Signature1 = Result<TaskRecord> (TaskService::*)(TaskRequest);
static_assert(std::is_same_v<decltype(&TaskService::start), Signature1>);
using Signature2 = Result<TaskRecord> (TaskService::*)(const Caller&, std::string_view) const;
static_assert(std::is_same_v<decltype(&TaskService::query), Signature2>);
using Signature3 = Result<TaskCancelResult> (TaskService::*)(const Caller&, std::string_view);
static_assert(std::is_same_v<decltype(&TaskService::cancel), Signature3>);
using Signature4 = Result<TaskRecord> (TaskService::*)(const Caller&, std::string_view);
static_assert(std::is_same_v<decltype(&TaskService::wait), Signature4>);
using Signature5 = Result<bool> (TaskService::*)();
static_assert(std::is_same_v<decltype(&TaskService::reconcile), Signature5>);
static_assert(std::is_same_v<decltype(TaskServiceLimits::workers), std::size_t>);
static_assert(std::is_same_v<decltype(TaskPublisher::persist), std::function<Result<bool>(const TaskRecord&, const std::optional<TaskRecord>&)>>);
int main() { return 0; }
