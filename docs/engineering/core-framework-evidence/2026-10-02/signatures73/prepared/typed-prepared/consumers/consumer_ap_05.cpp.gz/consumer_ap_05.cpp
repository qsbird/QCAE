// Prepared AP signature consumer; compilation and runtime have not been executed.
#include "qcae/line_mesh_task.hpp"
#include <type_traits>
using namespace qcae;
using Signature1 = TaskRequest (*)(const RecordSnapshot&, Caller, ProfileRef, LineMeshInput, std::string);
static_assert(std::is_same_v<decltype(&line_mesh_task), Signature1>);
static_assert(std::is_same_v<decltype(LineMeshInput::segments), std::uint32_t>);
static_assert(std::is_same_v<decltype(LineMeshInput::section), std::optional<EntityId>>);
int main() { return 0; }
