// Prepared AP signature consumer; compilation and runtime have not been executed.
#include "qcae/core.hpp"
#include "qcae/query.hpp"
#include <type_traits>
using namespace qcae;
using Signature1 = Result<EntityPage> (*)(const DocumentView&, const EntityFilter&, std::size_t, std::size_t, RecordStats*);
static_assert(std::is_same_v<decltype(static_cast<Signature1>(&query_entities)), Signature1>);
using Signature2 = Result<RecordInput> (*)(const DocumentView&, const EntityId&, RecordStats*);
static_assert(std::is_same_v<decltype(&query_fields), Signature2>);
using Signature3 = Result<ReferencePage> (*)(const DocumentView&, const EntityId&, bool, std::size_t, std::size_t, RecordStats*);
static_assert(std::is_same_v<decltype(&query_references), Signature3>);
using Signature4 = std::vector<EntityId> (*)(const DocumentView&, const EntityId&);
static_assert(std::is_same_v<decltype(&query_affected_analyses), Signature4>);
using Signature5 = Result<ChangePreview> (MemoryApplication::*)(const Caller&, const WriteContext&, const ModelEdit&);
static_assert(std::is_same_v<decltype(&MemoryApplication::preview_edit), Signature5>);
static_assert(std::is_same_v<decltype(EntityFilter::owner), std::optional<EntityId>>);
int main() { return 0; }
