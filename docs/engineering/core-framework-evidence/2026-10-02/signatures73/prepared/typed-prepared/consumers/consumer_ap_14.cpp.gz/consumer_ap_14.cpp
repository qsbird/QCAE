// Prepared AP signature consumer; compilation and runtime have not been executed.
#include "qcae/analysis_features.hpp"
#include <type_traits>
using namespace qcae;
using Signature1 = Result<features::analysis::CheckReport> (features::analysis::RuleCatalog::*)(const DocumentView&, const EntityId&) const;
static_assert(std::is_same_v<decltype(&features::analysis::RuleCatalog::check), Signature1>);
using Signature2 = Result<features::analysis::CheckReport> (features::analysis::CheckService::*)(const Caller&, const WriteContext&, const EntityId&, const std::string&);
static_assert(std::is_same_v<decltype(&features::analysis::CheckService::run), Signature2>);
using Signature3 = Result<features::analysis::CheckReport> (features::analysis::CheckService::*)(const Caller&, const DocumentRef&, const std::string&) const;
static_assert(std::is_same_v<decltype(&features::analysis::CheckService::get), Signature3>);
using Signature4 = features::analysis::IssueState (*)(const features::analysis::CheckReport&, const DocumentView&) noexcept;
static_assert(std::is_same_v<decltype(&features::analysis::issue_state), Signature4>);
static_assert(std::is_same_v<decltype(features::analysis::CheckReport::outcome), Status>);
static_assert(std::is_same_v<decltype(features::analysis::Issue::input), RecordVersion>);
int main() { return 0; }
