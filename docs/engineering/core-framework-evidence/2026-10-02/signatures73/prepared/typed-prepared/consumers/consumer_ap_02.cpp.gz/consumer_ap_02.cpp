// Prepared AP signature consumer; compilation and runtime have not been executed.
#include "qcae/record_registry.hpp"
#include <type_traits>
using namespace qcae;
using Signature1 = void (RecordRegistry::*)(RecordDescriptor);
static_assert(std::is_same_v<decltype(&RecordRegistry::add), Signature1>);
using Signature2 = void (RecordRegistry::*)();
static_assert(std::is_same_v<decltype(&RecordRegistry::freeze), Signature2>);
using Signature3 = const RecordDescriptor* (RecordRegistry::*)(RecordTypeId) const noexcept;
static_assert(std::is_same_v<decltype(&RecordRegistry::find), Signature3>);
using Signature4 = Record (RecordRegistry::*)(std::string_view, RecordStats*) const;
static_assert(std::is_same_v<decltype(&RecordRegistry::decode), Signature4>);
using Signature5 = Record (RecordRegistry::*)(const RecordInput&, RecordStats*) const;
static_assert(std::is_same_v<decltype(&RecordRegistry::from_input), Signature5>);
static_assert(std::is_same_v<decltype(RecordInput::key), RecordKey>);
static_assert(std::is_same_v<decltype(RecordDescriptor::current_version), std::uint32_t>);
int main() { return 0; }
