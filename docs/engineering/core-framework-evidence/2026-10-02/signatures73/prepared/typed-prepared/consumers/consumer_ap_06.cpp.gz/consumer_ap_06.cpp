// Prepared AP signature consumer; compilation and runtime have not been executed.
#include "qcae/document_view.hpp"
#include "qcae/record_registry.hpp"
#include <type_traits>
using namespace qcae;
using Signature1 = RecordVersion (DocumentView::*)() const;
static_assert(std::is_same_v<decltype(&DocumentView::version), Signature1>);
using Signature2 = bool (DocumentView::*)(const RecordVersion&) const noexcept;
static_assert(std::is_same_v<decltype(&DocumentView::matches_version), Signature2>);
using Signature3 = std::size_t (DocumentView::*)(RecordTypeId) const noexcept;
static_assert(std::is_same_v<decltype(&DocumentView::count), Signature3>);
using Signature4 = Record (DocumentView::*)(const RecordKey&) const noexcept;
static_assert(std::is_same_v<decltype(static_cast<Signature4>(&DocumentView::find)), Signature4>);
using Signature5 = DocumentView (*)(const DocumentView&, const RecordChangeSet&, RecordDirection, RecordStats*);
static_assert(std::is_same_v<decltype(&apply_record_changes), Signature5>);
static_assert(std::is_same_v<decltype(RecordVersion::revision), Revision>);
int main() { return 0; }
