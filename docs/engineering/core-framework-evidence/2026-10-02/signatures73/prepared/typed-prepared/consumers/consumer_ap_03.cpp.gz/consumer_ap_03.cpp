// Prepared AP signature consumer; compilation and runtime have not been executed.
#include "qcae/geometry_features.hpp"
#include <type_traits>
using namespace qcae;
using Signature1 = RecordPrepare (*)(LineGeometryInput);
static_assert(std::is_same_v<decltype(&create_line_handler), Signature1>);
using Signature2 = RecordPrepare (*)(records::GeometryId, std::array<double, 3>);
static_assert(std::is_same_v<decltype(&move_line_endpoint_handler), Signature2>);
using Signature3 = std::array<double, 3> (*)(const DocumentView&, const records::GeometryId&, double);
static_assert(std::is_same_v<decltype(&evaluate_line), Signature3>);
static_assert(std::is_same_v<decltype(LineGeometryInput::start_mm), std::array<double, 3>>);
int main() { return 0; }
