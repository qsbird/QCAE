"""Only parse finished root output/artifacts. No product/module imports or calls."""
import hashlib,json,re
from pathlib import Path
OUT=Path(__file__).resolve().parent;RUN=Path('/private/tmp/qcae-framework-runtime86');BUILD=Path('/private/tmp/qcae-framework86-builds');SRC=Path('/private/tmp/qcae-framework-preference-fix85')
HEAD='ef0df3bdd8c1b27330d71a596f16098cb6b6410a';DIGEST='15d20f20fef88ed6d1b8637b97edf77143887728cb9c42427620b25429e65c03'
INPUTS={}
def fact(path):
 path=Path(path).resolve();raw=path.read_bytes();v={'path':str(path),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()};INPUTS[str(path)]=v;return v
def read(path):fact(path);return json.loads(Path(path).read_text())
def pinned(v):assert fact(v['path'])==v,v['path']
review=read(OUT/'01-review.json')
assert review['source_commit']==HEAD and review['source410_sha256']==DIGEST
assert [x['raw_passed'] for x in review['matrices'] if x['status']=='complete']==[40,47,47,80,73,91]
assert sum(x.get('raw_passed',0) for x in review['matrices'])==378
assert all(x['status'] in ('complete','compile_gate_complete') for x in review['matrices'])
old65=read('/private/tmp/qcae-framework-runtime68/frozen-candidate.json');changed=[]
assert old65['commit']=='1c3f8f594409a73f03442ada47fa0d13d1b9f31a' and len(old65['tracked_files'])==2835
for name,expected in old65['tracked_files'].items():
 raw=(SRC/name).read_bytes()
 if (len(raw),hashlib.sha256(raw).hexdigest())!=(expected['bytes'],expected['sha256']):changed.append(name)
assert set(changed)=={'tests/c3_desktop_workflow_tests.cpp','tests/c3_tool_lifecycle_tests.cpp','tests/desktop_selection_tests.cpp','ui/desktop/src/desktop.cpp','ui/desktop/src/shortcut_preferences.cpp'}
rawpath=RUN/'full-regression-desktop-diagnostics/LastTest.log';fact(rawpath);raw=rawpath.read_text()
blocks={m[1]:m[0] for m in re.finditer(r'^\d+/\d+ Testing: (\S+)\n.*?(?=^\d+/\d+ Testing:|\Z)',raw,re.M|re.S)}
assert len(blocks)==91 and 'QSKIP' not in raw
for block in blocks.values():
 assert not re.search(r'(?m)^(?:SKIP|FAIL)\s*:',block)
 for qtest in re.finditer(r'Totals:\s*(\d+) passed,\s*(\d+) failed,\s*(\d+) skipped',block):assert qtest[2]=='0' and qtest[3]=='0'
workflow=blocks['c3_desktop_workflow']
names=['guiCreatesChecksRepairsAndPublishesM('+mode+'-M-'+str(i)+')' for mode in ['GUI','MIX'] for i in range(3)]
snapshots=['aiSnapshotUnitsAndCameraAreConsistent()','aiSnapshotForcePreviewUndoAndRecoveryUseSharedHistory()']
for name in names+snapshots:assert re.search(r'(?m)^PASS\s*:\s*Workflow::'+re.escape(name)+r'$',workflow),name
totals={'c3_desktop_workflow':109,'modeling_tools':12,'desktop_selection':71,'desktop':25,'c3_tool_lifecycle':3}
for name,count in totals.items():assert 'Totals: '+str(count)+' passed, 0 failed, 0 skipped' in blocks[name]
snapshot='/Users/qs/Documents/ChatGPT/QCAE/build-c3-ai-units-snapshots/session5.qcae'
receipt=read(RUN/'full-regression-desktop.json');assert receipt['explicit_environment']['QCAE_AI_UNITS_SNAPSHOT']==snapshot
assert fact(snapshot)['sha256']=='78b66ecb188d317c39192abedba25c5f335f87f56b9988dd0a1c9e5adfd33e83'
evidence=BUILD/'desktop/c3-evidence/desktop';native=[]
for mode in ['GUI','MIX']:
 for i in range(3):
  path=evidence/(mode+'-M-run-'+str(i)+'.json');d=read(path)
  assert d['source_tree_sha256']==DIGEST and d['mode']==mode and d['initial_entity_count']==0 and d['observer_writes']==0
  assert len(d['M'])==33 and len(d['external_writes'])==(0 if mode=='GUI' else 3)
  assert d['manifest']['complete'] is True and d['R']['source_kind']=='fixture'
  assert {'M_baseline','check_repaired','normal_open_M','published_M','recovered_M','selection_applied','selection_undone','stale_result_input_M'}==set(d['semantic_checkpoints'])
  assert sum(v['kind']=='node' for v in d['M'].values())==11 and sum(v['kind']=='beam' for v in d['M'].values())==10
  for write in d['external_writes']:assert write['response']['status']=='success'
  png=evidence/(mode+'-M-run-'+str(i)+'.png');assert png.read_bytes()[:8]==b'\x89PNG\r\n\x1a\n'
  native.append({'run_id':d['run_id'],'mode':mode,'json':fact(path),'PNG':fact(png),'entities':33,'nodes':11,'beams':10,'external_writes':len(d['external_writes']),'observer_writes':0,'source_digest_match':True,'fixture_source_preserved':True})
unit=list(evidence.glob('AI-units-*-check-units-original.json'));camera=list(evidence.glob('AI-units-*-check-actual-camera.json'));force=list(evidence.glob('AI-force-*-check-force-shared-history.json'));assert len(unit)==len(camera)==len(force)==1
u=read(unit[0]);c=read(camera[0]);f=read(force[0])
for value in [u,c,f]:assert value['snapshot_sha256']=='78b66ecb188d317c39192abedba25c5f335f87f56b9988dd0a1c9e5adfd33e83'
assert u['snapshot_path']==snapshot and u['backend']['qt_platform']=='cocoa'
assert c['actual_gui_drag'] and c['model_unchanged'] and c['before_fingerprint']!=c['after_fingerprint']
assert c['history_before']==c['history_after'] and c['context_before']==c['context_after']
for name in ['one_gui_transaction','preview_cancel_did_not_commit','actual_process_kill_and_gui_recover']:assert f[name] is True
assert f['model_before']==f['model_recovered'] and f['history_undone']==f['history_recovered']
assert f['force_before']['force_n']==[0,-1,0] and f['force_changed']['force_n']==[0,-2,0] and f['force_recovered']['force_n']==[0,-1,0]
assert f['undone']['document_id']==f['recovered']['document_id'] and f['undone']['document_epoch']!=f['recovered']['document_epoch']
life_path=BUILD/'desktop/c3_tool_lifecycle_evidence/tool-lifecycle.json';life=read(life_path)
assert life['passed_samples']==len(life['runs'])==life['script']['samples']==30 and life['final_revision']=='60'
assert life['script_sha256']==fact(SRC/'tests/fixtures/c3-tool-lifecycle-v1.json')['sha256']=='3f67b5096cc0527aca95177d71ef32006f762778c1a823cfeb55a7f27a72415a'
ids=set();transactions=set()
for i,r in enumerate(life['runs']):
 assert r['run_id']==life['session_id']+'-'+str(i+1).zfill(3);ids.add(r['run_id']);transactions.add(r['transaction_id'])
 assert r['passed'] and r['cancel_history_unchanged'] and r['final_matches_golden'] and r['final_entities']==[]
 assert r['geometry_commit_count']==1 and r['cancel_revision_delta']==0
 assert int(r['start_revision'])==2*i and int(r['cancel_revision'])==2*i and int(r['apply_revision'])==2*i+1 and int(r['end_revision'])==2*i+2
assert len(ids)==len(transactions)==30
prior=read(OUT/'01-audit.json');pinned(prior['reviewer_script']);pinned(prior['stdout']);pinned(prior['stderr']);pr=read(OUT/'01-review.json')
for item in pr['input_facts']:pinned(item)
priorfacts=[fact(p) for p in sorted(OUT.iterdir()) if p.is_file() and (p.name.startswith('01-') or p.name=='snapshot94.py')]
for item in list(INPUTS.values()):pinned(item)
report={'source_commit':HEAD,'source410_sha256':DIGEST,'source65_2830_other_files_byteidentical':True,'only_source65_changes':changed,'six_named_native_PASS':names,'native_artifacts':native,'snapshot_two_PASS':snapshots,'snapshot_jsons':[fact(p) for p in unit+camera+force],'snapshot_sha256':fact(snapshot)['sha256'],'native_platform':u['backend'],'all91_no_QTest_skip':True,'QTest_suite_totals':totals,'tool_lifecycle_real_samples':30,'tool_lifecycle_json':fact(life_path),'each_cancel0_commit1_undo_finalempty':True,'six_CTest_total':378,'independent74_compile_gate_not_CTest':True,'prior_snapshot_unchanged_facts':priorfacts,'input_facts':list(INPUTS.values()),'historical_limits':['Review70 private SyntaxError and GNU-dialect correction receipts remain old review70 facts; no new94 attempt is invented','Old79 fresh-GUI settings assertion failure and source65 Ini isolation limitation remain preserved; source85 audit consumes only new86 actual results'],'limits':['Fixture snapshot consumption and recovery, not new external AI execution','R fixture provenance retained, not actual solver engineering validation','Existing images byte-hashed without new GUI or screenshot generation','Configured SDK pins/static SAN symbols do not establish all loaded images/copy coverage','No staged macOS package smoke/full SK/P0 or separately rerun typed106 supplement acceptance','BP17 this full CTest layout suite uses the same QApplication for window recreation; fresh-process peer evidence is outside review94']}
with (OUT/'02-desktop-addendum.json').open('x') as stream:json.dump(report,stream,indent=2);stream.write('\n')
print(json.dumps({'six_current_CTest':378,'named_native6':6,'snapshot2':2,'native_QSKIP':0,'modeling_tools_QTest':12,'tool_lifecycle_QTest':3,'real_tool_samples':30,'source65_only_five_settings_isolation_changes':changed,'prior_snapshot_unchanged':True,'inputs':len(INPUTS)}))
