#!/usr/bin/env python3
"""Append-only read-only audit receipts; never start builds, tests or QCAE."""
import datetime
import hashlib
import json
import os
import re
import subprocess
import sys
import time
from pathlib import Path

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
PYTHON = Path('/Library/Frameworks/Python.framework/Versions/3.14/bin/python3.14')
HEAD = 'ef0df3bdd8c1b27330d71a596f16098cb6b6410a'
TREE = 'c82b70ca60a606da258a90c0da6502d7d45693f4'
DIGEST = '15d20f20fef88ed6d1b8637b97edf77143887728cb9c42427620b25429e65c03'
SRC = Path('/private/tmp/qcae-framework-preference-fix85')
RUN = Path('/private/tmp/qcae-framework-runtime86')


def fact(path):
    path = Path(path).resolve()
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, ensure_ascii=False)
        stream.write('\n')


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def source_fence(frozen):
    assert frozen['source_root'] == str(SRC)
    assert frozen['commit'] == HEAD and frozen['tree'] == TREE
    assert frozen['source410_sha256'] == DIGEST
    assert len(frozen['source_files']) == 410 and len(frozen['tracked_files']) == 2835
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=SRC, text=True).strip() == HEAD
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=SRC, text=True).strip() == TREE
    assert not subprocess.check_output(['git', 'status', '--porcelain=v1'], cwd=SRC, text=True).strip()
    for name, expected in frozen['tracked_files'].items():
        raw = (SRC / name).read_bytes()
        assert len(raw) == expected['bytes'] and hashlib.sha256(raw).hexdigest() == expected['sha256'], name
    return {'source_root': str(SRC), 'source_commit': HEAD, 'tree': TREE,
            'source410_sha256': DIGEST, 'tracked_file_count': 2835,
            'all_tracked_bytes_match': True, 'clean_HEAD': True}


def command(attempt, number, script, args, prepared):
    copied = attempt / script.name
    with copied.open('xb') as stream:
        stream.write(script.read_bytes())
    assert fact(copied)['sha256'] == fact(script)['sha256']
    argv = [str(PYTHON), str(copied), *args]
    stdout = attempt / (number + '-stdout.log')
    stderr = attempt / (number + '-stderr.log')
    start_utc = utc()
    started = time.monotonic()
    environment = os.environ.copy()
    environment['PYTHONDONTWRITEBYTECODE'] = '1'
    with stdout.open('xb') as out_stream, stderr.open('xb') as err_stream:
        process = subprocess.Popen(argv, cwd=attempt, env=environment,
                                   stdout=out_stream, stderr=err_stream)
        returncode = process.wait()
    receipt = {'reviewer_script': fact(copied), 'template_script': fact(script),
               'argv': argv, 'actual_argv': argv, 'actual_exit_code': returncode,
               'reviewer_parent_pid': os.getpid(), 'actual_pid': process.pid,
               'started_utc': start_utc, 'ended_utc': utc(),
               'elapsed_monotonic_seconds': time.monotonic() - started,
               'stdout': fact(stdout), 'stderr': fact(stderr),
               'explicit_environment': {'PYTHONDONTWRITEBYTECODE': '1'},
               'source_commit': HEAD, 'tree': TREE, 'source410_sha256': DIGEST,
               'prepared': fact(prepared), 'read_only_inspection': True}
    save(attempt / (number + '-audit.json'), receipt)
    return returncode


def main():
    assert len(sys.argv) == 3 and sys.argv[1] == '--root-authorized-terminal-read-only'
    run_id = sys.argv[2]
    assert re.fullmatch(r'matrix94-[0-9]{2}', run_id), run_id
    attempts = OUT / 'attempts'
    attempts.mkdir(exist_ok=True)
    attempt = attempts / run_id
    attempt.mkdir()
    status = 'failed'
    observed_exit = None
    frozen = None
    try:
        prepared_path = OUT / 'prepared.json'
        prepared = json.loads(prepared_path.read_text())
        for item in prepared['immutable_preparation_inputs']:
            assert fact(item['path']) == item, item['path']
        frozen = json.loads((RUN / 'frozen-candidate.json').read_text())
        before = source_fence(frozen)
        save(attempt / 'source-before.json', before)
        observed_exit = command(attempt, '01', OUT / 'snapshot94.py', ['01'], prepared_path)
        if observed_exit != 0:
            raise SystemExit(observed_exit)
        observed_exit = command(attempt, '02', OUT / 'desktop_terminal94.py', [], prepared_path)
        if observed_exit != 0:
            raise SystemExit(observed_exit)
        for item in prepared['immutable_preparation_inputs']:
            assert fact(item['path']) == item, item['path']
        after = source_fence(frozen)
        assert after == before
        save(attempt / 'source-after.json', after)
        status = 'complete'
        save(attempt / 'complete.json', {'status': status, 'source_commit': HEAD,
             'source410_sha256': DIGEST, 'actual_review_exits': [0, 0],
             'main_review': fact(attempt / '01-review.json'),
             'desktop_review': fact(attempt / '02-desktop-addendum.json'),
             'source_before': fact(attempt / 'source-before.json'),
             'source_after': fact(attempt / 'source-after.json'),
             'no_product_build_test_GUI_or_checker_execution': True})
        print(json.dumps({'status': status, 'attempt': str(attempt),
                          'actual_review_exits': [0, 0], 'source_commit': HEAD}))
    finally:
        if status != 'complete':
            error = sys.exc_info()[1]
            failure = {'status': status, 'last_observed_review_exit': observed_exit,
                       'source_commit': HEAD, 'source410_sha256': DIGEST,
                       'error': repr(error),
                       'no_success_claim': True}
            try:
                if frozen is not None:
                    failure['source_after_failure'] = source_fence(frozen)
            except Exception as error:
                failure['source_after_failure_error'] = repr(error)
            save(attempt / 'failure.json', failure)


if __name__ == '__main__':
    main()
