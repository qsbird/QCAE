#!/usr/bin/env python3
"""Read terminal root receipts; git/nm inspect bytes, never execute QCAE/checkers/tests."""
import hashlib, json, re, shlex, subprocess, sys, time
from pathlib import Path
sys.dont_write_bytecode = True
OUT=Path(__file__).resolve().parent
RUN=Path('/private/tmp/qcae-framework-runtime86')
BUILD=Path('/private/tmp/qcae-framework86-builds')
HEAD='ef0df3bdd8c1b27330d71a596f16098cb6b6410a'
DIGEST='15d20f20fef88ed6d1b8637b97edf77143887728cb9c42427620b25429e65c03'
TREE='c82b70ca60a606da258a90c0da6502d7d45693f4'
EXPECTED_SOURCE=Path('/private/tmp/qcae-framework-preference-fix85')
EXPECTED_COUNTS={'core':40,'sqlite_headless':47,'asan_ubsan':47,'asan_ipc':80,'package_disabled':73,'desktop':91}
MATRICES=['core','sqlite_headless','asan_ubsan','asan_ipc','package_disabled','desktop','public_consumers']
FOUR={'result_fixture_ipc':120.,'solver_run_ipc':120.,'c2_workflow':180.,'batch_translation_ipc':90.}
INPUTS={}
SEQ=sys.argv[1]
assert SEQ.isdecimal()
def fact(p):
 p=Path(p).resolve();h=hashlib.sha256()
 with p.open('rb') as f:
  for chunk in iter(lambda:f.read(1048576),b''):h.update(chunk)
 v={'path':str(p),'bytes':p.stat().st_size,'sha256':h.hexdigest()}
 INPUTS[str(p)]=v;return v
def read(p):fact(p);return json.loads(Path(p).read_text())
def pinned(v):assert fact(v['path'])==v,v['path']
def save(n,v):
 p=OUT/n
 with p.open('x') as f:json.dump(v,f,indent=2,ensure_ascii=False);f.write('\n')
def bind(d):assert d['source_commit']==HEAD and d['source410_sha256']==DIGEST
frozen=read(RUN/'frozen-candidate.json');prepared=read(RUN/'prepared.json');baseline=read('/private/tmp/qcae-sk-final-runner41/final-config44.json')['baseline_regressions']
SRC=Path(frozen['source_root']);assert frozen['commit']==HEAD and frozen['source410_sha256']==DIGEST
assert SRC==EXPECTED_SOURCE and frozen['tree']==TREE
for key in MATRICES:
 terminal=RUN/(('public-consumers74-compile-complete' if key=='public_consumers' else 'full-regression-'+key+'-complete')+'.json')
 assert terminal.is_file(), 'All seven actual terminal receipts required before review: '+key
pinned(prepared['frozen_source']);assert len(frozen['tracked_files'])==2835 and len(frozen['source_files'])==410
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=SRC,text=True).strip()==HEAD
assert subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=SRC,text=True).strip()==frozen['tree']
assert not subprocess.check_output(['git','status','--porcelain=v1'],cwd=SRC,text=True).strip()
modes={}
for entry in subprocess.check_output(['git','ls-files','--stage','-z'],cwd=SRC).split(b'\0'):
 if entry:
  prefix,name=entry.split(b'\t',1);mode,oid,stage=prefix.split();assert stage==b'0';modes[name.decode()]=mode
h=hashlib.sha256(b'QCAE-C4-SOURCE-SHA256-v1\0')
for name in sorted(frozen['source_files']):
 raw=(SRC/name).read_bytes();s=hashlib.sha256(raw);assert s.hexdigest()==frozen['source_files'][name]
 enc=name.encode();h.update(len(enc).to_bytes(8,'big'));h.update(enc);h.update(modes[name]);h.update(s.digest())
assert h.hexdigest()==DIGEST
for n,v in frozen['tracked_files'].items():
 raw=(SRC/n).read_bytes();assert len(raw)==v['bytes'] and hashlib.sha256(raw).hexdigest()==v['sha256'],n
for p in prepared['configured_tool_and_sdk_pins']:pinned(p)
assert '-fno-sanitize=all' in (SRC/'adapters/engine_api/CMakeLists.txt').read_text()
old80=read('/private/tmp/qcae-headless-permission03-review46/terminal-failure-audit.json')['actual_inventory_names']
result=[]
for key in MATRICES:
 complete=RUN/(('public-consumers74-compile-complete' if key=='public_consumers' else 'full-regression-'+key+'-complete')+'.json')
 if not complete.exists():
  stages={}
  for action in ('configure','build','inventory'):
   p=RUN/(action+'-'+key+'.json')
   if p.exists():d=read(p);bind(d);stages[action]=d['actual_exit_code']
   else:stages[action]='pending'
  result.append({'matrix':key,'status':'pending','stages':stages});continue
 d=read(complete);bind(d)
 if key!='public_consumers':assert d['count']==EXPECTED_COUNTS[key]
 config=read(RUN/('configure-'+key+'.json'));build=read(RUN/('build-'+key+'.json'));inv=read(RUN/('inventory-'+key+'.json'))
 for command in (config,build,inv):
  bind(command);assert command['actual_exit_code']==0
  for field in ('stdout','stderr','runner'):pinned(command[field])
 pins=read(RUN/('build-'+key+'-pins.json'));bind(pins)
 for item in [*pins['binaries'],pins['cache'],pins['compile_commands'],pins['architecture_trace']]:pinned(item)
 cache={}
 for line in Path(pins['cache']['path']).read_text().splitlines():
  m=re.match(r'([^:#=]+):[^=]+=(.*)',line)
  if m:cache[m[1]]=m[2]
 options=('QCAE_BUILD_IPC','QCAE_BUILD_STORAGE','QCAE_BUILD_DESKTOP','QCAE_ENABLE_SANITIZERS','QCAE_ENABLE_NASTRAN_PACKAGE','CMAKE_BUILD_TYPE')
 assert [cache[k] for k in options]==prepared['matrix_flags'][key]
 assert cache['CMAKE_HOME_DIRECTORY']==str(SRC/('tests/public_api_consumers' if key=='public_consumers' else ''))
 assert cache['Python3_EXECUTABLE']=='/Library/Frameworks/Python.framework/Versions/3.14/bin/python3.14'
 compiles=read(pins['compile_commands']['path']);instrumented=[];optout=[];generated=[]
 for entry in compiles:
  tokens=shlex.split(entry['command']);assert '-std=c++20' in tokens or (key=='public_consumers' and '-std=gnu++20' in tokens)
  source=Path(entry['file']).resolve()
  if source.is_relative_to(SRC):assert hashlib.sha256(source.read_bytes()).hexdigest()==frozen['source_files'][str(source.relative_to(SRC))]
  else:assert source.is_relative_to(BUILD/key);generated.append(str(source))
  if key in ('asan_ubsan','asan_ipc'):
   assert '-fsanitize=address,undefined' in tokens
   if '-fno-sanitize=all' in tokens:
    assert key=='asan_ipc' and source==SRC/'tests/solver_version_fixture.cpp'
    assert tokens.index('-fno-sanitize=all')>tokens.index('-fsanitize=address,undefined');optout.append(str(source))
   else:instrumented.append(str(source))
 warnings=re.findall(r'(?m)^.*\bwarning:.*$',Path(build['stdout']['path']).read_text()+Path(build['stderr']['path']).read_text())
 assert not warnings,warnings
 inventory=read(RUN/('inventory-'+key+'.stdout.log'))['tests'];names=sorted(t['name'] for t in inventory);assert len(names)==len(set(names))
 inventoryaudit=read(RUN/('inventory-'+key+'-audit.json'));assert inventoryaudit['current_applicable_names']==names
 if key=='public_consumers':
  assert not names and d['consumer_count']==74 and len(pins['binaries'])==74 and d['actual_build_exit_code']==0
  for image in d['consumer_binaries']:pinned(image)
  pinned(d['count_file']);assert Path(d['count_file']['path']).read_text().strip()=='74'
  result.append({'matrix':key,'status':'compile_gate_complete','compile_link_consumers':74,'CTest_registered':0,'compile_entries':len(compiles),'compiler_warnings':0,'consumer_dialect':'GNU C++20; product dependencies strict C++20'});continue
 assert set(baseline[key])<=set(names)
 if key=='asan_ipc':
  assert set(names)==set(old80) and len(compiles)==115 and len(optout)==1 and len(instrumented)==114
  for n,t in FOUR.items():assert next(x['value'] for x in next(y for y in inventory if y['name']==n)['properties'] if x['name']=='TIMEOUT')==t
 receipt=read(RUN/('full-regression-'+key+'.json'));scope=read(RUN/('full-regression-'+key+'-scope.json'))
 bind(receipt);assert receipt['actual_exit_code']==scope['actual_exit_code']==d['actual_exit_code']==0
 for field in ('stdout','stderr','runner'):pinned(receipt[field])
 for diag in scope['diagnostics']:pinned(diag)
 pinned(d['raw_log']);raw=Path(d['raw_log']['path']).read_text(errors='replace');stdout=Path(receipt['stdout']['path']).read_text()
 assert receipt['argv'][:4]==['/usr/bin/caffeinate','-i','/usr/bin/env','QT_QPA_PLATFORM=']
 assert receipt['argv'][-6:]==['/opt/homebrew/Cellar/cmake/4.3.0/bin/ctest','--test-dir',str(BUILD/key),'--output-on-failure','-j','1']
 assert receipt['explicit_environment']['QCAE_SOURCE_TREE_SHA256']==DIGEST
 if key in ('asan_ubsan','asan_ipc'):
  assert receipt['explicit_environment']['ASAN_OPTIONS']=='detect_leaks=0:halt_on_error=1'
  assert receipt['explicit_environment']['UBSAN_OPTIONS']=='halt_on_error=1:print_stacktrace=1'
 matches=list(re.finditer(r'^\d+/\d+ Testing: (\S+)\n.*?(?=^\d+/\d+ Testing:|\Z)',raw,re.M|re.S))
 actual=sorted(m[1] for m in matches);assert actual==names==d['executed_names'];assert len(matches)==d['count']
 assert raw.count('Test Passed.')==len(names) and 'Test Failed.' not in raw and not re.search(r'(?m)^SKIP\s*:',raw)
 assert not any(x in raw for x in ('ERROR: AddressSanitizer','SUMMARY: AddressSanitizer','runtime error:','UndefinedBehaviorSanitizer:'))
 assert '100% tests passed, 0 tests failed out of '+str(len(names)) in stdout
 seconds=float(re.search(r'Total Test time \(real\) =\s*([\d.]+) sec',stdout)[1])
 arch=read(RUN/'matrix-sequence86'/('architecture-'+key+'.json'));report=read(RUN/'matrix-sequence86'/('architecture-'+key+'-report.json'))
 assert arch['actual_exit_code']==0 and not report['errors']
 four=[]
 for match in matches:
  assert 'Test Passed.' in match[0]
  if key=='asan_ipc' and match[1] in FOUR:
   elapsed=float(re.search(r'Test time =\s*([\d.]+) sec',match[0])[1]);assert elapsed<FOUR[match[1]]
   four.append({'name':match[1],'seconds':elapsed,'timeout':FOUR[match[1]]})
 symbols=[]
 if key in ('asan_ubsan','asan_ipc'):
  nmargv=['/usr/bin/nm','-u',*[x['path'] for x in pins['binaries']]];started=time.monotonic()
  nm=subprocess.run(nmargv,capture_output=True,check=False)
  nmo=OUT/(SEQ+'-nm-'+key+'.stdout.log');nme=OUT/(SEQ+'-nm-'+key+'.stderr.log')
  with nmo.open('xb') as f:f.write(nm.stdout)
  with nme.open('xb') as f:f.write(nm.stderr)
  save(SEQ+'-nm-'+key+'.json',{'argv':nmargv,'actual_exit_code':nm.returncode,'elapsed_monotonic_seconds':time.monotonic()-started,'stdout':fact(nmo),'stderr':fact(nme),'static_inspection_only':True});assert nm.returncode==0
  text=nm.stdout.decode()
  for image in pins['binaries']:
   m=re.search(r'^'+re.escape(image['path'])+r':\n(.*?)(?=\n/[^\n]+:\n|\Z)',text,re.M|re.S);assert m,image['path']
   flags={'asan':bool(re.search(r'___asan_',m[1])),'ubsan':bool(re.search(r'___ubsan_',m[1]))}
   if Path(image['path']).name=='qcae_solver_version_fixture':assert flags=={'asan':False,'ubsan':False}
   else:assert all(flags.values()),image['path']
   symbols.append({'binary':Path(image['path']).name,**flags})
 result.append({'matrix':key,'status':'complete','actual_exit_code':0,'applicable_names':names,'R0_required':baseline[key],'R0_missing':[],'R0_additions':sorted(set(names)-set(baseline[key])),'raw_passed':len(names),'CTest_seconds':seconds,'receipt_seconds':receipt['elapsed_seconds'],'raw_log':d['raw_log'],'binaries':len(pins['binaries']),'compiler_warnings':len(warnings),'compile_entries':len(compiles),'san_instrumented_entries':len(instrumented),'san_optout_entries':optout,'binary_SAN_symbols':symbols,'original_four':four})
# Recheck immutable inputs read in this snapshot and the entire actual source.
inputs=list(INPUTS.values())
for item in inputs:pinned(item)
for n,v in frozen['tracked_files'].items():
 raw=(SRC/n).read_bytes();assert len(raw)==v['bytes'] and hashlib.sha256(raw).hexdigest()==v['sha256'],n
save(SEQ+'-review.json',{'review_kind':'final append-only independent read-only snapshot; all seven root matrices terminal','snapshot_unix':time.time(),'source_commit':HEAD,'tree':frozen['tree'],'source410_sha256':DIGEST,'source410_count':410,'tracked_source_fence_before_after':2835,'matrices':result,'input_facts':inputs,'limits':['No QCAE/checker/test/compiler/native/GUI executions by reviewer','nm symbols and configured SDK bytes do not prove runtime loaded SDK images','detect_leaks=0; no LSan coverage claim','74 independent consumers are compile/link gate; zero CTest registration','Old source68/source65/source62/source44 PASS never imported','Package staging/smoke, any separately rerun exact AP typed106 supplement and complete SK/P0/solver/AI/performance acceptance outside this audit']})
print(json.dumps({'snapshot':SEQ,'source_commit':HEAD,'source410_sha256':DIGEST,'matrices':[{k:r[k] for k in ('matrix','status','actual_exit_code','raw_passed','CTest_seconds','compile_entries','compiler_warnings') if k in r} for r in result],'input_facts':len(inputs),'all_inputs_and_2835_source_before_after_match':True},ensure_ascii=False))
