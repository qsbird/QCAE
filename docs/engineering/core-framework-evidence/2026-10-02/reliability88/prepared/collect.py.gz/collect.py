#!/usr/bin/env python3
"""Append-only reliability collection; root schedules execution after all68 gates."""
from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import json
import os
from pathlib import Path
import re
import selectors
import subprocess
import sys
import time

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
RUNTIME = Path('/private/tmp/qcae-framework-runtime86')
ROOT = Path('/private/tmp/qcae-framework-preference-fix85')
BUILDS = Path('/private/tmp/qcae-framework86-builds')
COMMIT = 'ef0df3bdd8c1b27330d71a596f16098cb6b6410a'
TREE = '15d20f20fef88ed6d1b8637b97edf77143887728cb9c42427620b25429e65c03'
PYTHON = '/Library/Frameworks/Python.framework/Versions/3.14/bin/python3.14'
PYTHON_BIN = '/Library/Frameworks/Python.framework/Versions/3.14/bin'
KEYS = ('core', 'sqlite_headless', 'asan_ubsan', 'asan_ipc', 'package_disabled', 'desktop')
OPTIONS = ('QCAE_BUILD_IPC', 'QCAE_BUILD_STORAGE', 'QCAE_BUILD_DESKTOP',
           'QCAE_ENABLE_SANITIZERS', 'QCAE_ENABLE_NASTRAN_PACKAGE', 'CMAKE_BUILD_TYPE')
SOURCE_ROOTS = ('CMakeLists.txt', '.clang-format', 'cmake', 'modules', 'features',
                'adapters', 'apps', 'ui', 'profiles', 'schemas', 'tests', 'tools')
FATAL = {'ASAN_OPTIONS': 'detect_leaks=0:halt_on_error=1',
         'UBSAN_OPTIONS': 'halt_on_error=1:print_stacktrace=1'}
BAD_SANITIZER = ('ERROR: AddressSanitizer', 'SUMMARY: AddressSanitizer',
                 'runtime error:', 'UndefinedBehaviorSanitizer:')
STAGES = {'M_baseline', 'selection_applied', 'selection_undone', 'repaired_M',
          'normal_open_M', 'recovered_M', 'published_M', 'stale_result_input_M'}


class Blocked(RuntimeError):
    """A prerequisite is missing or drifted; no fabricated test outcome."""


def require(value, message):
    if not value:
        raise Blocked(message)


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            digest.update(block)
    return digest.hexdigest()


def fact(path):
    path = Path(path).resolve()
    require(path.is_file(), 'Required file absent: ' + str(path))
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': sha(path)}


def read(path):
    require(Path(path).is_file(), 'Prerequisite not yet available: ' + str(path))
    return json.loads(Path(path).read_text())


def write(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def cache_values(path):
    values = {}
    for line in Path(path).read_text().splitlines():
        if line and not line.startswith(('#', '//')) and ':' in line and '=' in line:
            name, rest = line.split(':', 1)
            values[name] = rest.split('=', 1)[1]
    return values


def verify_fact(item):
    require(fact(item['path']) == item, 'Input byte drift: ' + item['path'])


def source_guard(frozen):
    require(frozen['commit'] == COMMIT and frozen['source_root'] == str(ROOT) and
            frozen['source410_sha256'] == TREE and frozen['clean'] is True,
            'Final frozen source identity changed')
    require(len(frozen['tracked_files']) == 2835 and len(frozen['source_files']) == 410,
            'Final tracked/source denominators changed')
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
    require(head == COMMIT, 'Current HEAD differs from final68')
    require(not subprocess.check_output(['git', 'status', '--porcelain=v1'], cwd=ROOT,
                                        text=True).strip(), 'Final source is not clean')
    for name, expected in frozen['tracked_files'].items():
        path = ROOT / name
        require(not path.is_symlink() and path.is_file(), 'Missing/replaced tracked path: ' + name)
        require(path.stat().st_size == expected['bytes'] and sha(path) == expected['sha256'],
                'Tracked file drift: ' + name)
    entries = []
    data = subprocess.check_output(['git', 'ls-tree', '-rz', COMMIT, '--', *SOURCE_ROOTS], cwd=ROOT)
    for raw in data.split(b'\0'):
        if raw:
            left, name = raw.split(b'\t', 1)
            mode, kind, _ = left.decode().split()
            require(kind == 'blob' and mode in ('100644', '100755'), 'Source mode/type changed')
            entries.append((name, mode))
    digest = hashlib.sha256(b'QCAE-C4-SOURCE-SHA256-v1\0')
    require(len(entries) == 410, 'Actual source inventory differs')
    for name, mode in sorted(entries):
        digest.update(len(name).to_bytes(8, 'big') + name + mode.encode())
        digest.update(bytes.fromhex(sha(ROOT / name.decode())))
    require(digest.hexdigest() == TREE, 'Actual410 digest differs')


def guard():
    """Read every prerequisite. Never invoke run68 or any compiler/test from a guard."""
    prep = read(HERE / 'prepared-final-inputs.json')
    for item in prep['fixed_inputs']:
        verify_fact(item)
    require(fact(__file__) == prep['collector'], 'Collector differs from reviewed preparation')
    frozen = read(RUNTIME / 'frozen-candidate.json')
    source_guard(frozen)
    prepared = read(RUNTIME / 'prepared.json')
    require(prepared['source_commit'] == COMMIT and prepared['source410_sha256'] == TREE,
            'run68 preparation source differs')
    require(prepared['matrix_flags'] == prep['matrix_flags'], 'Current matrix flags differ')
    require(prepared['configured_tool_and_sdk_pins'] == prep['configured_tool_and_sdk_pins'],
            'Prepared SDK/tool manifest differs')
    inputs = list(prep['fixed_inputs']) + [prep['collector']]
    for item in prepared['configured_tool_and_sdk_pins']:
        verify_fact(item)
        inputs.append(item)
    matrix_details = {}
    for key in (*KEYS, 'public_consumers'):
        cfg_path = RUNTIME / ('configure-' + key + '.json')
        build_path = RUNTIME / ('build-' + key + '.json')
        pins_path = RUNTIME / ('build-' + key + '-pins.json')
        inv_path = RUNTIME / ('inventory-' + key + '.json')
        audit_path = RUNTIME / ('inventory-' + key + '-audit.json')
        cfg, build, pins, inventory, audit = map(read, (cfg_path, build_path, pins_path, inv_path, audit_path))
        for receipt in (cfg, build, inventory):
            require(receipt['actual_exit_code'] == 0 and receipt['source_commit'] == COMMIT and
                    receipt['source410_sha256'] == TREE, 'Nonzero/wrong-source ' + key + ' gate')
            require(receipt['cwd'] == str(ROOT), 'Gate source cwd differs: ' + key)
            for field in ('stdout', 'stderr', 'runner'):
                verify_fact(receipt[field])
                inputs.append(receipt[field])
        require(pins['source_commit'] == COMMIT and pins['source410_sha256'] == TREE and
                pins['actual_fresh_clean_build'] is True, 'Wrong source/build provenance: ' + key)
        artifacts = [*pins['binaries'], pins['cache'], pins['compile_commands'], pins['architecture_trace']]
        require(artifacts and pins['binaries'], 'No current binary seal: ' + key)
        for item in artifacts:
            verify_fact(item)
            inputs.append(item)
        cache = cache_values(pins['cache']['path'])
        expected = dict(zip(OPTIONS, prep['matrix_flags'][key]))
        for option, value in expected.items():
            require(cache.get(option) == value, key + ' current flag differs: ' + option)
        require(cache.get('CMAKE_CXX_COMPILER') == '/Library/Developer/CommandLineTools/usr/bin/c++'
                and cache.get('Python3_EXECUTABLE') == PYTHON,
                'Compiler/Python selection drift: ' + key)
        top_level = ROOT / 'tests/public_api_consumers' if key == 'public_consumers' else ROOT
        require(cache.get('CMAKE_HOME_DIRECTORY') == str(top_level), 'CMake top-level source differs: ' + key)
        require(cache.get('QCAE_BUILD_SOLVER_LOCAL') == 'ON', 'Local fixture applicability changed')
        if expected['QCAE_BUILD_STORAGE'] == 'ON':
            require(cache.get('SQLite3_LIBRARY') == '/opt/homebrew/Cellar/sqlite/3.53.4/lib/libsqlite3.3.53.4.dylib'
                    and cache.get('SQLite3_INCLUDE_DIR') == '/opt/homebrew/Cellar/sqlite/3.53.4/include',
                    'SQLite configuration drift: ' + key)
        if expected['QCAE_BUILD_IPC'] == 'ON':
            require(cache.get('Qt6_DIR') == '/opt/homebrew/Cellar/qtbase/6.11.1/lib/cmake/Qt6',
                    'Qt configuration drift: ' + key)
        if expected['QCAE_BUILD_DESKTOP'] == 'ON':
            require(cache.get('VTK_DIR') == '/Users/qs/Documents/ChatGPT/QCAE/build-vtk-deps/install/lib/cmake/vtk-9.7',
                    'VTK configuration drift: ' + key)
        compilation = read(pins['compile_commands']['path'])
        if expected['QCAE_ENABLE_SANITIZERS'] == 'ON':
            for entry in compilation:
                argv = entry.get('command', ' '.join(entry.get('arguments', [])))
                require('-fsanitize=address,undefined' in argv, 'Missing ASan/UBSan: ' + entry['file'])
                require('-fno-sanitize' not in argv or Path(entry['file']).name == 'solver_version_fixture.cpp',
                        'Unapproved sanitizer exception: ' + entry['file'])
            if key == 'asan_ipc':
                client = [r for r in compilation if Path(r['file']).name == 'skeleton_fault_client_tests.cpp']
                require(client and all('-fno-sanitize' not in r.get('command', ' '.join(r.get('arguments', [])))
                                       for r in client), 'Sanitized client got a fixture exemption')
        raw_inventory = read(inventory['stdout']['path'])['tests']
        names = sorted(test['name'] for test in raw_inventory)
        require(names == audit['current_applicable_names'], 'Current inventory/audit differs: ' + key)
        for path in (cfg_path, build_path, pins_path, inv_path, audit_path):
            inputs.append(fact(path))
        if key == 'public_consumers':
            compile_path = RUNTIME / 'public-consumers74-compile-complete.json'
            compile_gate = read(compile_path)
            require(compile_gate['actual_build_exit_code'] == 0 and compile_gate['consumer_count'] == 74 and
                    compile_gate['source_commit'] == COMMIT and compile_gate['source410_sha256'] == TREE,
                    'Independent74 compile gate absent/failed/wrong source')
            require(compile_gate['independent_top_level_source'] == str(top_level),
                    'The74 compile gate is not the independent public consumer top level')
            require(not names and audit['count'] == 0 and audit['independent_compiled_consumer_count'] == 74,
                    'Independent consumers are compile74, registered CTest0')
            require(len(pins['binaries']) == 74 and len(compile_gate['consumer_binaries']) == 74,
                    'Consumer binary denominator differs')
            for item in (*compile_gate['consumer_binaries'], compile_gate['count_file']):
                verify_fact(item)
                inputs.append(item)
            require(Path(compile_gate['count_file']['path']).read_text().strip() == '74',
                    'Actual compiled count file differs')
            inputs.append(fact(compile_path))
        else:
            complete_path = RUNTIME / ('full-regression-' + key + '-complete.json')
            scope_path = RUNTIME / ('full-regression-' + key + '-scope.json')
            run_path = RUNTIME / ('full-regression-' + key + '.json')
            complete, scope, run = map(read, (complete_path, scope_path, run_path))
            require(complete['actual_exit_code'] == run['actual_exit_code'] == scope['actual_exit_code'] == 0,
                    'Full regression did not pass: ' + key)
            require(complete['source_commit'] == run['source_commit'] == COMMIT and
                    complete['source410_sha256'] == run['source410_sha256'] == TREE,
                    'Full regression source differs: ' + key)
            require(complete['executed_names'] == names and complete['count'] == len(names) and names,
                    'Full regression is not the applicable inventory: ' + key)
            require(scope['full_inventory'] is True and scope['source_and_build_fences_verified'] is True,
                    'Full regression fence missing: ' + key)
            require(run['explicit_environment'].get('QCAE_SOURCE_TREE_SHA256') == TREE,
                    'Full regression source environment differs: ' + key)
            for item in [complete['raw_log'], *scope['diagnostics'], run['stdout'], run['stderr'], run['runner']]:
                verify_fact(item)
                inputs.append(item)
            log = Path(complete['raw_log']['path']).read_text(errors='replace')
            require(sorted(set(re.findall(r'(?m)^\d+/\d+ Testing: (.+)$', log))) == names,
                    'Actual full log names differ: ' + key)
            require('Test Failed.' not in log and not re.search(r'(?m)^\s*SKIP\s*:', log) and
                    not re.search(r'\b[1-9]\d* skipped\b', log) and
                    not any(marker in log for marker in BAD_SANITIZER), 'Full failed/skipped/diagnostic log: ' + key)
            if expected['QCAE_ENABLE_SANITIZERS'] == 'ON':
                require(all(run['explicit_environment'].get(k) == v for k, v in FATAL.items()),
                        'Full sanitizer environment differs: ' + key)
            for path in (complete_path, scope_path, run_path):
                inputs.append(fact(path))
            matrix_details[key] = {'count': len(names), 'complete': fact(complete_path),
                                   'raw_log': complete['raw_log']}
            if key == 'desktop':
                native = [row for row in raw_inventory if row['name'] == 'c3_desktop_workflow']
                require(len(native) == 1, 'Full native workflow producer is not uniquely registered')
                native_command = native[0].get('command', [])
                expected_native_command = [str(BUILDS / 'desktop/qcae_c3_desktop_workflow_tests'),
                                           str(BUILDS / 'desktop/qcae-engine'),
                                           str(BUILDS / 'desktop/c3-evidence/desktop')]
                require(native_command == expected_native_command,
                        'Full native workflow registered executable/engine/evidence argv differs')
                sealed_binary_paths = {item['path'] for item in pins['binaries']}
                require(all(path in sealed_binary_paths for path in native_command[:2]),
                        'Native registered executable/engine are not current sealed binaries')
                properties = {item['name']: item['value'] for item in native[0].get('properties', [])}
                require(properties.get('RUN_SERIAL') is True and properties.get('TIMEOUT') == 600 and
                        properties.get('WORKING_DIRECTORY') == str(BUILDS / 'desktop'),
                        'Full native registered serial/timeout/working-directory contract differs')
                native_dir = Path(native_command[2])
                require(native_dir == BUILDS / 'desktop/c3-evidence/desktop', 'Native producer path differs')
                matrix_details[key]['native_evidence_dir'] = str(native_dir)
                matrix_details[key]['actual_run_window'] = {
                    'started_unix': run['started_unix'], 'finished_unix': run['finished_unix']}
        # Architecture checks are queued before each full production regression.
        if key != 'public_consumers':
            arch_path = RUNTIME / 'matrix-sequence86' / ('architecture-' + key + '.json')
            report_path = RUNTIME / 'matrix-sequence86' / ('architecture-' + key + '-report.json')
            arch, report = read(arch_path), read(report_path)
            require(arch['actual_exit_code'] == 0 and report['status'] == 'passed' and not report['errors']
                    and report['source'] == str(ROOT) and report['build'] == str(BUILDS / key),
                    'Current architecture gate absent/failed: ' + key)
            inputs.extend((fact(arch_path), fact(report_path)))
    unique = {item['path']: item for item in inputs}
    return {'source_commit': COMMIT, 'source410_sha256': TREE, 'tracked_files_verified': 2835,
            'source_files_verified': 410, 'six_full': matrix_details,
            'independent_compile_gate': {'count': 74, 'CTest_registered_count': 0},
            'inputs': [unique[path] for path in sorted(unique)]}


def environment(sanitized=False):
    inherited = os.environ.copy()
    removed = sorted(k for k in inherited if k.startswith(('DYLD_', 'LD_', 'QT_', 'QCAE_')) or
                     k in ('PYTHONPATH', 'PYTHONHOME', 'ASAN_OPTIONS', 'UBSAN_OPTIONS'))
    for key in removed:
        inherited.pop(key)
    explicit = {'PYTHONDONTWRITEBYTECODE': '1', 'QCAE_SOURCE_TREE_SHA256': TREE,
                'QT_QPA_PLATFORM': '', 'PATH': PYTHON_BIN + ':' + inherited.get('PATH', '')}
    if sanitized:
        explicit.update(FATAL)
    inherited.update(explicit)
    return inherited, explicit, removed


def files_under(paths):
    result = {}
    for path in paths:
        path = Path(path)
        candidates = [path] if path.is_file() else sorted(path.rglob('*')) if path.is_dir() else []
        for candidate in candidates:
            if candidate.is_file():
                item = fact(candidate)
                result[item['path']] = item
    return [result[path] for path in sorted(result)]


def command(attempt, name, argv, outputs, sanitized=False, extra_inputs=()):
    before = guard()
    for item in extra_inputs:
        verify_fact(item)
    require(all(not Path(path).exists() for path in outputs), 'Output already exists: ' + name)
    write(attempt / 'commands' / (name + '.inputs-before.json'), before)
    logs = attempt / 'logs'
    paths = {stream: logs / (name + '.' + stream + '.log') for stream in ('stdout', 'stderr', 'combined')}
    env, explicit, removed = environment(sanitized)
    started, monotonic = time.time(), time.monotonic()
    pid, code, error = None, None, None
    with paths['stdout'].open('xb') as stdout, paths['stderr'].open('xb') as stderr, paths['combined'].open('xb') as combined:
        process = None
        try:
            process = subprocess.Popen(argv, cwd=ROOT, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            pid = process.pid
            write(attempt / 'commands' / (name + '.started.json'), {
                'id': name, 'actual_argv': argv, 'pid': pid, 'started_unix': started,
                'cwd': str(ROOT), 'explicit_environment': explicit, 'source_commit': COMMIT,
                'source410_sha256': TREE})
            with selectors.DefaultSelector() as selector:
                selector.register(process.stdout, selectors.EVENT_READ, stdout)
                selector.register(process.stderr, selectors.EVENT_READ, stderr)
                while selector.get_map():
                    for key, _ in selector.select():
                        data = os.read(key.fileobj.fileno(), 65536)
                        if not data:
                            selector.unregister(key.fileobj)
                            key.fileobj.close()
                        else:
                            key.data.write(data)
                            combined.write(data)
            code = process.wait()
        except BaseException as failure:
            error = repr(failure)
            if process is not None:
                process.terminate()
                code = process.wait()
    finished = time.time()
    # Always persist actual process/error/raw-output facts before postconditions or nonzero stop.
    receipt = {'id': name, 'actual_argv': argv, 'cwd': str(ROOT), 'explicit_environment': explicit,
               'removed_environment_variable_names': removed, 'pid': pid,
               'started_unix': started, 'finished_unix': finished,
               'elapsed_seconds': finished - started, 'elapsed_monotonic_seconds': time.monotonic() - monotonic,
               'actual_exit_code': code, 'recorder_error': error,
               'stdout': fact(paths['stdout']), 'stderr': fact(paths['stderr']),
               'validator_combined_actual_log': fact(paths['combined']),
               'combined_log_order': 'Raw bytes tee in observed pipe-read order; no fabricated diagnostics or child-write-order guarantee',
               'source_commit': COMMIT, 'source410_sha256': TREE, 'collector': fact(__file__),
               'input_guard_before': fact(attempt / 'commands' / (name + '.inputs-before.json')),
               'extra_input_facts': list(extra_inputs), 'emitted_artifacts': files_under(outputs),
               'timeout_policy': 'No wrapper timeout/threshold introduced; existing producer deadlines unchanged',
               'sleep_timing_scope': 'Actual elapsed retained without subtraction; no performance claim'}
    write(attempt / 'commands' / (name + '.json'), receipt)
    after = guard()
    write(attempt / 'commands' / (name + '.inputs-after.json'), after)
    require(before == after, 'Source/build/SDK/receipt input drift during ' + name)
    for item in extra_inputs:
        verify_fact(item)
    write(attempt / 'commands' / (name + '.postconditions.json'), {'all_before_after_match': True})
    if code != 0 or error is not None:
        raise RuntimeError('Actual command failed; receipt preserved: ' + name)
    return receipt


def records(path):
    return [json.loads(line) for line in Path(path).read_text().splitlines() if line.strip()]


def fault_population(path, expected):
    rows = records(path)
    require(Counter(row.get('case_id') for row in rows) == Counter(expected), 'Fault population differs: ' + str(path))
    require(all(row.get('source_tree_sha256') == TREE and row.get('passed') is True and
                row.get('run_id') and row.get('input') and row.get('actual') and row.get('assertions')
                for row in rows), 'Fault raw records incomplete/failed/wrong source')
    require(len({row['run_id'] for row in rows}) == len(rows), 'Duplicate actual fault run_id')
    return rows


def collect(attempt):
    faults, workflow = attempt / 'faults', attempt / 'workflow'
    faults.mkdir()
    workflow.mkdir()
    app, client, sanitized = (faults / name for name in ('application.jsonl', 'client.jsonl', 'sanitizer-client.jsonl'))
    command(attempt, 'fault-application', [str(BUILDS / 'sqlite_headless/qcae_skeleton_fault_tests'), str(app), TREE], [app])
    app_expected = {f'F{index:02}': 10 for index in range(1, 22) if index not in (5, 16, 17)}
    fault_population(app, app_expected)
    command(attempt, 'fault-client', [str(BUILDS / 'desktop/qcae_skeleton_fault_client_tests'), str(client), TREE], [client])
    fault_population(client, {'F16': 10, 'F17': 10})
    wire = faults / 'ipc'
    command(attempt, 'fault-wire-result', [PYTHON, '-B', str(ROOT / 'tests/skeleton_fault_ipc_tests.py'),
            '--engine', str(BUILDS / 'desktop/qcae-engine'), '--cli', str(BUILDS / 'desktop/qcae-cli'),
            '--evidence-dir', str(wire), '--source-tree-sha256', TREE], [wire])
    result_records = wire / 'result-faults.jsonl'
    fault_population(result_records, {'F05': 10, 'F22': 10})
    asan = command(attempt, 'fault-sanitized-client', [str(BUILDS / 'asan_ipc/qcae_skeleton_fault_client_tests'),
                   str(sanitized), TREE], [sanitized], sanitized=True)
    instrumented = fault_population(sanitized, {'F16': 10, 'F17': 10})
    f17 = [row for row in instrumented if row['case_id'] == 'F17']
    require(len(f17) == 10 and all(row['actual'].get('asan_instrumented') is True and
                                  row['actual'].get('ubsan_instrumented') is True for row in f17),
            'F17 actual dual instrumentation not proved')
    validated = faults / 'validated.json'
    input_facts = [fact(path) for path in (app, client, result_records, sanitized,
                                         asan['validator_combined_actual_log']['path'])]
    command(attempt, 'fault-validation', [PYTHON, '-B', str(ROOT / 'tests/skeleton_fault_report.py'),
            '--application', str(app), '--client', str(client), '--results', str(result_records),
            '--sanitizer-client', str(sanitized), '--sanitizer-log', asan['validator_combined_actual_log']['path'],
            '--source-tree-sha256', TREE, '--output', str(validated)], [validated], extra_inputs=input_facts)
    report = read(validated)
    require(report['passed'] is True and report['runs'] == 220 and report['sanitizer']['verified'] is True and
            report['sanitizer']['runs'] == 10 and not report['errors'], 'Fault aggregate validator is not complete')
    cli = workflow / 'cli'
    command(attempt, 'workflow-cli', [PYTHON, '-B', str(ROOT / 'tests/skeleton_workflow_ipc_tests.py'),
            '--engine', str(BUILDS / 'desktop/qcae-engine'), '--cli', str(BUILDS / 'desktop/qcae-cli'),
            '--evidence-dir', str(cli), '--source-tree-sha256', TREE], [cli])
    cli_report = read(cli / 'workflow-report.json')
    rows = cli_report.get('runs_detail', [])
    require(len(rows) == 3 and all(row.get('passed') is True and row.get('source_tree_sha256') == TREE and
                                  row.get('mode', '').upper() == 'CLI' for row in rows),
            'Actual CLI3 workflow is incomplete')
    require(len({row.get('run_id') for row in rows}) == 3 and all(row.get('run_id') for row in rows),
            'Actual CLI run IDs are not distinct')
    artifact_facts = files_under((faults, workflow, attempt / 'commands', attempt / 'logs'))
    write(attempt / 'collected.json', {'kind': 'actual bounded reliability collection',
          'source_commit': COMMIT, 'source410_sha256': TREE, 'fault_main_runs': 220,
          'extra_instrumented_F17_runs': 10, 'ASAN_client_raw_runs': 20, 'extra_F16_added_to_main': 0,
          'CLI_actual_runs': 3, 'native6_status': 'Existing run68 full records only; pure compare action required',
          'fault_validator': fact(validated), 'cli_report': fact(cli / 'workflow-report.json'),
          'sealed_collection_artifacts': artifact_facts, 'no_performance_or_full_acceptance_claim': True})


def compare(attempt, collection):
    # No native launch. Reuse exact source-bound records from the completed full native run.
    previous = read(collection / 'collected.json')
    completion = read(collection / 'action-complete.json')
    require(completion['action'] == 'collect' and completion['source_commit'] == COMMIT and
            completion['source410_sha256'] == TREE and completion['all_prerequisites_before_after_match'] is True
            and not (collection / 'action-failure.json').exists(),
            'Collection has not reached clean final guard success; preserve its failure')
    require(previous['source_commit'] == COMMIT and previous['source410_sha256'] == TREE,
            'Collection belongs to another source')
    for item in previous['sealed_collection_artifacts']:
        verify_fact(item)
    state = guard()
    native_dir = Path(state['six_full']['desktop']['native_evidence_dir'])
    native_log = Path(state['six_full']['desktop']['raw_log']['path']).read_text(errors='replace')
    paths = [native_dir / f'{mode}-M-run-{index}.json' for mode in ('GUI', 'MIX') for index in range(3)]
    require(all(path.is_file() for path in paths), 'BLOCKED: six source-bound native raw records not available; no GUI rerun authorized here')
    native_facts, ids = [], []
    destination = attempt / 'native-full86-raw-copy'
    destination.mkdir()
    for path in paths:
        record = read(path)
        require(record.get('source_tree_sha256') == TREE and record.get('mode') in ('GUI', 'MIX') and
                record.get('run_id'), 'Native raw source/mode/run identity differs')
        mode, _, index = path.stem.rpartition('-')
        require(record['mode'] == mode.split('-')[0], 'Native record mode differs from filename')
        row = f"guiCreatesChecksRepairsAndPublishesM({record['mode']}-M-{index})"
        require(re.search(r'(?m)^PASS\s*:\s+\w+::' + re.escape(row) + r'\s*$', native_log),
                'Actual full native named row PASS absent: ' + row)
        stages = record.get('raw_semantic_checkpoints', record.get('semantic_checkpoints', {}))
        stage_names = {'repaired_M' if name == 'check_repaired' else name for name in stages}
        require(stage_names == STAGES and len(stages) == 8 and
                all(isinstance(rows, list) for rows in stages.values()),
                'Native semantic checkpoints incomplete')
        window = state['six_full']['desktop']['actual_run_window']
        require(window['started_unix'] <= path.stat().st_mtime <= window['finished_unix'],
                'Native raw file was modified outside the completed full-run window: ' + str(path))
        original = fact(path)
        with (destination / path.name).open('xb') as stream:
            stream.write(path.read_bytes())
        require(sha(destination / path.name) == original['sha256'], 'Native raw copy byte mismatch')
        native_facts.append(original)
        ids.append(record['run_id'])
    require(len(set(ids)) == 6, 'Native raw run IDs are not unique')
    write(attempt / 'native-reuse.json', {'kind': 'actual byte-preserving read/copy; no native process executed',
          'source_commit': COMMIT, 'source410_sha256': TREE, 'original_actual_records': native_facts,
          'full_native_complete': state['six_full']['desktop']['complete'],
          'full_native_raw_log': state['six_full']['desktop']['raw_log'],
          'exact_private_copies': files_under((destination,))})
    target = attempt / 'workflow-comparison.json'
    extra = [fact(collection / 'collected.json'), fact(collection / 'action-complete.json'),
             previous['cli_report'], *native_facts,
             *files_under((destination,))]
    command(attempt, 'workflow-comparison', [PYTHON, '-B', str(ROOT / 'tests/skeleton_workflow_compare.py'),
            '--cli-report', previous['cli_report']['path'], '--desktop-evidence-dir', str(destination),
            '--source-tree-sha256', TREE, '--expected-runs', '3', '--output', str(target)], [target], extra_inputs=extra)
    result = read(target)
    require(result['passed'] is True and result['acceptance_ready'] is True and
            result['mode_counts'] == {'CLI': 3, 'GUI': 3, 'MIX': 3} and
            len(result['comparisons']) == 72 and len(result['identity_bijections']) == 9 and
            result['semantic_difference_count'] == 0 and not result['errors'],
            'Nine-workflow/72-checkpoint comparison is incomplete')
    write(attempt / 'comparison-complete.json', {'kind': 'actual pure comparison of nine existing workflows',
          'source_commit': COMMIT, 'source410_sha256': TREE, 'actual_workflows': 9,
          'checkpoints': 72, 'semantic_differences': 0, 'identity_bijections': 9,
          'result': fact(target), 'no_new_native_GUI_solver_AI_or_performance_process': True,
          'no_full_SK_P0_or_SDK_internal_coverage_claim': True})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root-authorized-run', action='store_true', required=True)
    parser.add_argument('--action', choices=('collect', 'compare'), required=True)
    parser.add_argument('--attempt-id', required=True)
    parser.add_argument('--collection-attempt-id')
    args = parser.parse_args()
    require(re.fullmatch(r'[a-z0-9][a-z0-9_.-]{0,63}', args.attempt_id), 'Invalid attempt ID')
    if args.action == 'compare':
        require(args.collection_attempt_id and re.fullmatch(r'[a-z0-9][a-z0-9_.-]{0,63}', args.collection_attempt_id),
                'Pure comparison requires an explicit existing collection attempt')
    attempt = HERE / 'attempts' / args.attempt_id
    attempt.mkdir(parents=True, exist_ok=False)
    (attempt / 'logs').mkdir()
    (attempt / 'commands').mkdir()
    started = time.time()
    try:
        before = guard()
        write(attempt / 'prerequisite-before.json', before)
        if args.action == 'collect':
            collect(attempt)
        else:
            compare(attempt, HERE / 'attempts' / args.collection_attempt_id)
        after = guard()
        write(attempt / 'prerequisite-after.json', after)
        require(before == after, 'Prerequisites changed across collector action')
        write(attempt / 'action-complete.json', {'action': args.action, 'source_commit': COMMIT,
              'source410_sha256': TREE, 'started_unix': started, 'finished_unix': time.time(),
              'all_prerequisites_before_after_match': True, 'byte_cap_or_full_acceptance_claim': False})
        return 0
    except BaseException as error:
        write(attempt / 'action-failure.json', {'action': args.action,
              'kind': 'blocked_prerequisite_or_proof' if isinstance(error, Blocked) else 'actual_command_or_recorder_failure',
              'error': repr(error), 'source_commit': COMMIT, 'source410_sha256': TREE,
              'started_unix': started, 'finished_unix': time.time(),
              'actual_process_outcomes': 'See existing per-command receipts; absent receipt means no process outcome claim',
              'all_partial_raw_outputs_preserved': True})
        print(str(error), file=sys.stderr)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
