88 is preparation only. No guard, collection, comparison, compiler, test, engine or GUI execution occurred.

Source: /private/tmp/qcae-framework-preference-fix85
HEAD ef0df3bdd8c1b27330d71a596f16098cb6b6410a
source410 15d20f20fef88ed6d1b8637b97edf77143887728cb9c42427620b25429e65c03
All2835 tracked files and actual86 prepared88 tool/SDK facts were read/hash checked.
Old72 preparation/seal and all actual outcomes remain unchanged and retain their old source.

collect.py is a byte-method copy of72 with only explicit ROOT/COMMIT/TREE,
runtime68->86/builds68->86/matrix-sequence68->86 and private native-full86
output-name bindings changed. Inverse mapping restores72 bytes exactly.
Some comments/diagnostic labels still say run68/final68; actual constants,
all source checks, actual receipt paths and comparison inputs now require85/86.
No numeric threshold, population, application behavior, library guard or failure condition changed.

Future guard still requires all7 actual configure/build/inventory receipts, seven
new clean build/cache/compile/binary seals, original six full applicable test lists,
current six production architecture checks and public independent74 compile/inventory0.
The public top is tests/public_api_consumers; not74 CTest cases. Source410/all2835,
source env, source+actual command argv, raw logs, native six-row/fixture provenance,
configured SQLite3.53.4/Qt6.11.1/VTK9.7, sanitizer10 and original R0 inventory
remain required. All86 full gates are pending when this preparation is sealed.

Root alone schedules actual bounded collection after all gates are complete:

/Library/Frameworks/Python.framework/Versions/3.14/bin/python3.14 -B /private/tmp/qcae-framework-reliability-collector88/collect.py --root-authorized-run --action collect --attempt-id reliability88-01

That action collects original fault220 (180application/20client/20wire), actual
ASAN client20 with additional F17x10 (not an enlarged220 denominator), and CLI3.
Actual nonzero receipts/logs are written before stopping. No graphical/performance
process is launched by this collector. Root86 full Desktop must already provide
same-source actual GUI3/MIX3, no old68 raw replacement.

After actual clean collection, exact pure comparison of those CLI3 plus current
full native6 preserves9 workflows/72 comparisons and0 semantic difference:

/Library/Frameworks/Python.framework/Versions/3.14/bin/python3.14 -B /private/tmp/qcae-framework-reliability-collector88/collect.py --root-authorized-run --action compare --attempt-id comparison88-01 --collection-attempt-id reliability88-01

All outputs use fresh exclusive directories. Original failed attempts must remain.
No collection result, real solver/AI, SDK internal coverage, copy-budget, performance,
complete SK/C3/C4/P0 acceptance is claimed by this preparation.
