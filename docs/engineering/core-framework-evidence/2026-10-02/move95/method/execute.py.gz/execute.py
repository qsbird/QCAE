#!/usr/bin/env python3
"""Root-owned BP13 build/native execution. Preparation does not call this file."""
from __future__ import annotations

import argparse
import base64
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent


def require(value, message):
    if not value:
        raise RuntimeError(message)


def fact(path):
    path = Path(path).resolve()
    return {"path": str(path), "bytes": path.stat().st_size,
            "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def read(path):
    return json.loads(Path(path).read_text())


def write(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def preparation_guard(expected_index_sha):
    immutable_index_path = HERE / "immutable-index.json"
    require(re.fullmatch(r"[0-9a-f]{64}", expected_index_sha), "Explicit sealed index SHA required")
    require(fact(immutable_index_path)["sha256"] == expected_index_sha,
            "Preparation index differs from root-reviewed exact disk bytes")
    index = read(immutable_index_path)
    facts = []
    for item in index["files"]:
        path = HERE / item["relative_path"]
        require(path.is_file() and not path.is_symlink(), "Missing/replaced private input")
        actual = fact(path)
        require(actual["bytes"] == item["bytes"] and actual["sha256"] == item["sha256"],
                "Preparation byte drift: " + item["relative_path"])
        facts.append(actual)
    manifest = read(HERE / "prepared-inputs.json")
    require(manifest["production_settings_isolation"]["source_and_harness_guards_prepared"] is True,
            "Production/harness explicit Ini settings guards are not ready; stop before any build/native")
    external = [*manifest["fixed_inputs"], *manifest["configured_tool_and_sdk_pins"],
                *manifest["old_peer_inputs"]]
    for item in external:
        require(fact(item["path"]) == item, "Frozen external input drift: " + item["path"])
    require(manifest["source_commit"] == "ef0df3bdd8c1b27330d71a596f16098cb6b6410a" and
            manifest["source410_sha256"] ==
            "15d20f20fef88ed6d1b8637b97edf77143887728cb9c42427620b25429e65c03",
            "Current source binding changed")
    return manifest, [*facts, fact(immutable_index_path), *external]


def build(attempt, manifest, inputs, boundary):
    build_dir = Path(manifest["build_dir"])
    require(not build_dir.exists(), "Use the planned fresh peer build; no reuse")
    for phase, argv, outputs in (
        ("peer-configure", manifest["configure_argv"], [build_dir]),
        ("peer-build", manifest["build_argv"], []),
    ):
        boundary.command(attempt, phase, argv, outputs, extra_inputs=inputs)
    cache_path = build_dir / "CMakeCache.txt"
    cache = boundary.cache_values(cache_path)
    expected = {
        "QCAE_FINAL_SOURCE_ROOT": manifest["source_root"],
        "QCAE_FINAL_COMMIT": manifest["source_commit"],
        "QCAE_FINAL_SOURCE_TREE_SHA256": manifest["source410_sha256"],
        "BUILD_TESTING": "OFF", "QCAE_BUILD_IPC": "ON", "QCAE_BUILD_STORAGE": "ON",
        "QCAE_BUILD_DESKTOP": "ON", "QCAE_ENABLE_NASTRAN_PACKAGE": "ON",
        "QCAE_ENABLE_SANITIZERS": "OFF", "QCAE_BUILD_SOLVER_LOCAL": "ON",
        "CMAKE_BUILD_TYPE": "Release", "CMAKE_CXX_EXTENSIONS": "OFF",
        "CMAKE_HOME_DIRECTORY": str(HERE / "peer"),
        "CMAKE_CXX_COMPILER": "/Library/Developer/CommandLineTools/usr/bin/c++",
        "Python3_EXECUTABLE": boundary.PYTHON,
        "Qt6_DIR": "/opt/homebrew/Cellar/qtbase/6.11.1/lib/cmake/Qt6",
        "VTK_DIR": "/Users/qs/Documents/ChatGPT/QCAE/build-vtk-deps/install/lib/cmake/vtk-9.7",
        "SQLite3_INCLUDE_DIR": "/opt/homebrew/Cellar/sqlite/3.53.4/include",
        "SQLite3_LIBRARY": "/opt/homebrew/Cellar/sqlite/3.53.4/lib/libsqlite3.3.53.4.dylib",
    }
    for name, value in expected.items():
        require(cache.get(name) == value, "Peer configuration changed: " + name)
    for name in ("QCAE_C3_SQLITE_OBSERVED_OBJECT", "QCAE_C3_QT_SDK_MANIFEST",
                 "QCAE_C3_QT_SDK_IMAGE_BINDING", "QCAE_C3_HARFBUZZ_SDK_MANIFEST",
                 "QCAE_C3_HARFBUZZ_LIBRARY"):
        require(cache.get(name) == "", "Unexpected observed SDK override: " + name)
    commands_path = build_dir / "compile_commands.json"
    compilation = read(commands_path)
    peer = [row for row in compilation if Path(row["file"]).resolve() == HERE / "peer/peer.cpp"]
    require(len(peer) == 1, "Exactly one actual peer translation unit required")
    for row in compilation:
        command = row.get("command", " ".join(row.get("arguments", [])))
        require("-std=c++20" in command and "-std=gnu++20" not in command,
                "Current fresh peer/dependencies are not strict C++20")
    peer_command = peer[0].get("command", " ".join(peer[0].get("arguments", [])))
    require(manifest["source_commit"] in peer_command and manifest["source410_sha256"] in peer_command,
            "Actual peer compile definitions differ from frozen source")
    raw = "".join((attempt / "logs" / ("peer-build." + stream + ".log")).read_text(errors="replace")
                  for stream in ("stdout", "stderr"))
    warnings = re.findall(r"(?m)^.*\bwarning:.*$", raw)
    require(not warnings, "Actual peer build emitted warnings; raw retained")
    binary = fact(build_dir / "qcae_bp13_tool_lifecycle_peer")
    write(attempt / "peer-build-complete.json", {
        "kind": "actual root-run BP13 node-move lifecycle peer build", "actual_exit_code": 0,
        "source_commit": manifest["source_commit"], "source410_sha256": manifest["source410_sha256"],
        "binary": binary, "cache": fact(cache_path), "compile_commands": fact(commands_path),
        "actual_compile_count": len(compilation), "actual_peer_compile_count": 1,
        "CXX_EXTENSIONS": "OFF", "compiler_warnings": warnings,
        "configure_receipt": fact(attempt / "commands/peer-configure.json"),
        "build_receipt": fact(attempt / "commands/peer-build.json"),
        "build_artifacts": boundary.files_under([build_dir]),
        "native_execution": "NOT RUN by build action",
    })


def verify_peer_build(path, manifest):
    path = Path(path).resolve()
    require(path.parent == Path(manifest["runtime_root"]).resolve(),
            "Peer build receipt must belong to this fresh runtime")
    complete = read(path / "peer-build-complete.json")
    require(complete["source_commit"] == manifest["source_commit"] and
            complete["source410_sha256"] == manifest["source410_sha256"] and
            complete["actual_exit_code"] == 0 and complete["actual_peer_compile_count"] == 1 and
            complete["CXX_EXTENSIONS"] == "OFF" and not complete["compiler_warnings"],
            "Actual fresh peer build did not complete with the current inputs")
    inputs = [fact(path / "peer-build-complete.json"), *complete["build_artifacts"]]
    for item in (complete["binary"], complete["cache"], complete["compile_commands"],
                 complete["configure_receipt"], complete["build_receipt"], *inputs):
        require(fact(item["path"]) == item, "Fresh peer build fact drift: " + item["path"])
    return complete["binary"], inputs


def cli_call(attempt, manifest, boundary, endpoint, sequence, operation, parameters=None, key=None, context=None, profile=None):
    name = "bootstrap-" + str(sequence).zfill(3) + "-" + operation.replace(".", "-")
    request = {"api_version": "1.1", "request_id": "bp13-" + str(sequence),
               "operation": operation, "parameters": parameters or {}}
    if context:
        request.update(document_id=context["document_id"], document_epoch=context["document_epoch"],
                       expected_revision=context["revision"])
    if profile:
        request["expected_profile"] = profile
    if key:
        request["idempotency_key"] = key
    payload = json.dumps(request).encode()
    input_path = attempt / "commands" / (name + ".stdin.json")
    with input_path.open("xb") as stream:
        stream.write(payload)
    cli = next(p["path"] for p in manifest["stock_desktop_pins"] if Path(p["path"]).name == "qcae-cli")
    argv = [cli, "--socket", str(endpoint), "--no-start"]
    env, explicit, removed = boundary.environment()
    started, monotonic = time.time(), time.monotonic()
    process, error, stdout, stderr = None, None, b"", b""
    try:
        process = subprocess.Popen(argv, cwd=manifest["source_root"], env=env, stdin=subprocess.PIPE,
                                   stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        stdout, stderr = process.communicate(payload, timeout=15)
    except BaseException as failure:
        error = repr(failure)
        if process is not None:
            process.kill()
            stdout, stderr = process.communicate(timeout=10)
    finished = time.time()
    paths = {}
    for field, data in (("stdout", stdout), ("stderr", stderr)):
        path = attempt / "logs" / (name + "." + field + ".log")
        with path.open("xb") as stream:
            stream.write(data)
        paths[field] = fact(path)
    code = process.returncode if process else None
    receipt = {"id": name, "actual_argv": argv, "cwd": manifest["source_root"],
               "pid": process.pid if process else None, "actual_exit_code": code,
               "stdin": fact(input_path), "request": request, **paths,
               "started_unix": started, "finished_unix": finished,
               "elapsed_seconds": finished - started,
               "elapsed_monotonic_seconds": time.monotonic() - monotonic,
               "explicit_environment": explicit, "removed_environment_variable_names": removed,
               "recorder_error": error, "source_commit": manifest["source_commit"],
               "source410_sha256": manifest["source410_sha256"]}
    write(attempt / "commands" / (name + ".json"), receipt)
    require(error is None, "CLI recorder/timeout failure; actual receipt preserved")
    if code == 3 and operation == "capabilities.list" and not stdout and \
            stderr.startswith(b"Engine is not available: ") and stderr.count(b"\n") == 1:
        return None, receipt  # Only this actual startup readiness status may be retried.
    require(code == 0, "Unexpected actual CLI exit; no blanket exit3 waiver")
    response = json.loads(stdout)
    require(response.get("request_id") == request["request_id"] and response.get("status") == "success",
            "CLI success response identity/status differs")
    write(attempt / "commands" / (name + ".response.json"), response)
    return response["data"], receipt


def image_observation(path, pid, expected, manifest):
    text = Path(path).read_text(errors="replace")
    pattern = r"(?m)^dyld\[" + str(pid) + r"\]: <[0-9A-Fa-f-]+> (/.+)$"
    raw_paths = sorted(set(re.findall(pattern, text)))
    require(raw_paths and str(expected) in raw_paths, "Actual dyld image observation missing for owned PID")
    external = []
    system = []
    prepared = {item["path"]: item for item in manifest["configured_tool_and_sdk_pins"]}
    for raw in raw_paths:
        if raw.startswith(("/usr/lib/", "/System/Library/")):
            system.append(raw)
        else:
            item = fact(raw)
            if item["path"] in prepared:
                require(item == prepared[item["path"]], "Observed configured SDK image differs")
            external.append({"observed_path": raw, **item,
                             "matches_configured86_pin": item["path"] in prepared})
    return {"observed_pid": pid, "raw_log": fact(path), "raw_image_count": len(raw_paths),
            "external_images": external, "system_shared_cache_paths": system,
            "system_shared_cache_bytes_not_available": True,
            "SDK_internal_owned_copy_coverage": "unknown; no SDK measurement claim"}



def native(attempt, manifest, inputs, boundary, build_attempt):
    return load(HERE / "native.py", "bp13_native95").native(
        attempt, manifest, inputs, boundary, build_attempt, sys.modules[__name__])


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("action", choices=("build", "native"))
    parser.add_argument("--input-index-sha256", required=True)
    parser.add_argument("--peer-build-attempt", type=Path)
    parser.add_argument("--attempt", default="01")
    args = parser.parse_args()
    manifest, inputs = preparation_guard(args.input_index_sha256)
    original_private_inputs = list(inputs)
    require(re.fullmatch(r"[0-9]{2}", args.attempt), "Use a fresh two-digit attempt identifier")
    require(args.action != "native" or args.peer_build_attempt is not None,
            "Native action requires explicit actual peer build attempt")
    boundary = load(manifest["boundary_module"]["path"], "bp13_boundary88")
    before = boundary.guard()
    # Future actual86 binary facts come only from the fully checked same-source guard,
    # never a preparation placeholder or any old68 binary hash.
    pinned = {item["path"]: item for item in before["inputs"]}
    paths = manifest["stock_desktop_paths"]
    require(len(paths) == 3 and len(set(paths)) == 3 and all(path in pinned for path in paths),
            "All three planned stock86 paths must have actual current gate binary seals")
    manifest["stock_desktop_pins"] = [pinned[path] for path in paths]
    inputs = [*inputs, *manifest["stock_desktop_pins"]]
    for item in manifest["stock_desktop_pins"]:
        boundary.verify_fact(item)
    creation = manifest["existing_create30"]
    report_path, log_path = Path(creation["report_path"]), Path(creation["full_raw_log_path"])
    creation_raw = read(report_path)
    require(len(creation_raw["runs"]) == creation_raw["passed_samples"] == 30 and
            creation_raw["final_revision"] == "60" and
            all(row["passed"] is True and row["cancel_revision_delta"] == 0 and
                int(row["apply_revision"]) == int(row["start_revision"]) + 1 and
                row["geometry_commit_count"] == 1 and row["final_matches_golden"] is True
                for row in creation_raw["runs"]),
            "Original source85 create-line30 supplemental report incomplete")
    require(re.search(r"(?m)^PASS\s*:\s+ToolLifecycle::thirtyRealEngineLineToolRuns\(\)\s*$",
                      log_path.read_text(errors="replace")),
            "Current source85 full raw create-line30 QTest PASS line missing")
    actual_window = before["six_full"]["desktop"]["actual_run_window"]
    require(actual_window["started_unix"] <= report_path.stat().st_mtime <= actual_window["finished_unix"],
            "Creation30 report does not originate in the current actual full-run window")
    creation.update(report=fact(report_path), full_raw_log=fact(log_path),
                    actual_scope="Current actual86 full native create30, retained separately; no full BP13 relabel")
    inputs.extend([creation["report"], creation["full_raw_log"]])
    runtime = Path(manifest["runtime_root"])
    runtime.mkdir(exist_ok=True)
    attempt = runtime / (args.action + "-" + args.attempt)
    attempt.mkdir()
    (attempt / "logs").mkdir()
    (attempt / "commands").mkdir()
    write(attempt / "inputs-before.json", {"current86_guard": before, "private_preparation": inputs})
    started, monotonic = time.time(), time.monotonic()
    try:
        result = None
        if args.action == "build":
            build(attempt, manifest, inputs, boundary)
        else:
            result = native(attempt, manifest, inputs, boundary, args.peer_build_attempt)
        _, after_inputs = preparation_guard(args.input_index_sha256)
        after = boundary.guard()
        write(attempt / "inputs-after.json", {"current86_guard": after,
              "private_preparation": after_inputs, "all_current_action_input_facts": inputs})
        require(before == after and original_private_inputs == after_inputs,
                "Current source/build/tool/private inputs drifted")
        for item in inputs:
            boundary.verify_fact(item)
        write(attempt / "action-complete.json", {
            "action": args.action, "actual_exit_code": 0, "source_commit": manifest["source_commit"],
            "source410_sha256": manifest["source410_sha256"],
            "all_prerequisites_before_after_match": True, "result": result,
            "started_unix": started, "finished_unix": time.time(),
            "elapsed_seconds": time.time() - started,
            "elapsed_monotonic_seconds": time.monotonic() - monotonic,
            "timing_scope": "Actual wall time retained without sleep subtraction; no performance claim"})
    except BaseException as failure:
        write(attempt / "action-failed.json", {"action": args.action, "recorder_failure": repr(failure),
              "source_commit": manifest["source_commit"], "source410_sha256": manifest["source410_sha256"],
              "all_raw_failures_preserved": True, "actual_success": False,
              "started_unix": started, "finished_unix": time.time()})
        raise
    print(json.dumps({"action": args.action, "actual_attempt": str(attempt)}))


if __name__ == "__main__":
    main()
