BP13 后继95已准备，所有95 guard/configure/build/engine/CLI/GUI/native均 NOT RUN。
仅继承source85 ef0df3bdd8c1b27330d71a596f16098cb6b6410a、canonical410
15d20f20fef88ed6d1b8637b97edf77143887728cb9c42427620b25429e65c03，
shared88原all7/seven clean builds、six full原完整名单/public74compile/inventory0
及source/输入/SDK/二进制before-after门禁。主工作区、原89、原82、旧失败全部不改。

修正仅native.py:172–174原receipt写入之后的cleanup成功条件：自身Popen已reap、
cleanup前仍live、确实owner terminate、未强杀、actual returncode==-15；其它状态
停止并由原execute.py记录action-failed，不会记action-complete。实际exit/signals/raw
仍原样写engine-process.json，未重标产品0。原kill fallback只用于回收自有进程，
强杀现在必须判失败；不清理其它PID/进程组/用户引擎。

依据：157个canonical生产C++/headers静态扫描没有engine信号handler安装；
engine_host.cpp:468正常app.exec()，无明确SIGTERM->exit0生产定义。旧actual79失败
attempt的engine cleanup为-15/reaped/no kill，且engine_host字节与85相等。此旧记录
只说明旧清理信号事实，不作为85/95任何GUI/BP13通过证据。

原peer.cpp、CMakeLists.txt、observations.py及黄金校核逐字节等于89；完整M11/10、
实际生产viewport pick/blank leave、原节点5、preview cancel/apply0/1、唯一历史事务、
所有其它实体fields不变、离开后Apply不增写、私有fourarg Ini User/System路径隔离、
原productionclose、public idle全部条件不变。局部30000ms原等待不变。建线30依旧
只从新86实际full原窗口读取作为单独补充，不将旧30或准备trace relabel为新PASS。
BP13代表范围见逐字节保留contract-method-source85.json及原89 README原事实。

89-to95-method.diff仅模块标签、cleanup postcondition、独占95路径和prep状态文本。
prepared-inputs.json中现存状态文字是未执行的继承准备说明；未来成功不依赖文字，
必须由sealed88实际guard完整核对新86门禁和原create30 raw/mtime。未调用旧main。
95新build为/private/tmp/qcae-framework95-BP13-builds/peer-01，
95新runtime为/private/tmp/qcae-framework-BP13-runtime95；不复用89二进制或结果。

纯检查真实exit0：原配对observations synthetic positive1/refusal28；cleanup AST
synthetic positive1/refusal14，识别原89错误接受8例，并逐例证明原receipt先写、
实际退出值不改。只执行内存fake与AST，不import native module、guard或产品。
实际driver PID30856、children30857/30858已terminal，receipt见pure-checks-complete.json。
这些是准备检查，C++编译和实际GUI/BP13仍未知，不能据此宣称完整SK/P0。

根代理审核immutable-index.json实际SHA后独占顺序执行：

/Library/Frameworks/Python.framework/Versions/3.14/bin/python3.14 -B /private/tmp/qcae-framework-BP13-peer95/execute.py build --attempt 01 --input-index-sha256 ROOT_REVIEWED_ACTUAL_INDEX_SHA256

仅actual clean build完整成功且根复核后：

/usr/bin/caffeinate -i /Library/Frameworks/Python.framework/Versions/3.14/bin/python3.14 -B /private/tmp/qcae-framework-BP13-peer95/execute.py native --attempt 01 --peer-build-attempt /private/tmp/qcae-framework-BP13-runtime95/build-01 --input-index-sha256 ROOT_REVIEWED_ACTUAL_INDEX_SHA256

不修改89索引/原脚本；不修改86 runner/产品、阈值/预算、SDK unknown或真实solver/AI门禁。
