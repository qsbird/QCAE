"""Root-only native lifecycle phase; never called by preparation analysis."""
from __future__ import annotations

from pathlib import Path
import sys
import subprocess
import time


def native(attempt, manifest, inputs, boundary, build_attempt, api):
    binary, build_inputs = api.verify_peer_build(build_attempt, manifest)
    inputs = [*inputs, *build_inputs]
    for item in inputs:
        boundary.verify_fact(item)
    validate = api.load(api.HERE / "observations.py", "bp13_observations99").observations
    settings = attempt / "settings"
    settings.mkdir()
    (settings / "system").mkdir()
    api.require(settings.resolve() == settings and str(settings).startswith("/private/tmp/"),
                "Use canonical independent private/tmp settings")
    endpoint, workspace = attempt / "engine.sock", attempt / "work.sqlite"
    api.require(len(str(endpoint).encode()) < 104, "Unchanged macOS Unix socket length limit")
    engine = next(row["path"] for row in manifest["stock_desktop_pins"] if Path(row["path"]).name == "qcae-engine")
    argv = [engine, "--socket", str(endpoint), "--workspace", str(workspace)]
    env, explicit, removed = boundary.environment()
    env["DYLD_PRINT_LIBRARIES"] = "1"
    explicit["DYLD_PRINT_LIBRARIES"] = "1"
    stdout_path, stderr_path = attempt / "logs/engine.stdout.log", attempt / "logs/engine.stderr.log"
    process, error, precleanup_code = None, None, None
    stopped, killed, reviewed = False, False, None
    started, monotonic = time.time(), time.monotonic()
    try:
        with stdout_path.open("xb") as stdout, stderr_path.open("xb") as stderr:
            try:
                process = subprocess.Popen(argv, cwd=manifest["source_root"], env=env, stdout=stdout, stderr=stderr)
                api.write(attempt / "commands/engine.started.json", {
                    "actual_argv": argv, "cwd": manifest["source_root"], "actual_pid": process.pid,
                    "started_unix": started, "binary": api.fact(engine), "explicit_environment": explicit,
                    "source_commit": manifest["source_commit"], "source410_sha256": manifest["source410_sha256"]})
                deadline, sequence, retries = time.monotonic() + 15, 0, []
                while True:
                    api.require(process.poll() is None, "Owned engine exited during startup")
                    sequence += 1
                    capabilities, receipt = api.cli_call(attempt, manifest, boundary, endpoint,
                                                         sequence, "capabilities.list")
                    if capabilities is not None:
                        break
                    retries.append(api.fact(attempt / "commands" / (receipt["id"] + ".json")))
                    api.require(process.poll() is None and time.monotonic() < deadline,
                                "Specific readiness retry expired; every actual exit retained")
                    time.sleep(.05)
                api.write(attempt / "startup-readiness.json", {
                    "retry_receipts": retries, "retry_count": len(retries),
                    "scope": "Only capabilities.list before readiness: actual CLI3/empty stdout/single Engine is not available line within15s; all other nonzero stops"})
                api.require(capabilities.get("durable") and capabilities.get("storage_mode") == "sqlite",
                            "Current stock engine must own the durable document")
                profiles = capabilities.get("declared_solver_profiles")
                api.require(isinstance(profiles, list) and len(profiles) == 1,
                            "Current ON bootstrap must retain the one declared controlled package profile")
                # Only this frozen pure fixture function is reused; its main/run_once is never called.
                before_fixture = boundary.guard()
                for item in inputs:
                    boundary.verify_fact(item)
                sys.path.insert(0, str(Path(manifest["source_root"]) / "tests"))
                fixture = api.load(Path(manifest["source_root"]) / "tests/result_fixture_ipc_tests.py",
                                   "bp13_source85_fixture_method")

                class RecordedBootstrap:
                    def __init__(self):
                        self.sequence = sequence
                        self.receipts = []

                    def call(self, operation, parameters=None, context=None, key=None,
                             expected="success", profile=None):
                        api.require(expected == "success", "No bootstrap failure waiver")
                        api.require(process.poll() is None, "Owned engine exited during fixture setup")
                        self.sequence += 1
                        data, receipt = api.cli_call(attempt, manifest, boundary, endpoint,
                                                     self.sequence, operation, parameters, key,
                                                     context, profile)
                        api.require(data is not None, "No post-startup readiness retry is allowed")
                        self.receipts.append(api.fact(attempt / "commands" / (receipt["id"] + ".json")))
                        return data

                    def current(self):
                        return self.call("project.current")

                    def fields(self, entity):
                        return self.call("entity.fields", {"entity_id": entity}, self.current())["fields"]

                    def entities(self, kind):
                        return self.call("entity.query", {"kind": kind}, self.current())["entities"]

                    def edit(self, command, parameters, key):
                        context = self.current()
                        preview = self.call("changes.preview", {"command": command, **parameters}, context)
                        return self.call("changes.commit", {"preview_id": preview["preview_id"]}, context, key)

                recorder = RecordedBootstrap()
                nodes, beams, material, part, analysis = fixture.create_m(recorder, profiles[0]["profile_ref"])
                api.require(len(nodes) == 11 and len(beams) == 10 and analysis,
                            "Original M fixture population/analysis must remain intact")
                for index, node in enumerate(nodes):
                    api.require(recorder.fields(node)["position"] == [index * 100, 0, 0],
                                "Original M node positions differ")
                bootstrap = recorder.current()
                api.write(attempt / "bootstrap-M.json", {
                    "kind": "actual fixture setup, excluded from BP13 UI0/1 revision deltas",
                    "source_fixture_method": api.fact(Path(manifest["source_root"]) / "tests/result_fixture_ipc_tests.py"),
                    "actual_current": bootstrap, "nodes": nodes, "beams": beams, "material": material,
                    "part": part, "analysis": analysis, "node5": nodes[5], "actual_cli_receipts": recorder.receipts,
                    "scope": "Original create_m algorithm; all writes use stock versioned application operations and explicit keys; no second model/solver"})
                after_fixture = boundary.guard()
                api.require(before_fixture == after_fixture, "Fixture phase changed frozen source/build/tools")
                for item in inputs:
                    boundary.verify_fact(item)
                output = attempt / "BP13-node-move-lifecycle.json"
                peer_argv = ["/usr/bin/env", "QT_QPA_PLATFORM=cocoa", "DYLD_PRINT_LIBRARIES=1", binary["path"],
                             "--socket", str(endpoint), "--workspace", str(workspace),
                             "--settings-root", str(settings), "--output", str(output), "--node-id", nodes[5]]
                receipt = boundary.command(attempt, "BP13-paired-lifecycle", peer_argv, [output], extra_inputs=inputs)
                row = api.read(output)
                api.require(row.get("process_id") == str(receipt["pid"]), "Observed actual GUI PID differs")
                settings_file = Path(row["settings_file"]).resolve()
                api.require(settings_file.is_relative_to(settings) and settings_file.is_file(),
                            "Private QSettings escaped the owned root")
                reviewed = validate(row, manifest["source_commit"], manifest["source410_sha256"], nodes[5], str(settings))
                api.require(row["setup"]["golden"]["current"] == bootstrap,
                            "Read-only preparatory view isolation changed authoritative bootstrap context")
                peer_images = api.image_observation(receipt["stderr"]["path"], receipt["pid"], binary["path"], manifest)
                recorder.sequence += 1
                final_current, _ = api.cli_call(attempt, manifest, boundary, endpoint, recorder.sequence, "project.current")
                api.require(final_current == row["apply_leave_apply_noop"]["current"],
                            "Final stock engine context differs from the exact UI terminal observation")
                api.require(process.poll() is None, "Owned engine exited before explicit cleanup")
                api.write(attempt / "lifecycle-comparison.json", {
                    "kind": "actual BP13 representative node-move paired trace, bounded only",
                    "source_commit": manifest["source_commit"], "source410_sha256": manifest["source410_sha256"],
                    "observed": reviewed, "actual_observation": api.fact(output),
                    "runtime_command": api.fact(attempt / "commands/BP13-paired-lifecycle.json"),
                    "fixture_bootstrap": api.fact(attempt / "bootstrap-M.json"),
                    "private_settings_files": boundary.files_under([settings]), "final_engine_current": final_current,
                    "existing_create30": manifest["existing_create30"],
                    "scope": "Representative existing node.move property tool; leave is release by blank viewport pick/empty selection, no dock-hide/Escape/new ToolSession claim; full SK/P0 unknown"})
            finally:
                if process is not None:
                    precleanup_code = process.poll()
                    if precleanup_code is None:
                        stopped = True
                        process.terminate()
                        try:
                            process.wait(timeout=10)
                        except subprocess.TimeoutExpired:
                            killed = True
                            process.kill()
                            process.wait(timeout=10)
    except BaseException as failure:
        error = repr(failure)
        raise
    finally:
        api.write(attempt / "engine-process.json", {
            "actual_argv": argv, "cwd": manifest["source_root"], "actual_pid": process.pid if process else None,
            "actual_exit_code": process.returncode if process else None, "exit_code_before_owned_cleanup": precleanup_code,
            "terminated_by_owner": stopped, "killed_by_owner": killed,
            "owned_process_reaped": process is not None and process.returncode is not None,
            "actual_exit_scope": "Owned cleanup signal/exit recorded literally, not a product exit0 claim",
            "started_unix": started, "finished_unix": time.time(),
            "elapsed_monotonic_seconds": time.monotonic() - monotonic,
            "stdout": api.fact(stdout_path), "stderr": api.fact(stderr_path), "binary": api.fact(engine),
            "explicit_environment": explicit, "removed_environment_variable_names": removed,
            "recorder_error": error, "source_commit": manifest["source_commit"], "source410_sha256": manifest["source410_sha256"]})
    api.require(process is not None and process.returncode is not None and precleanup_code is None and stopped
                and not killed and process.returncode == -15,
                "Owned stock engine cleanup requires reap without force-kill and actual SIGTERM exit -15; raw receipt preserved")
    engine_images = api.image_observation(stderr_path, process.pid, engine, manifest)
    sqlite = "/opt/homebrew/Cellar/sqlite/3.53.4/lib/libsqlite3.3.53.4.dylib"
    api.require(any(item["path"] == sqlite and item["matches_configured86_pin"] for item in engine_images["external_images"]),
                "Actual stock engine SQLite is not the exact current86 image")
    for suffix in ("/QtCore.framework/Versions/A/QtCore", "/QtNetwork.framework/Versions/A/QtNetwork",
                   "/QtWidgets.framework/Versions/A/QtWidgets", "/libvtkGUISupportQt-9.7.9.7.dylib"):
        api.require(any(item["path"].endswith(suffix) and item["matches_configured86_pin"]
                        for item in peer_images["external_images"]),
                    "Actual GUI required SDK is not the exact configured86 image: " + suffix)
    external = {item["path"]: {key: item[key] for key in ("path", "bytes", "sha256")}
                for group in (engine_images, peer_images) for item in group["external_images"]}
    for item in external.values():
        boundary.verify_fact(item)
    api.write(attempt / "observed-images.json", {
        "engine": engine_images, "GUI": peer_images,
        "all_actual_external_image_facts": [external[path] for path in sorted(external)],
        "scope": "Actual owned PID dyld paths/byte hashes; system shared cache and SDK internal copy remain unknown"})
    return {"comparison": api.fact(attempt / "lifecycle-comparison.json"),
            "engine_lifecycle": api.fact(attempt / "engine-process.json"),
            "loaded_images": api.fact(attempt / "observed-images.json"),
            "actual_peer_commands": 1, "actual_peer_exit_codes": [0],
            "all_owned_processes_terminal": True, "full_SK_P0": "unknown"}
