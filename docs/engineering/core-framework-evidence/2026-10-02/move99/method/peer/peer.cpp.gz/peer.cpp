#include "qcae/desktop.hpp"
#include "qcae/vtk_view.hpp"

#include <QAction>
#include <QApplication>
#include <QCommandLineOption>
#include <QCommandLineParser>
#include <QDir>
#include <QDockWidget>
#include <QElapsedTimer>
#include <QEventLoop>
#include <QFile>
#include <QFileInfo>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QKeySequence>
#include <QLabel>
#include <QLineEdit>
#include <QMainWindow>
#include <QPushButton>
#include <QSaveFile>
#include <QSettings>
#include <QSignalSpy>
#include <QSurfaceFormat>
#include <QTest>
#include <QThread>
#include <QTreeWidget>
#include <QVTKOpenGLNativeWidget.h>
#include <algorithm>
#include <array>
#include <functional>
#include <iostream>
#include <memory>
#include <optional>
#include <stdexcept>
#include <unistd.h>
#include <vtkRenderWindow.h>
#include <vtkRenderer.h>
#include <vtkRendererCollection.h>

namespace {
QJsonArray reads;
void require(bool condition, const char* message) {
    if (!condition)
        throw std::runtime_error(message);
}
void wait_until(const std::function<bool()>& predicate, const char* message) {
    QElapsedTimer elapsed;
    elapsed.start();
    while (!predicate() && elapsed.elapsed() < 30000) {
        QCoreApplication::processEvents(QEventLoop::AllEvents, 10);
        QThread::msleep(1);
    }
    require(predicate(), message);
}
void idle(QMainWindow& window) {
    wait_until([&] { return qcae::desktop_pipeline_idle(window); },
               "Unchanged production desktop_pipeline_idle did not become true");
}
QJsonObject context(const QJsonObject& current) {
    return {{"document_id", current.value("document_id")},
            {"document_epoch", current.value("document_epoch")},
            {"expected_revision", current.value("revision")}};
}
qulonglong revision(const QJsonObject& current) {
    bool valid = false;
    const auto value = current.value("revision").toString().toULongLong(&valid);
    require(valid, "Authoritative revision is not an exact unsigned decimal string");
    return value;
}
QJsonObject call(qcae::DesktopClient& client,
                 const QString& operation,
                 const QJsonObject& parameters = {},
                 const QJsonObject& expected = {}) {
    require(operation == "project.current" || operation == "history.list" ||
                operation == "entity.query" || operation == "entity.fields",
            "The GUI peer observer must remain read-only");
    const auto response = std::make_shared<std::optional<QJsonObject>>();
    const auto id = client.request(operation, parameters, expected, [response](const auto& reply) {
        *response = reply;
    });
    wait_until([&] { return response->has_value(); }, "Read-only actual engine reply timed out");
    reads.append(QJsonObject{{"operation", operation}, {"request_id", id},
                             {"parameters", parameters}, {"context", expected},
                             {"response", **response}});
    require((*response)->value("request_id").toString() == id &&
                (*response)->value("status").toString() == "success",
            "Read-only engine response identity/status differs");
    return (*response)->value("data").toObject();
}
QJsonObject model_image(qcae::DesktopClient& observer, const QJsonObject& current) {
    const auto expected = context(current);
    const auto query = call(observer, "entity.query", {{"limit", 1000}}, expected);
    const auto rows = query.value("entities").toArray();
    require(query.value("revision") == current.value("revision") &&
                query.value("total").toInt(-1) == rows.size(),
            "Stable entity snapshot is incomplete or from another revision");
    QJsonObject image;
    for (const auto& value : rows) {
        const auto row = value.toObject();
        const auto id = row.value("entity_id").toString();
        require(!id.isEmpty() && !image.contains(id), "Stable entity identity is missing/duplicate");
        image.insert(id, QJsonObject{{"kind", row.value("kind")},
                                    {"fields", call(observer, "entity.fields",
                                                    {{"entity_id", id}}, expected).value("fields")}});
    }
    return image;
}
QJsonObject snapshot(qcae::DesktopClient& observer, QMainWindow& window) {
    idle(window);
    const auto current = call(observer, "project.current");
    const auto history = call(observer, "history.list", {}, context(current));
    require(history.value("revision") == current.value("revision"), "History revision differs");
    auto* dock = window.findChild<QDockWidget*>("selectionPropertiesDock");
    auto* selected = window.findChild<QLabel*>("selectedEntities");
    require(dock && selected, "Production property controls missing");
    const auto editors = dock->findChildren<QLineEdit*>();
    require(editors.size() == 4, "Expected original X/Y/Z/E property fields");
    QJsonArray fields;
    for (auto* editor : editors)
        fields.append(QJsonObject{{"text", editor->text()}, {"enabled", editor->isEnabled()}});
    auto* cancel = window.findChild<QPushButton*>("propertyCancel");
    require(cancel, "Production Cancel control missing");
    const auto image = model_image(observer, current);
    idle(window);
    return {{"current", current}, {"history", history}, {"model", image},
            {"selected_label", selected->text()},
            {"preview_id", window.property("propertyPreviewId").toString()},
            {"cancel_enabled", cancel->isEnabled()}, {"property_fields", fields},
            {"pipeline_idle", qcae::desktop_pipeline_idle(window)},
            {"pipeline_diagnostics", qcae::desktop_pipeline_diagnostics(window)}};
}
QJsonObject physical_model(const QJsonObject& row) {
    return row.value("model").toObject();
}
void unchanged(const QJsonObject& row, const QJsonObject& golden) {
    require(row.value("current") == golden.value("current") &&
                row.value("history") == golden.value("history") &&
                row.value("model") == golden.value("model"),
            "A local/cancel/leave action changed authoritative document, history or any entity");
}
void cleared(const QJsonObject& row) {
    require(row.value("selected_label").toString() == "No selection" &&
                row.value("preview_id").toString().isEmpty() && !row.value("cancel_enabled").toBool(),
            "Leaving through empty selection did not clear target/preview/cancel");
    for (const auto& field : row.value("property_fields").toArray())
        require(!field.toObject().value("enabled").toBool() &&
                    field.toObject().value("text").toString().isEmpty(),
                "Leaving did not clear and disable each property draft field");
}
QPoint viewport_position(QVTKOpenGLNativeWidget* widget, const std::array<double, 3>& point) {
    auto* renderer = widget->renderWindow()->GetRenderers()->GetFirstRenderer();
    require(renderer, "Actual VTK renderer missing");
    renderer->SetWorldPoint(point[0], point[1], point[2], 1.0);
    renderer->WorldToDisplay();
    const auto* display = renderer->GetDisplayPoint();
    const auto scale = widget->devicePixelRatioF();
    // Identical projection-to-logical-widget convention to the production PICK tests.
    return {qRound(display[0] / scale), qRound(widget->height() - display[1] / scale)};
}
QJsonObject pick(qcae::VtkView& viewport, QVTKOpenGLNativeWidget& widget,
                 QMainWindow& window, const QPoint& pixel, const QStringList& expected) {
    idle(window);
    require(widget.rect().contains(pixel), "Real mouse target is outside the exposed viewport");
    QSignalSpy spy(&viewport, &qcae::VtkView::picked);
    require(spy.isValid(), "Cannot observe the actual production picked signal");
    QTest::mouseClick(&widget, Qt::LeftButton, Qt::NoModifier, pixel);
    wait_until([&] { return spy.size() == 1; }, "Actual mouse click did not emit exactly one pick");
    const auto ids = spy.at(0).at(0).value<QStringList>();
    const bool through = spy.at(0).at(1).toBool();
    require(ids == expected && !through, "Actual visible pick IDs differ from the exact stable-ID golden");
    auto* label = window.findChild<QLabel*>("selectedEntities");
    wait_until([&] { return label->text() == (expected.isEmpty() ? QString("No selection")
                                                                         : expected.join(", ")) &&
                             qcae::desktop_pipeline_idle(window); },
               "Production selection.evaluate/get and display did not settle to the picked IDs");
    QJsonArray actual_ids;
    for (const auto& id : ids)
        actual_ids.append(id);
    return {{"logical_pixel", QJsonArray{pixel.x(), pixel.y()}},
            {"device_pixel_ratio", widget.devicePixelRatioF()},
            {"picked_ids", actual_ids}, {"through", through}, {"picked_signal_count", static_cast<qint64>(spy.size())},
            {"trigger", "QTest::mouseClick on actual QVTKOpenGLNativeWidget; no emitted/invoked fake signal"}};
}
void click(QPushButton& button) {
    require(button.isVisible() && button.isEnabled(), "Actual button is hidden/disabled");
    QTest::mouseClick(&button, Qt::LeftButton);
}
void change_y(QLineEdit& field) {
    require(field.isEnabled() && field.isVisible(), "Actual node Y field is hidden/disabled");
    QTest::mouseClick(&field, Qt::LeftButton);
    QTest::keySequence(&field, QKeySequence(QKeySequence::SelectAll));
    QTest::keyClicks(&field, "1");
    require(field.text() == "1", "Actual keyboard input did not set physical Y=1mm");
}
void save(const QString& path, const QJsonObject& row) {
    QSaveFile file(path);
    require(file.open(QIODevice::WriteOnly), "Cannot write fresh private observation");
    require(file.write(QJsonDocument(row).toJson(QJsonDocument::Indented)) >= 0 && file.commit(),
            "Cannot atomically publish private observation");
}
} // namespace

int main(int argc, char** argv) {
    QSurfaceFormat::setDefaultFormat(QVTKOpenGLNativeWidget::defaultFormat());
    QApplication app(argc, argv);
    app.setQuitOnLastWindowClosed(false);
    QCommandLineParser parser;
    for (const auto* name : {"socket", "workspace", "settings-root", "output", "node-id"})
        parser.addOption(QCommandLineOption(QString::fromLatin1(name), QString::fromLatin1(name), "value"));
    parser.process(app);
    const auto output = parser.value("output");
    if (output.isEmpty() || QFile::exists(output))
        return 2;
    QJsonObject report{{"kind", "actual-BP13-node-move-lifecycle"},
                       {"source_commit", QCAE_BP13_SOURCE_COMMIT},
                       {"source_tree_sha256", QCAE_BP13_SOURCE_TREE_SHA256},
                       {"process_id", QString::number(getpid())}, {"qt_version", qVersion()},
                       {"qt_platform", QGuiApplication::platformName()}, {"observer_model_writes", 0}};
    QJsonArray steps;
    int exit_code = 0;
    try {
        require(QGuiApplication::platformName() == "cocoa", "Actual native Cocoa platform required");
        const auto settings_root = QDir(parser.value("settings-root")).canonicalPath();
        require(!settings_root.isEmpty() && settings_root.startsWith("/private/tmp/"),
                "Use existing fresh private/tmp QSettings root");
        require(QDir(settings_root + "/system").canonicalPath() == settings_root + "/system",
                "Fresh private SystemScope directory must exist without a symlink alias");
        QSettings::setDefaultFormat(QSettings::IniFormat);
        QSettings::setPath(QSettings::IniFormat, QSettings::UserScope, settings_root);
        QSettings::setPath(QSettings::IniFormat, QSettings::SystemScope, settings_root + "/system");
        require(QSettings::defaultFormat() == QSettings::IniFormat,
                "Set explicit Ini default before constructing any QCAE preferences");
        QSettings settings(QSettings::defaultFormat(), QSettings::UserScope, "QCAE", "Desktop");
        QSettings system(QSettings::defaultFormat(), QSettings::SystemScope, "QCAE", "Desktop");
        const auto user_file = QDir::cleanPath(QFileInfo(settings.fileName()).absoluteFilePath());
        const auto system_file = QDir::cleanPath(QFileInfo(system.fileName()).absoluteFilePath());
        require(settings.format() == QSettings::IniFormat && settings.scope() == QSettings::UserScope &&
                    user_file == settings_root + "/QCAE/Desktop.ini" &&
                    system.format() == QSettings::IniFormat && system.scope() == QSettings::SystemScope &&
                    system_file == settings_root + "/system/QCAE/Desktop.ini",
                "Actual User/System format/scope/file paths must be the independent private Ini paths");
        // Path/format checks precede sync/allKeys and production window construction.
        require(settings.allKeys().isEmpty() && system.allKeys().isEmpty(),
                "Independent User/System GUI settings must initially be empty");
        report.insert("settings_isolation", QJsonObject{{"format", "IniFormat"},
                      {"user_scope", "UserScope"}, {"system_scope", "SystemScope"},
                      {"root", settings_root}, {"user_file", user_file}, {"system_file", system_file},
                      {"initial_user_empty", true}, {"initial_system_empty", true},
                      {"production_default_format_respected", true}});
        qcae::DesktopClient observer({parser.value("socket"), parser.value("workspace"), {}, false, 10000});
        observer.start();
        wait_until([&] { return observer.ready(); }, "Read-only observer handshake timed out");
        auto window = std::unique_ptr<QMainWindow>(qcae::create_desktop_window(
            {parser.value("socket"), parser.value("workspace"), {}, false, 10000}));
        require(bool(window), "Actual production window creation failed");
        window->resize(1210, 790);
        window->show();
        require(QTest::qWaitForWindowExposed(window.get()), "Native production window did not expose");
        idle(*window);
        auto* dock = window->findChild<QDockWidget*>("selectionPropertiesDock");
        auto* tree = window->findChild<QTreeWidget*>("entityTree");
        auto* viewport = window->findChild<qcae::VtkView*>();
        auto* widget = window->findChild<QVTKOpenGLNativeWidget*>();
        auto* preview = window->findChild<QPushButton*>("propertyPreview");
        auto* cancel = window->findChild<QPushButton*>("propertyCancel");
        auto* apply = window->findChild<QPushButton*>("propertyApply");
        require(dock && tree && viewport && widget && preview && cancel && apply,
                "Existing production node-move UI controls missing");
        dock->show();
        dock->raise();
        idle(*window);
        const auto editors = dock->findChildren<QLineEdit*>();
        require(editors.size() == 4, "Original X/Y/Z/E fields missing");
        const auto target = parser.value("node-id");
        require(!target.isEmpty(), "Pass actual bootstrap node5 identity; never guess an ID");
        const auto raw_current = call(observer, "project.current");
        const auto nodes = call(observer, "entity.query", {{"kind", "node"}}, context(raw_current)).value("entities").toArray();
        const auto beams = call(observer, "entity.query", {{"kind", "beam"}}, context(raw_current)).value("entities").toArray();
        require(nodes.size() == 11 && beams.size() == 10, "Original M population must be 11 nodes/10 beams");
        const auto target_fields = call(observer, "entity.fields", {{"entity_id", target}}, context(raw_current)).value("fields").toObject();
        require(target_fields.value("position").toArray() == QJsonArray{500, 0, 0},
                "Actual original node5 physical position differs");
        QTreeWidgetItem* target_item = nullptr;
        for (int index = 0; index < tree->topLevelItemCount(); ++index)
            if (tree->topLevelItem(index)->data(0, Qt::UserRole).toString() == target)
                target_item = tree->topLevelItem(index);
        require(target_item, "Actual node5 tree identity missing");
        tree->scrollToItem(target_item);
        QTest::mouseClick(tree->viewport(), Qt::LeftButton, Qt::NoModifier,
                          tree->visualItemRect(target_item).center());
        auto* label = window->findChild<QLabel*>("selectedEntities");
        wait_until([&] { return label->text() == target && editors[1]->isEnabled() &&
                             qcae::desktop_pipeline_idle(*window); }, "Preparatory production tree selection failed");
        auto* isolate = window->findChild<QAction*>("displayIsolateAction");
        auto* fit = window->findChild<QAction*>("displayFitAction");
        auto* front = window->findChild<QAction*>("displayFrontAction");
        require(isolate && fit && front, "Existing isolate/fit/front user actions missing");
        isolate->trigger();
        idle(*window);
        front->trigger();
        fit->trigger();
        idle(*window);
        const auto blank = QPoint(12, 12);
        const auto preparatory_empty = pick(*viewport, *widget, *window, blank, {});
        const auto golden = snapshot(observer, *window);
        cleared(golden);
        require(golden.value("current").toObject() == raw_current,
                "Preparatory selection/isolation/view actions changed the model version");
        report.insert("setup", QJsonObject{{"node_id", target}, {"node_position_mm", QJsonArray{500, 0, 0}},
                       {"M_nodes", static_cast<qint64>(nodes.size())}, {"M_beams", static_cast<qint64>(beams.size())},
                       {"view_isolation", "Existing tree selection + Display/Isolate selected; only selected node remains pickable"},
                       {"preparatory_empty_pick", preparatory_empty}, {"golden", golden}});
        auto record = [&](const QString& name, const QJsonObject& extra = QJsonObject{}) {
            const auto row = snapshot(observer, *window);
            QJsonObject step{{"name", name}, {"observed", row}, {"actual_input", extra}};
            steps.append(step);
            return row;
        };
        auto enter = [&] {
            dock->show();
            dock->raise();
            idle(*window);
        };
        enter();
        unchanged(record("cancel.enter"), golden);
        const auto first_pick = pick(*viewport, *widget, *window,
                                    viewport_position(widget, {500, 0, 0}), {target});
        wait_until([&] { return editors[1]->isEnabled(); }, "Picked original node did not enable Y editor");
        unchanged(record("cancel.pick", first_pick), golden);
        change_y(*editors[1]);
        click(*preview);
        wait_until([&] { return !window->property("propertyPreviewId").toString().isEmpty() &&
                             qcae::desktop_pipeline_idle(*window); }, "Actual node.move preview token did not settle");
        const auto cancel_preview = record("cancel.preview");
        unchanged(cancel_preview, golden);
        require(cancel_preview.value("cancel_enabled").toBool(), "Actual Cancel was not enabled by preview");
        click(*cancel);
        wait_until([&] { return window->property("propertyPreviewId").toString().isEmpty() &&
                             qcae::desktop_pipeline_idle(*window); }, "Actual Cancel failed to clear preview token");
        unchanged(record("cancel.cancel"), golden);
        const auto first_leave = pick(*viewport, *widget, *window, blank, {});
        const auto cancelled = record("cancel.leave", first_leave);
        cleared(cancelled);
        unchanged(cancelled, golden);
        click(*apply);
        const auto cancelled_noop = snapshot(observer, *window);
        cleared(cancelled_noop);
        unchanged(cancelled_noop, golden);
        report.insert("cancel_leave_apply_noop", cancelled_noop);
        enter();
        unchanged(record("apply.enter"), golden);
        const auto second_pick = pick(*viewport, *widget, *window,
                                     viewport_position(widget, {500, 0, 0}), {target});
        wait_until([&] { return editors[1]->isEnabled(); }, "Second real pick did not enable Y editor");
        unchanged(record("apply.pick", second_pick), golden);
        change_y(*editors[1]);
        click(*preview);
        wait_until([&] { return !window->property("propertyPreviewId").toString().isEmpty() &&
                             qcae::desktop_pipeline_idle(*window); }, "Second node.move preview token did not settle");
        const auto apply_preview = record("apply.preview");
        unchanged(apply_preview, golden);
        require(apply_preview.value("preview_id") != cancel_preview.value("preview_id"),
                "Second preview must use a fresh actual admission token");
        click(*apply);
        const auto expected_revision = revision(golden.value("current").toObject()) + 1;
        wait_until([&] { return window->property("treeRevision").toString() == QString::number(expected_revision) &&
                             qcae::desktop_pipeline_idle(*window); }, "Actual UI commit/display did not reach exact next revision");
        const auto applied = record("apply.apply");
        require(revision(applied.value("current").toObject()) == expected_revision,
                "Actual node-move Apply must increment revision exactly once");
        const auto old_history = golden.value("history").toObject();
        const auto new_history = applied.value("history").toObject();
        require(new_history.value("items").toArray().size() == old_history.value("items").toArray().size() + 1 &&
                    new_history.value("cursor").toInt(-1) == old_history.value("cursor").toInt(-1) + 1,
                "Actual Apply must produce exactly one persistent transaction/cursor advance");
        auto expected_model = physical_model(golden);
        auto changed_node = expected_model.value(target).toObject();
        auto changed_fields = changed_node.value("fields").toObject();
        changed_fields.insert("position", QJsonArray{500, 1, 0});
        changed_node.insert("fields", changed_fields);
        expected_model.insert(target, changed_node);
        require(physical_model(applied) == expected_model && applied.value("preview_id").toString().isEmpty(),
                "Only the selected node position may change; consumed preview token must be cleared");
        const auto second_leave = pick(*viewport, *widget, *window, blank, {});
        const auto left_applied = record("apply.leave", second_leave);
        cleared(left_applied);
        unchanged(left_applied, applied);
        click(*apply);
        const auto applied_noop = snapshot(observer, *window);
        cleared(applied_noop);
        unchanged(applied_noop, applied);
        report.insert("apply_leave_apply_noop", applied_noop);
        report.insert("leave_binding", "Release node edit by actual blank viewport pick -> empty engine selection -> property draft clear; no dock-hide/close/Escape claim");
        report.insert("representative", "Existing node.move property tool; original create-line30 remains separate evidence");
        report.insert("cancel_revision_delta", QString::number(revision(cancelled.value("current").toObject()) - revision(golden.value("current").toObject())));
        report.insert("apply_revision_delta", QString::number(revision(left_applied.value("current").toObject()) - revision(golden.value("current").toObject())));
        window->close();
        window.reset();
        settings.sync();
        require(settings.status() == QSettings::NoError, "Fresh private settings save failed");
        report.insert("settings_file", settings.fileName());
        report.insert("observation_status", "paired_lifecycle_observed");
    } catch (const std::exception& error) {
        report.insert("observation_status", "failed");
        report.insert("error", QString::fromUtf8(error.what()));
        std::cerr << error.what() << '\n';
        exit_code = 1;
    }
    report.insert("steps", steps);
    report.insert("observer_reads", reads);
    report.insert("actual_exit_code", exit_code);
    try {
        save(output, report);
    } catch (const std::exception& error) {
        std::cerr << error.what() << '\n';
        return 3;
    }
    return exit_code;
}
