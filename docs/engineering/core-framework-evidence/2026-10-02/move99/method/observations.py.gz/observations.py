"""Pure validation of a future actual representative BP13 trace; no product imports."""
from __future__ import annotations

import copy

STEPS = ('cancel.enter', 'cancel.pick', 'cancel.preview', 'cancel.cancel', 'cancel.leave',
         'apply.enter', 'apply.pick', 'apply.preview', 'apply.apply', 'apply.leave')


def need(condition, message):
    if not condition:
        raise ValueError(message)


def revision(row):
    text = row['current']['revision']
    need(isinstance(text, str) and text.isdecimal() and str(int(text)) == text,
         'Exact authoritative decimal revision required')
    return int(text)


def same_model(row, golden):
    need(all(row[key] == golden[key] for key in ('current', 'history', 'model')),
         'Model/context/history changed during a non-writing stage')


def cleared(row):
    need(row['selected_label'] == 'No selection' and row['preview_id'] == '' and
         row['cancel_enabled'] is False, 'Selection/preview/Cancel cleanup missing')
    fields = row['property_fields']
    need(len(fields) == 4 and all(field == {'text': '', 'enabled': False} for field in fields),
         'All four draft fields must be cleared and disabled')


def mouse(row, expected):
    observed = row['actual_input']
    need(observed['picked_ids'] == expected and observed['through'] is False and
         observed['picked_signal_count'] == 1, 'Actual visible mouse pick differs from stable-ID golden')
    pixel = observed['logical_pixel']
    need(isinstance(pixel, list) and len(pixel) == 2 and
         all(type(value) is int and value >= 0 for value in pixel) and
         observed['device_pixel_ratio'] > 0 and
         observed['trigger'] == 'QTest::mouseClick on actual QVTKOpenGLNativeWidget; no emitted/invoked fake signal',
         'Real viewport input facts missing')


def observations(actual, commit, tree, target, settings_root):
    need(actual['kind'] == 'actual-BP13-node-move-lifecycle' and
         actual['source_commit'] == commit and actual['source_tree_sha256'] == tree and
         actual['observation_status'] == 'paired_lifecycle_observed' and actual['actual_exit_code'] == 0,
         'Actual report is failed/incomplete or belongs to another source')
    need(actual['qt_platform'] == 'cocoa' and actual['qt_version'] == '6.11.1' and
         isinstance(actual['process_id'], str) and actual['process_id'].isdecimal() and
         int(actual['process_id']) > 0 and actual['observer_model_writes'] == 0,
         'Native current Qt/PID/read-only observer scope differs')
    isolation = actual['settings_isolation']
    need(isolation == {'format': 'IniFormat', 'user_scope': 'UserScope', 'system_scope': 'SystemScope',
                       'root': settings_root, 'user_file': settings_root + '/QCAE/Desktop.ini',
                       'system_file': settings_root + '/system/QCAE/Desktop.ini',
                       'initial_user_empty': True, 'initial_system_empty': True,
                       'production_default_format_respected': True} and
         actual['settings_file'] == isolation['user_file'],
         'Actual private User/System Ini settings identities differ')
    setup = actual['setup']
    need(setup['node_id'] == target and setup['node_position_mm'] == [500, 0, 0] and
         setup['M_nodes'] == 11 and setup['M_beams'] == 10,
         'Original M/node5 identity or physical fixture differs')
    need(setup['view_isolation'] == 'Existing tree selection + Display/Isolate selected; only selected node remains pickable',
         'Preparatory view-only isolation method missing')
    golden = setup['golden']
    cleared(golden)
    need(target in golden['model'] and golden['model'][target]['kind'] == 'node' and
         golden['model'][target]['fields']['position'] == [500, 0, 0], 'Golden node5 geometry differs')
    need(sum(item['kind'] == 'node' for item in golden['model'].values()) == 11 and
         sum(item['kind'] == 'beam' for item in golden['model'].values()) == 10,
         'Actual model snapshot must retain all original11 nodes/10 beams')
    steps = actual['steps']
    need(len(steps) == 10 and [row['name'] for row in steps] == list(STEPS),
         'Exact original two-branch ordered lifecycle required')
    rows = {row['name']: row['observed'] for row in steps}
    doc_epoch = {key: golden['current'][key] for key in ('document_id', 'document_epoch')}
    for row in [golden, *rows.values(), actual['cancel_leave_apply_noop'], actual['apply_leave_apply_noop']]:
        need(all(row['current'][key] == value for key, value in doc_epoch.items()),
             'Original document/epoch fence differs')
        need(row['pipeline_idle'] is True and row['pipeline_diagnostics']['idle'] is True and
             row['pipeline_diagnostics']['tree_revision'] == row['current']['revision'] and
             row['pipeline_diagnostics']['revision'] == row['current']['revision'],
             'Unchanged public desktop pipeline/display fence did not settle')
        need(row['history']['revision'] == row['current']['revision'], 'History revision differs')
        items = row['history']['items']
        need(isinstance(items, list) and all(item['transaction_id'] and item['applied'] is True for item in items) and
             len({item['transaction_id'] for item in items}) == len(items),
             'Persistent history is duplicate/incomplete/unapplied')
    for name in STEPS[:8]:
        same_model(rows[name], golden)
    for branch in ('cancel', 'apply'):
        mouse(next(row for row in steps if row['name'] == branch + '.pick'), [target])
        mouse(next(row for row in steps if row['name'] == branch + '.leave'), [])
        picked = rows[branch + '.pick']
        previewed = rows[branch + '.preview']
        need(picked['selected_label'] == target and picked['property_fields'][1]['enabled'] is True,
             'Real selected node must enable its physical Y field')
        need(previewed['selected_label'] == target and isinstance(previewed['preview_id'], str) and
             bool(previewed['preview_id']) and previewed['cancel_enabled'] is True and
             previewed['property_fields'][1] == {'text': '1', 'enabled': True},
             'Actual node.move preview token/physical input differs')
        cleared(rows[branch + '.leave'])
    need(rows['cancel.preview']['preview_id'] != rows['apply.preview']['preview_id'],
         'Separate preview must have a fresh actual admission token')
    need(rows['cancel.cancel']['preview_id'] == '' and rows['cancel.cancel']['cancel_enabled'] is False,
         'Actual Cancel must clear token and disable Cancel')
    cleared(actual['cancel_leave_apply_noop'])
    same_model(actual['cancel_leave_apply_noop'], golden)
    applied = rows['apply.apply']
    need(revision(applied) == revision(golden) + 1 and applied['preview_id'] == '',
         'Actual Apply must commit exactly one revision and consume preview')
    old = golden['history']
    new = applied['history']
    need(new['cursor'] == old['cursor'] + 1 and len(new['items']) == len(old['items']) + 1,
         'Actual Apply must add exactly one persistent transaction')
    old_ids = {item['transaction_id'] for item in old['items']}
    new_items = [item for item in new['items'] if item['transaction_id'] not in old_ids]
    need(len(new_items) == 1 and [item for item in new['items'] if item['transaction_id'] in old_ids] == old['items'],
         'Old history must remain exact; one new transaction only')
    expected_model = copy.deepcopy(golden['model'])
    expected_model[target]['fields']['position'] = [500, 1, 0]
    need(applied['model'] == expected_model, 'Only node5 physical position may change')
    same_model(rows['apply.leave'], applied)
    cleared(actual['apply_leave_apply_noop'])
    same_model(actual['apply_leave_apply_noop'], applied)
    need(actual['cancel_revision_delta'] == '0' and actual['apply_revision_delta'] == '1',
         'Original BP13 exact0/1 revision deltas required')
    reads = actual['observer_reads']
    need(reads and all(item['operation'] in ('project.current', 'history.list', 'entity.query', 'entity.fields') and
                      item['request_id'] and item['response']['request_id'] == item['request_id'] and
                      item['response']['status'] == 'success' for item in reads),
         'Observer actual request identity/read-only response transcript differs')
    need(actual['leave_binding'] == 'Release node edit by actual blank viewport pick -> empty engine selection -> property draft clear; no dock-hide/close/Escape claim' and
         actual['representative'] == 'Existing node.move property tool; original create-line30 remains separate evidence',
         'Exact bounded representative/leave mapping required')
    return {'representative': 'existing production node.move property tool', 'contract_steps': list(STEPS),
            'cancel_revision_delta': 0, 'apply_revision_delta': 1, 'new_persistent_transactions': 1,
            'actual_transaction_id': new_items[0]['transaction_id'], 'formal_target_viewport_picks': 2,
            'formal_empty_viewport_leaves': 2, 'post_leave_apply_extra_writes': 0,
            'M_population': {'nodes': 11, 'beams': 10}, 'node5': target,
            'after_position_mm': [500, 1, 0], 'all_other_entity_fields_unchanged': True,
            'observer_model_writes': 0, 'leave_scope': 'release by empty selection; dock-close/Escape unmeasured',
            'full_SK_P0': 'unknown'}
