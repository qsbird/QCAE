BP13 最小输入后继99已准备；99的guard、CMake、编译、engine、CLI、GUI、native均NOT RUN。
源绑定85 ef0df3bdd8c1b27330d71a596f16098cb6b6410a / canonical410
15d20f20fef88ed6d1b8637b97edf77143887728cb9c42427620b25429e65c03；
shared88原all7、six full原完整名单、public74compile/inventory0以及全部工具、
SDK、输入、源、实际二进制before-after门禁不变。root独占实际顺序执行。

唯一CPP行为改动：change_y中硬编码Qt Meta+A替换为
QTest::keySequence(&field, QKeySequence(QKeySequence::SelectAll));
增加Qt公开QKeySequence include。原真实mouseClick/keyClicks("1")与field.text()=="1"
完全保留；没有直接setText/selectAll/setter、假picked或产品改动。
已安装6.11.1 SDK QWidget overload确实逐键发keyClick事件；官方exact-v6.11.1
源码中Apple的QtControl代表Command，QtMeta代表physicalControl。原硬编码Meta+A
并非标准Mac SelectAll；采用当前平台StandardKey是有界harness修正，尚未实际GUI
证明。SDK与upstream行号不同，事实分别见Qt-standard-key-basis.json。

原95实际native-01 GUI进程exit1，已真实完成cancel.enter/cancel.pick；失败在输入Y。
失败时最终字段文本未记录，不猜测10/01或声称后来步骤已过。原engine实际-15、
未强杀、已reap；全部446个失败运行文件与30个准备文件字节原样保留。
原95索引b86f718773e49907957e753623788a72bccd39e665e7facf4ae16deff32f93b4不变。

observations/CMake/合同映射/82保留事实逐字节等于95；execute/native仅内部module
标签重绑定99，95原receipt后的strictcleanup保持exact-15/reaped/precleanup-live/
owner-terminate/no-force-kill。完整M11nodes10beams、真实生产viewport pick原node5、
两次真实blank-viewport leave、preview cancel0/apply1、所有黄金fields/history及
离开后Apply无写、public pipelineIdle与原30000ms都逐字节保留。Isolate selected仅
为原可见性准备，不代替正式鼠标pick或leave。现存create-line30仅依原88门禁读取
actual86 full当前窗口补充，不能作为配对BP13 PASS。

fourarg Ini/privateUser+SystemScope/exactfilePath guards、原productionclose不变。
原所有预算、ACK/性能、未知SDK/真实solver/AI范围均未更改。未宣称AP/SK/P0完整通过。
纯read/hash/AST/inverse-diff实际exit0、PID35714已terminal；源2835/410事实一致且clean。
新准备仅增加四个现存Qt公开header bytefacts，不安装或新增依赖。

新build必须干净创建/private/tmp/qcae-framework99-BP13-builds/peer-01；
新runtime仅/private/tmp/qcae-framework-BP13-runtime99/{build-01,native-01}。
不复用95 binary/runtime，不重写95或原product/runner/raw。输入索引先由root审核；
下列占位符须替换成最终immutable-index.json实际SHA，避免self-hash循环。

/Library/Frameworks/Python.framework/Versions/3.14/bin/python3.14 -B /private/tmp/qcae-framework-BP13-peer99/execute.py build --attempt 01 --input-index-sha256 ROOT_REVIEWED_ACTUAL_INDEX_SHA256

仅新actual build完整成功且root审核后：

/usr/bin/caffeinate -i /Library/Frameworks/Python.framework/Versions/3.14/bin/python3.14 -B /private/tmp/qcae-framework-BP13-peer99/execute.py native --attempt 01 --peer-build-attempt /private/tmp/qcae-framework-BP13-runtime99/build-01 --input-index-sha256 ROOT_REVIEWED_ACTUAL_INDEX_SHA256
