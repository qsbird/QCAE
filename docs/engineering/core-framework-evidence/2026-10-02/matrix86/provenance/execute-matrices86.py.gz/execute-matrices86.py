#!/usr/bin/env python3
"""Run the remaining frozen-source matrices sequentially; stop at first failure."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

sys.dont_write_bytecode = True
ROOT = Path('/private/tmp/qcae-framework-preference-fix85')
OUT = Path(__file__).resolve().parent / 'matrix-sequence86'
RUNNER = Path(__file__).resolve().parent / 'run.py'
BUILDS = Path('/private/tmp/qcae-framework86-builds')
PYTHON = '/Library/Frameworks/Python.framework/Versions/3.14/bin/python3.14'
OUT.mkdir(exist_ok=False)

def execute(name, argv):
    started = time.time()
    print(json.dumps({'matrix_step': name, 'argv': argv}), flush=True)
    with (OUT / (name + '.stdout.log')).open('xb') as stdout, (OUT / (name + '.stderr.log')).open('xb') as stderr:
        result = subprocess.run(argv, cwd=ROOT, stdout=stdout, stderr=stderr, check=False)
    receipt = {'name': name, 'argv': argv, 'actual_exit_code': result.returncode,
               'started_unix': started, 'finished_unix': time.time(),
               'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
               'runner_sha256': hashlib.sha256(RUNNER.read_bytes()).hexdigest()}
    (OUT / (name + '.json')).write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({'matrix_step': name, 'actual_exit_code': result.returncode}), flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)

for key in ('core', 'sqlite_headless', 'asan_ubsan', 'asan_ipc', 'package_disabled', 'desktop', 'public_consumers'):
    for action in ('configure', 'build'):
        execute(action + '-' + key, [PYTHON, str(RUNNER), action, key])
    if key != 'public_consumers':
        execute('architecture-' + key, [PYTHON, str(ROOT / 'tools/check_architecture.py'),
            '--root', str(ROOT), '--build-dir', str(BUILDS / key), '--no-refresh',
            '--report', str(OUT / ('architecture-' + key + '-report.json'))])
    execute('inventory-' + key, [PYTHON, str(RUNNER), 'inventory', key])
    if key != 'public_consumers':
        execute('full-' + key, [PYTHON, str(RUNNER), 'full', key])
print('Six full production regressions and the separate 74-consumer compile gate reached actual terminal success.', flush=True)
