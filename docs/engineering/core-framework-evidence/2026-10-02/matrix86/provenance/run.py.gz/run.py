#!/usr/bin/env python3
"""Root-only fresh framework builds and actual regressions, preserving failures."""
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
ROOT = Path('/private/tmp/qcae-framework-preference-fix85')
BUILDS = Path('/private/tmp/qcae-framework86-builds')
FROZEN = OUT / 'frozen-candidate.json'
SOURCE = json.loads(FROZEN.read_text())
CMAKE = '/opt/homebrew/Cellar/cmake/4.3.0/bin/cmake'
CTEST = '/opt/homebrew/Cellar/cmake/4.3.0/bin/ctest'
PYTHON = '/Library/Frameworks/Python.framework/Versions/3.14/bin/python3.14'
COMPILER = '/Library/Developer/CommandLineTools/usr/bin/c++'
OPTIONS = ('QCAE_BUILD_IPC', 'QCAE_BUILD_STORAGE', 'QCAE_BUILD_DESKTOP',
           'QCAE_ENABLE_SANITIZERS', 'QCAE_ENABLE_NASTRAN_PACKAGE', 'CMAKE_BUILD_TYPE')
MATRICES = {
    'core': ('OFF', 'OFF', 'OFF', 'OFF', 'ON', 'Release'),
    'sqlite_headless': ('OFF', 'ON', 'OFF', 'OFF', 'ON', 'Release'),
    'desktop': ('ON', 'ON', 'ON', 'OFF', 'ON', 'Release'),
    'asan_ubsan': ('OFF', 'ON', 'OFF', 'ON', 'ON', 'Debug'),
    'asan_ipc': ('ON', 'ON', 'OFF', 'ON', 'ON', 'Debug'),
    'package_disabled': ('ON', 'ON', 'OFF', 'OFF', 'OFF', 'Release'),
    'public_consumers': ('ON', 'ON', 'ON', 'OFF', 'ON', 'Release'),
}
FOUR = {'result_fixture_ipc': 120.0, 'solver_run_ipc': 120.0,
        'c2_workflow': 180.0, 'batch_translation_ipc': 90.0}
FATAL = {'ASAN_OPTIONS': 'detect_leaks=0:halt_on_error=1',
         'UBSAN_OPTIONS': 'halt_on_error=1:print_stacktrace=1'}

def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for data in iter(lambda: stream.read(1048576), b''):
            digest.update(data)
    return digest.hexdigest()

def fact(path):
    path = Path(path).resolve()
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': sha(path)}

def write(name, value):
    path = OUT / name
    assert not path.exists(), str(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + '\n')

def guard():
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
    assert head == SOURCE['commit']
    assert not subprocess.check_output(['git', 'status', '--porcelain=v1'], cwd=ROOT, text=True).strip()
    for name, frozen in SOURCE['tracked_files'].items():
        path = ROOT / name
        assert path.stat().st_size == frozen['bytes'] and sha(path) == frozen['sha256'], name
    assert fact(FROZEN) == json.loads((OUT / 'prepared.json').read_text())['frozen_source']
    for image in json.loads((OUT / 'prepared.json').read_text())['configured_tool_and_sdk_pins']:
        assert fact(image['path']) == image, image['path']

def command(name, argv, env=None):
    guard()
    assert not (OUT / (name + '.json')).exists()
    started = time.time()
    explicit = {'PYTHONDONTWRITEBYTECODE': '1', 'QCAE_SOURCE_TREE_SHA256': SOURCE['source410_sha256'], **(env or {})}
    inherited = os.environ.copy()
    inherited.update(explicit)
    with (OUT / (name + '.stdout.log')).open('xb') as stdout, (OUT / (name + '.stderr.log')).open('xb') as stderr:
        process = subprocess.Popen(argv, cwd=ROOT, env=inherited, stdout=stdout, stderr=stderr)
        print(json.dumps({'started': name, 'pid': process.pid}), flush=True)
        result = process.wait()
    finished = time.time()
    # Write the actual command outcome before evaluating post-run conditions.
    write(name + '.json', {'argv': argv, 'cwd': str(ROOT), 'explicit_environment': explicit,
        'pid': process.pid, 'started_unix': started, 'finished_unix': finished,
        'elapsed_seconds': finished - started, 'actual_exit_code': result,
        'stdout': fact(OUT / (name + '.stdout.log')), 'stderr': fact(OUT / (name + '.stderr.log')),
        'source_commit': SOURCE['commit'], 'source410_sha256': SOURCE['source410_sha256'],
        'runner': fact(__file__)})
    guard()
    print(json.dumps({'finished': name, 'actual_exit_code': result}), flush=True)
    return result

def prepare():
    assert not (OUT / 'prepared.json').exists()
    assert len(SOURCE['source_files']) == 410 and len(SOURCE['tracked_files']) == 2835
    pins = [fact(path) for path in [CMAKE, CTEST, PYTHON, COMPILER,
        '/opt/homebrew/Cellar/sqlite/3.53.4/lib/libsqlite3.3.53.4.dylib',
        '/opt/homebrew/Cellar/sqlite/3.53.4/include/sqlite3.h',
        '/opt/homebrew/Cellar/qtbase/6.11.1/lib/QtCore.framework/Versions/A/QtCore',
        '/opt/homebrew/Cellar/qtbase/6.11.1/lib/QtNetwork.framework/Versions/A/QtNetwork',
        '/opt/homebrew/Cellar/qtbase/6.11.1/lib/QtTest.framework/Versions/A/QtTest']]
    snapshot = fact('/Users/qs/Documents/ChatGPT/QCAE/build-c3-ai-units-snapshots/session5.qcae')
    assert snapshot['sha256'] == '78b66ecb188d317c39192abedba25c5f335f87f56b9988dd0a1c9e5adfd33e83'
    pins.append(snapshot)
    qt_root = Path('/opt/homebrew/Cellar/qtbase/6.11.1/lib')
    sdk_paths = {path.resolve() for path in Path('/Users/qs/Documents/ChatGPT/QCAE/build-vtk-deps/install/lib').glob('*.dylib') if path.is_file()}
    sdk_paths.update((path / 'Versions/A' / path.stem).resolve() for path in qt_root.glob('*.framework') if (path / 'Versions/A' / path.stem).is_file())
    existing = {row['path'] for row in pins}
    pins += [fact(path) for path in sorted(sdk_paths) if str(path) not in existing]
    write('prepared.json', {'frozen_source': fact(FROZEN), 'source_commit': SOURCE['commit'],
        'source410_sha256': SOURCE['source410_sha256'], 'matrix_flags': MATRICES,
        'configured_tool_and_sdk_pins': pins, 'full_runtime_acceptance': 'NOT RUN',
        'four_original_timeouts': FOUR, 'sanitizer_scope': FATAL,
        'LeakSanitizer': 'unsupported Apple platform; explicit OFF, no LSan claim'})
    guard()
    print('Prepared source and actual configured tool/SDK pins; no product run.', flush=True)

def configure(key):
    build = BUILDS / key
    assert not build.exists()
    query = build / '.cmake/api/v1/query'
    query.mkdir(parents=True)
    for name in ('codemodel-v2', 'cache-v2'):
        (query / name).write_text('')
    definitions = dict(zip(OPTIONS, MATRICES[key]))
    definitions.update(CMAKE_EXPORT_COMPILE_COMMANDS='ON', Python3_EXECUTABLE=PYTHON,
                       CMAKE_CXX_COMPILER=COMPILER, QCAE_SOURCE_ROOT=str(ROOT))
    if definitions['QCAE_BUILD_STORAGE'] == 'ON':
        definitions.update(SQLite3_LIBRARY='/opt/homebrew/Cellar/sqlite/3.53.4/lib/libsqlite3.3.53.4.dylib',
                           SQLite3_INCLUDE_DIR='/opt/homebrew/Cellar/sqlite/3.53.4/include')
    if definitions['QCAE_BUILD_IPC'] == 'ON':
        definitions['Qt6_DIR'] = '/opt/homebrew/Cellar/qtbase/6.11.1/lib/cmake/Qt6'
    if definitions['QCAE_BUILD_DESKTOP'] == 'ON':
        definitions['VTK_DIR'] = '/Users/qs/Documents/ChatGPT/QCAE/build-vtk-deps/install/lib/cmake/vtk-9.7'
    source = ROOT / 'tests/public_api_consumers' if key == 'public_consumers' else ROOT
    trace = build / '.cmake/api/v1/architecture-trace.jsonl'
    argv = [CMAKE, '-S', str(source), '-B', str(build), '-G', 'Ninja']
    argv += ['-D' + name + '=' + value for name, value in definitions.items()]
    argv += ['--trace-expand', '--trace-format=json-v1', '--trace-redirect=' + str(trace)]
    result = command('configure-' + key, argv)
    if result:
        raise SystemExit(result)

def binaries(key):
    pattern = 'consumer_*' if key == 'public_consumers' else 'qcae*'
    return [fact(path) for path in sorted((BUILDS / key).glob(pattern))
            if path.is_file() and os.access(path, os.X_OK)]

def build(key):
    result = command('build-' + key, [CMAKE, '--build', str(BUILDS / key), '--clean-first', '-j', '2'])
    if result:
        raise SystemExit(result)
    binary_facts = binaries(key)
    assert binary_facts
    if key == 'public_consumers':
        assert len(binary_facts) == 74 and int((BUILDS / key / 'public-consumer-count.txt').read_text()) == 74
        write('public-consumers74-compile-complete.json', {'actual_build_exit_code': result,
            'source_commit': SOURCE['commit'], 'source410_sha256': SOURCE['source410_sha256'],
            'consumer_count': 74, 'consumer_binaries': binary_facts,
            'count_file': fact(BUILDS / key / 'public-consumer-count.txt'),
            'independent_top_level_source': str(ROOT / 'tests/public_api_consumers'),
            'CTest_registered_count': 'NOT YET OBSERVED; separate actual inventory follows', 'no_74_CTest_or_AP_behavior_claim': True})
    write('build-' + key + '-pins.json', {'source_commit': SOURCE['commit'],
        'source410_sha256': SOURCE['source410_sha256'], 'binaries': binary_facts,
        'cache': fact(BUILDS / key / 'CMakeCache.txt'),
        'compile_commands': fact(BUILDS / key / 'compile_commands.json'),
        'architecture_trace': fact(BUILDS / key / '.cmake/api/v1/architecture-trace.jsonl'),
        'actual_fresh_clean_build': True, 'no_old_PASS_imported': True})

def inventory(key):
    result = command('inventory-' + key, [CTEST, '--test-dir', str(BUILDS / key), '--show-only=json-v1'])
    if result:
        raise SystemExit(result)
    tests = json.loads((OUT / ('inventory-' + key + '.stdout.log')).read_text())['tests']
    if key == 'public_consumers':
        assert not tests
        count = int((BUILDS / key / 'public-consumer-count.txt').read_text())
        assert count == 74 and len(binaries(key)) == 74
        write('inventory-' + key + '-audit.json', {'current_applicable_names': [], 'count': 0,
            'independent_compiled_consumer_count': count, 'not_a_CTest74_claim': True,
            'actual_count_file': fact(BUILDS / key / 'public-consumer-count.txt')})
        return
    assert tests
    original_names = json.loads(Path('/private/tmp/qcae-sk-final-runner41/final-config44.json').read_text())['baseline_regressions'][key]
    assert set(original_names) <= {test['name'] for test in tests}
    if key == 'asan_ipc':
        old_names = json.loads(Path('/private/tmp/qcae-headless-permission03-review46/terminal-failure-audit.json').read_text())['actual_inventory_names']
        assert {test['name'] for test in tests} == set(old_names)
        for name, timeout in FOUR.items():
            row = next(test for test in tests if test['name'] == name)
            assert next(p['value'] for p in row['properties'] if p['name'] == 'TIMEOUT') == timeout
    write('inventory-' + key + '-audit.json', {'current_applicable_names': sorted(t['name'] for t in tests),
        'count': len(tests), 'unchanged_four_timeouts': FOUR if key == 'asan_ipc' else None})

def regression(key, targeted):
    assert key != 'public_consumers', 'Independent 74-consumer compile gate has no CTest registration'
    pins = json.loads((OUT / ('build-' + key + '-pins.json')).read_text())
    for item in [*pins['binaries'], pins['cache'], pins['compile_commands'], pins['architecture_trace']]:
        assert fact(item['path']) == item
    argv = [CTEST, '--test-dir', str(BUILDS / key), '--output-on-failure', '-j', '1']
    if targeted:
        assert key == 'asan_ipc'
        argv += ['-R', '^(result_fixture_ipc|solver_run_ipc|c2_workflow|batch_translation_ipc)$']
    env = {'QT_QPA_PLATFORM': '', 'PATH': '/Library/Frameworks/Python.framework/Versions/3.14/bin:' + os.environ['PATH']}
    if key == 'desktop':
        env['QCAE_AI_UNITS_SNAPSHOT'] = '/Users/qs/Documents/ChatGPT/QCAE/build-c3-ai-units-snapshots/session5.qcae'
    if MATRICES[key][3] == 'ON':
        env.update(FATAL)
    name = ('four-timeouts-' if targeted else 'full-regression-') + key
    launcher = ['/usr/bin/caffeinate', '-i', '/usr/bin/env']
    launcher += [option + '=' + value for option, value in env.items()]
    result = command(name, launcher + argv, env)
    diagnostics = OUT / (name + '-diagnostics')
    diagnostics.mkdir()
    for filename in ('LastTest.log', 'LastTestsFailed.log', 'CTestCostData.txt'):
        source = BUILDS / key / 'Testing/Temporary' / filename
        if source.is_file():
            shutil.copyfile(source, diagnostics / filename)
    for item in pins['binaries']:
        assert fact(item['path']) == item
    write(name + '-scope.json', {'actual_exit_code': result, 'targeted_four_only': targeted,
        'full_inventory': not targeted, 'diagnostics': [fact(path) for path in sorted(diagnostics.iterdir())],
        'source_and_build_fences_verified': True, 'not_full_SK_or_P0': True})
    if result:
        raise SystemExit(result)
    log = (diagnostics / 'LastTest.log').read_text(errors='replace')
    executed = set(re.findall(r'(?m)^\d+/\d+ Testing: (.+)$', log))
    expected = set(FOUR) if targeted else set(json.loads((OUT / ('inventory-' + key + '-audit.json')).read_text())['current_applicable_names'])
    assert executed == expected, (executed, expected)
    assert 'Test Failed.' not in log and not re.search(r'(?m)^SKIP\s*:', log)
    assert not any(marker in log for marker in ('ERROR: AddressSanitizer', 'SUMMARY: AddressSanitizer', 'runtime error:', 'UndefinedBehaviorSanitizer:'))
    write(name + '-complete.json', {'actual_exit_code': 0, 'executed_names': sorted(executed),
        'count': len(executed), 'source_commit': SOURCE['commit'], 'source410_sha256': SOURCE['source410_sha256'],
        'raw_log': fact(diagnostics / 'LastTest.log'), 'no_SK_or_performance_claim': True})

action = sys.argv[1]
if action == 'prepare':
    prepare()
else:
    key = sys.argv[2]
    assert key in MATRICES
    if action == 'configure':
        configure(key)
    elif action == 'build':
        build(key)
    elif action == 'inventory':
        inventory(key)
    elif action == 'four':
        regression(key, True)
    elif action == 'full':
        regression(key, False)
    else:
        raise ValueError(action)
