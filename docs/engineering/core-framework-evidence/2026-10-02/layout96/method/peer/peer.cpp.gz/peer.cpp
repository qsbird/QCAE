#include "qcae/desktop.hpp"

#include <QAction>
#include <QApplication>
#include <QComboBox>
#include <QCommandLineOption>
#include <QCommandLineParser>
#include <QCryptographicHash>
#include <QDialog>
#include <QDir>
#include <QDockWidget>
#include <QElapsedTimer>
#include <QEventLoop>
#include <QFile>
#include <QFileInfo>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QKeySequenceEdit>
#include <QMainWindow>
#include <QPushButton>
#include <QSaveFile>
#include <QSettings>
#include <QSurfaceFormat>
#include <QTest>
#include <QThread>
#include <QToolBar>
#include <QVTKOpenGLNativeWidget.h>
#include <algorithm>
#include <functional>
#include <iostream>
#include <memory>
#include <optional>
#include <stdexcept>
#include <unistd.h>

namespace {
void require(bool condition, const char* message) {
    if (!condition)
        throw std::runtime_error(message);
}
void wait_until(const std::function<bool()>& predicate, const char* message) {
    QElapsedTimer elapsed;
    elapsed.start();
    while (!predicate() && elapsed.elapsed() < 30000) {
        QCoreApplication::processEvents(QEventLoop::AllEvents, 10);
        QThread::msleep(1);
    }
    require(predicate(), message);
}
QByteArray read_file(const QString& path) {
    QFile file(path);
    require(file.open(QIODevice::ReadOnly), "Cannot read actual evidence/settings bytes");
    return file.readAll();
}
QJsonObject read_object(const QString& path) {
    const auto parsed = QJsonDocument::fromJson(read_file(path));
    require(parsed.isObject(), "Golden observation is not a JSON object");
    return parsed.object();
}
QString sha(const QByteArray& bytes) {
    return QString::fromLatin1(QCryptographicHash::hash(bytes, QCryptographicHash::Sha256).toHex());
}
QJsonObject call(qcae::DesktopClient& client,
                 const QString& operation,
                 const QJsonObject& parameters = {},
                 const QJsonObject& context = {}) {
    const auto response = std::make_shared<std::optional<QJsonObject>>();
    (void)client.request(operation, parameters, context, [response](const auto& reply) {
        *response = reply;
    });
    wait_until([&] { return response->has_value(); }, "Actual engine reply timed out");
    require((*response)->value("status").toString() == "success", "Actual engine request failed");
    return (*response)->value("data").toObject();
}
QJsonObject context(const QJsonObject& current) {
    return {{"document_id", current.value("document_id")},
            {"document_epoch", current.value("document_epoch")},
            {"expected_revision", current.value("revision")}};
}
QJsonArray names(const QStringList& values) {
    QJsonArray output;
    for (const auto& value : values)
        output.append(value);
    return output;
}
QJsonObject panels(QMainWindow& window) {
    auto* views = window.findChild<QDockWidget*>("modelViewsDock");
    auto* selection = window.findChild<QDockWidget*>("selectionPropertiesDock");
    auto* history = window.findChild<QDockWidget*>("historyDock");
    require(views && selection && history, "Three fixed production panels missing");
    return {{"modelViewsDock_width", views->width()},
            {"selectionPropertiesDock_width", selection->width()},
            {"historyDock_height", history->height()}};
}
QJsonObject layout_configuration(QMainWindow& window) {
    QStringList dock_names, toolbar_names;
    QJsonObject docks, toolbars;
    for (auto* dock : window.findChildren<QDockWidget*>()) {
        require(!dock->objectName().isEmpty(), "Anonymous production dock cannot be registered");
        dock_names.append(dock->objectName());
        QStringList tab_names;
        for (auto* tab : window.tabifiedDockWidgets(dock))
            tab_names.append(tab->objectName());
        tab_names.sort();
        docks.insert(dock->objectName(), QJsonObject{{"area", static_cast<int>(window.dockWidgetArea(dock))},
                     {"floating", dock->isFloating()}, {"hidden", dock->isHidden()},
                     {"tabified_with", names(tab_names)}});
    }
    for (auto* toolbar : window.findChildren<QToolBar*>()) {
        require(!toolbar->objectName().isEmpty(), "Anonymous production toolbar cannot be registered");
        toolbar_names.append(toolbar->objectName());
        toolbars.insert(toolbar->objectName(), QJsonObject{{"area", static_cast<int>(window.toolBarArea(toolbar))},
                        {"floating", toolbar->isFloating()}, {"hidden", toolbar->isHidden()}});
    }
    dock_names.sort();
    toolbar_names.sort();
    require(dock_names == QStringList({"analysisDock", "historyDock", "modelViewsDock", "modelingDock", "selectionPropertiesDock"}),
            "Production dock catalog differs from five named docks");
    require(toolbar_names == QStringList({"selectionToolbar", "workspaceToolbar"}),
            "Production toolbar catalog differs from two named toolbars");
    for (const auto& name : dock_names) {
        const auto actual = docks.value(name).toObject();
        const int expected_area = name == "modelViewsDock" ? Qt::LeftDockWidgetArea
                                 : name == "historyDock" ? Qt::BottomDockWidgetArea
                                                        : Qt::RightDockWidgetArea;
        require(actual.value("area").toInt() == expected_area &&
                    !actual.value("floating").toBool() &&
                    actual.value("hidden").toBool() == (name == "analysisDock"),
                "Actual named dock position/visibility differs from requested fixed configuration");
    }
    for (const auto& name : toolbar_names) {
        const auto actual = toolbars.value(name).toObject();
        require(actual.value("area").toInt() == Qt::TopToolBarArea &&
                    !actual.value("floating").toBool() && !actual.value("hidden").toBool(),
                "Actual toolbar configuration differs from fixed production configuration");
    }
    return {{"dock_names", names(dock_names)}, {"toolbar_names", names(toolbar_names)},
            {"docks", docks}, {"toolbars", toolbars}, {"fixed_panel_count", 3}, {"fixed_panels", panels(window)}};
}
void exact_requested_sizes(QMainWindow& window) {
    auto* views = window.findChild<QDockWidget*>("modelViewsDock");
    auto* selection = window.findChild<QDockWidget*>("selectionPropertiesDock");
    auto* history = window.findChild<QDockWidget*>("historyDock");
    int views_request = 280, selection_request = 360, history_request = 170;
    for (int iteration = 0; iteration < 12; ++iteration) {
        window.resizeDocks({views, selection}, {views_request, selection_request}, Qt::Horizontal);
        window.resizeDocks({history}, {history_request}, Qt::Vertical);
        QTest::qWait(50);
        if (views->width() == 280 && selection->width() == 360 && history->height() == 170)
            return;
        // These are real Qt resize requests, never edits to measured sizes or tolerance.
        views_request += 280 - views->width();
        selection_request += 360 - selection->width();
        history_request += 170 - history->height();
    }
    require(false, "Exact requested 280/360/170 dimensions were not achieved; no +/- tolerance applies");
}
void change_shortcut_through_production_dialog(QMainWindow& window) {
    auto* preferences = window.findChild<QAction*>("shortcutPreferencesAction");
    require(preferences, "Production shortcut preferences action missing");
    preferences->trigger();
    auto* dialog = window.findChild<QDialog*>("shortcutPreferencesForm");
    require(dialog, "Production shortcut dialog missing");
    auto* action = dialog->findChild<QComboBox*>("shortcutAction");
    auto* sequence = dialog->findChild<QKeySequenceEdit*>("shortcutSequence");
    auto* apply = dialog->findChild<QPushButton*>("shortcutApply");
    require(action && sequence && apply, "Production shortcut form fields missing");
    const auto index = action->findData("historyUndoAction");
    require(index >= 0, "Undo action missing from actual shortcut catalog");
    action->setCurrentIndex(index);
    sequence->setKeySequence(QKeySequence(Qt::CTRL | Qt::Key_U));
    apply->click();
    require(window.findChild<QAction*>("historyUndoAction")->shortcut() == QKeySequence(Qt::CTRL | Qt::Key_U),
            "Production Apply did not change actual QAction shortcut");
    dialog->close();
}
} // namespace

int main(int argc, char** argv) {
    QSurfaceFormat::setDefaultFormat(QVTKOpenGLNativeWidget::defaultFormat());
    QApplication app(argc, argv);
    app.setQuitOnLastWindowClosed(false);
    QCommandLineParser parser;
    for (const auto* name : {"phase", "socket", "workspace", "settings-root", "output", "golden"})
        parser.addOption(QCommandLineOption(QString::fromLatin1(name), QString::fromLatin1(name), "value"));
    parser.process(app);
    const auto phase = parser.value("phase");
    const auto output_path = parser.value("output");
    if (output_path.isEmpty() || QFile::exists(output_path))
        return 2;
    QJsonObject observation{{"kind", "actual-fresh-GUI-preference-observation"}, {"phase", phase},
                            {"process_id", QString::number(getpid())},
                            {"source_commit", QCAE_BP17_SOURCE_COMMIT},
                            {"source_tree_sha256", QCAE_BP17_SOURCE_TREE_SHA256},
                            {"qt_version", qVersion()}, {"qt_platform", QGuiApplication::platformName()}};
    int exit_code = 0;
    try {
        require(phase == "write" || phase == "read", "phase must be write or read");
        require(!output_path.isEmpty() && !QFile::exists(output_path), "Use a new explicit peer output path");
        require(QGuiApplication::platformName() == "cocoa", "Actual frozen Cocoa GUI backend required");
        const auto settings_root = QDir(parser.value("settings-root")).canonicalPath();
        require(settings_root.startsWith("/private/tmp/") && !settings_root.isEmpty(), "Use independent existing private/tmp QSettings root");
        QSettings::setDefaultFormat(QSettings::IniFormat);
        require(QSettings::defaultFormat() == QSettings::IniFormat,
                "Select IniFormat before constructing any QCAE settings");
        require(QDir(settings_root + "/system").canonicalPath() == settings_root + "/system" &&
                    QDir(settings_root + "/QCAE").canonicalPath() == settings_root + "/QCAE",
                "Use exact existing private user/system preference directories");
        QSettings::setPath(QSettings::IniFormat, QSettings::UserScope, settings_root);
        QSettings::setPath(QSettings::IniFormat, QSettings::SystemScope, settings_root + "/system");
        QSettings settings(QSettings::defaultFormat(), QSettings::UserScope, "QCAE", "Desktop");
        const auto actual_settings_file = QDir::cleanPath(QFileInfo(settings.fileName()).absoluteFilePath());
        const auto expected_settings_file = QDir(settings_root).absoluteFilePath("QCAE/Desktop.ini");
        require(settings.format() == QSettings::IniFormat && settings.scope() == QSettings::UserScope &&
                    settings.organizationName() == "QCAE" && settings.applicationName() == "Desktop",
                "Actual QCAE settings constructor must select the private Ini backend");
        require(actual_settings_file == expected_settings_file &&
                    actual_settings_file.startsWith(settings_root + "/") &&
                    QDir(QFileInfo(actual_settings_file).absolutePath()).canonicalPath() == settings_root + "/QCAE" &&
                    !QFileInfo(actual_settings_file).isSymLink(),
                "Actual QCAE settings file escaped this exact private root");
        observation.insert("settings_format", static_cast<int>(settings.format()));
        observation.insert("settings_scope", static_cast<int>(settings.scope()));
        observation.insert("private_settings_root", settings_root);
        observation.insert("settings_file", actual_settings_file);
        settings.sync();
        require(settings.status() == QSettings::NoError, "Actual settings read failed");
        QJsonObject golden;
        QByteArray persisted_before;
        if (phase == "write") {
            require(settings.allKeys().isEmpty(), "First fresh GUI settings must be empty");
        } else {
            golden = read_object(parser.value("golden"));
            require(golden.value("source_commit").toString() == QCAE_BP17_SOURCE_COMMIT &&
                    golden.value("source_tree_sha256").toString() == QCAE_BP17_SOURCE_TREE_SHA256,
                    "Golden belongs to a different final source");
            require(golden.value("process_id").toString() != QString::number(getpid()), "Second GUI is not a fresh process");
            persisted_before = read_file(settings.fileName());
            require(sha(persisted_before) == golden.value("raw_preferences_sha256").toString(), "Persisted preferences changed between fresh processes");
        }
        qcae::DesktopClient observer({parser.value("socket"), parser.value("workspace"), {}, false, 10000});
        observer.start();
        wait_until([&] { return observer.ready(); }, "Actual observer handshake timed out");
        const auto before = call(observer, "project.current");
        const auto before_history = call(observer, "history.list", {}, context(before));
        if (phase == "read") {
            require(before == golden.value("model_after").toObject(), "Engine document changed between fresh GUI processes");
            require(before_history == golden.value("history_after").toObject(), "Engine history changed between fresh GUI processes");
        }
        auto window = std::unique_ptr<QMainWindow>(qcae::create_desktop_window(
            {parser.value("socket"), parser.value("workspace"), {}, false, 10000}));
        require(bool(window), "Production create_desktop_window failed");
        if (phase == "write")
            window->resize(1210, 790);
        window->show();
        require(QTest::qWaitForWindowExposed(window.get()), "Actual production window is not exposed");
        wait_until([&] { return qcae::desktop_pipeline_idle(*window); }, "Actual desktop pipeline did not reach idle");
        if (phase == "write") {
            change_shortcut_through_production_dialog(*window);
            auto* views = window->findChild<QDockWidget*>("modelViewsDock");
            auto* selection = window->findChild<QDockWidget*>("selectionPropertiesDock");
            auto* modeling = window->findChild<QDockWidget*>("modelingDock");
            auto* history = window->findChild<QDockWidget*>("historyDock");
            require(views && selection && modeling && history, "Fixed production docks missing");
            window->addDockWidget(Qt::LeftDockWidgetArea, views);
            window->addDockWidget(Qt::RightDockWidgetArea, selection);
            window->addDockWidget(Qt::RightDockWidgetArea, modeling);
            window->tabifyDockWidget(selection, modeling);
            selection->raise();
            window->addDockWidget(Qt::BottomDockWidgetArea, history);
            views->show();
            selection->show();
            modeling->show();
            history->show();
            window->findChild<QDockWidget*>("analysisDock")->hide();
            exact_requested_sizes(*window);
        }
        QTest::qWait(50);
        const auto actual_layout = layout_configuration(*window);
        const auto requested = QJsonObject{{"modelViewsDock_width", 280}, {"selectionPropertiesDock_width", 360}, {"historyDock_height", 170}};
        require(actual_layout.value("fixed_panels").toObject() == requested, "Actual fixed dimensions differ from exact contract request");
        const auto state = window->saveState(1), geometry = window->saveGeometry();
        require(!state.isEmpty() && !geometry.isEmpty(), "Actual serialized preferences missing");
        auto* undo = window->findChild<QAction*>("historyUndoAction");
        require(undo && undo->shortcut() == QKeySequence(Qt::CTRL | Qt::Key_U), "Shortcut did not restore exactly");
        if (phase == "read") {
            require(actual_layout == golden.value("layout_configuration").toObject(), "Fresh-process dock/toolbar count/config differs from golden");
            require(state.toBase64() == golden.value("serialized_state_base64").toString().toLatin1(), "Fresh-process serialized layout state differs from golden");
            require(geometry.toBase64() == golden.value("serialized_geometry_base64").toString().toLatin1(), "Fresh-process serialized geometry differs from golden");
        }
        observation.insert("layout_configuration", actual_layout);
        observation.insert("serialized_state_base64", QString::fromLatin1(state.toBase64()));
        observation.insert("serialized_geometry_base64", QString::fromLatin1(geometry.toBase64()));
        observation.insert("shortcut", undo->shortcut().toString(QKeySequence::PortableText));
        require(window->close(), "Production window refused close/save-preferences");
        window.reset();
        settings.sync();
        require(settings.status() == QSettings::NoError && settings.value("layout/state").toByteArray() == state &&
                settings.value("layout/geometry").toByteArray() == geometry &&
                settings.value("shortcuts/historyUndoAction").toString() == QKeySequence(Qt::CTRL | Qt::Key_U).toString(QKeySequence::PortableText),
                "Raw production settings did not persist exact state/geometry/shortcut");
        const auto actual_bytes = read_file(settings.fileName());
        if (phase == "read")
            require(actual_bytes == persisted_before, "Second fresh GUI process rewrote different raw preference bytes");
        const auto after = call(observer, "project.current");
        const auto after_history = call(observer, "history.list", {}, context(after));
        require(before == after && before_history == after_history, "Layout/shortcut changes modified authoritative document/history");
        observation.insert("model_before", before);
        observation.insert("model_after", after);
        observation.insert("history_before", before_history);
        observation.insert("history_after", after_history);
        observation.insert("settings_file", settings.fileName());
        observation.insert("raw_preferences_base64", QString::fromLatin1(actual_bytes.toBase64()));
        observation.insert("raw_preferences_sha256", sha(actual_bytes));
        observation.insert("settings_keys", names(settings.allKeys()));
        observation.insert("observation_status", "exact_boundaries_observed");
    } catch (const std::exception& error) {
        observation.insert("observation_status", "failed_actual_observation");
        observation.insert("error", QString::fromUtf8(error.what()));
        std::cerr << error.what() << '\n';
        exit_code = 1;
    }
    QSaveFile file(output_path);
    const auto bytes = QJsonDocument(observation).toJson(QJsonDocument::Indented);
    if (!file.open(QIODevice::WriteOnly) || file.write(bytes) != bytes.size() || !file.commit())
        return 2;
    std::cout << bytes.constData();
    return exit_code;
}
