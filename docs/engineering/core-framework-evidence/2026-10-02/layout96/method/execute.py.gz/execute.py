#!/usr/bin/env python3
"""Root-owned BP17 build/native execution. Preparation does not call this file."""
from __future__ import annotations

import argparse
import base64
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent


def require(value, message):
    if not value:
        raise RuntimeError(message)


def fact(path):
    path = Path(path).resolve()
    return {"path": str(path), "bytes": path.stat().st_size,
            "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def read(path):
    return json.loads(Path(path).read_text())


def write(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def preparation_guard(expected_index_sha):
    immutable_index_path = HERE / "immutable-index.json"
    require(re.fullmatch(r"[0-9a-f]{64}", expected_index_sha), "Explicit sealed index SHA required")
    require(fact(immutable_index_path)["sha256"] == expected_index_sha,
            "Preparation index differs from root-reviewed exact disk bytes")
    index = read(immutable_index_path)
    facts = []
    for item in index["files"]:
        path = HERE / item["relative_path"]
        require(path.is_file() and not path.is_symlink(), "Missing/replaced private input")
        actual = fact(path)
        require(actual["bytes"] == item["bytes"] and actual["sha256"] == item["sha256"],
                "Preparation byte drift: " + item["relative_path"])
        facts.append(actual)
    manifest = read(HERE / "prepared-inputs.json")
    external = [*manifest["fixed_inputs"], *manifest["configured_tool_and_sdk_pins"],
                *manifest["stock_desktop_pins"], *manifest["old_peer_inputs"]]
    for item in external:
        require(fact(item["path"]) == item, "Frozen external input drift: " + item["path"])
    require(manifest["source_commit"] == "ef0df3bdd8c1b27330d71a596f16098cb6b6410a" and
            manifest["source410_sha256"] ==
            "15d20f20fef88ed6d1b8637b97edf77143887728cb9c42427620b25429e65c03",
            "Current source binding changed")
    return manifest, [*facts, fact(immutable_index_path), *external]



def bind_actual_stock(manifest, boundary):
    pins_path = Path(manifest["stock_desktop_pins_receipt"])
    pins = boundary.read(pins_path)
    require(pins["source_commit"] == manifest["source_commit"] and
            pins["source410_sha256"] == manifest["source410_sha256"] and
            pins["actual_fresh_clean_build"] is True,
            "Stock binaries require the actual new-source86 fresh build seal")
    stock = [item for item in pins["binaries"]
             if Path(item["path"]).name in ("qcae-engine", "qcae-cli", "qcae-desktop")]
    require(sorted(item["path"] for item in stock) == sorted(manifest["planned_stock_desktop_paths"]),
            "Actual stock86 binary paths/denominator differ")
    for item in stock:
        boundary.verify_fact(item)
    bound = dict(manifest)
    bound["stock_desktop_pins"] = stock
    return bound, [boundary.fact(pins_path), *stock]


def build(attempt, manifest, inputs, boundary):
    build_dir = Path(manifest["build_dir"])
    require(not build_dir.exists(), "Use the planned fresh peer build; no reuse")
    for phase, argv, outputs in (
        ("peer-configure", manifest["configure_argv"], [build_dir]),
        ("peer-build", manifest["build_argv"], []),
    ):
        boundary.command(attempt, phase, argv, outputs, extra_inputs=inputs)
    cache_path = build_dir / "CMakeCache.txt"
    cache = boundary.cache_values(cache_path)
    expected = {
        "QCAE_FINAL_SOURCE_ROOT": manifest["source_root"],
        "QCAE_FINAL_COMMIT": manifest["source_commit"],
        "QCAE_FINAL_SOURCE_TREE_SHA256": manifest["source410_sha256"],
        "BUILD_TESTING": "OFF", "QCAE_BUILD_IPC": "ON", "QCAE_BUILD_STORAGE": "ON",
        "QCAE_BUILD_DESKTOP": "ON", "QCAE_ENABLE_NASTRAN_PACKAGE": "ON",
        "QCAE_ENABLE_SANITIZERS": "OFF", "QCAE_BUILD_SOLVER_LOCAL": "ON",
        "CMAKE_BUILD_TYPE": "Release", "CMAKE_CXX_EXTENSIONS": "OFF",
        "CMAKE_HOME_DIRECTORY": str(HERE / "peer"),
        "CMAKE_CXX_COMPILER": "/Library/Developer/CommandLineTools/usr/bin/c++",
        "Python3_EXECUTABLE": boundary.PYTHON,
        "Qt6_DIR": "/opt/homebrew/Cellar/qtbase/6.11.1/lib/cmake/Qt6",
        "VTK_DIR": "/Users/qs/Documents/ChatGPT/QCAE/build-vtk-deps/install/lib/cmake/vtk-9.7",
        "SQLite3_INCLUDE_DIR": "/opt/homebrew/Cellar/sqlite/3.53.4/include",
        "SQLite3_LIBRARY": "/opt/homebrew/Cellar/sqlite/3.53.4/lib/libsqlite3.3.53.4.dylib",
    }
    for name, value in expected.items():
        require(cache.get(name) == value, "Peer configuration changed: " + name)
    for name in ("QCAE_C3_SQLITE_OBSERVED_OBJECT", "QCAE_C3_QT_SDK_MANIFEST",
                 "QCAE_C3_QT_SDK_IMAGE_BINDING", "QCAE_C3_HARFBUZZ_SDK_MANIFEST",
                 "QCAE_C3_HARFBUZZ_LIBRARY"):
        require(cache.get(name) == "", "Unexpected observed SDK override: " + name)
    commands_path = build_dir / "compile_commands.json"
    compilation = read(commands_path)
    peer = [row for row in compilation if Path(row["file"]).resolve() == HERE / "peer/peer.cpp"]
    require(len(peer) == 1, "Exactly one actual peer translation unit required")
    for row in compilation:
        command = row.get("command", " ".join(row.get("arguments", [])))
        require("-std=c++20" in command and "-std=gnu++20" not in command,
                "Current fresh peer/dependencies are not strict C++20")
    peer_command = peer[0].get("command", " ".join(peer[0].get("arguments", [])))
    require(manifest["source_commit"] in peer_command and manifest["source410_sha256"] in peer_command,
            "Actual peer compile definitions differ from frozen source")
    raw = "".join((attempt / "logs" / ("peer-build." + stream + ".log")).read_text(errors="replace")
                  for stream in ("stdout", "stderr"))
    warnings = re.findall(r"(?m)^.*\bwarning:.*$", raw)
    require(not warnings, "Actual peer build emitted warnings; raw retained")
    binary = fact(build_dir / "qcae_bp17_fresh_gui_peer")
    write(attempt / "peer-build-complete.json", {
        "kind": "actual root-run fresh BP17 peer build", "actual_exit_code": 0,
        "source_commit": manifest["source_commit"], "source410_sha256": manifest["source410_sha256"],
        "binary": binary, "cache": fact(cache_path), "compile_commands": fact(commands_path),
        "actual_compile_count": len(compilation), "actual_peer_compile_count": 1,
        "CXX_EXTENSIONS": "OFF", "compiler_warnings": warnings,
        "configure_receipt": fact(attempt / "commands/peer-configure.json"),
        "build_receipt": fact(attempt / "commands/peer-build.json"),
        "build_artifacts": boundary.files_under([build_dir]),
        "native_execution": "NOT RUN by build action",
    })


def verify_peer_build(path, manifest):
    path = Path(path).resolve()
    require(path.parent == Path(manifest["runtime_root"]).resolve(),
            "Peer build receipt must belong to this fresh runtime")
    complete = read(path / "peer-build-complete.json")
    require(complete["source_commit"] == manifest["source_commit"] and
            complete["source410_sha256"] == manifest["source410_sha256"] and
            complete["actual_exit_code"] == 0 and complete["actual_peer_compile_count"] == 1 and
            complete["CXX_EXTENSIONS"] == "OFF" and not complete["compiler_warnings"],
            "Actual fresh peer build did not complete with the current inputs")
    inputs = [fact(path / "peer-build-complete.json"), *complete["build_artifacts"]]
    for item in (complete["binary"], complete["cache"], complete["compile_commands"],
                 complete["configure_receipt"], complete["build_receipt"], *inputs):
        require(fact(item["path"]) == item, "Fresh peer build fact drift: " + item["path"])
    return complete["binary"], inputs


def cli_call(attempt, manifest, boundary, endpoint, sequence, operation, parameters=None, key=None):
    name = "bootstrap-" + str(sequence).zfill(3) + "-" + operation.replace(".", "-")
    request = {"api_version": "1.1", "request_id": "bp17-" + str(sequence),
               "operation": operation, "parameters": parameters or {}}
    if key:
        request["idempotency_key"] = key
    payload = json.dumps(request).encode()
    input_path = attempt / "commands" / (name + ".stdin.json")
    with input_path.open("xb") as stream:
        stream.write(payload)
    cli = next(p["path"] for p in manifest["stock_desktop_pins"] if Path(p["path"]).name == "qcae-cli")
    argv = [cli, "--socket", str(endpoint), "--no-start"]
    env, explicit, removed = boundary.environment()
    started, monotonic = time.time(), time.monotonic()
    process, error, stdout, stderr = None, None, b"", b""
    try:
        process = subprocess.Popen(argv, cwd=manifest["source_root"], env=env, stdin=subprocess.PIPE,
                                   stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        stdout, stderr = process.communicate(payload, timeout=15)
    except BaseException as failure:
        error = repr(failure)
        if process is not None:
            process.kill()
            stdout, stderr = process.communicate(timeout=10)
    finished = time.time()
    paths = {}
    for field, data in (("stdout", stdout), ("stderr", stderr)):
        path = attempt / "logs" / (name + "." + field + ".log")
        with path.open("xb") as stream:
            stream.write(data)
        paths[field] = fact(path)
    code = process.returncode if process else None
    receipt = {"id": name, "actual_argv": argv, "cwd": manifest["source_root"],
               "pid": process.pid if process else None, "actual_exit_code": code,
               "stdin": fact(input_path), "request": request, **paths,
               "started_unix": started, "finished_unix": finished,
               "elapsed_seconds": finished - started,
               "elapsed_monotonic_seconds": time.monotonic() - monotonic,
               "explicit_environment": explicit, "removed_environment_variable_names": removed,
               "recorder_error": error, "source_commit": manifest["source_commit"],
               "source410_sha256": manifest["source410_sha256"]}
    write(attempt / "commands" / (name + ".json"), receipt)
    require(error is None, "CLI recorder/timeout failure; actual receipt preserved")
    if code == 3 and operation == "capabilities.list" and not stdout and \
            stderr.startswith(b"Engine is not available: ") and stderr.count(b"\n") == 1:
        return None, receipt  # Only this actual startup readiness status may be retried.
    require(code == 0, "Unexpected actual CLI exit; no blanket exit3 waiver")
    response = json.loads(stdout)
    require(response.get("request_id") == request["request_id"] and response.get("status") == "success",
            "CLI success response identity/status differs")
    write(attempt / "commands" / (name + ".response.json"), response)
    return response["data"], receipt


def image_observation(path, pid, expected, manifest):
    text = Path(path).read_text(errors="replace")
    pattern = r"(?m)^dyld\[" + str(pid) + r"\]: <[0-9A-Fa-f-]+> (/.+)$"
    raw_paths = sorted(set(re.findall(pattern, text)))
    require(raw_paths and str(expected) in raw_paths, "Actual dyld image observation missing for owned PID")
    external = []
    system = []
    prepared = {item["path"]: item for item in manifest["configured_tool_and_sdk_pins"]}
    for raw in raw_paths:
        if raw.startswith(("/usr/lib/", "/System/Library/")):
            system.append(raw)
        else:
            item = fact(raw)
            if item["path"] in prepared:
                require(item == prepared[item["path"]], "Observed configured SDK image differs")
            external.append({"observed_path": raw, **item,
                             "matches_configured86_pin": item["path"] in prepared})
    return {"observed_pid": pid, "raw_log": fact(path), "raw_image_count": len(raw_paths),
            "external_images": external, "system_shared_cache_paths": system,
            "system_shared_cache_bytes_not_available": True,
            "SDK_internal_owned_copy_coverage": "unknown; no SDK measurement claim"}


def native(attempt, manifest, inputs, boundary, build_attempt):
    binary, build_inputs = verify_peer_build(build_attempt, manifest)
    inputs = [*inputs, *manifest["stock_desktop_pins"], *build_inputs]
    for item in inputs:
        boundary.verify_fact(item)
    validate = load(HERE / "observations.py", "bp17_observations87").observations
    settings = attempt / "settings"
    settings.mkdir()
    (settings / "system").mkdir()
    (settings / "QCAE").mkdir()
    (settings / "system/QCAE").mkdir()
    require(settings.resolve() == settings and str(settings).startswith("/private/tmp/"),
            "Fresh settings must be canonical private/tmp")
    require(not list(settings.rglob("*.ini")), "First process settings must be empty")
    endpoint, workspace = attempt / "engine.sock", attempt / "work.sqlite"
    require(len(str(endpoint).encode()) < 104, "Unix socket exceeds the unchanged macOS bound")
    engine = next(p["path"] for p in manifest["stock_desktop_pins"] if Path(p["path"]).name == "qcae-engine")
    argv = [engine, "--socket", str(endpoint), "--workspace", str(workspace)]
    env, explicit, removed = boundary.environment()
    env["DYLD_PRINT_LIBRARIES"] = "1"
    explicit["DYLD_PRINT_LIBRARIES"] = "1"
    stdout_path, stderr_path = attempt / "logs/engine.stdout.log", attempt / "logs/engine.stderr.log"
    process, error, stopped_by_owner, killed_by_owner = None, None, False, False
    precleanup_code, comparison, image_facts = None, None, []
    started, monotonic = time.time(), time.monotonic()
    try:
        with stdout_path.open("xb") as stdout, stderr_path.open("xb") as stderr:
            try:
                process = subprocess.Popen(argv, cwd=manifest["source_root"], env=env, stdout=stdout, stderr=stderr)
                write(attempt / "commands/engine.started.json", {
                    "actual_argv": argv, "cwd": manifest["source_root"], "actual_pid": process.pid,
                    "started_unix": started, "binary": fact(engine), "explicit_environment": explicit,
                    "source_commit": manifest["source_commit"], "source410_sha256": manifest["source410_sha256"]})
                deadline, sequence, retries = time.monotonic() + 15, 0, []
                while True:
                    require(process.poll() is None, "Owned engine exited during startup")
                    sequence += 1
                    capabilities, receipt = cli_call(attempt, manifest, boundary, endpoint, sequence, "capabilities.list")
                    if capabilities is not None:
                        break
                    retries.append(fact(attempt / "commands" / (receipt["id"] + ".json")))
                    require(process.poll() is None and time.monotonic() < deadline,
                            "Specific startup readiness retry expired; actual exits retained")
                    time.sleep(.05)
                write(attempt / "startup-readiness.json", {
                    "retry_receipts": retries, "retry_count": len(retries),
                    "scope": "Only capabilities.list before readiness: CLI actual3, emptystdout, single Engine is not available stderr; every other nonzero fails"})
                require(capabilities.get("durable") and capabilities.get("storage_mode") == "sqlite",
                        "The stock current engine must own a durable SQLite workspace")
                sequence += 1
                cli_call(attempt, manifest, boundary, endpoint, sequence, "project.create",
                         {"name": "BP17 exact fresh-process preferences"}, "bp17-create")
                sequence += 1
                bootstrap, _ = cli_call(attempt, manifest, boundary, endpoint, sequence, "project.current")
                receipts, observations = [], []
                for phase in ("write", "read"):
                    require(process.poll() is None, "Owned engine exited before GUI phase")
                    output = attempt / (phase + ".json")
                    peer_argv = ["/usr/bin/env", "QT_QPA_PLATFORM=cocoa", "DYLD_PRINT_LIBRARIES=1", binary["path"],
                                 "--phase", phase, "--socket", str(endpoint), "--workspace", str(workspace),
                                 "--settings-root", str(settings), "--output", str(output)]
                    if phase == "read":
                        peer_argv.extend(["--golden", str(attempt / "write.json")])
                    receipt = boundary.command(attempt, "fresh-gui-" + phase, peer_argv, [output], extra_inputs=inputs)
                    row = read(output)
                    require(type(row.get("settings_format")) is int and row["settings_format"] == 1 and
                            type(row.get("settings_scope")) is int and row["settings_scope"] == 0,
                            "Actual fresh GUI settings format/scope differ from private Ini/UserScope")
                    require(row.get("private_settings_root") == str(settings) and
                            row.get("settings_file") == str(settings / "QCAE/Desktop.ini"),
                            "Actual fresh GUI preferences were not preflighted in this exact private root")
                    require(row.get("process_id") == str(receipt["pid"]),
                            "Actual GUI PID differs from the separately launched command")
                    settings_file = Path(row["settings_file"]).resolve()
                    require(settings_file.is_relative_to(settings) and settings_file.is_file(),
                            "QSettings file escaped the fresh private root")
                    require(settings_file.read_bytes() == base64.b64decode(row["raw_preferences_base64"], validate=True),
                            "Observed raw preferences differ from actual private settings bytes")
                    image_facts.append(image_observation(receipt["stderr"]["path"], receipt["pid"],
                                                         binary["path"], manifest))
                    receipts.append(fact(attempt / "commands" / ("fresh-gui-" + phase + ".json")))
                    observations.append(row)
                comparison = validate(*observations)
                require(comparison["document_revision_before"] == bootstrap["revision"] and
                        comparison["document_revision_after"] == bootstrap["revision"],
                        "GUI observation revision differs from actual bootstrap")
                sequence += 1
                final_current, _ = cli_call(attempt, manifest, boundary, endpoint, sequence, "project.current")
                require(final_current == bootstrap, "Authoritative current document changed during preferences")
                require(process.poll() is None, "Owned engine exited prematurely after GUI phases")
                write(attempt / "comparison.json", {
                    "kind": "actual BP17 two separately launched GUI processes", "pure_comparison_succeeded": True,
                    "source_commit": manifest["source_commit"], "source410_sha256": manifest["source410_sha256"],
                    "observed": comparison, "write": fact(attempt / "write.json"), "read": fact(attempt / "read.json"),
                    "runtime_commands": receipts, "private_settings_files": boundary.files_under([settings]),
                    "bootstrap_current": bootstrap, "final_current": final_current,
                    "both_peer_processes_terminal_and_reaped": True,
                    "comparison_scope": "Exact bytes/state/geometry/panel catalogs and positions/280/360/170/Ctrl+U/document revision/history; no full acceptance claim"})
            finally:
                if process is not None:
                    precleanup_code = process.poll()
                    if precleanup_code is None:
                        stopped_by_owner = True
                        process.terminate()
                        try:
                            process.wait(timeout=10)
                        except subprocess.TimeoutExpired:
                            killed_by_owner = True
                            process.kill()
                            process.wait(timeout=10)
    except BaseException as failure:
        error = repr(failure)
        raise
    finally:
        finished = time.time()
        write(attempt / "engine-process.json", {
            "kind": "actual owned stock engine lifecycle", "actual_argv": argv,
            "cwd": manifest["source_root"], "actual_pid": process.pid if process else None,
            "actual_exit_code": process.returncode if process else None,
            "exit_code_before_owned_cleanup": precleanup_code,
            "terminated_by_owner": stopped_by_owner, "killed_by_owner": killed_by_owner,
            "owned_process_reaped": process is not None and process.returncode is not None,
            "actual_exit_scope": "Owned cleanup signal is recorded literally; never relabeled product exit0",
            "started_unix": started, "finished_unix": finished, "elapsed_seconds": finished - started,
            "elapsed_monotonic_seconds": time.monotonic() - monotonic,
            "stdout": fact(stdout_path), "stderr": fact(stderr_path), "binary": fact(engine),
            "explicit_environment": explicit, "removed_environment_variable_names": removed,
            "recorder_error": error, "source_commit": manifest["source_commit"],
            "source410_sha256": manifest["source410_sha256"]})
    cleanup = read(attempt / "engine-process.json")
    require(cleanup["owned_process_reaped"] is True and
            cleanup["exit_code_before_owned_cleanup"] is None and
            cleanup["terminated_by_owner"] is True and cleanup["killed_by_owner"] is False and
            type(cleanup["actual_exit_code"]) is int and cleanup["actual_exit_code"] == -15,
            "Owned engine cleanup requires reaped SIGTERM (-15) without force; actual receipt preserved")
    engine_images = image_observation(stderr_path, process.pid, engine, manifest)
    sqlite = "/opt/homebrew/Cellar/sqlite/3.53.4/lib/libsqlite3.3.53.4.dylib"
    require(any(row["path"] == sqlite for row in engine_images["external_images"]),
            "Actual stock engine SQLite image differs from current86")
    for row in image_facts:
        require(any(item["path"].endswith("/QtWidgets.framework/Versions/A/QtWidgets")
                    and item["matches_configured86_pin"] for item in row["external_images"]),
                "Actual fresh GUI QtWidgets is not the configured86 image")
        require(any(item["path"].endswith("/libvtkGUISupportQt-9.7.9.7.dylib")
                    and item["matches_configured86_pin"] for item in row["external_images"]),
                "Actual fresh GUI VTK support is not the configured86 image")
    external_by_process = [{item["path"]: item for item in row["external_images"]} for row in image_facts]
    require(external_by_process[0] == external_by_process[1],
            "External image bytes/binding differ between GUI processes")
    write(attempt / "observed-images.json", {"engine": engine_images, "fresh_gui": image_facts,
          "all_observed_external_image_facts": sorted(
              {item["path"]: {k: item[k] for k in ("path", "bytes", "sha256")}
               for row in [engine_images, *image_facts] for item in row["external_images"]}.values(),
              key=lambda item: item["path"])})
    return {"comparison": fact(attempt / "comparison.json"),
            "engine_lifecycle": fact(attempt / "engine-process.json"),
            "loaded_images": fact(attempt / "observed-images.json"),
            "actual_peer_commands": 2, "actual_peer_exit_codes": [0, 0],
            "all_owned_processes_terminal": True}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("action", choices=("build", "native"))
    parser.add_argument("--input-index-sha256", required=True)
    parser.add_argument("--peer-build-attempt", type=Path)
    parser.add_argument("--attempt", default="01")
    args = parser.parse_args()
    manifest, inputs = preparation_guard(args.input_index_sha256)
    require(re.fullmatch(r"[0-9]{2}", args.attempt), "Use a fresh two-digit attempt identifier")
    require(args.action != "native" or args.peer_build_attempt is not None,
            "Native action requires explicit actual peer build attempt")
    boundary = load(manifest["boundary_module"]["path"], "bp17_boundary88")
    before = boundary.guard()
    manifest, runtime_stock_inputs = bind_actual_stock(manifest, boundary)
    runtime = Path(manifest["runtime_root"])
    runtime.mkdir(exist_ok=True)
    attempt = runtime / (args.action + "-" + args.attempt)
    attempt.mkdir()
    (attempt / "logs").mkdir()
    (attempt / "commands").mkdir()
    write(attempt / "inputs-before.json", {"current86_guard": before, "private_preparation": inputs})
    started, monotonic = time.time(), time.monotonic()
    try:
        result = None
        if args.action == "build":
            build(attempt, manifest, inputs + runtime_stock_inputs, boundary)
        else:
            result = native(attempt, manifest, inputs, boundary, args.peer_build_attempt)
        _, after_inputs = preparation_guard(args.input_index_sha256)
        after = boundary.guard()
        _, after_runtime_stock_inputs = bind_actual_stock(manifest, boundary)
        require(runtime_stock_inputs == after_runtime_stock_inputs, "Actual stock86 binary seal drifted")
        write(attempt / "inputs-after.json", {"current86_guard": after, "private_preparation": after_inputs})
        require(before == after and inputs == after_inputs, "Current source/build/tool/private inputs drifted")
        write(attempt / "action-complete.json", {
            "action": args.action, "actual_exit_code": 0, "source_commit": manifest["source_commit"],
            "source410_sha256": manifest["source410_sha256"],
            "all_prerequisites_before_after_match": True, "result": result,
            "started_unix": started, "finished_unix": time.time(),
            "elapsed_seconds": time.time() - started,
            "elapsed_monotonic_seconds": time.monotonic() - monotonic,
            "timing_scope": "Actual wall time retained without sleep subtraction; no performance claim"})
    except BaseException as failure:
        write(attempt / "action-failed.json", {"action": args.action, "recorder_failure": repr(failure),
              "source_commit": manifest["source_commit"], "source410_sha256": manifest["source410_sha256"],
              "all_raw_failures_preserved": True, "actual_success": False,
              "started_unix": started, "finished_unix": time.time()})
        raise
    print(json.dumps({"action": args.action, "actual_attempt": str(attempt)}))


if __name__ == "__main__":
    main()
