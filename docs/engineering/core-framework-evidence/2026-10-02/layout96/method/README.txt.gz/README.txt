96是87的有限后继准备。原87所有25indexed bytes/index保持；没有新product/source变更。

已确认的collector问题：87 execute.py原381后置条件仅看engine returncode非null、
precleanup null与owner terminate，因而即使兜底SIGKILL/-9且已reap仍可达native成功。
这是静态加纯synthetic证明，不宣称87实际native运行或87实际出现过强杀。

唯一wrapper执行逻辑变更：在原engine-process.json finally收据写入之后读取该实际收据，
要求owned_process_reaped is True、exit_before null、terminated_by_owner is True、
killed_by_owner is False、actual_exit为exact int -15。强杀兜底仍执行并wait/reap且记录
literal -9，随后失败；main保留action-failed/raw，不得写action-complete。
新postcondition inverse恢复完整87 wrapper bytes。build action不运行engine，保持原逻辑。

原peer CPP/CMake/observations逐字节等于87；独立两GUI process/PID、280/360/170零容差、
Ctrl+U、state/geometry/raw偏好黄金、document/history中立、actualQt/VTK/SQLite image pins
全部保持。public pipeline idle与GUI 30000ms、engine startup15s、两cleanup wait10s不变。
私有Ini/User/System实际format/path preflight仍在allKeys与production construct之前。
原caps、ledger、未知SDK内部copy覆盖不改；无性能工作。

来源与前置约束保持：
/private/tmp/qcae-framework-preference-fix85
HEAD ef0df3bdd8c1b27330d71a596f16098cb6b6410a
source410 15d20f20fef88ed6d1b8637b97edf77143887728cb9c42427620b25429e65c03
guard88 /private/tmp/qcae-framework-reliability-collector88/collect.py
SHA5e2c60060fcb1ed2a86d6f6104434db603294651a46ab0aec8a0a9efc0a9f7ad
新source86真实all7原门禁必须在执行前后由88核对：40/47/47/80/73/91六full，
public74为compile gate、registeredCTest0。根报告86已全部actual0、94只读actual0；
96只读audit未执行88，不用根报告代替将来guard。stock86事实只读检查见
engine-signal-readonly.json；执行wrapper仍先guard，再动态绑定exact86三stock pins。

自有stock engine信号仅只读结论：source85 engine入口QCoreApplication/app.exec，无
product signal handler注册；全源匹配handler仅solver tests/version fixture。实际stock86
Mach-O nm未导入signal/sigaction/sigset。stock86 engine bytes4986552 SHA
7aa2d0e87056f4fade4684fae03f99282c523f1e61ce3473bdbbc9f484e9513c，
与历史79 engine SHA相同；原79 actual -15/unforced/reaped与GUI前置失败全部保留。
该历史运行不重标为96；源/import不能证明所有传递SDK运行信号状态，96实际cleanup仍待根观察。

actual private preparation检查exit0、1.644665002822876s：2835 tracked/410 sources，
135external beforeafter稳定，旧87全部entries与index核对。AST抽取真实old/new谓词，
synthetic positive1/refusal15并检查每个拒绝路径不达completion sentinel。
不是Qt/native/product测试；没有guard/configure/compiler/engine/CLI/GUI执行。
新configured/built/native exits与peer binary为null，planned输出均不存在。

根审核immutable-index实际磁盘SHA后独占执行。将下方外部ROOT_REVIEWED_ACTUAL_INDEX_SHA256
替换交付消息中的真实indexSHA，不能用某entry SHA、旧87SHA或空值。

/Library/Frameworks/Python.framework/Versions/3.14/bin/python3.14 -B /private/tmp/qcae-framework-layout-peer96/execute.py build --attempt 01 --input-index-sha256 ROOT_REVIEWED_ACTUAL_INDEX_SHA256

实际build0并审核warning/binary/config/flags/raw后：

/usr/bin/caffeinate -i /Library/Frameworks/Python.framework/Versions/3.14/bin/python3.14 -B /private/tmp/qcae-framework-layout-peer96/execute.py native --attempt 01 --peer-build-attempt /private/tmp/qcae-framework-layout-runtime96/build-01 --input-index-sha256 ROOT_REVIEWED_ACTUAL_INDEX_SHA256

96 build /private/tmp/qcae-framework96-bp17-builds/peer-01
96 runtime /private/tmp/qcae-framework-layout-runtime96
两个输出新目录拒绝覆盖；原失败与日志不可删除或改写。无完整SK/C3/C4/P0、solver/AI/性能acceptance声明。
