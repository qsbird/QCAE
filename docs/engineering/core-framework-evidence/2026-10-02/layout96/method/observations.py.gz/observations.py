"""Pure BP17 comparison only; no product execution or old collector import."""
import hashlib
import re
FINAL_COMMIT = 'ef0df3bdd8c1b27330d71a596f16098cb6b6410a'
FINAL_TREE = '15d20f20fef88ed6d1b8637b97edf77143887728cb9c42427620b25429e65c03'

def need(condition, message):
    if not condition:
        raise ValueError(message)

def observations(first, second):
    """Pure checks: no measured byte/pixel/PID can be replaced by a bool."""
    for phase, row in (("write", first), ("read", second)):
        need(row.get("phase") == phase and row.get("observation_status") == "exact_boundaries_observed",
             "Peer did not produce an exact actual observation")
        need(row.get("source_commit") == FINAL_COMMIT and row.get("source_tree_sha256") == FINAL_TREE,
             "Peer source identity differs from final commit")
        need(row.get("qt_platform") == "cocoa" and row.get("qt_version"), "Missing actual native Qt provenance")
        need(re.fullmatch(r"[1-9][0-9]*", row.get("process_id", "")), "Missing actual GUI PID")
        configuration = row.get("layout_configuration", {})
        need(configuration.get("dock_names") == ["analysisDock", "historyDock", "modelViewsDock", "modelingDock", "selectionPropertiesDock"],
             "Dock catalog count/names differ")
        need(configuration.get("toolbar_names") == ["selectionToolbar", "workspaceToolbar"], "Toolbar catalog differs")
        need(configuration.get("fixed_panel_count") == 3 and configuration.get("fixed_panels") == {
            "modelViewsDock_width": 280, "selectionPropertiesDock_width": 360, "historyDock_height": 170},
             "Exact fixed dimensions differ; no pixel tolerance applies")
        docks, toolbars = configuration.get("docks", {}), configuration.get("toolbars", {})
        need(set(docks) == set(configuration["dock_names"]) and set(toolbars) == set(configuration["toolbar_names"]),
             "Named catalog entries do not match exact configuration")
        for name, entry in docks.items():
            area = 1 if name == "modelViewsDock" else 8 if name == "historyDock" else 2
            need(entry.get("area") == area and entry.get("floating") is False
                 and entry.get("hidden") is (name == "analysisDock"), "Fixed dock position/visibility differs: " + name)
            need(isinstance(entry.get("tabified_with"), list), "Missing actual tab relationships: " + name)
        for name, entry in toolbars.items():
            need(entry == {"area": 4, "floating": False, "hidden": False}, "Fixed toolbar configuration differs: " + name)
        for field in ("serialized_state_base64", "serialized_geometry_base64", "raw_preferences_base64", "raw_preferences_sha256"):
            need(isinstance(row.get(field), str) and row[field], "Missing actual serialized preference bytes: " + field)
        import base64
        raw = base64.b64decode(row["raw_preferences_base64"], validate=True)
        need(hashlib.sha256(raw).hexdigest() == row["raw_preferences_sha256"], "Raw preference bytes/hash mismatch")
        need(row.get("shortcut") == "Ctrl+U", "Actual shortcut differs")
        need(row.get("settings_keys") == ["layout/geometry", "layout/state", "shortcuts/historyUndoAction"],
             "Unexpected preference key count/configuration")
        need(row.get("model_before") == row.get("model_after") and isinstance(row.get("model_before"), dict),
             "Layout changed engine model")
        need(row.get("history_before") == row.get("history_after") and isinstance(row.get("history_before"), dict),
             "Layout changed engine history")
    need(first["process_id"] != second["process_id"], "The GUI did not restart as a fresh process")
    for key in ("qt_version", "layout_configuration", "serialized_state_base64", "serialized_geometry_base64", "shortcut",
                "raw_preferences_base64", "raw_preferences_sha256", "settings_file", "settings_keys", "model_after", "history_after"):
        need(first[key] == second[key], "Fresh-process golden comparison differs: " + key)
    return {"first_gui_pid": first["process_id"], "second_gui_pid": second["process_id"],
            "actual_dimensions": first["layout_configuration"]["fixed_panels"],
            "document_revision_before": first["model_before"].get("revision"),
            "document_revision_after": second["model_after"].get("revision"),
            "raw_preferences_sha256": first["raw_preferences_sha256"]}
