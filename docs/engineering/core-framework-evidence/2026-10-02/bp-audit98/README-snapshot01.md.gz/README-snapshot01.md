# Current source85 BP mechanism review — snapshot01

Source `ef0df3bdd8c1b27330d71a596f16098cb6b6410a`;410 digest `15d20f20fef88ed6d1b8637b97edf77143887728cb9c42427620b25429e65c03`. Private read-only audit attempt03 exited0 in2.726313s;488 recorded input facts and all2835 frozen tracked files matched before/after. No guard/compiler/test/engine/CLI/GUI executed by this auditor.

This is a mechanism evidence map. It records19 bounded current-source mechanisms and BP13 actual95 failure, preserving the canonical20 denominator; it is not20/20 acceptance or fullP0/SK14/97 completion. Root99 build may be active; no99 GUI PASS is accepted here.

| BP | Current evidence and limit |
|---|---|
| BP-01 | 90 original six: normal-open/new DocId and real kill/recover/epoch checks. |
| BP-02 | 86 material_description_ipc plus frozen record-v1 codec/assertions; field generation/query/edit/history. |
| BP-03 | 86 named geometry evaluation u0/.5/1; exact ID after save/open. |
| BP-04 | 90 original six stale binding, regenerate120mm and reject_unmapped atomicity. |
| BP-05 | 90 actual M11/10 plus86 four real worker negative assertions. |
| BP-06 | 86 stable-ID/number/container permutation and25public BDF bijections/readback. |
| BP-07 | 86 actual cli/script reports: two changed IDs, single batch transaction, undo/redo. |
| BP-08 | 90 original six assembly/set membership shares original11IDs. |
| BP-09 | 86 exact units/coordinates/table named assertions. |
| BP-10 | 90 actual six passive ON categories called;86 applicable OFF service/package regressions separate. |
| BP-11 | 86 exact analysis/LoadCase refs; task ID is explicitly rejected as analysis. |
| BP-12 | 90 original six:100 undo/redo rounds with exact M goldens. |
| BP-13 | 95 actual1 after cancel.enter/pick; Y1 keyboard input failed.99 has no actual GUI result yet. |
| BP-14 | 86 one located missing-load issue, repair0/current and oldcheck stale. |
| BP-15 | 90 currentM duplicate-GRID import atomic refusal +86 separate frozen legacy fixtures; no fabricated completeM migration. |
| BP-16 | 86 actual12 named point/line/Tri3 frozen VTK PICK cases and exact2fixture hashes. |
| BP-17 | 96 two fresh Cocoa GUI peers actual0/0;280/360/170 exact and all preference/document goldens unchanged. |
| BP-18 | 88 actual CLI3/GUI3/MIX3,72checkpoints/9ID bijections/0semantic differences; current86 bytes preserved. |
| BP-19 | 86 explicit fixture result endpoints/metadata/provenance, stale physical edit and undo-current. |
| BP-20 | 86 actual workers2/queue8/ninth quota rejection; child86;10 recovered tasks interrupted/no rerun. |

Six original applicable current86 full suites total378 (40/47/47/80/73/91); all7builds have warning0 per actual94 audit. Public74 remains compile proof with registeredCTest0. Current90 typed20/106 is compiler proof, not runtime74 or BP denominator.

96 native wrapper actual0 contains peer0/0, readiness CLI3 once and owned engine-15/unforced/reaped. Each status is scoped literally. GUI actual external writes0; MIX actual external shared-service writes3 per run; observer writes0. Loaded image bytes/hash facts do not measure SDK internal copies.

The first two private audit failures are preserved in attempt01/02. Attempt01 incorrectly imposed external writes0 on MIX; attempt02 used a wrong95 step-key name. Both were auditor errors; no product tests ran. Positive attempt03 and both raw failures remain separate.

BP13 input diagnosis: the95 private peer sent Meta+A. The exact Qt6.11.1 standard binding and line-control handler expect the SelectAll semantic key; default Apple Qt modifier mapping uses Control for Command. Use `QTest::keySequence(&field, QKeySequence(QKeySequence::SelectAll))` while retaining mouseClick, real typing, exact Y1, pick, revision deltas and30000ms. This method correction awaits a fresh actual99 native result. [Qt binding](https://raw.githubusercontent.com/qt/qtbase/v6.11.1/src/gui/kernel/qplatformtheme.cpp), [line-control handler](https://raw.githubusercontent.com/qt/qtbase/v6.11.1/src/widgets/widgets/qwidgetlinecontrol.cpp), [key event helper](https://raw.githubusercontent.com/qt/qtbase/v6.11.1/src/testlib/qtestkeyboard.h).

Proof: [compact map](BP20-compact-snapshot01.json), [full source/raw map](attempt-03/BP20-source85-map-snapshot01.json), [488 immutable input facts](attempt-03/input-facts-beforeafter.json), [actual audit receipt](attempt-03/audit-receipt.json), [keyboard diagnosis](BP13-keyboard-diagnosis.json).

Snapshot01 remains unchanged. Later99 outcomes require an append-only current-runtime addendum before final delivery seal. Old68 raw/PASS records are not accepted as current85 proof. No real solver/external AI or engineering validation claim is made.
