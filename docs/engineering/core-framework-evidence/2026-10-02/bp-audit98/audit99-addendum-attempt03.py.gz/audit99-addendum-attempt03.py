"""Read existing actual99 evidence only; no collector/validator/product imports."""
from pathlib import Path
import copy
import hashlib
import json
import subprocess
import time

HERE = Path(__file__).resolve().parent
SOURCE = Path('/private/tmp/qcae-framework-preference-fix85')
PEER = Path('/private/tmp/qcae-framework-BP13-peer99')
RUN = Path('/private/tmp/qcae-framework-BP13-runtime99')
COMMIT = 'ef0df3bdd8c1b27330d71a596f16098cb6b6410a'
DIGEST = '15d20f20fef88ed6d1b8637b97edf77143887728cb9c42427620b25429e65c03'
facts = {}


def fact(path):
    p = Path(path).resolve()
    raw = p.read_bytes()
    return {'path': str(p), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def text(path):
    p = Path(path).resolve()
    actual = fact(p)
    if str(p) in facts:
        assert facts[str(p)] == actual
    facts[str(p)] = actual
    return p.read_text()


def read(path):
    return json.loads(text(path))


def save(name, value):
    with (HERE / name).open('x') as output:
        json.dump(value, output, ensure_ascii=False, indent=2)
        output.write('\n')


def verify(item):
    actual = fact(item['path'])
    assert actual['sha256'] == item['sha256']
    if 'bytes' in item:
        assert actual['bytes'] == item['bytes']
    facts[actual['path']] = actual


def descriptors(value):
    if isinstance(value, dict):
        if {'path', 'sha256'} <= value.keys():
            verify(value)
        else:
            for child in value.values():
                descriptors(child)
    elif isinstance(value, list):
        for child in value:
            descriptors(child)


def bound(value):
    assert value['source_commit'] == COMMIT and value['source410_sha256'] == DIGEST


snapshot_index = HERE / 'snapshot01-immutable-index.json'
assert fact(snapshot_index)['sha256'] == '30fd4f582f0570be56800b654e8eedf2a4dda40f27b370d199a121729fe3ede4'
snapshot = read(snapshot_index)
for item in snapshot['entries']:
    verify({**item, 'path': str(HERE / item['path'])})
frozen = read('/private/tmp/qcae-framework-preference-evidence85/frozen-candidate.json')
assert frozen['commit'] == COMMIT and frozen['source410_sha256'] == DIGEST
assert len(frozen['tracked_files']) == 2835 and len(frozen['source_files']) == 410
for name, item in frozen['tracked_files'].items():
    verify({**item, 'path': str(SOURCE / name)})

index_path = PEER / 'immutable-index.json'
assert fact(index_path)['sha256'] == '553c4abfc4a8f9bb05e0720e3d814e754f1e62564caaf9f7cccc8700c93a1e2e'
index = read(index_path)
bound(index)
assert len(index['files']) == 18
for item in index['files']:
    verify({**item, 'path': str(PEER / item['relative_path'])})
old_cpp = text('/private/tmp/qcae-framework-BP13-peer95/peer/peer.cpp')
new_cpp = text(PEER / 'peer/peer.cpp')
assert old_cpp.count('QTest::keyClick(&field, Qt::Key_A, Qt::MetaModifier);') == 1
expected_cpp = old_cpp.replace('#include <QJsonObject>\n', '#include <QJsonObject>\n#include <QKeySequence>\n', 1)
expected_cpp = expected_cpp.replace('QTest::keyClick(&field, Qt::Key_A, Qt::MetaModifier);',
                                    'QTest::keySequence(&field, QKeySequence(QKeySequence::SelectAll));', 1)
assert new_cpp == expected_cpp
for name in ('peer/CMakeLists.txt', 'observations.py'):
    assert text(PEER / name) == text(Path('/private/tmp/qcae-framework-BP13-peer95') / name)
assert 'elapsed.elapsed() < 30000' in new_cpp
assert 'QTest::mouseClick(&field, Qt::LeftButton);' in new_cpp and 'QTest::keyClicks(&field, "1");' in new_cpp
assert 'require(field.text() == "1", "Actual keyboard input did not set physical Y=1mm");' in new_cpp

build = read(RUN / 'build-01/peer-build-complete.json')
bound(build)
assert build['actual_exit_code'] == 0 and build['CXX_EXTENSIONS'] == 'OFF'
assert build['actual_compile_count'] == 75 and build['actual_peer_compile_count'] == 1 and not build['compiler_warnings']
for key in ('binary', 'cache', 'compile_commands', 'configure_receipt', 'build_receipt'):
    verify(build[key])
for key in ('configure_receipt', 'build_receipt'):
    command = read(build[key]['path'])
    bound(command)
    assert command['actual_exit_code'] == 0 and command['recorder_error'] is None
    verify(command['stdout'])
    verify(command['stderr'])
compiles = read(build['compile_commands']['path'])
peer_compile = [row for row in compiles if Path(row['file']).resolve() == PEER / 'peer/peer.cpp']
assert len(compiles) == 75 and len(peer_compile) == 1
assert '-std=c++20' in peer_compile[0]['command'] and '-std=gnu++20' not in peer_compile[0]['command']

native = RUN / 'native-02'
complete = read(native / 'action-complete.json')
bound(complete)
assert complete['actual_exit_code'] == 0 and complete['all_prerequisites_before_after_match'] is True
assert complete['result']['actual_peer_commands'] == 1 and complete['result']['actual_peer_exit_codes'] == [0]
assert complete['result']['all_owned_processes_terminal'] is True
for key in ('comparison', 'engine_lifecycle', 'loaded_images'):
    verify(complete['result'][key])
before, after = (read(native / name) for name in ('inputs-before.json', 'inputs-after.json'))
assert before['current86_guard'] == after['current86_guard']
assert before['private_preparation'] == after['all_current_action_input_facts']
assert all(item in before['private_preparation'] for item in after['private_preparation'])
descriptors(before)
descriptors(after)
cmp = read(native / 'lifecycle-comparison.json')
bound(cmp)
for key in ('actual_observation', 'runtime_command', 'fixture_bootstrap'):
    verify(cmp[key])
for item in cmp['private_settings_files']:
    verify(item)
actual = read(cmp['actual_observation']['path'])
assert actual['source_commit'] == COMMIT and actual['source_tree_sha256'] == DIGEST
assert actual['actual_exit_code'] == 0 and actual['observation_status'] == 'paired_lifecycle_observed'
assert actual['qt_platform'] == 'cocoa' and actual['qt_version'] == '6.11.1'
assert actual['observer_model_writes'] == 0
settings_root = str(native / 'settings')
assert actual['settings_isolation'] == {'format': 'IniFormat', 'initial_system_empty': True, 'initial_user_empty': True,
    'production_default_format_respected': True, 'root': settings_root, 'system_file': settings_root + '/system/QCAE/Desktop.ini',
    'system_scope': 'SystemScope', 'user_file': settings_root + '/QCAE/Desktop.ini', 'user_scope': 'UserScope'}
assert actual['settings_file'] == settings_root + '/QCAE/Desktop.ini'
setup = actual['setup']
target = setup['node_id']
assert setup['M_nodes'] == 11 and setup['M_beams'] == 10 and setup['node_position_mm'] == [500, 0, 0]
golden = setup['golden']
assert sum(v['kind'] == 'node' for v in golden['model'].values()) == 11
assert sum(v['kind'] == 'beam' for v in golden['model'].values()) == 10
expected_steps = ['cancel.enter', 'cancel.pick', 'cancel.preview', 'cancel.cancel', 'cancel.leave',
                  'apply.enter', 'apply.pick', 'apply.preview', 'apply.apply', 'apply.leave']
assert [row['name'] for row in actual['steps']] == expected_steps
rows = {row['name']: row['observed'] for row in actual['steps']}
for row in [golden, *rows.values(), actual['cancel_leave_apply_noop'], actual['apply_leave_apply_noop']]:
    assert row['current']['document_id'] == golden['current']['document_id']
    assert row['current']['document_epoch'] == golden['current']['document_epoch']
    assert row['pipeline_idle'] is True and row['pipeline_diagnostics']['idle'] is True
    assert row['pipeline_diagnostics']['tree_revision'] == row['pipeline_diagnostics']['revision'] == row['current']['revision'] == row['history']['revision']
    ids = [item['transaction_id'] for item in row['history']['items']]
    assert len(ids) == len(set(ids)) and all(item['applied'] is True for item in row['history']['items'])
for name in expected_steps[:8]:
    for key in ('current', 'history', 'model'):
        assert rows[name][key] == golden[key], (name, key)
for branch in ('cancel', 'apply'):
    for phase, ids in (('pick', [target]), ('leave', [])):
        event = next(row['actual_input'] for row in actual['steps'] if row['name'] == branch + '.' + phase)
        assert event['picked_ids'] == ids and event['through'] is False and event['picked_signal_count'] == 1
        assert len(event['logical_pixel']) == 2 and all(type(v) is int and v >= 0 for v in event['logical_pixel'])
        assert event['device_pixel_ratio'] > 0
        assert event['trigger'] == 'QTest::mouseClick on actual QVTKOpenGLNativeWidget; no emitted/invoked fake signal'
    assert rows[branch + '.preview']['property_fields'][1] == {'text': '1', 'enabled': True}
    assert rows[branch + '.preview']['preview_id'] and rows[branch + '.preview']['cancel_enabled'] is True
    left = rows[branch + '.leave']
    assert left['selected_label'] == 'No selection' and left['preview_id'] == '' and left['cancel_enabled'] is False
    assert left['property_fields'] == [{'enabled': False, 'text': ''}] * 4
assert rows['cancel.preview']['preview_id'] != rows['apply.preview']['preview_id']
assert rows['cancel.cancel']['preview_id'] == '' and rows['cancel.cancel']['cancel_enabled'] is False
assert actual['cancel_revision_delta'] == '0' and actual['apply_revision_delta'] == '1'
applied = rows['apply.apply']
assert int(applied['current']['revision']) == int(golden['current']['revision']) + 1
assert applied['preview_id'] == ''
assert applied['history']['cursor'] == golden['history']['cursor'] + 1
assert len(applied['history']['items']) == len(golden['history']['items']) + 1
assert applied['history']['items'][:-1] == golden['history']['items']
new_transaction = applied['history']['items'][-1]['transaction_id']
assert new_transaction not in {item['transaction_id'] for item in golden['history']['items']}
expected_model = copy.deepcopy(golden['model'])
expected_model[target]['fields']['position'] = [500, 1, 0]
assert applied['model'] == expected_model
for actual_row, expected_row in ((actual['cancel_leave_apply_noop'], golden), (rows['apply.leave'], applied), (actual['apply_leave_apply_noop'], applied)):
    for key in ('current', 'history', 'model'):
        assert actual_row[key] == expected_row[key]
for row in (actual['cancel_leave_apply_noop'], actual['apply_leave_apply_noop']):
    assert row['selected_label'] == 'No selection' and row['preview_id'] == '' and row['cancel_enabled'] is False
    assert row['property_fields'] == [{'enabled': False, 'text': ''}] * 4
assert actual['observer_reads']
for item in actual['observer_reads']:
    assert item['operation'] in ('project.current', 'history.list', 'entity.query', 'entity.fields')
    assert item['request_id'] == item['response']['request_id'] and item['response']['status'] == 'success'
assert cmp['final_engine_current'] == applied['current']
observed = cmp['observed']
assert observed['contract_steps'] == expected_steps and observed['cancel_revision_delta'] == 0 and observed['apply_revision_delta'] == 1
assert observed['new_persistent_transactions'] == 1 and observed['actual_transaction_id'] == new_transaction
assert observed['formal_target_viewport_picks'] == observed['formal_empty_viewport_leaves'] == 2
assert observed['post_leave_apply_extra_writes'] == observed['observer_model_writes'] == 0
assert observed['after_position_mm'] == [500, 1, 0] and observed['all_other_entity_fields_unchanged'] is True
command = read(cmp['runtime_command']['path'])
bound(command)
assert command['actual_exit_code'] == 0 and command['recorder_error'] is None and command['pid'] == int(actual['process_id'])
assert command['actual_argv'][3] == build['binary']['path']
for key in ('stdout', 'stderr', 'validator_combined_actual_log'):
    verify(command[key])
# This peer writes its observation file, not JSON to stdout; source save(output, report) matches that contract.
assert text(command['stdout']['path']) == ''
assert any(item['path'] == cmp['actual_observation']['path'] and item['sha256'] == cmp['actual_observation']['sha256'] for item in command['emitted_artifacts'])
engine = read(native / 'engine-process.json')
bound(engine)
assert engine['actual_exit_code'] == -15 and engine['exit_code_before_owned_cleanup'] is None
assert engine['terminated_by_owner'] is True and engine['killed_by_owner'] is False and engine['owned_process_reaped'] is True
for key in ('stdout', 'stderr', 'binary'):
    verify(engine[key])
images = read(native / 'observed-images.json')
assert len(images['all_actual_external_image_facts']) == 103
descriptors(images['all_actual_external_image_facts'])
for row in (images['engine'], images['GUI']):
    verify(row['raw_log'])
    raw = text(row['raw_log']['path'])
    assert row['raw_image_count'] > 0 and 'dyld[' + str(row['observed_pid']) + ']' in raw
    for item in row['external_images']:
        verify(item)
        assert item['observed_path'] in raw
commands = []
for path in sorted((native / 'commands').glob('*.json')):
    record = read(path)
    if 'actual_argv' not in record or 'actual_exit_code' not in record:
        continue
    for key in ('stdin', 'stdout', 'stderr'):
        if key in record:
            verify(record[key])
    if record['actual_exit_code'] != 0:
        assert path.name == 'bootstrap-001-capabilities-list.json' and record['actual_exit_code'] == 3
        assert record['request']['operation'] == 'capabilities.list'
        assert text(record['stdout']['path']) == ''
        assert text(record['stderr']['path']).strip() == 'Engine is not available: QLocalSocket::connectToServer: Invalid name'
    commands.append({'path': str(path), 'actual_exit_code': record['actual_exit_code']})
assert sum(item['actual_exit_code'] == 3 for item in commands) == 1
old_failure = read(RUN / 'native-01/action-failed.json')
bound(old_failure)
assert old_failure['actual_success'] is False and not (RUN / 'native-01/action-complete.json').exists()
failed_engine = read(RUN / 'native-01/engine-process.json')
bound(failed_engine)
assert failed_engine['actual_exit_code'] == 4 and failed_engine['exit_code_before_owned_cleanup'] == 4
assert failed_engine['terminated_by_owner'] is False and failed_engine['killed_by_owner'] is False and failed_engine['owned_process_reaped'] is True
verify(failed_engine['stdout'])
verify(failed_engine['stderr'])
assert 'QLocalServer::listen: Unknown error 1' in text(failed_engine['stderr']['path'])
assert not (RUN / 'native-01/commands/BP13-paired-lifecycle.json').exists()
for p in sorted((RUN / 'native-01').rglob('*')):
    if p.is_file():
        facts[str(p.resolve())] = fact(p)

readonly_git = []
for i, argv in enumerate((['git', 'rev-parse', 'HEAD'], ['git', 'status', '--porcelain=v1']), 1):
    start, clock = time.time(), time.monotonic()
    result = subprocess.run(argv, cwd=SOURCE, capture_output=True)
    for key in ('stdout', 'stderr'):
        p = HERE / ('addendum-readonly-git-' + str(i) + '.' + key + '.log')
        with p.open('xb') as output:
            output.write(getattr(result, key))
        facts[str(p)] = fact(p)
    assert result.returncode == 0 and result.stdout.decode().strip() == (COMMIT if i == 1 else '')
    readonly_git.append({'actual_argv': argv, 'actual_exit_code': result.returncode, 'started_unix': start, 'elapsed_monotonic_seconds': time.monotonic() - clock})
for expected in facts.values():
    assert fact(expected['path']) == expected
addendum = {'kind': 'Independent read-only actual99 BP13 addendum; bounded mechanism only', 'source_commit': COMMIT,
    'source410_sha256': DIGEST, 'actual_root_native_wrapper_exit': 0, 'actual_peer_exit': 0, 'actual_engine_exit': -15,
    'engine_unforced_reaped': True, 'actual_native_completion': fact(native / 'action-complete.json'),
    'actual_observation': fact(native / 'BP13-node-move-lifecycle.json'), 'actual_comparison': fact(native / 'lifecycle-comparison.json'),
    'independently_recomputed_observed_invariants': observed, 'actual_peer_argv': command['actual_argv'],
    'actual_observer_read_count': len(actual['observer_reads']), 'all_actual_command_exit_statuses': commands,
    'actual_build': {'configure_exit': 0, 'build_exit': 0, 'compile_entries': 75, 'peer_entries': 1, 'CXX_EXTENSIONS': 'OFF', 'warnings': 0, 'binary': build['binary']},
    'CPP_diff_scope': 'Exactly public QKeySequence include plus Meta+A replaced by StandardKey keySequence; mouseClick/keyClicks/exactY1/30000ms preserved; CMake and pure observations bytes equal95',
    'native99_01_failure': {'actual_engine_exit': 4, 'actual_stderr': 'QLocalServer::listen: Unknown error 1', 'GUI_started': False,
       'failure_record': fact(RUN / 'native-01/action-failed.json'), 'scope': 'Recorded pre-GUI server-listen failure, not another physical keyboard failure; environment attribution requires root runner context'},
    'old_snapshot01_preserved': fact(snapshot_index), 'tracked2835_source410_preserved': True,
    'existing_create30': {'current_report': cmp['existing_create30']['report'], 'current_full_raw': cmp['existing_create30']['full_raw_log'],
       'literal_inherited_status': cmp['existing_create30']['status'], 'limit': 'Its inherited Pending string is retained; actual86/94 full source-bound30 support is separately verified by snapshot01. It is not paired node.move evidence.'},
    'limits': ['Only existing node.move property representative; leave means blank viewport pick/empty engine selection, not dock close or Escape.',
       'Original create-line30 remains a separate population.', 'No fullSK14/P0/97 metrics or real solver/external AI claim.', 'Loaded image facts are not SDK internal copy measurement.'],
    'actual_auditor_scope': 'Read-onlyGit/data/source/hash checks only; no guard import/call, CMake/compiler/test/engine/CLI/GUI', 'actual_readonly_git': readonly_git}
save('BP13-actual99-addendum.json', addendum)
final = read(HERE / 'attempt-03/BP20-source85-map-snapshot01.json')
old_row = next(row for row in final['cases'] if row['case_id'] == 'BP-13')
old_row['historical_failed_predecessor95'] = old_row.pop('actual95')
old_row['historical_failed_private_assertions95'] = [item for item in old_row['current_source_assertions'] if '/qcae-framework-BP13-peer95/' in item['path']]
old_row['current_source_assertions'] = [item for item in old_row['current_source_assertions'] if '/qcae-framework-BP13-peer95/' not in item['path']]
old_row['current_source_assertions'].append({'path': str(PEER / 'peer/peer.cpp'), 'line': 190, 'last_line': 196, 'assertion_scope': 'Actual StandardKey keyboard input preserves mouseClick/real keyClicks and exactY1 before complete two-branch actual trace', 'span_sha256': hashlib.sha256(('\n'.join(new_cpp.splitlines()[189:196]) + '\n').encode()).hexdigest()})
old_row['status'] = 'CURRENT_SOURCE_BOUNDED_MECHANISM_EVIDENCE'
old_row['actual99_addendum'] = fact(HERE / 'BP13-actual99-addendum.json')
old_row['current_private_actual_source'] = {'path': str(PEER / 'peer/peer.cpp'), 'line': 190, 'scope': addendum['CPP_diff_scope']}
old_row['limits'] = addendum['limits']
final['statuses'] = {'CURRENT_SOURCE_BOUNDED_MECHANISM_EVIDENCE': 20}
final['snapshot01_superseded_BP13_status_only'] = True
final['final_addendum_unix'] = time.time()
final['snapshot01_immutable_index'] = fact(snapshot_index)
final['acceptance_registry_update'] = False
save('BP20-final-current-mechanisms.json', final)
save('addendum-input-facts-beforeafter.json', {'all_input_facts_stable': True, 'actual_count': len(facts), 'facts': list(facts.values()), 'snapshot01_all38_entries_unchanged': True, 'source_tracked2835_unchanged': True})
print(json.dumps({'actual_readonly_audit': 'complete', 'bounded_current_mechanisms': 20, 'BP13_actual99_steps': 10,
    'actual_old95_failure_preserved': True, 'actual99_native01_preGUI_failure_preserved': True, 'input_facts': len(facts), 'global_acceptance': False}))
