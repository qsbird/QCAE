"""Read-only BP mechanism mapping; never import a collector or execute products."""
from pathlib import Path
import base64
import hashlib
import json
import re
import subprocess
import time

HERE = Path(__file__).resolve().parent
SOURCE = Path('/private/tmp/qcae-framework-preference-fix85')
RUN86 = Path('/private/tmp/qcae-framework-runtime86')
BUILD86 = Path('/private/tmp/qcae-framework86-builds')
RUN90 = Path('/private/tmp/qcae-framework-supplement90/attempts/supplement90-01')
RUN88 = Path('/private/tmp/qcae-framework-reliability-collector88/attempts')
COMMIT = 'ef0df3bdd8c1b27330d71a596f16098cb6b6410a'
DIGEST = '15d20f20fef88ed6d1b8637b97edf77143887728cb9c42427620b25429e65c03'
facts = {}


def fact(path):
    path = Path(path).resolve()
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def text(path):
    path = Path(path).resolve()
    value = fact(path)
    if str(path) in facts:
        assert facts[str(path)] == value, str(path)
    facts[str(path)] = value
    return path.read_text()


def read(path):
    return json.loads(text(path))


def save(name, value):
    with (HERE / name).open('x') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')


def verify(item):
    actual = fact(item['path'])
    assert actual['sha256'] == item['sha256'], item['path']
    if 'bytes' in item:
        assert actual['bytes'] == item['bytes'], item['path']
    facts[actual['path']] = actual


def bound(value):
    assert value['source_commit'] == COMMIT and value['source410_sha256'] == DIGEST


def span(relative, first, last, label):
    path = SOURCE / relative if not relative.startswith('/') else Path(relative)
    lines = text(path).splitlines()
    assert 1 <= first <= last <= len(lines), (path, first, last)
    selected = '\n'.join(lines[first - 1:last]) + '\n'
    return {'path': str(path), 'line': first, 'last_line': last,
            'assertion_scope': label, 'span_sha256': hashlib.sha256(selected.encode()).hexdigest()}


frozen = read('/private/tmp/qcae-framework-preference-evidence85/frozen-candidate.json')
assert frozen['commit'] == COMMIT and frozen['source410_sha256'] == DIGEST
assert len(frozen['tracked_files']) == 2835 and len(frozen['source_files']) == 410
for name, expected in frozen['tracked_files'].items():
    actual = fact(SOURCE / name)
    assert actual['bytes'] == expected['bytes'] and actual['sha256'] == expected['sha256'], name
commands = []
for index, argv in enumerate((['git', 'rev-parse', 'HEAD'], ['git', 'status', '--porcelain=v1'], ['git', 'ls-tree', '-rz', 'HEAD']), 1):
    started, monotonic = time.time(), time.monotonic()
    completed = subprocess.run(argv, cwd=SOURCE, capture_output=True)
    logs = {}
    for field in ('stdout', 'stderr'):
        path = HERE / ('readonly-git-' + str(index) + '.' + field + '.log')
        with path.open('xb') as stream:
            stream.write(getattr(completed, field))
        logs[field] = fact(path)
    commands.append({'actual_argv': argv, 'cwd': str(SOURCE), 'actual_exit_code': completed.returncode,
                     'started_unix': started, 'finished_unix': time.time(),
                     'elapsed_monotonic_seconds': time.monotonic() - monotonic, **logs})
    assert completed.returncode == 0
    if index < 3:
        assert completed.stdout.decode().strip() == (COMMIT if index == 1 else '')
    else:
        modes = {}
        for record in completed.stdout.split(b'\0'):
            if record:
                descriptor, name = record.split(b'\t', 1)
                modes[name.decode()] = descriptor.decode().split()[0]
        digest = hashlib.sha256(b'QCAE-C4-SOURCE-SHA256-v1\0')
        for name in sorted(frozen['source_files'], key=lambda value: value.encode()):
            encoded = name.encode()
            actual = fact(SOURCE / name)
            assert actual['sha256'] == frozen['source_files'][name], name
            digest.update(len(encoded).to_bytes(8, 'big'))
            digest.update(encoded)
            digest.update(modes[name].encode())
            digest.update(bytes.fromhex(actual['sha256']))
        assert digest.hexdigest() == DIGEST

requirements = {}
for line, value in enumerate(text(SOURCE / 'docs/baseline/skeleton-acceptance.md').splitlines(), 1):
    match = re.match(r'\| (BP-\d\d) / AP-\d\d \| (.*) \|', value)
    if match:
        requirements[match[1]] = {'path': str(SOURCE / 'docs/baseline/skeleton-acceptance.md'),
                                 'line': line, 'canonical_requirement': match[2]}
assert len(requirements) == 20
review94 = read('/private/tmp/qcae-framework-matrix-review94/attempts/matrix94-01/01-review.json')
desktop94 = read('/private/tmp/qcae-framework-matrix-review94/attempts/matrix94-01/02-desktop-addendum.json')
complete94 = read('/private/tmp/qcae-framework-matrix-review94/attempts/matrix94-01/complete.json')
for value in (review94, desktop94, complete94):
    bound(value)
assert complete94['actual_review_exits'] == [0, 0]
for key in ('main_review', 'desktop_review', 'source_before', 'source_after'):
    verify(complete94[key])
logs = {}
foundation = []
for matrix in review94['matrices']:
    name = matrix['matrix']
    if name == 'public_consumers':
        continue
    assert matrix['status'] == 'complete' and matrix['actual_exit_code'] == 0
    assert matrix['compiler_warnings'] == 0 and not matrix['R0_missing']
    verify(matrix['raw_log'])
    raw = text(matrix['raw_log']['path'])
    headers = list(re.finditer(r'(?m)^(\d+)/(\d+) Testing: ([^\n]+)\n', raw))
    assert len(headers) == matrix['raw_passed'] == len(matrix['applicable_names'])
    rows = {}
    for index, match in enumerate(headers):
        block = raw[match.start():headers[index + 1].start() if index + 1 < len(headers) else len(raw)]
        assert 'Test Passed.' in block, match[3]
        assert match[3] not in rows
        rows[match[3]] = (raw[:match.start()].count('\n') + 1, block)
    assert sorted(rows) == matrix['applicable_names']
    logs[name] = (matrix['raw_log']['path'], rows)
    foundation.append({'matrix': name, 'actual_full_exit': 0, 'original_applicable_count': len(rows),
                       'raw_log_path': matrix['raw_log']['path'], 'warnings': 0, 'R0_missing': []})
assert sorted(row['original_applicable_count'] for row in foundation) == [40, 47, 47, 73, 80, 91]
assert sum(row['original_applicable_count'] for row in foundation) == 378


def entry(name, matrix='desktop'):
    log_path, rows = logs[matrix]
    line, block = rows[name]
    command = next(row.removeprefix('Command: ') for row in block.splitlines() if row.startswith('Command: '))
    assert 'qcae-framework68-builds' not in command and 'qcae-framework-architecture-fix65' not in command
    status = [row for row in block.splitlines() if row == 'Test Passed.']
    witnesses = [row for row in block.splitlines() if row.startswith(('PASS:', 'Totals:'))]
    return {'CTest_case': name, 'matrix': matrix, 'raw_log_path': log_path, 'raw_start_line': line,
            'actual_command_line': command, 'actual_recorded_test_result': status[0],
            'stdout_named_witness': witnesses[:3], 'block_sha256': hashlib.sha256(block.encode()).hexdigest()}


mechanism_file = BUILD86 / 'desktop/c3-evidence/representatives/mechanism-representatives.jsonl'
mechanism_rows = {}
for line, raw in enumerate(text(mechanism_file).splitlines(), 1):
    row = json.loads(raw)
    assert row['passed'] is True and not row['error'] and all(item['passed'] is True for item in row['assertions'])
    # This intrinsic historical-style tag is kept literally, never replaced by a source SHA.
    assert row['source_tree_sha256'] == 'mutable-diagnostic'
    assert raw in logs['desktop'][1]['skeleton_representatives'][1]
    mechanism_rows[row['case_id']] = {'raw_record_path': str(mechanism_file), 'jsonl_line': line,
                                    'run_id': row['run_id'], 'intrinsic_source_field': row['source_tree_sha256'],
                                    'source_binding_scope': 'Actual current86 source/build/full raw fences; raw tag is unchanged',
                                    'actual_assertion_count': len(row['assertions']), 'all_assertions_passed': True,
                                    'actual_small_values': {k: v for k, v in row['actual'].items() if len(str(v)) < 120}}
assert set(mechanism_rows) == {'BP-03', 'BP-05-negative', 'BP-06', 'BP-09', 'BP-20'}

complete90 = read(RUN90 / 'complete.json')
bound(complete90)
assert complete90['actual_completed_actions'] == ['signatures', 'representatives', 'package']
assert complete90['all_before_after_match'] is True
for item in complete90['action_completions']:
    verify(item)
rep90 = read(RUN90 / 'representatives/complete.json')
bound(rep90)
assert rep90['actual_exit_code'] == 0 and rep90['actual_cases'] == rep90['actual_passed'] == 6
rep_command = read(RUN90 / 'representatives/commands/representative-six.json')
assert rep_command['actual_exit_code'] == 0 and rep_command['actual_argv'] == rep90['actual_argv']
for field in ('stdout', 'stderr'):
    verify(rep_command[field])
for item in rep90['raw_artifacts']:
    verify(item)
representatives = {}
rep_file = RUN90 / 'representatives/evidence/M-representatives.jsonl'
for line, raw in enumerate(text(rep_file).splitlines(), 1):
    row = json.loads(raw)
    assert row['source_tree_sha256'] == DIGEST and row['passed'] is True
    assert row['assertions'] and all(item['passed'] is True for item in row['assertions'])
    assert row['case_id'] not in representatives
    representatives[row['case_id']] = {'raw_record_path': str(rep_file), 'jsonl_line': line,
                                      'run_id': row['run_id'], 'literal_source_field': row['source_tree_sha256'],
                                      'actual_assertion_count': len(row['assertions']), 'all_assertions_passed': True,
                                      'first_assertion': row['assertions'][0]['expected'],
                                      'last_assertion': row['assertions'][-1]['expected']}
assert set(representatives) == {'BP-01', 'BP-04', 'BP-05', 'BP-08', 'BP-12', 'BP-15'}

package90 = read(RUN90 / 'package/complete.json')
bound(package90)
assert package90['actual_build_exit'] == package90['actual_peer_exit'] == 0
verify(package90['raw_report'])
categories = read(package90['raw_report']['path'])
assert categories['source_commit'] == COMMIT and categories['source_tree_sha256'] == DIGEST
assert categories['observed_category_count'] == 6 and len(categories['categories']) == 6
assert all(row['observation_status'] == 'enumerated_and_called' and row['actual_calls'] for row in categories['categories'])
assert sorted(row['category'] for row in categories['categories']) == ['codecs', 'core', 'operations', 'render', 'ui', 'validation']
package_command = read(RUN90 / 'package/commands/six-category-calls.json')
assert package_command['actual_exit_code'] == 0
for field in ('stdout', 'stderr'):
    verify(package_command[field])
for item in package90['peer_facts']:
    verify(item)

compare_dir = RUN88 / 'comparison88-01'
collect_dir = RUN88 / 'reliability88-01'
for path in (compare_dir / 'action-complete.json', collect_dir / 'action-complete.json'):
    value = read(path)
    bound(value)
    assert value['all_prerequisites_before_after_match'] is True
comparison_complete = read(compare_dir / 'comparison-complete.json')
bound(comparison_complete)
assert comparison_complete['actual_workflows'] == 9 and comparison_complete['checkpoints'] == 72
verify(comparison_complete['result'])
comparison = read(compare_dir / 'workflow-comparison.json')
assert comparison['source_tree_sha256'] == DIGEST and comparison['mode_counts'] == {'CLI': 3, 'GUI': 3, 'MIX': 3}
assert len(comparison['comparisons']) == 72 and len(comparison['identity_bijections']) == 9
assert comparison['semantic_difference_count'] == 0 and not comparison['errors'] and comparison['passed'] is True
assert all(row['passed'] is True and row['difference_count'] == 0 for row in comparison['comparisons'])
compare_command = read(compare_dir / 'commands/workflow-comparison.json')
assert compare_command['actual_exit_code'] == 0
for field in ('stdout', 'stderr'):
    verify(compare_command[field])
for item in comparison['input_files']:
    verify(item)
native_reuse = read(compare_dir / 'native-reuse.json')
bound(native_reuse)
assert len(native_reuse['original_actual_records']) == len(native_reuse['exact_private_copies']) == 6
for original, copied in zip(native_reuse['original_actual_records'], native_reuse['exact_private_copies']):
    verify(original)
    verify(copied)
    assert original['bytes'] == copied['bytes'] and original['sha256'] == copied['sha256']
    assert Path(original['path']).name == Path(copied['path']).name
    assert Path(original['path']).read_bytes() == Path(copied['path']).read_bytes()
verify(native_reuse['full_native_complete'])
verify(native_reuse['full_native_raw_log'])
collect_complete = read(collect_dir / 'collected.json')
bound(collect_complete)
for item in collect_complete['sealed_collection_artifacts']:
    verify(item)
for item in desktop94['native_artifacts']:
    verify(item['json'])
    verify(item['PNG'])
    assert item['source_digest_match'] is True and item['observer_writes'] == 0
    assert item['external_writes'] == (0 if item['mode'] == 'GUI' else 3)
assert len(desktop94['six_named_native_PASS']) == 6 and desktop94['all91_no_QTest_skip'] is True

specs = {
    'BP-01': [('tests/skeleton_representative_ipc_tests.py', 261, 279, 'normal-open changes DocId; real kill/recover preserves DocId, changes epoch and exact M/history')],
    'BP-02': [('tests/material_description_ipc_tests.py', 65, 137, 'null/string generated field, query/edit, one history item, retry, undo/redo, save/normal-open and recover'), ('tests/record_document_tests.cpp', 241, 259, 'frozen v1 lacks field5; current codec defaults description null without changing values')],
    'BP-03': [('tests/skeleton_representative_tests.cpp', 109, 143, 'evaluate u0/.5/1 to0/500/1000; save/normal-open retains GeometryId')],
    'BP-04': [('tests/skeleton_representative_ipc_tests.py', 100, 160, '1000→1200; stale binding;120mm spacing; reject_unmapped atomically preserves all rows/history')],
    'BP-05': [('tests/skeleton_representative_ipc_tests.py', 82, 98, 'real task builds complete M11nodes/10beams'), ('tests/skeleton_representative_tests.cpp', 145, 214, 'empty/self-loop actual worker candidates fail with no authority publication')],
    'BP-06': [('tests/skeleton_representative_tests.cpp', 218, 285, 'separate ID/number/container permutations'), ('tests/skeleton_representative_tests.cpp', 287, 405, 'query all11 original IDs, public BDF decode, number bijection, ordered connectivity/section/physics equality')],
    'BP-07': [('tests/batch_translation_ipc_tests.py', 62, 70, 'select original nodes4/5; local preview/cancel preserves model/history'), ('tests/batch_translation_ipc_tests.py', 112, 144, 'one revision/history item; only selected nodes Y+1; one undo restores complete M; redo/retries')],
    'BP-08': [('tests/skeleton_representative_ipc_tests.py', 221, 241, 'part/assembly/two sets return original11 stableIDs without copying; membership mutation/undo')],
    'BP-09': [('tests/parameter_tests.cpp', 43, 49, 'canonical1m1000mm and210GPa210000MPa'), ('tests/parameter_tests.cpp', 150, 152, 'local1/2/3 to global11/22/33'), ('tests/parameter_tests.cpp', 208, 211, 'linear interpolation.5→1.5'), ('tests/skeleton_representative_tests.cpp', 407, 428, 'named exact four parameter witnesses')],
    'BP-10': [('tests/nastran_disabled_ipc_tests.py', 20, 39, 'OFF no declared profiles/Nastran operations; common create/query/transaction/history still works')],
    'BP-11': [('tests/analysis_check_ipc_tests.py', 134, 153, 'exact LoadCase references; reject deleting referenced force; analysis !=Task ID and reject task-is-analysis'), ('tests/analysis_check_tests.cpp', 138, 165, 'authoritative case and exact force/constraint references; dangling deletion rejection')],
    'BP-12': [('tests/skeleton_representative_ipc_tests.py', 243, 259, 'complete M node5 Y+1 then100 undo/redo rounds, exact pre/post goldens and201 revision delta')],
    'BP-13': [('tests/c3_tool_lifecycle_tests.cpp', 1, 45, 'current86 line-tool coverage is support only; not a substitute for paired node.move enter/pick/leave'), ('/private/tmp/qcae-framework-BP13-peer95/peer/peer.cpp', 137, 175, 'read-only snapshot/cancel/leave neutrality and real viewport mouse pick'), ('/private/tmp/qcae-framework-BP13-peer95/peer/peer.cpp', 189, 195, 'actual failed Meta+A physical keyboard input; Y==1 was not satisfied')],
    'BP-14': [('tests/analysis_check_ipc_tests.py', 155, 186, 'exact1 missing-load issue locates analysis, version binds; repair→zero/current and oldcheck stale'), ('tests/analysis_check_tests.cpp', 184, 199, 'named missing-load location and oldissue invalidation')],
    'BP-15': [('tests/skeleton_representative_ipc_tests.py', 162, 219, 'published complete M deck + duplicate GRID actual model.import rejects with unchanged M/revision/history'), ('tests/legacy_migration_tests.cpp', 248, 328, 'six frozen legacy fixture mechanisms; detached migration preserves identities/facts/redo/save intent'), ('tests/legacy_migration_tests.cpp', 490, 502, 'actual six legacy fixtures and source-byte changes0')],
    'BP-16': [('tests/desktop_tests.cpp', 223, 255, 'load exact two point/line/Tri3 PICK fixture hashes/12named rows'), ('tests/desktop_tests.cpp', 343, 379, 'actual VTK mouse box pick; sorted actualIDs==goldenIDs; Tri3 additional render checks')],
    'BP-17': [('tests/c3_desktop_workflow_tests.cpp', 2108, 2116, 'current86 same QApplication QMainWindow roundtrip support only'), ('/private/tmp/qcae-framework-layout-peer96/peer/peer.cpp', 145, 157, 'strict280/360/170; no tolerance'), ('/private/tmp/qcae-framework-layout-peer96/peer/peer.cpp', 281, 303, 'newprocess state/geometry/raw preference/Ctrl+U exact golden and document-neutral requirement')],
    'BP-18': [('tests/skeleton_workflow_compare.py', 1, 205, 'exact CLI3/GUI3/MIX3 and8checkpoints each; ID bijections and semantic comparison'), ('tests/skeleton_workflow_ipc_tests.py', 1, 30, 'real CLI engine workflow producer, common authoritative services')],
    'BP-19': [('tests/result_fixture_tests.cpp', 139, 156, 'R endpoint values, displacement/mm/global/node/LC1 and fixture provenance'), ('tests/result_fixture_tests.cpp', 267, 280, 'physical node edit stales R; undo restoring physical input current'), ('tests/result_fixture_ipc_tests.py', 122, 137, 'public read_fixture and exact metadata/provenance through current engine')],
    'BP-20': [('tests/skeleton_representative_tests.cpp', 440, 469, 'real workers2/queued8, ninthRESOURCE_LIMIT and actual childExit86'), ('tests/skeleton_representative_tests.cpp', 471, 560, 'recover ten interrupted tasks, strictly increasing events, no rerun, unchanged model/history/revision')],
}
names = {
    'BP-01': ['analysis_check_ipc', 'skeleton_workflow_cli'], 'BP-02': ['material_description_ipc', 'record_document', 'entity_generation', 'generated_entities'],
    'BP-03': ['skeleton_representatives'], 'BP-04': ['geometry_binding_ipc', 'line_mesh_regeneration'], 'BP-05': ['skeleton_representatives', 'geometry_mesh'],
    'BP-06': ['skeleton_representatives'], 'BP-07': ['batch_translation_ipc'], 'BP-08': ['record_query'], 'BP-09': ['parameters', 'skeleton_representatives'],
    'BP-10': ['nastran_package', 'engine_assembly', 'engine_contributions_ipc'], 'BP-11': ['analysis_check_ipc', 'analysis_checks'],
    'BP-12': ['geometry_mesh'], 'BP-13': ['c3_tool_lifecycle', 'modeling_tools'], 'BP-14': ['analysis_check_ipc', 'analysis_checks'],
    'BP-15': ['legacy_migration', 'nastran_artifact_ipc', 'skeleton_workflow_cli'], 'BP-16': ['desktop'], 'BP-17': ['c3_desktop_workflow'],
    'BP-18': ['skeleton_workflow_cli', 'c3_desktop_workflow'], 'BP-19': ['result_fixture_ipc', 'result_fixture'], 'BP-20': ['skeleton_representatives'],
}
cases = []
for number in range(1, 21):
    case = 'BP-' + str(number).zfill(2)
    row = {'case_id': case, **requirements[case],
           'status': 'CURRENT_SOURCE_BOUNDED_MECHANISM_EVIDENCE',
           'current_source_assertions': [span(*item) for item in specs[case]],
           'actual86_named_records': [entry(name) for name in names[case]],
           'global_acceptance_claim': False}
    if case in mechanism_rows:
        row['actual_mechanism_record'] = mechanism_rows[case]
    if case in representatives:
        row['actual90_six_case_record'] = representatives[case]
        row['actual90_command_receipt_path'] = str(RUN90 / 'representatives/commands/representative-six.json')
    if case == 'BP-05':
        row['actual_negative_worker_record'] = mechanism_rows['BP-05-negative']
    if case == 'BP-07':
        reports = []
        for mode in ('cli', 'script'):
            p = BUILD86 / ('desktop/features/mesh_editing/batch-translation-evidence/' + mode + '-report.json')
            report = read(p)
            assert report['mode'] == mode and json.dumps(report) in logs['desktop'][1]['batch_translation_ipc'][1]
            assert report['passed'] is True and len(report['changed_ids']) == 2 and report['transactions_for_batch'] == 1
            assert report['nodes'] == 11 and report['line2'] == 10 and report['single_undo_redo_verified'] is True
            reports.append({'path': str(p), **report})
        row['actual_two_mode_reports'] = reports
    if case == 'BP-10':
        row['actual90_six_categories'] = {'raw_path': package90['raw_report']['path'],
                                        'actual_peer_exit': 0, 'actual_count': 6,
                                        'actual_calls': {item['category']: item['actual_calls'] for item in categories['categories']}}
        row['actual86_OFF_records'] = [entry('nastran_disabled_ipc', 'package_disabled'), entry('engine_assembly', 'package_disabled')]
        row['limits'] = ['Six passive ON categories observed; OFF real common-service regressions and package exclusion are separate.',
                         'No invented OFF six-row observer or generic unified category registry.', 'No active document or engineering solver execution in passive peer.']
    if case == 'BP-15':
        row['limits'] = ['Exact currentM duplicate import and normal-open/BDF mechanisms are combined with separate six frozen legacy-format fixtures.',
                         'Do not describe legacy fixture tests as a newly migrated completeM run unless that exact fixture is identified.']
    if case == 'BP-16':
        block = logs['desktop'][1]['desktop'][1]
        picks = re.findall(r'PASS\s+: DesktopTests::frozenPointAndLinePickingMatrix\(([^)]+)\)', block)
        assert len(picks) == 12 and len(set(picks)) == 12
        assert {kind: sum(p.startswith(kind + '-') for p in picks) for kind in ('point', 'line', 'tri3')} == {'point': 4, 'line': 4, 'tri3': 4}
        fixture_paths = [SOURCE / 'tests/fixtures/vtk-pick-matrix-v1.json', SOURCE / 'tests/fixtures/vtk-tri3-pick-matrix-v1.json']
        for p in fixture_paths:
            f = fact(p)
            assert f['sha256'] in block
            facts[f['path']] = f
        row['actual_PICK_case_names'] = picks
        row['actual_PICK_denominator'] = 12
        row['fixture_hashes_in_actual_log'] = [facts[str(p)] for p in fixture_paths]
    if case == 'BP-18':
        row['actual88_compare'] = {'path': str(compare_dir / 'workflow-comparison.json'),
                                  'command_receipt_path': str(compare_dir / 'commands/workflow-comparison.json'),
                                  'actual_compare_exit': 0, 'mode_counts': comparison['mode_counts'],
                                  'actual_workflows': 9, 'actual_checkpoint_comparisons': 72,
                                  'identity_bijections': 9, 'semantic_difference_count': 0,
                                  'GUI_MIX_origin': 'Byte-preserved current86 actual native6, validated94; no source68 import',
                                  'literal_native_external_writes': {'GUI_each': 0, 'MIX_each': 3}, 'literal_native_observer_writes_each': 0}
        row['limits'] = ['Thin script/shared service proof; real externalAI=false, real engineering solver=false.',
                         'Comparer acceptance_ready is its workflow-local result, notSK14/P0 readiness.']
    if case == 'BP-13':
        failed = Path('/private/tmp/qcae-framework-BP13-runtime95/native-01')
        observer = read(failed / 'BP13-node-move-lifecycle.json')
        assert observer['source_commit'] == COMMIT and observer['source_tree_sha256'] == DIGEST and observer['actual_exit_code'] == 1
        assert observer['error'] == 'Actual keyboard input did not set physical Y=1mm'
        failure = read(failed / 'action-failed.json')
        bound(failure)
        engine = read(failed / 'engine-process.json')
        assert engine['actual_exit_code'] == -15 and engine['killed_by_owner'] is False and engine['owned_process_reaped'] is True
        actual_command = read(failed / 'commands/BP13-paired-lifecycle.json')
        assert actual_command['actual_exit_code'] == 1
        for field in ('stdout', 'stderr'):
            verify(actual_command[field])
        row['status'] = 'CURRENT_NATIVE_FAILED_PAIRED_LIFECYCLE_UNCOMPLETED'
        row['actual95'] = {'observer_path': str(failed / 'BP13-node-move-lifecycle.json'),
                           'actual_command_receipt_path': str(failed / 'commands/BP13-paired-lifecycle.json'),
                           'actual_peer_exit': 1, 'error': observer['error'],
                           'completed_steps': [step['step'] for step in observer['steps']],
                           'actual_engine_cleanup_exit': -15, 'actual_engine_unforced_reaped': True,
                           'cancel_preview_leave_and_apply_branch': 'NOT COMPLETED'}
        row['limits'] = ['Current86 original30 line runs are support, not full paired node.move lifecycle.',
                         'Input-method mapping flaw is read-only diagnosed; no corrected peer run has been imported.']
    if case == 'BP-17':
        native = Path('/private/tmp/qcae-framework-layout-runtime96/native-01')
        complete = read(native / 'action-complete.json')
        bound(complete)
        assert complete['actual_exit_code'] == 0 and complete['all_prerequisites_before_after_match'] is True
        result = complete['result']
        assert result['actual_peer_commands'] == 2 and result['actual_peer_exit_codes'] == [0, 0]
        assert result['all_owned_processes_terminal'] is True
        for key in ('comparison', 'engine_lifecycle', 'loaded_images'):
            verify(result[key])
        cmp = read(native / 'comparison.json')
        bound(cmp)
        assert cmp['pure_comparison_succeeded'] is True and cmp['both_peer_processes_terminal_and_reaped'] is True
        assert cmp['bootstrap_current'] == cmp['final_current']
        first, second = (read(native / (phase + '.json')) for phase in ('write', 'read'))
        for phase, observation in zip(('write', 'read'), (first, second)):
            assert observation['phase'] == phase and observation['observation_status'] == 'exact_boundaries_observed'
            assert observation['source_commit'] == COMMIT and observation['source_tree_sha256'] == DIGEST
            assert observation['qt_platform'] == 'cocoa' and observation['qt_version'] == '6.11.1'
            assert observation['settings_format'] == 1 and observation['settings_scope'] == 0
            assert observation['settings_file'] == str(native / 'settings/QCAE/Desktop.ini')
            assert observation['private_settings_root'] == str(native / 'settings')
            assert observation['model_before'] == observation['model_after'] == cmp['bootstrap_current']
            assert observation['history_before'] == observation['history_after'] == {'cursor': 0, 'items': [], 'revision': '0'}
            assert observation['layout_configuration']['fixed_panels'] == {'historyDock_height': 170, 'modelViewsDock_width': 280, 'selectionPropertiesDock_width': 360}
            assert observation['settings_keys'] == ['layout/geometry', 'layout/state', 'shortcuts/historyUndoAction']
            assert observation['shortcut'] == 'Ctrl+U'
            assert hashlib.sha256(base64.b64decode(observation['raw_preferences_base64'], validate=True)).hexdigest() == observation['raw_preferences_sha256']
        assert first['process_id'] != second['process_id']
        for key in ('layout_configuration', 'serialized_state_base64', 'serialized_geometry_base64', 'raw_preferences_base64', 'raw_preferences_sha256', 'shortcut', 'settings_file', 'settings_keys', 'model_after', 'history_after'):
            assert first[key] == second[key], key
        for key in ('write', 'read'):
            verify(cmp[key])
        for item in cmp['runtime_commands'] + cmp['private_settings_files']:
            verify(item)
        actual_commands = []
        for phase, observation in zip(('write', 'read'), (first, second)):
            cmdpath = native / ('commands/fresh-gui-' + phase + '.json')
            command = read(cmdpath)
            bound(command)
            assert command['actual_exit_code'] == 0 and command['recorder_error'] is None
            assert command['pid'] == int(observation['process_id']) and command['elapsed_monotonic_seconds'] < 30
            assert command['timeout_policy'] == 'No wrapper timeout/threshold introduced; existing producer deadlines unchanged'
            for key in ('stdout', 'stderr', 'validator_combined_actual_log'):
                verify(command[key])
            assert json.loads(text(command['stdout']['path'])) == observation
            assert read(native / ('commands/fresh-gui-' + phase + '.postconditions.json'))['all_before_after_match'] is True
            for item in command['extra_input_facts']:
                verify(item)
            actual_commands.append({'receipt_path': str(cmdpath), 'actual_argv': command['actual_argv'], 'pid': command['pid'], 'actual_exit': 0, 'elapsed_monotonic_seconds': command['elapsed_monotonic_seconds']})
        engine = read(native / 'engine-process.json')
        bound(engine)
        assert engine['actual_exit_code'] == -15 and engine['exit_code_before_owned_cleanup'] is None
        assert engine['terminated_by_owner'] is True and engine['killed_by_owner'] is False and engine['owned_process_reaped'] is True
        for key in ('stdout', 'stderr', 'binary'):
            verify(engine[key])
        images = read(native / 'observed-images.json')
        assert len(images['fresh_gui']) == 2 and len(images['all_observed_external_image_facts']) == 103
        for item in images['all_observed_external_image_facts']:
            verify(item)
        for image_row in [images['engine'], *images['fresh_gui']]:
            verify(image_row['raw_log'])
            raw = text(image_row['raw_log']['path'])
            assert image_row['raw_image_count'] > 0 and 'dyld[' + str(image_row['observed_pid']) + ']' in raw
            for item in image_row['external_images']:
                verify(item)
                assert item['observed_path'] in raw
        readiness = read(native / 'startup-readiness.json')
        assert readiness['retry_count'] == len(readiness['retry_receipts']) == 1
        for item in readiness['retry_receipts']:
            verify(item)
            retry = read(item['path'])
            assert retry['actual_exit_code'] == 3 and retry['request']['operation'] == 'capabilities.list'
            for key in ('stdin', 'stdout', 'stderr'):
                verify(retry[key])
            assert text(retry['stdout']['path']) == ''
            assert text(retry['stderr']['path']).strip() == 'Engine is not available: QLocalSocket::connectToServer: Invalid name'
        row['actual96'] = {'completion_path': str(native / 'action-complete.json'), 'comparison_path': str(native / 'comparison.json'),
                           'actual_native_wrapper_exit': 0, 'actual_peer_exit_codes': [0, 0], 'actual_process_ids': [first['process_id'], second['process_id']],
                           'actual_fixed_dimensions': first['layout_configuration']['fixed_panels'], 'exact_state_geometry_raw_shortcut_and_document_neutral': True,
                           'private_settings_file': first['settings_file'], 'settings_format': 1, 'settings_scope': 0,
                           'actual_engine_cleanup_exit': -15, 'actual_engine_unforced_reaped': True,
                           'one_exact_before_ready_capabilities_retry_exit': 3, 'actual_peer_commands': actual_commands,
                           'actual_external_loaded_image_facts': 103, 'SDK_internal_owned_copy_coverage': 'UNKNOWN; loaded-image facts are not copy measurement'}
        row['limits'] = ['Full86 layout roundtrip is same QApplication/window recreation, not fresh process restart.',
                         'Actual96 supplies the separate fresh-process proof; old79 failure and old87 preparation are not imported as success.',
                         'One readiness CLIexit3 and owned engine SIGTERMexit-15 are literal scoped statuses, not every-command-exit0.']
    cases.append(row)

assert len(cases) == 20
status_counts = {}
for row in cases:
    status_counts[row['status']] = status_counts.get(row['status'], 0) + 1
save('BP20-source85-map-snapshot01.json', {
    'kind': 'Read-only current bounded framework mechanism evidence mapping, not acceptance registry',
    'snapshot_unix': time.time(), 'source_root': str(SOURCE), 'source_commit': COMMIT, 'source410_sha256': DIGEST,
    'canonical_BP_denominator': 20, 'statuses': status_counts,
    'all86_six_full_original_applicable_total': 378, 'foundation': foundation,
    'public74_scope': 'Independent compile gate; registeredCTest0, not74 runtime cases or BP acceptance',
    'current94_actual_exits': [0, 0], 'current90_representatives_actual': '6/6',
    'current90_signature_scope': '20typed/106assertions compiler proof only, not runtimeBP denominator',
    'current88_fault_scope': 'Original220 main plus separate extraF17x10 and actualSAN client20; no newBP or total220 population',
    'cases': cases, 'no_old68_PASS_or_raw_evidence_import': True,
    'global_claims': {'SK14': False, 'performance97_metrics': False, 'fullP0': False, 'real_solver': False, 'real_external_AI': False},
    'SDK_internal_copy_scope': 'Unknown/deferred; configured/static import facts do not measure internal copies',
    'auditor_executions': 'Read-onlyGit and data/hash mapping only; no guard/compiler/test/engine/CLI/GUI'})
for name, expected in frozen['tracked_files'].items():
    actual = fact(SOURCE / name)
    assert actual['bytes'] == expected['bytes'] and actual['sha256'] == expected['sha256'], name
for expected in facts.values():
    assert fact(expected['path']) == expected, expected['path']
save('input-facts-beforeafter.json', {'source_commit': COMMIT, 'source410_sha256': DIGEST,
                                    'tracked2835_matches_frozen_before_after': True,
                                    'actual_readonly_Git_commands': commands,
                                    'all_actual_input_facts_stable': True,
                                    'facts': list(facts.values()),
                                    'accepted_old68_actual_results': 0,
                                    'initial_lookup_limits': 'Early broad rg touched historical engineering evidence and nonexistent guessed paths, producing truncated output/exit2; used for lookup only. No historical raw is an accepted proof input.'})
print(json.dumps({'canonical_cases': 20, 'statuses': status_counts, 'input_facts': len(facts),
                  'actual_readonly_only': True}))
