# Final combined QG-02 source review — batch 176

**No blocking source finding identified.** Reviewed the combined frozen source in `/private/tmp/qcae-framework-delivery80`, including the formatted IPC adapter and new `host_read_and_history_contracts` test. The checkout was not edited. This review follows product171 and MCP173; it applies to the exact final hashes below, rather than treating the earlier product hash as the final source.

| Final combined source | SHA256 |
|---|---|
| `adapters/engine_api/src/ipc_api.cpp` | `6fafc3cd23841ab8cd2d31f0d7d5a9aba93b1620f29e309146b07c4cc13ebd34` |
| `tests/typed_host_tests.cpp` | `a7a37c40bb6a3de51a6a812064ac9d03af4ef2db5a45bfa54579883699057b0e` |
| `tests/mcp_bridge_tests.py` | `5d830b86a1b2fa2bf0f41dddb6ea0752a4318f8d95fbe8daf531f77b64836da3` |
| `tests/host_controls_ipc_tests.py` | `d3eaf238ddeae8373701228302dbb7a8d2dad14a368ef809f26a7454b7b8c5ba` |
| `schemas/operations/host_reads.json` | `350f29adce5dd83ff3be9b51f285ef8dc9ab8792b9363dd4b557245ee0f02396` |
| `schemas/operations/document_changes.json` | `855db11f8b932c68642653de4f30a0ad870776891030ce0f26a23bf560cd912c` |
| `CMakeLists.txt` | `6906b75127d94d16e7721e9af663e1f0fcef025ef2ce912e2a405919228ef1aa` |
| `tools/generate_operation_contracts.py` — unchanged | `c9bfd4f9ead15951ba51ae49ee90e9565bc1974fb83a7560296f9752c8444db2` |
| `docs/contracts/operations.json` — unchanged | `1f4edc5eff997ae37780d8d6c2216e2442bd6dad2a8744bc86558ad2729d27cd` |

## Authority and refusal ordering

`ipc_api.cpp:320` retains the supported-operation and object-envelope checks before the seven-route admission list. Existing expected_profile refusal remains in place. Each new branch runs `version_rejection` and generated empty `string_input` decoding before document/context/key extraction or its application call. The selection and model delegates guard their own operation names before application access (`ipc_selection.cpp:192`, `ipc_model.cpp:465`), so they do not consume these seven requests first. The new helpers do not register substitute handlers or execute commands through a second application.

The five reads retain catalog assembly/current/snapshot/history services. History writes at `ipc_api.cpp:631` keep caller, WriteContext, key, application undo/redo and receipt serializer. The existing facade forwards into the one RecordApplication (`features/legacy_api/src/core.cpp:212,241,257,261,264`). `modules/application/src/core.cpp:767` checks active document/epoch, then caller/operation/key and normalized-context replay, then fresh revision/inapplicable history; accepted candidates validate, persist and swap under the existing application lock. The reviewed stale-context, caller and replay expectations match this ordering. No coordinator bypass was found in the change.

## Generated definition versus preserved discovery

The schema files define exactly seven v1 empty DTOs. Host reads have no context requirements; document reads require identity+epoch; history writes require identity+epoch+revision+key; none requires Profile. The unchanged generator handles empty fields with zero-size allowed/required arrays and `wire::object_fields` before constructing the input. No generator output was executed or compile-verified by this reviewer.

`typed_host_tests.cpp:1159` checks internal OperationDefinition equality with read_only/document_write effects. Its descriptor check at `1180` separately checks preserved query/model_write catalog effects, legacy symbolic input/output labels, wire labels, contexts and closed parameters. This prevents conflating the two effect vocabularies. MCP and SQLite tables use the same preserved catalog vocabulary. The SQLite draft mismatch reported in MCP173 remains corrected at the final hash. Optional version discovery retains the bounded integer schema and installed version1 metadata; it does not invent const1 or a new output schema.

## Combined test quality and compatibility

The new C++ test at `1054` uses one saved material/history scenario, a seven-route contract table and local reject/read/move/replay helpers. `OpenContractState` at `102` deep-copies persisted rows, project save token/payload, generation, document metadata, history, recovery availability and commit/publish/read counters. `unchanged` at `1252` also checks the complete DocumentView delta and its version. `reject` at `1261` repeats each malformed/version/context request twice against that state, including version/input refusal after removing the otherwise required context. Mutation keys history-U/history-R are subsequently accepted, and an inapplicable redo with history-R is also followed by a valid redo.

The read checks at `1381` send no write revision/key and assert complete existing results and top-level revision projection for omitted/v1. Material/count/history content is authored explicitly. The move/replay checks at `1413` cover one persistence generation/commit per accepted move, saved/dirty semantics, original history item identity, complete receipts, current outcome state, undo U → redo R → retry U, stale revision/epoch, mismatched document, same-key/different-context, caller-scoped replay and unrecorded outcome keys. `operations.get` stays outside the new generated contract: `1205` verifies its old descriptor; `1501` protects ignored irrelevant original_mode values and explicit-version rejection. The pre-existing open rejection probe now names that excluded operation at `191`, avoiding its former project.current expectation after current became versioned.

The production SQLite fixture complements the fake store with complete logical SQLite rows, saved geometry/material, actual persistent generations, fresh omitted/v1 history writes, original facts and independent engine recovery. The MCP fixture complements the application test with two actual stdio clients and CLI, exact retained engine metadata, document reads without write context, rejected-key reuse and history retries. Their engine lifetime workflows are reused rather than cloned for seven routes. CMake registers the new SQLite test only for UNIX+storage and retains the existing MCP durable parameterization. Source responsibilities remain explicit; no extra framework/dependency or duplicated business implementation was introduced.

## Evidence limits and false-positive review

The C++ OpenContractStore is explicitly documented as a fake at `typed_host_tests.cpp:66`; a metadata storage_mode string is not physical SQLite evidence. Its complete state assertions establish the intended in-memory application/store observation scope only when executed. Actual SQLite I/O/recovery belongs to the separate parent fixture and runtime results.

Some complete expected read objects reuse the unchanged `ipc::info_json` serializer and the active capability payload. These checks protect version equivalence and the existing wire shape, with separately authored material/count/history facts and descriptor assertions; they are not an independent specification of every legacy output field. The product diff leaves those serializers/result policies unchanged. This limitation does not require a new output-contract scope for this seven-input slice. No test bug that would make the new refusal/replay assertions vacuous was identified by source review.

Tests/build/runtime execution, generator freshness, configure, compiler warnings, CTest, sanitizers, automated design/format/diff gates and product execution: **NOT RUN by this reviewer**. Parent matrix176 execution is independent. No running receipt or earlier pass was inspected or adopted as current validation evidence. This report is the QG-02 source review contribution; QG-01/QG-03 and final acceptance depend on the parent's actual completed results. It does not establish full REQ-16/SK-04/P0, GUI selection, real AI/solver integration or performance acceptance.
