# Seven host controls — MCP test 173

Source is frozen in `/private/tmp/qcae-framework-delivery80` at supplied and independently read HEAD `ba6d6809a6e189c381d6a924db14c6a50c331649`. This worker edited only `tests/mcp_bridge_tests.py`; other current checkout changes belong to the parent and other owners. No dependencies or production bridge files were changed.

| Source boundary | SHA256 read after edits/review |
|---|---|
| `tests/mcp_bridge_tests.py` — owned and frozen | `5d830b86a1b2fa2bf0f41dddb6ea0752a4318f8d95fbe8daf531f77b64836da3` |
| `apps/mcp/bridge.py` — read only | `586c2ed9ab01b8b3eb0001f954209aebaa4046edbab147cdd5f1120c171c8fa8` |
| `tests/host_controls_ipc_tests.py` — parent owned, statically reviewed | `d3eaf238ddeae8373701228302dbb7a8d2dad14a368ef809f26a7454b7b8c5ba` |
| `CMakeLists.txt` — parent owned, read only | `6906b75127d94d16e7721e9af663e1f0fcef025ef2ce912e2a405919228ef1aa` |
| `schemas/operations/host_reads.json` — product owner, read only | `350f29adce5dd83ff3be9b51f285ef8dc9ab8792b9363dd4b557245ee0f02396` |
| `schemas/operations/document_changes.json` — product owner, read only | `855db11f8b932c68642653de4f30a0ad870776891030ce0f26a23bf560cd912c` |
| `adapters/engine_api/src/ipc_api.cpp` — product owner, read only | `573706b7964426a0b2a1e4c658b1bb4177add7848ae2438b97ce35bf447e8aa8` |

Hashes and source/diff reads are static evidence. They do not establish compilation or runtime behavior.

## Owned coverage

One `HOST_CONTROLS` table drives the actual MCP discovery assertion for capabilities.list, project.current, project.status, model.summary, history.list, history.undo and history.redo. It requires one available engine descriptor per route, exact schema identity/version/omission policy/wire input and existing result labels, fields=[], the closed empty parameter object, preserved symbolic catalog labels/effect/target context, and exact context flags. The MCP description's complete `Engine capability` JSON is compared with the actual engine descriptor. The full MCP input schema is compared with its expected shape, including empty required sets for host reads, document+epoch for document reads, and document+epoch+revision+key for history writes.

Optional requested_version uses the existing integer/minimum=1/maximum=4294967295 schema. Installed version metadata remains 1. The parent's initial `const: 1` wording was explicitly corrected after source inspection: the unchanged bridge applies const only to mandatory `descriptor.requested_version`. Advertising optional const1 here would invent a production change and misstate the existing compatibility helper. Future versions are sent by tools/call and must be refused by the engine as SCHEMA_UNSUPPORTED/requested_version.

The existing two-client run and `--durable` parameterization remain the only engine workflow. `Client.call` can now send a document+epoch read context without a revision; existing full write contexts retain the original behavior. Five grouped reads compare complete responses except transport request_id for omitted/v1, check extra string/numeric/null fields and malformed/future versions, and compare current/status/summary/history before and after. Document reads are also called without context and with an expired epoch. The existing no-active project.current behavior is checked before creation for omitted/v1.

The populated material/CLI-undo workflow now refuses history inputs before valid moves, then reuses the exact rejected mcp-undo and mcp-redo keys. One short move table gives fresh omitted/v1 calls for each history write, one revision increment per accepted move, original transaction replay, applied item/cursor/material state, and existing operations.get facts. Retrying the original undo after a later redo returns the original outcome and leaves the redone state unchanged. The workflow finishes with the material restored, preserving the later save/close and CLI-visible document assertions. StructuredContent/text/isError checks and the existing overall available-tool catalog assertion remain intact.

## Static readability and authority review

Read AGENTS.md, docs/baseline/README.md, REQ-16, SK-04, QG-01/02/03, architecture overview/modules/runtime/dependency graph, batch167 plan, product171 review, and actual MCP/IPC/coordinator source. MCP remains a transport/discovery adapter: tools/call forwards parameters/context/version into the existing engine; generated version/input refusal precedes the unchanged application calls; undo/redo use the same WriteContext, caller, key and coordinator as before. The tests observe current state and history through the same engine. No test writes storage directly.

The added helpers group metadata, refusal and read observations; the existing run owns process/client lifetime. This is static QG-02 input only. It does not close the repository readability/behavior gate without the parent's required execution.

## Parent SQLite fixture static review

Reviewed `tests/host_controls_ipc_tests.py` and the CMake registration without editing or executing them. The fixture uses existing production EngineProcess/IpcClient and complete logical SQLite row snapshots, explicit workspace, actual geometry+preview/commit material, saved state, persistent generation, history moves/replays, stable sorted entities and independent engine recovery. Read requests use document+epoch through `extra`, avoiding the shared IpcClient's write-context revision injection. Refusal checks compare complete snapshots; rejected write keys are subsequently reused. Original undo/redo/commit facts and expired activation contexts remain distinct from fresh recovery identity.

One blocking draft assertion was reported: it expected generated internal effect strings read_only/document_write from the compatibility catalog. The parent corrected it to preserved query/model_write without changing production source; the reviewed hash above contains that correction. No further blocking static finding was identified. CMake gates the fixture on UNIX and storage and gives it 60 seconds. Runtime timing, actual results and any hidden environmental failures remain unverified.

## NOT RUN and acceptance limits

Generator execution/freshness checks, Python syntax/compile checks, compiler/build, CMake configure, public-header consumers, design check, C++ format check, git diff --check, CTest, sanitizers, actual engine/CLI/MCP product execution, SQLite fixture execution, GUI or external AI, and all Git mutations: **NOT RUN by this worker**. Parent owns the combined validation from this frozen source. No runtime pass count is claimed.

REQ-16/SK-04 coverage is bounded to the seven existing input/discovery boundaries. Full catalog type coverage, required three-entry acceptance, complete SK/P0 acceptance, GUI selection, real AI/solver integration and performance are not established by this static handoff.
