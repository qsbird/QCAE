import hashlib,json,os,subprocess,time
from pathlib import Path
R=Path('/private/tmp/qcae-host-controls174-baseline');S=Path('/Users/qs/Documents/ChatGPT/QCAE');B=Path('/private/tmp/qcae-changes-commit165-builds/sqlite-on');P='/Library/Frameworks/Python.framework/Versions/3.14/bin/python3'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
products={n:sha(B/n) for n in ['qcae_typed_host_tests','qcae-engine','qcae-cli','qcae-mcp']}
sources={n:sha(S/n) for n in ['tests/typed_host_tests.cpp','tests/ipc_tests.py','tests/mcp_bridge_tests.py','adapters/engine_api/src/ipc_api.cpp']}
dump(R/'candidate.json',{'head':subprocess.check_output(['git','-C',str(S),'rev-parse','HEAD'],text=True).strip(),'sources':sources,'products':products,'scope':'Existing exact baseline cases before new contract; not new-contract evidence'})
commands=[('typed_host',[str(B/'qcae_typed_host_tests')]),('ipc',[P,str(S/'tests/ipc_tests.py'),'--engine',str(B/'qcae-engine'),'--cli',str(B/'qcae-cli')]),('mcp',[P,str(S/'tests/mcp_bridge_tests.py'),'--engine',str(B/'qcae-engine'),'--cli',str(B/'qcae-cli'),'--mcp',str(B/'qcae-mcp')]),('mcp_durable',[P,str(S/'tests/mcp_bridge_tests.py'),'--engine',str(B/'qcae-engine'),'--cli',str(B/'qcae-cli'),'--mcp',str(B/'qcae-mcp'),'--durable'])]
for name,argv in commands:
 start=time.time()
 with (R/(name+'.stdout.log')).open('xb') as out,(R/(name+'.stderr.log')).open('xb') as err:r=subprocess.run(argv,cwd=S,stdout=out,stderr=err,timeout=90)
 receipt={'argv':argv,'cwd':str(S),'actual_exit_code':r.returncode,'started_unix':start,'elapsed_seconds':time.time()-start}
 dump(R/(name+'.json'),receipt);print(json.dumps(receipt),flush=True)
 assert r.returncode==0,name
 assert products=={n:sha(B/n) for n in products}
 assert sources=={n:sha(S/n) for n in sources}
dump(R/'complete.json',{'actual_executions':len(commands),'all_exit_zero':True,'baseline_source_and_products_unchanged':True})
