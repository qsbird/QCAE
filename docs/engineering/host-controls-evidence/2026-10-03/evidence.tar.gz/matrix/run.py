#!/usr/bin/env python3
"""Root-owned fresh, non-graphical contract regressions. Original GUI failures stay open."""
from concurrent.futures import ThreadPoolExecutor
import hashlib,json,os,re,subprocess,time
from pathlib import Path
SOURCE=Path('/private/tmp/qcae-framework-delivery80');ROOT=Path(__file__).resolve().parent
OUT=ROOT/'attempt-01';BUILD=Path('/private/tmp/qcae-host-controls176-builds')
BASE=Path('/private/tmp/qcae-changes-commit168-source/freeze.json')
CMAKE='/opt/homebrew/Cellar/cmake/4.3.0/bin/cmake';CTEST='/opt/homebrew/Cellar/cmake/4.3.0/bin/ctest'
PYTHON='/Library/Frameworks/Python.framework/Versions/3.14/bin/python3.14';COMPILER='/Library/Developer/CommandLineTools/usr/bin/c++'
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def fact(path):
 p=Path(path);return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
def dump(path,value):
 with Path(path).open('x') as f:json.dump(value,f,indent=2,sort_keys=True);f.write('\n')
assert not OUT.exists() and not BUILD.exists();OUT.mkdir();BUILD.mkdir()
files=set(json.loads(BASE.read_text())['source_files'])
for name in subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=SOURCE,text=True).splitlines():
 assert name in ['tests/host_controls_ipc_tests.py','schemas/operations/host_reads.json'],name
 files.add(name)
inputs={n:sha(SOURCE/n) for n in sorted(files)};assert len(inputs)==420
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=SOURCE,text=True).strip();assert head=='ba6d6809a6e189c381d6a924db14c6a50c331649'
method=fact(__file__)
dump(OUT/'candidate.json',{'base_head':head,'source':str(SOURCE),'candidate_files':inputs,'candidate_files_count':len(inputs),'source_dictionary_sha256':hashlib.sha256(json.dumps(inputs,sort_keys=True,separators=(',',':')).encode()).hexdigest(),'method':method,'fresh_build_root':str(BUILD),'scope':'Relevant full non-graphical core, local, SQLite package ON/OFF plus one ASan/UBSan adapter test. No new GUI execution here; original desktop_selection failures remain open.','tools':{n:fact(p) for n,p in {'cmake':CMAKE,'ctest':CTEST,'python':PYTHON,'compiler':COMPILER}.items()}})
def guard():
 assert inputs=={n:sha(SOURCE/n) for n in inputs},'Candidate changed'
 assert method==fact(__file__),'Method changed'
 assert head==subprocess.check_output(['git','rev-parse','HEAD'],cwd=SOURCE,text=True).strip(),'HEAD changed'
def command(name,argv,extra=None):
 guard();env=os.environ.copy()
 for key in ['ASAN_OPTIONS','UBSAN_OPTIONS','LSAN_OPTIONS','DYLD_INSERT_LIBRARIES','DYLD_LIBRARY_PATH','DYLD_PRINT_LIBRARIES','QT_QPA_PLATFORM']:env.pop(key,None)
 env.update(extra or {});start=time.time();out=OUT/(name+'.stdout.log');err=OUT/(name+'.stderr.log')
 with out.open('xb') as o,err.open('xb') as e:r=subprocess.run(argv,cwd=SOURCE,env=env,stdout=o,stderr=e)
 guard();receipt={'actual_exit_code':r.returncode,'argv':argv,'cwd':str(SOURCE),'started_unix':start,'elapsed_seconds':time.time()-start,'explicit_environment':extra or {},'stdout':fact(out),'stderr':fact(err),'candidate_before_after_equal':True};dump(OUT/(name+'.json'),receipt)
 print(json.dumps({'command':name,'actual_exit_code':r.returncode,'elapsed_seconds':receipt['elapsed_seconds']}),flush=True)
 if not name.endswith('-ctest'): assert r.returncode==0,name+' failed; original evidence retained'
 if name.endswith('-build'):assert not re.findall(r'(?m)^.*\bwarning:.*$',out.read_text(errors='replace')+err.read_text(errors='replace')),'Compiler warning'
 return receipt
configs=[('core',False,False,True,'Release',False),('local',True,False,True,'Debug',False),('sqlite-on',True,True,True,'Release',False),('sqlite-off',True,True,False,'Release',False),('sanitized',True,False,True,'Release',True)]
def build(config):
 name,ipc,storage,package,mode,sanitize=config;directory=BUILD/name
 argv=[CMAKE,'-S',str(SOURCE),'-B',str(directory),'-G','Ninja','-DBUILD_TESTING=ON','-DCMAKE_EXPORT_COMPILE_COMMANDS=ON','-DCMAKE_CXX_EXTENSIONS=OFF','-DCMAKE_CXX_COMPILER='+COMPILER,'-DPython3_EXECUTABLE='+PYTHON,'-DCMAKE_BUILD_TYPE='+mode,'-DQCAE_BUILD_IPC='+('ON' if ipc else 'OFF'),'-DQCAE_BUILD_STORAGE='+('ON' if storage else 'OFF'),'-DQCAE_BUILD_DESKTOP=OFF','-DQCAE_ENABLE_NASTRAN_PACKAGE='+('ON' if package else 'OFF')]
 if ipc:argv+=['-DCMAKE_PREFIX_PATH=/opt/homebrew/opt/qt']
 if storage:argv+=['-DSQLite3_LIBRARY=/opt/homebrew/Cellar/sqlite/3.53.4/lib/libsqlite3.3.53.4.dylib','-DSQLite3_INCLUDE_DIR=/opt/homebrew/Cellar/sqlite/3.53.4/include']
 if sanitize:argv+=['-DQCAE_ENABLE_SANITIZERS=ON']
 command(name+'-configure',argv);command(name+'-build',[CMAKE,'--build',str(directory),'-j','3',*(['--target','qcae_typed_host_tests'] if sanitize else [])])
 compilation=json.loads((directory/'compile_commands.json').read_text());assert all('-std=c++20' in row['command'] and '-std=gnu++20' not in row['command'] for row in compilation)
 dump(OUT/(name+'-compile-summary.json'),{'strict_cpp20':True,'compiler_warnings':[],'compile_commands':fact(directory/'compile_commands.json'),'configured_compile_units':len(compilation)})
for name,argv in [('design',[PYTHON,'tools/check_design.py']),('format',[PYTHON,'tools/check_cpp_format.py']),('diff',['git','diff','--check'])]:command(name,argv)
with ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(build,configs))
def test(config):
 name,*rest=config;sanitize=config[-1];directory=BUILD/name
 command(name+'-inventory',[CTEST,'--test-dir',str(directory),'--show-only=json-v1']);inventory=json.loads((OUT/(name+'-inventory.stdout.log')).read_text());names=[x['name'] for x in inventory['tests']]
 selected=['typed_host'] if sanitize else names
 env={'ASAN_OPTIONS':'detect_leaks=0:halt_on_error=1','UBSAN_OPTIONS':'halt_on_error=1:print_stacktrace=1'} if sanitize else None
 receipt=command(name+'-ctest',[CTEST,'--test-dir',str(directory),'--output-on-failure','--verbose','-j','1',*(['-R','^typed_host$'] if sanitize else [])],env)
 raw=directory/'Testing/Temporary/LastTest.log';copy=OUT/(name+'-LastTest.log');copy.write_bytes(raw.read_bytes())
 result={'configuration':name,'actual_exit_code':receipt['actual_exit_code'],'configured_test_names':names,'executed_test_names':selected,'executed_count':len(selected),'raw_log':fact(copy),'scope':'ASan/UBSan typed_host only; LSan unmeasured' if sanitize else 'full existing non-graphical configuration'};dump(OUT/(name+'-tests.json'),result);return result
with ThreadPoolExecutor(max_workers=2) as pool:completed=list(pool.map(test,configs))
assert all(x['actual_exit_code']==0 for x in completed),'CTest failure retained in attempt; no complete receipt'
guard();dump(OUT/'complete.json',{'actual_exit_code':0,'candidate_before_after_equal':True,'candidate':fact(OUT/'candidate.json'),'method':method,'configurations':completed,'total_test_executions':sum(x['executed_count'] for x in completed),'original_graphical_gate_still_open':True})
print(json.dumps({'completed':sum(x['executed_count'] for x in completed),'original_graphical_gate_still_open':True}),flush=True)
