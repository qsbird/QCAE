# Seven host read/history input contracts — product 171

Implemented the bounded seven-route source batch in `/private/tmp/qcae-framework-delivery80`. Source editing is complete and frozen. The parent supplied starting HEAD `ba6d6809a6e189c381d6a924db14c6a50c331649`; this worker did not run Git to independently attest HEAD or repository status.

## Owned source and hash boundary

| Source | SHA256 after edits |
|---|---|
| `schemas/operations/host_reads.json` | `350f29adce5dd83ff3be9b51f285ef8dc9ab8792b9363dd4b557245ee0f02396` |
| `schemas/operations/document_changes.json` | `855db11f8b932c68642653de4f30a0ad870776891030ce0f26a23bf560cd912c` |
| `adapters/engine_api/src/ipc_api.cpp` | `573706b7964426a0b2a1e4c658b1bb4177add7848ae2438b97ce35bf447e8aa8` |

Only these three product source files were edited. Review files live outside the checkout. Hashes were read with `shasum -a 256`; hashing is static source inspection, not generation or runtime validation. Existing generator (`c9bfd4f9ead15951ba51ae49ee90e9565bc1974fb83a7560296f9752c8444db2`), symbolic operation catalog (`1f4edc5eff997ae37780d8d6c2216e2442bd6dad2a8744bc86558ad2729d27cd`) and TypedHost (`39b7478957cd45f6f1d7593c0df83dda67a85f023eaaf445712a81ce32700c98`) retain their supplied plan hashes.

## Contract source

All seven generated definitions use version 1, schema identity `qcae.operation.<operation>.v1`, no expected Profile requirement and `fields: []`.

| Operation | Input DTO | Generated effect | document / epoch / revision / key | Existing wire result label |
|---|---|---|---|---|
| `capabilities.list` | `CapabilitiesListInput` | `read_only` | false / false / false / false | `CapabilityCatalog` |
| `project.current` | `ProjectCurrentInput` | `read_only` | false / false / false / false | `DocumentInfo` |
| `project.status` | `ProjectStatusInput` | `read_only` | true / true / false / false | `ProjectStatus` |
| `model.summary` | `ModelSummaryInput` | `read_only` | true / true / false / false | `ModelSummary` |
| `history.list` | `HistoryListInput` | `read_only` | true / true / false / false | `HistorySnapshot` |
| `history.undo` | `HistoryUndoInput` | `document_write` | true / true / true / true | `ChangeReceipt` |
| `history.redo` | `HistoryRedoInput` | `document_write` | true / true / true / true | `ChangeReceipt` |

The five reads are in new `host_reads.json`; undo/redo append to `document_changes.json` without changing the existing changes.commit definition. Wire result labels describe existing serializers; this input generator does not generate output DTOs or output schemas. Symbolic catalog input/output labels, effects, context, availability and supported scopes remain as before.

## Static dispatch and authority review

1. The existing generated-version admission list adds exactly these seven routes. All other compatibility routes retain the existing explicit-version rejection. `expected_profile` still rejects on this boundary.
2. Each new route selects its `InputTraits` definition, calls existing `version_rejection`, then existing `string_input` before its existing app call or catalog assembly. Source semantics admit omitted/numeric integer v1, diagnose malformed/nonpositive/out-of-uint32 versions as `INVALID_INPUT` with `requested_version`, and refuse other valid uint32 versions with `SCHEMA_UNSUPPORTED` and that field. These are source conclusions, not runtime evidence.
3. `string_input` creates the shared `Value::Object`. Unknown string fields reach generated `object_fields`; nonstring values reject first with an input field diagnostic. The generator already emits zero-size allowed/required arrays and validates empty object inputs. Source readback found no generator change needed.
4. Dispatch first consults selection/model routes, but both helpers return without an application call for these seven names: `ipc_selection.cpp:192` guards its six view/selection names; `ipc_model.cpp:465` guards its edits/query/reference/export names. Thus no earlier helper consumes the seven inputs or mutates state before their new validation.
5. `capabilities.list` still builds the existing catalog/storage/recovery/package/Profile result. `project.current` still calls `app.current_document()` and `info_json`. `project.status`/`model.summary` still call `app.snapshot(DocumentRef)` and preserve the old saved/dirty/count/material/geometry/mesh result construction. `history.list` still calls `app.history(DocumentRef)` and serializes items/cursor/revision.
6. `history.undo`/`history.redo` still construct the same `WriteContext` and key, pass the same trusted caller, call the same `app.undo`/`app.redo`, and use unchanged `receipt_json`. Source decode/version refusal happens before context/key extraction and the app call.
7. `features/legacy_api/src/core.cpp:212,241,257,261,264` forwards current/snapshot/history/undo/redo to the one RecordApplication (snapshot retains its old record-to-model conversion). `modules/application/src/core.cpp:859,873` locks and calls existing `move_history`. That coordinator retains scoped key/signature replay, document/revision checks, candidate validation, history cursor/content/revision updates, operation fact recording, persist-before-swap and existing error outcomes. This worker did not change those files.
8. Existing `info_json`, `receipt_json`, history serializer and outer revision insertion remain unchanged. `operations.get`, including caller-scoped outcome mapping to commit/undo/redo, is untouched and is not in the generated admission list.
9. `describe_string_input` now supplies each added route's version/schema/field/wire/closed parameter metadata. Only obsolete manual empty schema behavior for status/summary was removed from `read_parameters_schema`; entity.query/entity.references shapes and bounds stay unchanged. Existing `modules/operations/CMakeLists.txt` already tracks schema JSON membership through CONFIGURE_DEPENDS and generator dependencies, so no CMake edit was made.

Readability review by source inspection: uses the same three helpers as changes.commit; explicit route and descriptor branches keep each actual service call visible; no additional framework, dependency, output policy or performance mechanism. This is a worker static review, not a completed repository validation/readability acceptance gate.

## NOT RUN / acceptance limits

Generation, generated input freshness, compiler/build, public-header consumers, design check, C++ format check, `git diff --check`, CTest, sanitizers, coordinator/store assertions, SQLite production IPC, MCP, CLI/desktop, product execution and Git mutations: **NOT RUN by this worker**. Root owns all combined execution after the source/test freeze. No runtime pass count or rejection atomicity/replay persistence claim is made here.

REQ-16 and SK-04 are addressed only for these seven existing input/discovery boundaries. Full operation catalog type coverage, three-entry acceptance, full SK/P0, graphical failures, solver/AI integration and performance acceptance remain outside this worker's conclusion. Earlier sources and tests are not reclassified as passes for this edited source.
