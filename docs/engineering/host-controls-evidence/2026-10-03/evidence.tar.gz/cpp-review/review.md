# Seven host read/history contracts — C++ test 172

The owned test source is frozen in `/private/tmp/qcae-framework-delivery80`. Only `tests/typed_host_tests.cpp` was edited by this worker. Starting HEAD `ba6d680` is parent-supplied; this worker did not run Git. The primary workspace and its unknown `AGENTS.md` changes were not touched.

## Source boundary

| Source | SHA256 at worker freeze |
|---|---|
| `tests/typed_host_tests.cpp` | `f7dcb9ee3c82402162b835a3e9ef13dedba6f632e3e6ce6e454f0c4a6897754c` |
| `schemas/operations/host_reads.json` | `350f29adce5dd83ff3be9b51f285ef8dc9ab8792b9363dd4b557245ee0f02396` |
| `schemas/operations/document_changes.json` | `855db11f8b932c68642653de4f30a0ad870776891030ce0f26a23bf560cd912c` |
| `adapters/engine_api/src/ipc_api.cpp` | `573706b7964426a0b2a1e4c658b1bb4177add7848ae2438b97ce35bf447e8aa8` |

The three product hashes match `/private/tmp/qcae-host-controls171-product/review.md`. Hashing and source reading are static inspection. Root owns formatting, generation and combined validation; formatting will change the test hash and requires a new final source hash.

## Test change and static findings

Added one `host_read_and_history_contracts()` function and one invocation in the existing test executable. It reuses `OpenContractStore`, `open_contract_state`, `write_lifecycle_request`, actual `MemoryApplication`/`TypedHost`/IPC dispatch, and record-view comparisons. It uses one saved material and one history item throughout, rather than one lifecycle workflow per operation.

1. Before project creation, omitted/v1 `capabilities.list` must return the identical full catalog without changing fake-store state. Both versions of `project.current` must retain the existing no-active-document failure. Catalog assertions preserve storage/recovery/Profile/unit facts.
2. A seven-row table names the exact DTO and existing output labels. Each generated definition is compared to its exact v1 operation/schema identity, empty field list, effect and context. Discovery requires one available descriptor, the existing symbolic input/output labels, query/model_write catalog effects, target context, no Profile-match requirement, closed empty schema, and the actual `version`/`requested_version_field`/`omitted_version_policy` metadata. It explicitly does not expect a `requested_version` metadata entry.
3. The table refuses malformed versions (including noninteger/nonpositive/out-of-uint32, strings, booleans, null, array and object) and valid future uint32 versions with the exact code/field. Extra string/numeric/null parameters and nonobject parameter shapes must reject. Context-free probes retain the mutation key while removing document/epoch/revision, requiring the schema diagnostic before context extraction. These probes supplement the static product call-chain review; they are not application-call instrumentation.
4. All five successful reads use their minimum context, with no write revision or key. Omitted/v1 responses must be identical. Current/status/summary/history have complete expected result objects and top-level revision assertions. The complete application record view, record version, stored rows, saved project payloads, saved/dirty metadata, history, generation, recovery flag and store counters are compared across reads and repeated refusals. Document reads also retain missing-context, stale-epoch and wrong-document outcomes.
5. Keys U and R are used in the refusal table and then accepted by actual undo/redo. R is also reused after `NOTHING_TO_REDO`. Omitted undo and explicit-v1 redo each require exactly one store commit, generation and document revision increment, one cursor move, preserved history item identity/label and saved metadata, full expected record contents, and the exact existing six-field receipt shape. Each route accepts the opposite version policy on its immutable replay.
6. The sequence undo U → redo R → retry original U returns the original U transaction/current-state receipt and leaves the redone record view and cursor intact. Stale revision with an unrecorded key, another caller using the old request, changed context signature under the recorded key, stale epoch, wrong document and unavailable undo/redo must preserve complete state.
7. `operations.get` remains outside generated admission. Its existing metadata/context is asserted; commit/U/R document facts still resolve without write context, cross-caller/unrecorded-key lookups still fail, and explicit requested_version still rejects. Numeric document `original_mode` and null host-create `original_mode` remain accepted where irrelevant. Host create lookup still requires no document context and returns the original lifecycle info.
8. Source scan found one obsolete version assertion in `rejected_open_inputs_are_atomic`: it expected `project.current` v1 to be rejected. That assertion now uses a well-formed `operations.get` request, retaining the excluded-route compatibility policy. The preexisting main task/geometry version checks remove their temporary version before existing summary/history calls; no other stale seven-route version expectation was found.

## Authority and readability review

The test entry is real IPC dispatch, which reaches the frozen generated-input validation and existing `MemoryApplication` facade. That facade retains the one `RecordApplication` authority. History changes retain the existing coordinator, scope/signature checks, persist-before-swap path and persistent operation facts. No application, store, registry, bridge, schema or product implementation was edited by this worker. The grouped scenario has shared observation/refusal/move/replay helpers local to the test; every expected effect and service transition is visible.

Read `AGENTS.md`, `docs/baseline/README.md`, REQ-16, SK-04, QG-01/02/03, architecture overview/modules/dependency/runtime documents and the authoritative batch167 plan before editing. Static test review addresses the scoped REQ-16/SK-04 boundaries; it is not a completed acceptance gate.

## NOT RUN

Generation/freshness, compilation/build, CTest, sanitizers, formatting, design checks, `git diff --check`, public-header consumers, SQLite I/O, production engine/CLI/MCP/desktop execution and Git: **NOT RUN by this worker**. Root owns combined execution after freeze. `OpenContractStore` persists actual application rows and saved payloads in a fake store; these assertions do not establish SQLite I/O. No runtime pass counts, complete SK-04/REQ-16/P0 acceptance, graphical acceptance, solver/AI integration or performance evidence is claimed.
