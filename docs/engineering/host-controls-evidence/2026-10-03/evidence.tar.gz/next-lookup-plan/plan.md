# operations.get next contract slice — read-only plan 177

Recommend one bounded **operations.get** slice: an existing generated string DTO for the semantic lookup input, an adapter-owned conditional raw-input schema, and a small MCP pass-through for a complete conditional arguments schema. No generator or Value-tree extension is required. Keep the current application calls and response return paths. The seven-route product source remains frozen.

Status: **PLAN ONLY**. Repository source and Git were not modified by this planning turn. Generator/tool scripts, builds, tests, products and Git commands were **NOT RUN**. Shell calls only read source and compute SHA256; this document and its JSON companion are the only files written, outside the checkout. No complete REQ-16/SK/P0 result is claimed.

## Actual source and behavior

Inspection used `/private/tmp/qcae-framework-delivery80`, including the frozen seven-route IPC changes. The parent's starting HEAD remains supplied context, not a Git attestation by this worker. Tests were being integrated by the parent; test function locations below are illustrative and should be re-resolved by name.

| Source location | Finding |
|---|---|
| `adapters/engine_api/src/ipc_api.cpp:296` | Envelope field/API/operation/parameters-object checks precede route dispatch. |
| `ipc_api.cpp:323` | Generated version admission excludes operations.get, so every supplied requested_version currently rejects before lookup parsing. expected_profile also rejects. |
| `ipc_api.cpp:666` | Raw parameters allow exactly lookup_scope, original_operation, original_mode and idempotency_key. Scope is parsed first. |
| `ipc_api.cpp:670` | Host branch maps project.create/open/save/save_as/close to the existing host namespace. Only project.open reads original_mode; omission means normal and recover is supported. Other host operations ignore original_mode, including nonstring/null values. |
| `ipc_api.cpp:695` | Document branch requires DocumentRef, maps changes.commit/history.undo/history.redo to commit/undo/redo, and sends any other nonempty original_operation to RecordApplication.action_outcome. It ignores original_mode, including nonstring/null values. |
| `ipc_api.cpp:686,703,726` | Host lookup and arbitrary document action lookup return result_json directly. Mapped document commit/undo/redo pass through outer revision insertion. Preserve this successful-envelope difference. |
| `features/legacy_api/src/core.cpp:236,267` | Host and mapped document outcomes forward to the same RecordApplication. |
| `modules/application/src/core.cpp:668,901,942` | action_outcome, operation and host_operation use caller-scoped retained facts. action_outcome does not require an installed handler. The services return actual DocumentInfo or ChangeReceipt. |
| `docs/contracts/operations.json:226` | Symbolic OperationLookup/OperationOutcome, query effect and all unconditional context flags false are already correct for the union. |
| `tools/generate_operation_contracts.py:16,58,122,140` | Current generator supports strings/optional strings and fixed context flags, but no discriminator/context union. No schema passthrough/arbitrary JSON field exists. |
| `modules/operations/include/qcae/operation_registry.hpp:31` | Value contains bool/number/string/array/object, without null. TypedHost JSON decoder (`typed_host.cpp:39`) explicitly refuses null. Generic registry decoding is not a safe replacement for this route. |
| `modules/operations/src/operation_registry.cpp:271` | Existing generated string decoder rejects empty strings, without trimming. Keep whitespace handling in the existing services; do not add a normalization policy. |
| `apps/mcp/bridge.py:134,190` | Explicit parameters_schema validates/transmits bounded oneOf, enum, unconstrained property `{}` and known JSON types. if/then/else, const and pattern are not accepted by this metadata validator. |
| `bridge.py:200,212` | Generic tool schema adds unconditional optional document/key/revision properties and derives required context only from booleans. It cannot currently express document-only requirements conditioned on a parameter. |
| `bridge.py:79,295` | MCP forwards parameters/context to the engine; it checks top-level argument names/object shape, not business parameter semantics. It must continue doing that. |

`parameters.idempotency_key` is the **key of the original operation being looked up**, not a new write/idempotency requirement. No expected_revision or top-level idempotency_key is needed for either branch. Host requires no active document/context; document requires document_id and document_epoch. Host service facts may remain available after close. Document facts remain readable after undo, retries or contributor removal, subject to the existing document/epoch/caller scope.

The plan167 exclusion is confirmed, not superseded by a finding of a missing handler. Raw original_mode compatibility and conditional request context make this route different from the seven empty-input routes.

## Smallest honest representation

### Generated semantic DTO, without generator changes

Add one `schemas/operations/operation_lookup.json` definition:

- operation_id `operations.get`; version `1`; schema_id `qcae.operation.operations.get.v1`; type_name `OperationsGetInput`; effect `read_only`.
- All five generated context flags false. They describe unconditional requirements; do not make host requests need a document.
- Fixed fields: 1 lookup_scope:string, 2 original_operation:string, 3 idempotency_key:string, 4 original_mode:optional string. None allow empty; no units.

This DTO describes the **semantic input after the compatibility adapter projection**, not a promise to round-trip irrelevant raw original_mode bytes. Keep one local helper in ipc_api.cpp which performs the current allowed-field/scope/operation/mode checks in their existing branch order, and forms canonical parameters for the existing string_input/InputTraits decoder. Include original_mode only for host project.open; leave it absent for every branch which currently ignores it. Unknown raw fields must reject before projection; do not drop arbitrary fields or parse ignored values. An ignored null or an object containing null never enters Value/string_input.

Keep original_operation as the user-facing operation string until the existing branch mapping. Decode to OperationsGetInput and use its common strings for the existing calls. For open, preserve omitted-mode default normal and explicit recover. Do not lowercase, trim, canonicalize arbitrary operation names, require original handlers to be available, or collapse host/document namespaces.

There is no need to add opaque JSON/null to Value, generator conditionals, a registry handler, TypedHost support, a new coordinator or an output DTO. The compatibility route remains the executable handler. A contract is not less real because its branch checks remain explicit at that boundary.

### Raw parameter schema which matches accepted inputs

Use an adapter-owned descriptor function beside describe_project_open. Produce a closed object with common nonempty string properties lookup_scope, original_operation and idempotency_key, plus unconstrained optional original_mode (`{}`), all three common fields required, and three **disjoint oneOf** branches:

| Branch | lookup_scope | original_operation | original_mode |
|---|---|---|---|
| host open | enum [host] | enum [project.open] | optional string enum [normal,recover]; omit defaults normal |
| other host lifecycle | enum [host] | enum [project.create,project.save,project.save_as,project.close] | `{}`; any JSON value accepted/ignored |
| document | enum [document] | nonempty string, unrestricted by handler availability | `{}`; any JSON value accepted/ignored |

Each branch declares its properties/required list and additionalProperties:false, as the existing project.open branches do. Avoid overlapping oneOf alternatives, tightening ignored original_mode, restricting document operations to the currently installed catalog, or using unsupported conditional JSON-schema keywords.

Discovery retains symbolic input_type/output_type, effect, supported_scope, availability and all unconditional context flags. Add the installed version/schema/omission policy and `wire_input_type: OperationsGetInput`. Present the raw field contract honestly: original_mode's raw wire metadata is `json_value` with a description explaining the host-open string condition, rather than advertising an unconditional string restriction. The explicit parameters_schema is authoritative and matches the raw union. Generated InputTraits still accurately describe the projected semantic DTO; document this distinction locally.

Expose existing output labels by scope, for example `wire_output_types: [DocumentInfo,ChangeReceipt]` and `output_by_lookup_scope: {host:DocumentInfo,document:ChangeReceipt}`. Preserve symbolic OperationOutcome. Do not invent a generated union/output serializer or imply new output fields.

### Conditional context reaches MCP with schema pass-through

Correct parameter shape alone cannot describe conditional top-level context. Add one optional descriptor key `arguments_schema` and a small bridge branch which validates it with the existing bounded schema validator and returns it as the tool inputSchema. It is an engine-supplied complete tool-arguments schema, not a business decoder. Existing tools without this key keep the existing tool_schema behavior. No generator change is needed.

Build arguments_schema in the same operation-specific descriptor function, reusing the exact parameters_schema as its parameters property. Root properties stay within `parameters` and existing QCAE context names; root requires `parameters`, closes additional properties, and exposes optional requested_version as positive uint32, **without const or requiring it**. Conditional oneOf branches select parameters.lookup_scope:

- Host branch requires parameters only. Optional document_id/document_epoch remain unconstrained (`{}`), because this route currently ignores them. The host parameter union above still validates open mode and known host operation names.
- Document branch requires parameters, document_id and document_epoch; the two document identities are nonempty strings.
- Both branches leave optional expected_revision and top-level idempotency_key unconstrained/unused, matching the current ignored envelope fields. They must never enter a write context or key namespace. expected_profile is excluded from the advertised schema, because the engine rejects it.

Keep the top-level parameters property identical to parameters_schema; branch selector schemas need only narrow lookup_scope and repeat allowed property names so they pass the existing validator's required-subset checks. Construct the schema below depth 16 / 128 nodes. A full provided arguments schema prevents accidental global document requirements and preserves host ignored-context acceptance; the current generic MCP properties are narrower than that engine behavior.

The bridge verifies the complete schema is a closed object, only uses the existing keyword/type subset, and its root property names stay within recognized argument names. Also require the root parameters schema to equal the descriptor parameters_schema. Do not add if/then, discriminator interpretation, operations.get literals or mode parsing to the bridge. Test the optional schema path in isolation with synthetic valid/invalid metadata as well as real discovery.

## Version and error ordering

Add only operations.get to generated admission, then call existing version_rejection at the start of this route before its current parameters field/scope/operation/mode checks and before any outcome service call. Omission/v1 uses installed definition; malformed/nonpositive/out-of-uint32 returns INVALID_INPUT/requested_version, valid other uint32 versions return SCHEMA_UNSUPPORTED/requested_version. The envelope/API/operation/parameters-object checks and expected_profile rejection retain their existing earlier positions.

For omission/v1, preserve the old ordered branch checks: allowed fields, lookup_scope, relevant original_operation, relevant original_mode, then the relevant key and document lookup. Do not run a global required-field/string decoder before scope/mode discrimination: it could turn an unknown scope/host operation error into a missing-key error or reject ignored raw mode. Parse/project first, then use the existing generated decoder on already validated semantic parameters. Keep the existing error messages/statuses where old parsing applies; the new named version diagnostic is the intended addition.

DocumentRef and lookup-key extraction currently occur as arguments in service-call expressions; C++ does not define their relative evaluation order. Do not claim a stable error priority when both are malformed. Preserve the current call structure where practical and test each independent invalid context/key plus the specified version-before-branch precedence. Do not fabricate an old portable ordering for simultaneously invalid function arguments.

Preserve host and arbitrary-action early returns and the mapped-history final response path. They carry different current top-level revision presence; complete JSON envelope comparison is needed, not only transaction IDs. Current_receipt/replayed/current_revision and stale context/caller failures remain controlled by the unchanged application services.

## One grouped verification plan for the implementer/root

1. **One descriptor/projection table:** exactly one available operations.get entry; exact schema/version/unconditional flags, raw closed three-branch parameters schema and full conditional arguments schema. DTO tests cover projected common strings, mode only for open, generated deterministic/fresh inputs and semantic to_value; do not claim raw ignored-value roundtrip. Decoder/version cases include omit/v1, malformed versions, valid future versions, unknown/missing/empty common fields and extra fields. Combine invalid scope/mode/key with malformed/future version to prove version ordering without a service call.
2. **One populated application/store scenario:** create/open/save/save_as/close host facts plus commit/undo/redo and one contributed action. Lookup original_mode omitted/normal/recover for open; check bad open modes/nonstring/null refuse. For other host operations and document outcomes, table-test irrelevant mode string, empty string, number, bool, null, array and object with nested null, preserving complete legacy success/failure envelopes. Test host no-context/no-active-document after close; document missing/old document/epoch; omitted/ignored revision/top-level key and varied ignored host context. Reads must preserve full snapshot, store generation, saved/dirty state, history/cursor and idempotency facts.
3. **Authority and replay in the same scenario:** exact actor/key outcome and cross-actor/unrecorded refusal; undo then redo then original commit/undo/redo lookups retain original transactions/current effect. Use existing retained_outcome_without_handler test (currently tests/typed_host_tests.cpp around 1516) and repeat lookup with removed contributor and explicit v1. Do not re-register the contributor to make lookup pass. Preserve direct-return versus mapped-history revision presence.
4. **One real SQLite IPC/MCP continuation:** extend the current shared fixture, not a fresh lifecycle for each lookup case. Save/normal-open and fault recovery keep their existing identity/epoch distinctions and fact retention policy; host and retained document facts use the same engine. Through two MCP clients verify parameters_schema and arguments_schema equal the engine metadata, host schema does not require document context, document schema does, omitted version remains optional, and real ignored-mode values forward unchanged. Cross-caller assertions must use actual distinct trusted caller scopes rather than forge an actor parameter. CLI outcome lookup belongs to this same frozen fixture where available.
5. **Run once after freeze:** required generation/freshness, relevant contract/application/IPC/MCP tests, public-header build, design/format/diff checks and applicable common CMake+CTest configurations. No extra performance work, solver/AI environment, graphical diagnosis or repeated seven-route rebuild loops. Record actual source/product hashes, failures and NOT RUN boundaries.

Product ownership should stay bounded: one owner for the new lookup schema plus ipc_api.cpp, one owner for the optional MCP metadata pass-through, independent test owners; root alone executes integration. No application, registry, Value, TypedHost, core context type, dependencies, CMake or graphics changes are proposed. New generator capabilities become necessary only if a future requirement explicitly demands raw arbitrary-JSON roundtrip or generated conditional schemas; neither is necessary for preserving this existing route.

## Static source SHA256

| Path | SHA256 |
|---|---|
| `adapters/engine_api/src/ipc_api.cpp` | `6fafc3cd23841ab8cd2d31f0d7d5a9aba93b1620f29e309146b07c4cc13ebd34` |
| `schemas/operations/host_reads.json` | `350f29adce5dd83ff3be9b51f285ef8dc9ab8792b9363dd4b557245ee0f02396` |
| `schemas/operations/document_changes.json` | `855db11f8b932c68642653de4f30a0ad870776891030ce0f26a23bf560cd912c` |
| `tools/generate_operation_contracts.py` | `c9bfd4f9ead15951ba51ae49ee90e9565bc1974fb83a7560296f9752c8444db2` |
| `apps/mcp/bridge.py` | `586c2ed9ab01b8b3eb0001f954209aebaa4046edbab147cdd5f1120c171c8fa8` |
| `modules/operations/include/qcae/operation_registry.hpp` | `a2f43f7421b8dd637f11c8b6eb51d4d91c1fd5251b4e46f35d3b620a121e1306` |
| `modules/operations/src/operation_registry.cpp` | `a4d2ac049137e4e542674b528a766195776a654ab05d2d16440bede695cae5ca` |
| `modules/application/src/core.cpp` | `c83a85a16dd03984fde634e5eb889b67b39e02dfa84743783b3322481359b712` |
| `features/legacy_api/src/core.cpp` | `47ccef1f9128a1e280b849410f675e1903bdc834b13ac360a5363b0b753fc9b2` |
| `docs/contracts/operations.json` | `1f4edc5eff997ae37780d8d6c2216e2442bd6dad2a8744bc86558ad2729d27cd` |
| `/private/tmp/qcae-core-contract-batch167/plan.md` | `2d3e7fe3bc9b3d602361e4b6ce67de015da01a8fddc05151a3a3c1633ef67709` |

These hashes identify source inspected, not a compiled or executed candidate. Wider operation coverage, complete SK-04/REQ-16/P0 and all previously unclosed graphical/solver/AI/performance gates remain outside this plan.
