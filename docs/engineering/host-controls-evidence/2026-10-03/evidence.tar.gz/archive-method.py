#!/usr/bin/env python3
"""Archive actual frozen batch results; exclude binaries, builds and databases."""
import copy
import datetime
import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

SOURCE = Path('/private/tmp/qcae-framework-delivery80')
MAIN = Path('/Users/qs/Documents/ChatGPT/QCAE')
ROOT = Path(__file__).resolve().parent
MATRIX = Path('/private/tmp/qcae-host-controls176-regression')
BUILD = Path('/private/tmp/qcae-host-controls176-builds')
COMMIT = Path('/private/tmp/qcae-host-controls178-commit')
DEST = SOURCE / 'docs/engineering/host-controls-evidence/2026-10-03'
REPORT = SOURCE / 'docs/engineering/host-controls-contracts-2026-10-03.md'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def dump(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')


def fact(path):
    return {'bytes': path.stat().st_size, 'sha256': sha(path)}


def insert_before(path, marker, text):
    original = path.read_text()
    assert original.count(marker) == 1, (path, marker)
    path.write_text(original.replace(marker, text + '\n\n' + marker))


assert not DEST.exists() and not REPORT.exists()
DEST.mkdir(parents=True)
candidate = json.loads((MATRIX / 'attempt-01/candidate.json').read_text())
completed = json.loads((MATRIX / 'attempt-01/complete.json').read_text())
receipt = json.loads((COMMIT / 'complete.json').read_text())
head = receipt['implementation_commit']
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=SOURCE, text=True).strip() == head
assert completed['actual_exit_code'] == 0 and completed['total_test_executions'] == 261
inputs = candidate['candidate_files']
assert len(inputs) == 420 and all(sha(SOURCE / name) == digest for name, digest in inputs.items())
assert all(sha(MAIN / name) == digest for name, digest in inputs.items())
assert sha(MAIN / 'AGENTS.md') == 'eaa469194e6952cc8e7a73859f8023216379fa65085ccd8bfd7efc075fe9eaa9'
dump(ROOT / 'freeze.json', {'implementation_commit': head, 'source_files': inputs,
     'source_files_count': 420, 'source_dictionary_sha256': candidate['source_dictionary_sha256'],
     'source_hash_algorithm': 'canonical sorted relative-path to file-SHA256 JSON; not C4-source-v1',
     'main_private_compiled_source_equal': True})
products = {}
for name in ('core', 'local', 'sqlite-on', 'sqlite-off', 'sanitized'):
    directory = BUILD / name
    for product in ('qcae_typed_host_tests', 'qcae-engine', 'qcae-cli', 'qcae-mcp'):
        path = directory / product
        if path.is_file():
            products[str(path)] = fact(path)
dump(ROOT / 'tested-products.json', products)

members = {}


def add_tree(prefix, directory):
    assert directory.exists(), directory
    for path in sorted(directory.rglob('*')):
        if path.is_file():
            assert path.suffix in {'.py', '.json', '.md', '.txt', '.log', '.cpp', '.hpp'}, path
            member = str(Path(prefix) / path.relative_to(directory))
            assert member not in members
            members[member] = path


add_tree('matrix', MATRIX)
add_tree('baseline', Path('/private/tmp/qcae-host-controls174-baseline'))
add_tree('commit', COMMIT)
add_tree('product-review', Path('/private/tmp/qcae-host-controls171-product'))
add_tree('cpp-review', Path('/private/tmp/qcae-host-controls172-cpp'))
add_tree('mcp-review', Path('/private/tmp/qcae-host-controls173-mcp'))
add_tree('sqlite-static', Path('/private/tmp/qcae-host-controls175-ipc'))
add_tree('batch-plan', Path('/private/tmp/qcae-core-contract-batch167'))
add_tree('next-lookup-plan', Path('/private/tmp/qcae-operations-get177-plan'))
for name in ('sqlite-on', 'sqlite-off'):
    for folder in ('host-controls-evidence', 'changes-commit-evidence'):
        add_tree('actual-sqlite/' + name + '/' + folder, BUILD / name / folder)
members['freeze.json'] = ROOT / 'freeze.json'
members['tested-products.json'] = ROOT / 'tested-products.json'
members['archive-method.py'] = Path(__file__)
index = {name: {'origin': str(path), **fact(path)} for name, path in sorted(members.items())}
archive = DEST / 'evidence.tar.gz'
with archive.open('xb') as raw, gzip.GzipFile(fileobj=raw, mode='wb', mtime=0) as compressed:
    with tarfile.open(fileobj=compressed, mode='w') as tar:
        for name, path in sorted(members.items()):
            data = path.read_bytes()
            info = tarfile.TarInfo(name)
            info.size = len(data)
            info.mode = 0o644
            info.mtime = 0
            tar.addfile(info, io.BytesIO(data))
with tarfile.open(archive, 'r:gz') as tar:
    assert set(tar.getnames()) == set(index)
    for name, record in index.items():
        data = tar.extractfile(name).read()
        assert len(data) == record['bytes'] and hashlib.sha256(data).hexdigest() == record['sha256']
        assert fact(members[name]) == {key: record[key] for key in ('bytes', 'sha256')}
dump(DEST / 'archive-index.json', {'member_count': len(index), 'archive': fact(archive), 'members': index})
actual_sqlite = {}
for name in ('sqlite-on', 'sqlite-off'):
    paths = list((BUILD / name / 'host-controls-evidence').glob('run-*/observations.json'))
    assert len(paths) == 1
    facts = json.loads(paths[0].read_text())
    counts = {key: len(facts[key]) for key in ('refusals', 'reads', 'replays', 'history_writes')}
    assert counts == {'refusals': 101, 'reads': 5, 'replays': 6, 'history_writes': 8}
    assert facts['engine_exit_codes'] == [-15, -15] and 'recovered_entities' in facts
    actual_sqlite[name] = {**counts, 'engine_exit_codes': facts['engine_exit_codes'],
        'complete_logical_state_unchanged_around_refusals_reads_and_replays': True,
        'independent_recovery_preserves_stable_records_history_and_operation_facts': True}
validation = {'schema_version': 1, 'status': 'bounded_seven_contracts_validated_full_graphical_gate_open',
    'implementation_commit': head, 'tested_source_count': 420,
    'tested_source_dictionary_sha256': candidate['source_dictionary_sha256'],
    'source_hash_algorithm': 'canonical sorted relative-path to file-SHA256 JSON; not C4-source-v1',
    'configuration_counts': {entry['configuration']: entry['executed_count'] for entry in completed['configurations']},
    'actual_ctest_executions': 261, 'actual_ctest_passed': 261, 'actual_ctest_failed': 0,
    'complete_relevant_non_graphical_matrix_passed': True,
    'compiler_warnings': 0, 'strict_cpp20': True,
    'asan_ubsan_scope': 'typed_host only', 'lsan': 'NOT RUN',
    'baseline': {'final_existing_cases_passed': 4, 'first_sandbox_cpp_passed': 1,
                 'first_sandbox_ipc_failed_before_ready': 1, 'failure_preserved': True,
                 'not_in_261_ctest_denominator': True},
    'actual_SQLite': actual_sqlite, 'independent_source_review_blockers': 0,
    'archive': {**fact(archive), 'member_count': len(index), 'all_members_and_origins_reverified': True},
    'docs_only_frozen_input_delta': ['adapters/engine_api/README.md'],
    'limits': ['No new GUI execution or cumulative graphical failure closure',
               'f2d local bundle remains unrefreshed; old package evidence keeps its source scope',
               'No real solver/full external AI/performance/full SK or P0 acceptance',
               'Full SDK copy coverage remains unknown/deferred only from C4 startup; measured constraints and material14/30 failures retained',
               'Output labels describe existing results; no new generated output schemas',
               'operations.get retains its conditional compatibility outside this implemented batch']}
dump(DEST / 'validation.json', validation)
REPORT.write_text(f'''# 七个读取与历史入口的生成契约

实现提交 `{head}` 已合入主工作区。五个读取入口和undo/redo共用生成版本1输入、闭合空参数schema与版本规则；相关五配置实际261/261通过。完整图形、SK和P0验收仍未关闭，本机包仍为 `f2d2e7f`，未刷新。

## 实现与权威路径

| 入口 | 实际输入DTO | 已有结果标签 | 最小上下文 |
|---|---|---|---|
| capabilities.list | CapabilitiesListInput | CapabilityCatalog | 无文档上下文 |
| project.current | ProjectCurrentInput | DocumentInfo | 无文档上下文 |
| project.status | ProjectStatusInput | ProjectStatus | document/epoch |
| model.summary | ModelSummaryInput | ModelSummary | document/epoch |
| history.list | HistoryListInput | HistorySnapshot | document/epoch |
| history.undo | HistoryUndoInput | ChangeReceipt | document/epoch/revision/key |
| history.redo | HistoryRedoInput | ChangeReceipt | document/epoch/revision/key |

`host_reads.json` 定义五个读取，`document_changes.json` 追加两个历史输入。所有schema为 `qcae.operation.<operation>.v1`，字段为空。IPC复用已有输入/版本/发现函数，省略或整数1选择已安装合同；非法版本为 `INVALID_INPUT`，其他合法uint32为 `SCHEMA_UNSUPPORTED`，字段均为 `requested_version`。额外字符串、数字、null输入拒绝在原应用调用之前。

输入验证后仍调用原 `MemoryApplication` → 单一 `RecordApplication`；undo/redo仍使用同一caller、WriteContext、幂等命名空间与persist-before-swap协调器。读取不要求写修订或变更键；历史写各提交一次，旧请求重放只报告原事实。没有修改应用、TypedHost、registry、存储或桥实现，也没有增加依赖、SDK公开核心类型或性能机制。

发现保留设计符号类型与query/model_write效果，用wire标签描述实际DTO/既有结果；生成内部效果read_only/document_write分别保留。结果标签不是新增的生成输出schema。status/summary原来已有正确手写空schema，此次统一来源与版本；其他五个入口补齐实际接受的闭合参数发现。`operations.get` 的条件上下文、忽略的original_mode及原返回路径继续保留。

## 实际验证

| 配置 | 实际执行/通过 |
|---|---:|
| 纯核心Release | 40/40 |
| 本地Debug | 55/55 |
| SQLite/Nastran ON，无桌面 | 87/87 |
| SQLite/Nastran OFF，无桌面 | 78/78 |
| ASan/UBSan typed_host专项 | 1/1 |
| 合计 | 261/261 |

同一冻结420输入完成所有配置，严格C++20、零编译警告；生成及公共头消费者在对应构建/CTest中检查。LSan未测。修改前四项既有C++/IPC/MCP基线通过；最初沙箱内C++通过、IPC因本地socket监听限制失败，原记录保留，随后同源同产品的已授权基线四项通过。这六次前置执行不计入261次CTest分母。

C++共用一个实际应用/假存储场景，比较完整record view/version、存储行、保存快照、metadata、history、generation和计数器；精确检查七个定义与发现、读取的完整既有结果、版本/形状/上下文拒绝、caller/key/replay及排除的lookup兼容。假存储不充当SQLite证据。最终独立源码审查无阻塞，审查者未运行产品。

两个真实SQLite场景各完成101次拒绝、5个读取的省略/显式版本对比、8次历史写、6次原commit/undo/redo重放。每次读取/拒绝/重放比较全部逻辑表、列、BLOB、generation、DocumentInfo和history。保存后的两记录模型在undo U → redo R → retry U中保持重做后的内容与游标；非法输入及不可重做拒绝后的同键可成功执行。旧签名、旧revision、unknown key和旧epoch拒绝，原三份结果仍可查询。每次独立进程recover后稳定ID/完整暴露字段/history相等、epoch更新、原事实保留；两个engine均SIGTERM退出-15，无物理WAL字节相等主张。

实际双MCP/CLI共享流程覆盖七个入口的完整engine元数据到工具schema/说明、参数和版本转发，以及历史原结果重放。可选requested_version仍是正uint32范围schema，安装版本为1；未人为加const或在桥内解码业务。既有save/open/close及其他回归在对应完整配置保留，不为七个入口复制生命周期。

## 证据与剩余工作

[机器记录](host-controls-evidence/2026-10-03/validation.json)、[成员索引](host-controls-evidence/2026-10-03/archive-index.json)和[原始归档](host-controls-evidence/2026-10-03/evidence.tar.gz)保留方法、源码/产品hash、实际命令/日志、SQLite观察和transcript、初始沙箱失败、格式前后源码、静态审查及后续只读方案。归档{len(index)}成员、{archive.stat().st_size}字节，SHA256 `{sha(archive)}`；每成员和来源已回读相等，不含数据库、二进制或构建树。

冻结420输入字典SHA256 `{candidate['source_dictionary_sha256']}`，算法为排序相对路径→文件SHA256的canonical JSON，非C4-source-v1。说明阶段只有冻结输入中的engine_api README文档变化，其他419输入保留测试范围；没有为文档重跑产品。设计/格式/diff门禁与最终归档独立核对在收尾记录登记。

原累计图形180秒失败及旧二进制69数据行隔离诊断仍按[原证据](changes-commit-contract-2026-10-03.md)保留，当前源码没有新增图形执行或根因修复。下一步为 `operations.get` 的条件schema、兼容投影与MCP上下文发现，使用已有生成器并保留原应用路径；这是未执行方案，不能据此宣布完成。更广目录、真实Nastran/完整外部AI、性能、未知SDK覆盖、已测原预算及完整SK/P0仍保持此前范围。继续以核心框架质量为目标，不追加非必要性能优化。
''')

# Current entry points point to the verified new slice; older evidence is unchanged.
path = SOURCE / 'README.md'
lines = path.read_text().splitlines()
old = next(line for line in lines if line.startswith('最新源码 `88942c0`'))
path.write_text(path.read_text().replace(old, '最新源码 `8924149` 已成组补齐五个读取与undo/redo入口的生成输入、实际发现及版本规则，沿用单一应用状态和历史事务，见[本轮验证](docs/engineering/host-controls-contracts-2026-10-03.md)。同源五配置261/261通过，包含真实SQLite拒绝/原结果重放/独立进程恢复与双MCP/CLI流程。本机包尚未刷新；原累计图形失败及完整图形门禁仍未关闭。接续 `operations.get` 条件契约和核心正式验收，真实求解、完整AI、性能及完整SK/P0仍未验收，原约束见[开发计划](docs/baseline/development-plan.md#c2之后的接续计划)。'))
insert_before(SOURCE / 'docs/README.md', '[预览提交契约与实际恢复验证]', '[七个读取与历史入口契约](engineering/host-controls-contracts-2026-10-03.md)：`8924149` 五配置261/261通过，真实SQLite完整状态保护、原结果重放和恢复，以及双MCP/CLI元数据/调用。原图形失败、旧包及完整SK/P0范围保留。')
latest = '2026-10-03，`8924149` 已成组完成七个读取/历史入口生成合同及发现、版本与原子性保护；五配置261/261实际通过，见[验证](../engineering/host-controls-contracts-2026-10-03.md)。读取不要求写修订/键，历史提交与原结果重放保持单一应用权威。下一切片为 `operations.get` 条件输入/上下文与兼容投影，方案未执行；原图形累计失败、未刷新本机包、真实环境、性能和完整SK/P0仍保持未完成范围，不做非必要性能优化。'
insert_before(SOURCE / 'docs/baseline/README.md', '2026-10-03，`changes.commit`', latest)
insert_before(SOURCE / 'docs/baseline/development-plan.md', '2026-10-03，`88942c0`', latest)
path = SOURCE / 'docs/implementation/core-local-handoff.md'
old = next(line for line in path.read_text().splitlines() if line.startswith('最新源码 `88942c0`'))
path.write_text(path.read_text().replace(old, '最新源码 `8924149` 已补齐七个读取/历史生成入口，并以同源五配置261/261验证，见[本轮证据](../engineering/host-controls-contracts-2026-10-03.md)。此前提交契约及图形诊断见[原记录](../engineering/changes-commit-contract-2026-10-03.md)。本页本机包仍为 `f2d2e7f`，未刷新，不能据此使用新版元数据。原累计图形失败和完整图形门禁仍未关闭；接续 `operations.get` 条件契约及核心正式验收。真实Nastran/完整外部AI、性能、SDK复制未知与已测预算失败仍保持原范围，不把本地交接标为完整P0。'))
path = SOURCE / 'docs/contracts/README.md'
original = path.read_text()
assert '五个宿主工程生命周期入口及 `changes.commit` 同样接受操作版本' in original
original = original.replace('五个宿主工程生命周期入口及 `changes.commit` 同样接受操作版本', '五个宿主工程生命周期入口、`changes.commit` 及七个读取/历史入口同样接受操作版本')
original += '\n## 已有读取与历史输入\n\n`capabilities.list/project.current/project.status/model.summary/history.list/history.undo/history.redo` 使用生成版本1的空参数输入及闭合schema，省略版本选择安装版本，额外字段与非法/未安装版本在原应用调用前拒绝。前两项无文档上下文，中间三个读取只需document/epoch，undo/redo保持原document/epoch/revision/key。发现保留符号类型/效果并公布实际wire输入和既有结果标签；没有生成新的输出schema。`operations.get` 条件兼容仍单独保留。实际范围见[七入口验证](../engineering/host-controls-contracts-2026-10-03.md)，不据此声明完整目录/SK/P0通过。\n'
path.write_text(original)
path = SOURCE / 'adapters/engine_api/README.md'
original = path.read_text().replace('below and `changes.commit` also accept this operation version. Other legacy operations keep their existing request\nshape and reject the new context fields.', 'below, `changes.commit`, and the seven host read/history routes also accept this operation\nversion. Other legacy operations keep their existing request shape and reject the new context fields.')
marker = '### C3 versioned display resources and events'
section = '''### Versioned host reads and history

`capabilities.list`, `project.current`, `project.status`, `model.summary`, `history.list`,
`history.undo` and `history.redo` decode generated empty v1 inputs and advertise closed
empty parameter schemas. The first two need no document context; the next three need
document/epoch only; undo/redo retain document/epoch/revision/key. Omitted/v1 requests use
the installed contract. Invalid shape/version is rejected before the same application
service call. Reads preserve authoritative state; history writes use the original one
commit coordinator and retain replay facts after later undo/redo. Symbolic catalog labels
and serializers are unchanged; wire result labels describe existing results rather than
new generated output schemas. `operations.get` retains its conditional compatibility.
See [actual tests and scope](../../docs/engineering/host-controls-contracts-2026-10-03.md).

'''
assert original.count(marker) == 1
path.write_text(original.replace(marker, section + marker))
path = SOURCE / 'docs/engineering/execution-status.json'
state = json.loads(path.read_text())
previous = state['current_core_framework']
assert 'historical_core_framework_before_host_controls' not in state
state['historical_core_framework_before_host_controls'] = copy.deepcopy(previous)
state['current_core_framework'] = {
    'status': 'seven_generated_host_contracts_validated_non_graphical_full_graphical_gate_open',
    'tested_implementation_commit': head, 'source_files_count': 420,
    'source_dictionary_sha256': candidate['source_dictionary_sha256'],
    'source_hash_algorithm': validation['source_hash_algorithm'],
    'manifest': 'docs/engineering/host-controls-evidence/2026-10-03/validation.json',
    'report': 'docs/engineering/host-controls-contracts-2026-10-03.md',
    'handoff': 'docs/implementation/core-local-handoff.md',
    'configuration_order': ['core', 'local', 'sqlite_on_no_desktop', 'sqlite_off_no_desktop', 'asan_ubsan_typed_host'],
    'full_regression_counts': [40, 55, 87, 78, 1], 'configuration_inventory_counts': [40, 55, 87, 78, 55],
    'cross_configuration_executions': 261, 'cross_configuration_passed': 261,
    'actual_ctest_executions_with_rerun_and_repeat': 261, 'actual_ctest_passed_with_repeats': 261,
    'actual_ctest_failures': 0, 'actual_ctest_timeouts': 0,
    'full_matrix_passed': True, 'full_matrix_scope': 'relevant non-graphical four full configurations plus one ASan/UBSan typed_host test',
    'versioned_existing_host_inputs': previous['versioned_existing_host_inputs'] + [item[0] for item in (
        ('capabilities.list',), ('project.current',), ('project.status',), ('model.summary',), ('history.list',), ('history.undo',), ('history.redo',))],
    'actual_contribution_categories': previous['actual_contribution_categories'],
    'actual_contribution_selected_ports': previous['actual_contribution_selected_ports'],
    'local_package': copy.deepcopy(previous['local_package']),
    'actual_packaged_workflows': copy.deepcopy(previous['actual_packaged_workflows']),
    'current_graphical_blocker': copy.deepcopy(previous['current_graphical_blocker']),
    'bounded_host_controls_SQLite': actual_sqlite,
    'post_validation_frozen_input_documentation_delta': ['adapters/engine_api/README.md'],
    'priority': previous['priority'],
    'next_core_interface': 'operations.get conditional parameter/context discovery and compatibility projection; plan177 only, not implemented',
    'limits': validation['limits'] + ['ASan/UBSan typed_host only; LSan unmeasured',
        'Prior commit-contract259/263 counts and original failures retained under historical_core_framework_before_host_controls']}
# Inventory must come from the actual configured CTest JSON, including sanitizer's unexecuted cases.
state['current_core_framework']['configuration_inventory_counts'] = [
    len(entry['configured_test_names']) for entry in completed['configurations']]
state['updated_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
dump(path, state)
post_inputs = {name: sha(SOURCE / name) for name in inputs}
delta = [name for name in inputs if post_inputs[name] != inputs[name]]
assert delta == ['adapters/engine_api/README.md'], delta
dump(ROOT / 'post-doc-source.json', {'compiled_source_dictionary_sha256': candidate['source_dictionary_sha256'],
    'frozen_input_documentation_delta': delta, 'other419_inputs_unchanged': True,
    'compiled_products_before_after_equal': all(fact(Path(name)) == record for name, record in products.items()),
    'archive_all_members_and_origins_equal': True, 'archive': fact(archive), 'member_count': len(index),
    'documentation_product_rerun': 'NOT RUN; no compiled input change except README documentation'})
print(json.dumps({'implementation_commit': head, 'archive': fact(archive), 'member_count': len(index),
                  'report': str(REPORT), 'frozen_input_documentation_delta': delta}, ensure_ascii=False))
