# 本地 Release 包与重定位观察：138 私有方法

状态：**PREPARED / NOT RUN**。以 `ac7a20046e83acba525395da10b43468923ef755` 只读审查 staging 工具和既有 smoke 方法；最终 combined create/assembly 的 HEAD、生产输入 SHA、实际 build 来源由根代理冻结后传入，不把旧来源改标最终通过。本目录不构建，不运行 guard、产品或 GUI。根代理统一调度下述四个动作，无新依赖或下载。

## 最终输入

复制 `config.template.json` 到新的 root-owned 配置文件，填入三项 null，必要时改 fresh bundle/relocation 路径。`frozen_source` 必须有 `commit`、`source_files`（相对路径→SHA 或 `{sha256,...}`）以及与显式 `expected_source_sha256` 相同的 `source*_sha256` 字段。生产字典与实际 successor141 `candidate_files` 必须完全相等；不会把已失败初轮141当成功构建。根会在最终提交后快进 main，保留用户 AGENTS 修改；main 与 delivery80 的同一最终 HEAD/生产输入逐项相等，`source_dirty` 原样记录，允许仅这些已冻结生产输入之外的用户/文档变动。

现工具强制 `.app` 为其脚本 ROOT 下新 `out/` 目录；主工作区已具备固定 VTK license 路径。Qt 许可证来自同版本 `qtbase-everywhere-src-6.11.1/LICENSES`，不是旧 bundle 的副本。实际 stock Qt CMake `/opt/homebrew/Cellar/qtbase/6.11.1/lib/cmake/Qt6`，VTK CMake `.../build-vtk-deps/install/lib/cmake/vtk-9.7`，SQLite 默认 3.53.4；库及工具/许可证摘要在 `prepared-inputs.json`。匹配源码之外的 Qt、VTK、SQLite 内部复制量不在本观察范围，不冒充整库 sanitizer。

不另建 build runner。消费 successor141 实际 `desktop-build.json` 的 `actual_exit_code=0`、完整 candidate 输入和 Release cache；检查 IPC/storage/desktop/Nastran ON、SAN OFF、SQLite observer 空。由未修改的 `tools/stage_macos_package.py` 复制四个 app、部署实际 Mach-O 闭包/许可证、相对 loader paths、adhoc 签名，保留相邻 manifest。检查原 build 五个文件前后 SHA 相同；新重定位副本所有非 symlink 文件 SHA、相对 link targets 与原 bundle 相同，每个非 system Mach-O 依赖重新解析到重定位副本内，再验深签名。

## 根代理顺序执行命令（现在全部 NOT RUN）

每个 output 都必须不存在。下面 `final-config.json` 是根填好的**新**配置；不修改本目录封存 template。所有路径是具体建议，根可改为其他 fresh 路径，Unix socket 字节路径需小于100。

```sh
/Library/Frameworks/Python.framework/Versions/3.14/bin/python3.14 /private/tmp/qcae-local-delivery138/run.py --config /private/tmp/qcae-local-delivery138-final-config.json --action package --output /private/tmp/qcae-delivery138-package-01 --root-authorized-execution

/Library/Frameworks/Python.framework/Versions/3.14/bin/python3.14 /private/tmp/qcae-local-delivery138/run.py --config /private/tmp/qcae-local-delivery138-final-config.json --action sqlite --package-summary /private/tmp/qcae-delivery138-package-01/package-summary.json --output /private/tmp/qcae-delivery138-sqlite-01 --root-authorized-execution

/Library/Frameworks/Python.framework/Versions/3.14/bin/python3.14 /private/tmp/qcae-local-delivery138/run.py --config /private/tmp/qcae-local-delivery138-final-config.json --action mcp --package-summary /private/tmp/qcae-delivery138-package-01/package-summary.json --output /private/tmp/qcae-delivery138-mcp-01 --root-authorized-execution

/Library/Frameworks/Python.framework/Versions/3.14/bin/python3.14 /private/tmp/qcae-local-delivery138/run.py --config /private/tmp/qcae-local-delivery138-final-config.json --action gui --package-summary /private/tmp/qcae-delivery138-package-01/package-summary.json --output /private/tmp/qcae-delivery138-gui-01 --root-authorized-execution
```

`sqlite` 使用新 SQLite 工作库和包内 CLI/engine：Version1 新建→材料创建/编辑→保存→另存→keep_recovery 关闭→SIGTERM/reap→同工作库新 engine PID→显式 recover。四个生命周期操作分别以 unsupported2 和错误字段类型拒绝，要求精确错误码、所有 SQLite schema/tables 逻辑行前后相等，随后同 key 有效 Version1 成功。明确保存不增加 revision/history，省略/空 save path 保持原语义，恢复保留 DocId/revision/材料全部字段/history、更新 Epoch，旧 Epoch 的 undo 拒绝。目标仅一个材料的真实生命周期，不替代完整33M、故障矩阵或 normal-open 全契约测试。

`mcp` 同时启动两个包内 launcher，显式传现有 Python：初始化、真实 tools/list、发现目录与生产 available 描述相等；共享新建/材料创建，两客户端共享 DocId/revision，第二客户端同 key 重试返回同 tx，CLI 观察一致。每个客户端保留原始 JSONRPC transcript 和 stdout/stderr，stdin EOF 正常0回收。它证明 stdio bridge 能运行，不是外部AI会话，也不声称每个 handler 的行为。

`gui` 使用生产 `--smoke --socket ... --screenshot ... --quit-after-ms 5000`，保持既有25s外层期限。从已冻结仓库 BDF 输入经 preview/commit 导入2节点1梁，真实 Cocoa Qt/VTK 启动退出0，PNG头正确且至少5000B，CLI 文档前后完全相同/revision1，engine仍活着。smoke生产路径不读写用户布局；未调用 `setText`、假pick或 offscreen。本观察不证明正式选择/交互生命周期或性能。

## 原始输出与退出

四次各写 source-before/after、config-input、complete 或 failure；每个实际 CLI/stage/GUI/MCP/engine 命令分目录保存 argv/env/PID/start/end/return、stdout/stderr bytes/SHA。每次 CLI 的输入完整保存。SQLite拒绝前后全部逻辑行各存原JSON，保存文件、截图和原 DB/WAL 留在私有 work/。MCP transcript 保留实际双方调用。失败先写 receipt/failure，不续跑其后步骤；不覆盖失败或自动重试。

移除环境中的 DYLD/Qt 插件覆盖及 sanitizer 变量，显式 PATH 与 CommandLineTools；不改 HOME/CODEX_HOME。仅对本次 `start_new_session` 持有的进程组清理：engine SIGTERM，10s内 reap，要求 literal -15；MCP先 EOF，5s正常0，否则保留失败并对 owned group SIGTERM。不会 SIGKILL，不查杀其他进程；不能回收则写 cleanup-incomplete，根须处理。正常结束/失败后都做源码/工具/SDK guard；正常观察还核对原 build/bundle 字节未变。

包仅本机 arm64、macOS 最小目标26.0（更旧系统未验证）、本地 adhoc 签名，未公证。MCP 的 Python>=3.10 明确**不在包内**，不用源码/旧build启动engine/CLI。真实 solver、外部AI、fullSK/P0 与既有性能未知/失败不随本任务晋级。构建、打包和三个观察现均 **NOT RUN**。

## README/status-only 建议（不写入仓库）

1. 根 README 第5行把“几何/网格暂无GUI入口”改为已有C3建线/网格工具入口，并连接最新当前契约记录；保留历史 C2 说明的来源。新增本次最终 Release bundle 路径、四个包内启动方法、Python前置、显式 SQLite workspace 与包限度，待实际结果后填 source/manifest SHA。
2. `execution-status.json.current_core_framework` 的 ef0df/378 仍保留其真实来源，另加当前 combined 的 commit/输入SHA与实际141 counts、当前包观察 evidence；不能把旧378替换为新来源的通过数。当前413/177+33 SQLite补证与未来combined也各自标来源。
3. 旧 M6 build33e 的144/418仅历史，不拿它声称当前包已可运行；本次新包实际 closure、签名、重定位及三个有限观察成功后再写“本机包已验证”，仍不写 M6/P0 发布完成。用户 AGENTS 修改不动，DB/bundle/build均不入版本控制。

Root successor01: the initial package preflight stopped before any product command because Homebrew uses an aggregate Qt6 directory. The actual Qt6Config.cmake resolves to the identical previously pinned qtbase 6.11.1 file (SHA e51efd902565cdef78a66174dfd5771096ecd79fea73f282fd843a9d1e751faa). Only this directory-versus-file identity check changed; all 184 tool/SDK/license pins and product guards remain. Original method and failed package-01 receipts remain unchanged.
