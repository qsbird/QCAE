#!/usr/bin/env python3
"""Root-owned, bounded local package checks; preparation has no product side effects."""
from __future__ import annotations

import argparse
import base64
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import select
import shutil
import signal
import sqlite3
import subprocess
import time
import traceback
from urllib.parse import quote

HERE = Path(__file__).resolve().parent
TARGETS = ("qcae-desktop", "qcae-engine", "qcae-cli", "qcae-mcp")
REMOVED_ENV = ("DYLD_LIBRARY_PATH", "DYLD_FRAMEWORK_PATH", "DYLD_FALLBACK_LIBRARY_PATH",
               "DYLD_FALLBACK_FRAMEWORK_PATH", "QT_PLUGIN_PATH", "QT_QPA_PLATFORM_PLUGIN_PATH",
               "QML2_IMPORT_PATH", "QML_IMPORT_PATH", "QT_QPA_PLATFORM",
               "DYLD_INSERT_LIBRARIES", "DYLD_PRINT_LIBRARIES", "ASAN_OPTIONS", "UBSAN_OPTIONS", "LSAN_OPTIONS")


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def fact(path):
    path = Path(path).resolve(strict=True)
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return {"path": str(path), "bytes": path.stat().st_size, "sha256": digest.hexdigest()}


def write(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x") as stream:
        stream.write(json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False) + "\n")


def git(root, *args):
    return subprocess.check_output(["git", "-C", str(root), *args], text=True).strip()


def source_fence(config):
    frozen = json.loads(Path(config["frozen_source"]).read_text())
    expected = config["expected_head"]
    require(frozen["commit"] == expected, "Freeze/explicit HEAD mismatch")
    source = frozen["source_files"]
    require(len(source) >= 400, "Expected final full production/source input inventory")
    require(config["expected_source_sha256"] in
            [v for k, v in frozen.items() if k.startswith("source") and k.endswith("sha256")],
            "Explicit source digest is absent from supplied freeze")
    states = []
    for root_name in ("source_root", "build_source_root"):
        root = Path(config[root_name]).resolve(strict=True)
        require(git(root, "rev-parse", "HEAD") == expected, root_name + " has wrong HEAD")
        for name, expected_sha in source.items():
            expected_sha = expected_sha["sha256"] if isinstance(expected_sha, dict) else expected_sha
            require(fact(root / name)["sha256"] == expected_sha, root_name + ": " + name)
        untracked = git(root, "ls-files", "--others", "--exclude-standard").splitlines()
        require(not any(name.startswith(("apps/", "adapters/", "modules/", "profiles/", "tools/", "tests/"))
                        for name in untracked), "Untracked production input is outside freeze")
        states.append({"root": str(root), "head": expected,
                       "source_inputs_verified": len(source),
                       "status_porcelain": git(root, "status", "--porcelain=v1")})
    pins = json.loads((HERE / "prepared-inputs.json").read_text())
    for row in pins["tool_sdk_and_license_inputs"]:
        require(fact(row["path"]) == row, "Prepared tool/SDK/license changed: " + row["path"])
    for row in pins["method_files"]:
        require(fact(row["path"]) == row, "Prepared method changed: " + row["path"])
    # The staging tool and seed resources were read on ac7a200. A future change
    # requires a method successor, rather than silently importing a new method.
    for row in pins["repository_method_inputs"]:
        if not row["runtime_input"]:
            continue
        require(fact(Path(config["source_root"]) / row["relative_path"])["sha256"] == row["sha256"],
                "Reviewed staging/smoke input changed: " + row["relative_path"])
    return {"frozen_source": fact(config["frozen_source"]), "explicit_head": expected,
            "explicit_source_sha256": config["expected_source_sha256"], "roots": states,
            "prepared_inputs": fact(HERE / "prepared-inputs.json")}


def bundle_facts(bundle):
    bundle = Path(bundle).resolve(strict=True)
    entries = []
    for path in sorted(bundle.rglob("*")):
        relative = str(path.relative_to(bundle))
        if path.is_symlink():
            require(path.resolve(strict=True).is_relative_to(bundle), "Bundle link escapes: " + relative)
            entries.append({"path": relative, "link": os.readlink(path)})
        elif path.is_file():
            row = fact(path)
            entries.append({"path": relative, "bytes": row["bytes"], "sha256": row["sha256"]})
    require(all(any(row["path"] == "Contents/MacOS/" + name for row in entries) for name in TARGETS),
            "Relocated package is missing executable")
    return entries


class Recorder:
    def __init__(self, config, output):
        self.config, self.output, self.sequence = config, output, 0
        self.env = os.environ.copy()
        self.removed = {name: self.env.pop(name) for name in REMOVED_ENV if name in self.env}
        self.env["PYTHONDONTWRITEBYTECODE"] = "1"
        self.env["QCAE_SOURCE_TREE_SHA256"] = config["expected_source_sha256"]
        self.env["PATH"] = "/usr/bin:/bin:/usr/sbin:/sbin"
        self.env["DEVELOPER_DIR"] = "/Library/Developer/CommandLineTools"
        self.captured_environment = {"removed_names": sorted(self.removed),
                                     "explicit": {"PYTHONDONTWRITEBYTECODE": "1",
                                                  "QCAE_SOURCE_TREE_SHA256": config["expected_source_sha256"],
                                                  "PATH": self.env["PATH"],
                                                  "DEVELOPER_DIR": self.env["DEVELOPER_DIR"]},
                                     "HOME_unchanged": True, "CODEX_HOME_unchanged": True}
        self.children = []

    def new_dir(self, label):
        self.sequence += 1
        path = self.output / f"{self.sequence:03d}-{label}"
        path.mkdir()
        return path

    def start(self, label, argv, pipe_input=False, pipe_output=False):
        directory = self.new_dir(label)
        stdout = None if pipe_output else (directory / "stdout.log").open("xb")
        stderr = (directory / "stderr.log").open("xb")
        started = time.time()
        requested = [str(x) for x in argv]
        write(directory / "command-input.json", {"requested_argv": requested,
              "cwd": str(directory), "requested_unix": started, "environment": self.captured_environment})
        try:
            process = subprocess.Popen(requested, cwd=directory, env=self.env,
                                       stdin=subprocess.PIPE if pipe_input else subprocess.DEVNULL,
                                       stdout=subprocess.PIPE if pipe_output else stdout, stderr=stderr,
                                       start_new_session=True)
        except Exception as error:
            for handle in (stdout, stderr):
                if handle:
                    handle.close()
            write(directory / "spawn-failure.json", {"error": repr(error), "requested_argv": requested,
                  "actual_pid": None, "actual_exit_code": None, "product_started": False})
            raise
        item = {"process": process, "directory": directory, "started": started,
                "argv": [str(x) for x in argv], "handles": [x for x in (stdout, stderr) if x],
                "pipe_output": pipe_output, "sealed": False}
        self.children.append(item)
        write(directory / "started.json", {"actual_argv": item["argv"], "pid": process.pid,
              "started_unix": started, "cwd": str(directory), "environment": self.captured_environment})
        print(json.dumps({"started": label, "pid": process.pid}), flush=True)
        return item

    def finish(self, item, timed_out=False, cleanup=None):
        require(item["process"].poll() is not None, "Owned process has not terminated")
        require(not item["sealed"], "Duplicate process receipt")
        for handle in item["handles"]:
            handle.close()
        item["sealed"] = True
        directory = item["directory"]
        receipt = {"actual_argv": item["argv"], "pid": item["process"].pid,
                   "started_unix": item["started"], "finished_unix": time.time(),
                   "actual_exit_code": item["process"].returncode, "timed_out": timed_out,
                   "cwd": str(directory), "environment": self.captured_environment,
                   "source_head": self.config["expected_head"],
                   "source_sha256": self.config["expected_source_sha256"],
                   "stdout": fact(directory / "stdout.log"), "stderr": fact(directory / "stderr.log"),
                   "cleanup": cleanup, "method": fact(__file__)}
        write(directory / "receipt.json", receipt)
        return receipt

    def stop(self, item, expected_exit=-15):
        process = item["process"]
        signaled = process.poll() is None
        if signaled:
            # The new session and all descendants belong to this invocation.
            os.killpg(process.pid, signal.SIGTERM)
            try:
                process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                write(item["directory"] / "cleanup-incomplete.json",
                      {"owned_pid": process.pid, "SIGTERM_sent": True, "SIGKILL_sent": False,
                       "still_live": process.poll() is None})
                raise RuntimeError("Owned PID did not reap after SIGTERM; root attention required")
        receipt = self.finish(item, cleanup={"SIGTERM_sent": signaled, "SIGKILL_sent": False,
                                            "reaped": True})
        require(receipt["actual_exit_code"] == expected_exit, "Unexpected owned-process cleanup exit")
        return receipt

    def run(self, label, argv, stdin=None, timeout=None):
        item = self.start(label, argv, pipe_input=stdin is not None, pipe_output=True)
        if stdin is not None:
            (item["directory"] / "stdin.json").write_bytes(stdin)
        timed_out = False
        try:
            stdout, _ = item["process"].communicate(input=stdin, timeout=timeout)
        except subprocess.TimeoutExpired:
            timed_out = True
            os.killpg(item["process"].pid, signal.SIGTERM)
            stdout, _ = item["process"].communicate(timeout=10)
        (item["directory"] / "stdout.log").write_bytes(stdout)
        receipt = self.finish(item, timed_out=timed_out)
        require(not timed_out, "Actual command timed out; receipt retained")
        require(receipt["actual_exit_code"] == 0, "Actual command failed; receipt retained")
        return stdout


class Host:
    def __init__(self, recorder, directory):
        self.recorder, self.directory = recorder, directory
        self.socket = directory / "engine.sock"
        require(len(os.fsencode(self.socket)) < 100, "Use a shorter fresh runtime path for Unix socket")
        self.database = directory / "workspace.sqlite"
        self.bin = Path(recorder.config["relocated_bundle"]) / "Contents/MacOS"
        self.process, self.calls = None, 0

    def start(self):
        self.process = self.recorder.start("engine", [self.bin / "qcae-engine", "--socket", self.socket,
                                                    "--workspace", self.database])
        deadline = time.monotonic() + 15
        while time.monotonic() < deadline and self.process["process"].poll() is None:
            if self.socket.exists() and b"QCAE engine ready:" in (self.process["directory"] / "stderr.log").read_bytes():
                return self.call("capabilities.list")
            time.sleep(.025)
        raise RuntimeError("Owned engine did not reach actual socket/readiness marker within 15s")

    def stop(self):
        result = self.recorder.stop(self.process)
        self.process = None
        return result

    def call(self, operation, parameters=None, context=None, key=None, version=None, status="success", code=None):
        self.calls += 1
        request = {"api_version": "1.1", "request_id": f"delivery138-{self.calls}",
                   "operation": operation, "parameters": parameters or {}}
        if context:
            request.update(document_id=context["document_id"], document_epoch=context["document_epoch"],
                           expected_revision=context["revision"])
        if key:
            request["idempotency_key"] = key
        if version is not None:
            request["requested_version"] = version
        # Expected negative CLI exits are captured before their semantic assertion.
        item = self.recorder.start("cli-" + operation.replace(".", "-"),
                                   [self.bin / "qcae-cli", "--socket", self.socket, "--no-start"],
                                   pipe_input=True, pipe_output=True)
        encoded = (json.dumps(request, separators=(",", ":")) + "\n").encode()
        (item["directory"] / "stdin.json").write_bytes(encoded)
        try:
            stdout, _ = item["process"].communicate(encoded, timeout=15)
        except subprocess.TimeoutExpired:
            os.killpg(item["process"].pid, signal.SIGTERM)
            stdout, _ = item["process"].communicate(timeout=10)
            (item["directory"] / "stdout.log").write_bytes(stdout)
            self.recorder.finish(item, timed_out=True)
            raise RuntimeError("CLI timed out; failed receipt retained")
        (item["directory"] / "stdout.log").write_bytes(stdout)
        receipt = self.recorder.finish(item)
        require(receipt["actual_exit_code"] == (0 if status == "success" else 2), "CLI exit/status mismatch")
        response = json.loads(stdout)
        require(response["request_id"] == request["request_id"] and response["status"] == status,
                "CLI response mismatch")
        if code:
            require(response["error"]["code"] == code, "Exact negative error-code mismatch")
        return response["data"] if status == "success" else response

    def current(self):
        return self.call("project.current")

    def rows(self, name):
        def value(cell):
            return {"blob_base64": base64.b64encode(cell).decode()} if isinstance(cell, bytes) else cell
        uri = "file:" + quote(str(self.database)) + "?mode=ro"
        with sqlite3.connect(uri, uri=True) as connection:
            connection.execute("BEGIN")
            schemas = list(connection.execute("SELECT type,name,tbl_name,sql FROM sqlite_schema ORDER BY type,name"))
            tables = {}
            for (table,) in connection.execute("SELECT name FROM sqlite_schema WHERE type='table' ORDER BY name"):
                quoted = '"' + table.replace('"', '""') + '"'
                rows = [[value(cell) for cell in row] for row in connection.execute("SELECT * FROM " + quoted)]
                tables[table] = sorted(rows, key=lambda row: json.dumps(row, sort_keys=True, allow_nan=False))
        result = {"schema": schemas, "tables": tables, "read_only": True}
        result["logical_rows_byte_sha256"] = hashlib.sha256(
            json.dumps(result, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()).hexdigest()
        write(self.recorder.output / (name + ".json"), result)
        return result

    def reject(self, label, operation, parameters, context, key, version, code):
        before = self.rows(label + "-rows-before")
        raw = self.call(operation, parameters, context, key, version, "failed", code)
        after = self.rows(label + "-rows-after")
        require(before == after, "Rejected request changed complete SQLite logical rows")
        return raw


def package(recorder):
    config = recorder.config
    source, build = Path(config["source_root"]), Path(config["build_dir"])
    build_receipt = json.loads(Path(config["actual_build_receipt"]).read_text())
    require(build_receipt["actual_exit_code"] == 0, "Root actual build receipt is not successful")
    compiled = json.loads(Path(config["actual_build_candidate"]).read_text())["candidate_files"]
    frozen_inputs = json.loads(Path(config["frozen_source"]).read_text())["source_files"]
    normalized = {name: value["sha256"] if isinstance(value, dict) else value
                  for name, value in frozen_inputs.items()}
    require(compiled == normalized, "Actual build candidate inputs differ from final frozen production inputs")
    cache = (build / "CMakeCache.txt").read_text()
    for name, kind, value in (("CMAKE_BUILD_TYPE", "STRING", "Release"),
                              ("QCAE_C3_SQLITE_OBSERVED_OBJECT", "FILEPATH", ""),
                              ("QCAE_BUILD_IPC", "BOOL", "ON"), ("QCAE_BUILD_STORAGE", "BOOL", "ON"),
                              ("QCAE_BUILD_DESKTOP", "BOOL", "ON"), ("QCAE_ENABLE_SANITIZERS", "BOOL", "OFF"),
                              ("QCAE_ENABLE_NASTRAN_PACKAGE", "BOOL", "ON")):
        require(f"{name}:{kind}={value}\n" in cache, "Package cache mismatch: " + name)
    require(config["macdeployqt"] == "/opt/homebrew/Cellar/qtbase/6.11.1/bin/macdeployqt" and
            config["qt_license_dir"] == "/Users/qs/Documents/ChatGPT/QCAE/build-c3-qt-observed/qtbase-everywhere-src-6.11.1/LICENSES",
            "Prepared matching stock Qt/deployer/license paths differ")
    cache_values = {line.split(":", 1)[0]: line.split("=", 1)[1] for line in cache.splitlines()
                    if not line.startswith(("#", "//")) and ":" in line and "=" in line}
    for name, expected_path in (("Qt6_DIR", "/opt/homebrew/Cellar/qtbase/6.11.1/lib/cmake/Qt6"),
                                ("VTK_DIR", "/Users/qs/Documents/ChatGPT/QCAE/build-vtk-deps/install/lib/cmake/vtk-9.7"),
                                ("SQLite3_LIBRARY", "/opt/homebrew/Cellar/sqlite/3.53.4/lib/libsqlite3.3.53.4.dylib"),
                                ("SQLite3_INCLUDE_DIR", "/opt/homebrew/Cellar/sqlite/3.53.4/include")):
        # Homebrew's aggregate Qt6 directory contains per-file symlinks into qtbase.
        # Compare the actual pinned config file, not the aggregate directory's identity.
        actual_input = Path(cache_values[name])
        expected_input = Path(expected_path)
        if name == "Qt6_DIR":
            actual_input /= "Qt6Config.cmake"
            expected_input /= "Qt6Config.cmake"
        require(actual_input.resolve(strict=True) == expected_input.resolve(strict=True),
                "Root Release cache differs from prepared stock SDK: " + name)
    require(f"CMAKE_HOME_DIRECTORY:INTERNAL={Path(config['build_source_root']).resolve()}\n" in cache,
            "Build cache source differs from explicitly pinned build root")
    vtk_licenses = source / "build-vtk-deps/install/share/licenses/VTK"
    require(vtk_licenses.is_dir() and any(vtk_licenses.rglob("LICENSE*")), "Fixed staging VTK licenses are absent")
    before = [fact(build / name) for name in (*TARGETS, "qcae_mcp_bridge.py")]
    write(recorder.output / "build-binaries-before.json", before)
    stage = source / "tools/stage_macos_package.py"
    argv = [config["python"], stage, "--build-dir", build, "--bundle", config["bundle"],
            "--macdeployqt", config["macdeployqt"], "--qt-license-dir", config["qt_license_dir"]]
    for libpath in config["libpaths"]:
        argv.extend(("--libpath", libpath))
    recorder.run("stage", argv)
    bundle = Path(config["bundle"]).resolve(strict=True)
    manifest = bundle.parent / (bundle.stem + "-manifest.json")
    content = json.loads(manifest.read_text())
    require(content["source_head"] == config["expected_head"] and content["complete_p0_release"] is False,
            "Staging manifest source/scope mismatch")
    for row in content["files"]:
        current = fact(bundle / row["path"])
        require(current["sha256"] == row["sha256"] and current["bytes"] == row["size"], "Staging manifest byte mismatch")
    relocated = Path(config["relocated_bundle"])
    require(not relocated.exists() and not relocated.is_symlink(), "Relocation destination must be new")
    relocated.parent.mkdir(parents=True, exist_ok=True)
    shutil.copytree(bundle, relocated, symlinks=True)
    original, copied = bundle_facts(bundle), bundle_facts(relocated)
    require(original == copied, "Relocated files/link identities differ")
    # Reuse the existing resolver with no ambient SDK libpaths. Every non-system
    # Mach-O edge must resolve into this fresh relocated bundle itself.
    spec = importlib.util.spec_from_file_location("stage138", stage)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    closure = []
    for row in content["binaries"]:
        binary = relocated / row["path"]
        for dependency in module.dependencies(binary):
            if dependency.startswith(module.SYSTEM_ROOTS):
                continue
            resolved = module.resolve(dependency, binary, relocated / "Contents/MacOS/qcae-desktop",
                                      module.rpaths(binary), [relocated / "Contents/Frameworks"])
            require(resolved.is_relative_to(relocated.resolve()), "Relocated dependency escaped")
            closure.append({"binary": row["path"], "dependency": dependency,
                            "resolved": str(resolved.relative_to(relocated.resolve()))})
    recorder.run("relocated-codesign", ["/usr/bin/codesign", "--verify", "--deep", "--strict", relocated])
    after = [fact(build / name) for name in (*TARGETS, "qcae_mcp_bridge.py")]
    require(before == after, "Staging altered original build binaries")
    write(recorder.output / "package-summary.json", {"actual_build_receipt": fact(config["actual_build_receipt"]),
          "actual_build_candidate": fact(config["actual_build_candidate"]),
          "source_head": config["expected_head"], "source_sha256": config["expected_source_sha256"],
          "cache": fact(build / "CMakeCache.txt"), "staging_manifest": fact(manifest),
          "original_bundle": str(bundle), "relocated_bundle": str(relocated), "files": copied,
          "relocated_dependency_edges": closure, "build_binaries_before_after": before,
          "local_adhoc_only": True, "notarization": False, "full_P0": False})


def sqlite_workflow(recorder, host):
    cap = host.start()
    require(cap["durable"] and cap["storage_mode"] == "sqlite", "Explicit SQLite engine is required")
    host.reject("create-version", "project.create", {"name": "Local package138"}, None,
                "create138", 2, "SCHEMA_UNSUPPORTED")
    host.reject("create-shape", "project.create", {"name": False}, None,
                "create138", 1, "INVALID_INPUT")
    created = host.call("project.create", {"name": "Local package138"}, key="create138", version=1)
    require(host.call("project.create", {"name": "Local package138"}, key="create138") == created,
            "Omitted-version create replay differs")
    material = host.call("material.create", {"name": "Steel", "young_modulus": {"value": 210, "unit": "GPa"},
                                             "poisson_ratio": .3}, host.current(), "material138")
    identity = material["entity_id"]
    changed = host.call("material.set_young_modulus", {"entity_id": identity,
                       "young_modulus": {"value": 200, "unit": "GPa"}}, host.current(), "edit138")
    current = host.current()
    require(current["revision"] == "2", "Create/edit must commit exactly two revisions")
    fields = host.call("entity.fields", {"entity_id": identity}, current)["fields"]
    require(fields["young_modulus_mpa"] == 200000, "Canonical material edit differs")
    golden_history = host.call("history.list", context=current)
    first_path, second_path = host.directory / "saved.qcae", host.directory / "saved-as.qcae"
    for operation, path, key in (("project.save", first_path, "save138"),
                                ("project.save_as", second_path, "save-as138")):
        host.reject(key + "-version", operation, {"path": str(path)}, current, key, 2, "SCHEMA_UNSUPPORTED")
        host.reject(key + "-shape", operation, {"path": False}, current, key, 1, "INVALID_INPUT")
        saved = host.call(operation, {"path": str(path)}, current, key, version=1)
        require(saved["document_id"] == created["document_id"] and saved["revision"] == current["revision"]
                and saved["dirty"] is False, "Save lifecycle changed document revision/identity")
        require(host.call("history.list", context=host.current()) == golden_history, "Pure save changed history")
        if operation == "project.save":
            first_project = saved["project_id"]
            for label, params in (("omitted", {}), ("empty", {"path": ""})):
                repeat = host.call("project.save", params, host.current(), "save-" + label + "138", version=1)
                require(repeat["project_id"] == first_project and repeat["revision"] == "2" and not repeat["dirty"],
                        "Omitted/empty save path semantics changed")
        else:
            require(saved["project_id"] != first_project, "Save-as failed to assign distinct project identity")
        current = host.current()
        require(path.is_file(), "Snapshot was not published")
    host.reject("close-version", "project.close", {"policy": "keep_recovery"}, current,
                "close138", 2, "SCHEMA_UNSUPPORTED")
    host.reject("close-shape", "project.close", {"policy": False}, current,
                "close138", 1, "INVALID_INPUT")
    closed = host.call("project.close", {"policy": "keep_recovery"}, current, "close138", version=1)
    host.call("project.current", status="failed", code="DOCUMENT_NOT_FOUND")
    first_pid = host.process["process"].pid
    host.stop()
    restarted = host.start()
    require(restarted["recovery_available"], "Closed durable document lacks explicit recovery")
    require(host.process["process"].pid != first_pid, "Expected a distinct real engine process")
    recovered = host.call("project.open", {"mode": "recover"}, key="recover138", version=1)
    require(recovered["document_id"] == created["document_id"] and recovered["document_epoch"] != current["document_epoch"]
            and recovered["revision"] == "2", "Recovery DocId/Epoch/revision differ")
    recovered_fields = host.call("entity.fields", {"entity_id": identity}, recovered)["fields"]
    require(recovered_fields == fields, "Full material fields differ after process restart recovery")
    require(host.call("history.list", context=recovered) == golden_history, "History differs after durable restart")
    host.call("history.undo", context=current, key="stale-epoch138", status="conflict", code="DOCUMENT_EPOCH_EXPIRED")
    host.rows("recovered-complete-sqlite-rows")
    write(recorder.output / "sqlite-summary.json", {"created": created, "edited_receipt": changed,
          "closed": closed, "before_restart": current, "recovered": recovered,
          "material_fields": fields, "history": golden_history, "first_engine_pid": first_pid,
          "second_engine_pid": host.process["process"].pid, "all_negative_full_rows_unchanged": True,
          "same_keys_then_valid": ["create138", "save138", "save-as138", "close138"],
          "snapshot_files": [fact(first_path), fact(second_path)], "scope": "one material; local release lifecycle"})


class Mcp:
    def __init__(self, recorder, host, label):
        self.recorder, self.sequence, self.transcript = recorder, 0, []
        self.item = recorder.start(label, [host.bin / "qcae-mcp", "--python", recorder.config["python"],
                                          "--endpoint", host.socket], pipe_input=True, pipe_output=True)
        self.raw_stdout = (self.item["directory"] / "stdout.log").open("xb")

    def send(self, value):
        raw = (json.dumps(value, separators=(",", ":")) + "\n").encode()
        self.transcript.append({"request": value})
        self.item["process"].stdin.write(raw)
        self.item["process"].stdin.flush()

    def request(self, method, params=None):
        self.sequence += 1
        self.send({"jsonrpc": "2.0", "id": self.sequence, "method": method, "params": params or {}})
        require(select.select([self.item["process"].stdout], [], [], 15)[0], "MCP response timeout")
        raw = self.item["process"].stdout.readline()
        self.raw_stdout.write(raw)
        self.raw_stdout.flush()
        response = json.loads(raw)
        self.transcript[-1]["response"] = response
        require(response["jsonrpc"] == "2.0" and response["id"] == self.sequence, "MCP response identity mismatch")
        return response

    def initialize(self):
        value = self.request("initialize", {"protocolVersion": "2025-11-25", "capabilities": {},
                             "clientInfo": {"name": "local-delivery138", "version": "1"}})
        require(value["result"]["protocolVersion"] == "2025-11-25", "MCP protocol mismatch")
        self.send({"jsonrpc": "2.0", "method": "notifications/initialized"})

    def call(self, operation, parameters=None, context=None, key=None, version=None):
        arguments = {"parameters": parameters or {}}
        if context:
            arguments.update(document_id=context["document_id"], document_epoch=context["document_epoch"],
                             expected_revision=context["revision"])
        if key:
            arguments["idempotency_key"] = key
        if version is not None:
            arguments["requested_version"] = version
        result = self.request("tools/call", {"name": operation, "arguments": arguments})["result"]
        raw = result["structuredContent"]
        require(json.loads(result["content"][0]["text"]) == raw and raw["status"] == "success"
                and result["isError"] is False, "MCP actual structured/text response mismatch or failure")
        return raw["data"]

    def close(self):
        process = self.item["process"]
        if process.poll() is None:
            process.stdin.close()
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self.raw_stdout.close()
                write(self.item["directory"] / "transcript.json", self.transcript)
                self.recorder.stop(self.item)
                raise RuntimeError("MCP EOF cleanup timeout; actual SIGTERM receipt retained")
        tail = process.stdout.read()
        self.raw_stdout.write(tail)
        self.raw_stdout.close()
        write(self.item["directory"] / "transcript.json", self.transcript)
        receipt = self.recorder.finish(self.item, cleanup={"stdin_EOF": True, "SIGKILL_sent": False, "reaped": True})
        require(receipt["actual_exit_code"] == 0, "MCP launcher did not exit normally after EOF")


def mcp_workflow(recorder, host):
    host.start()
    clients = []
    try:
        clients = [Mcp(recorder, host, "mcp-first"), Mcp(recorder, host, "mcp-second")]
        catalogs = []
        for client in clients:
            client.initialize()
            catalogs.append(client.request("tools/list")["result"]["tools"])
        require(sorted(catalogs[0], key=lambda row: row["name"]) == sorted(catalogs[1], key=lambda row: row["name"]),
                "Two actual MCP catalogs differ")
        capabilities = clients[0].call("capabilities.list")
        require({row["name"] for row in catalogs[0]} ==
                {row["name"] for row in capabilities["operations"] if row["available"] and row["name"] != "events.subscribe"},
                "Actual MCP tools do not match available production descriptors")
        created = clients[0].call("project.create", {"name": "Two MCP clients138"}, key="mcp-create138", version=1)
        context = clients[1].call("project.current")
        require(context == clients[0].call("project.current") and context["document_id"] == created["document_id"],
                "MCP clients do not share the actual engine document")
        payload = {"name": "Shared Steel", "young_modulus": {"value": 210, "unit": "GPa"}}
        committed = clients[0].call("material.create", payload, context, "mcp-material138", version=1)
        updated = clients[1].call("project.current")
        require(int(updated["revision"]) == int(context["revision"]) + 1, "MCP shared write revision differs")
        replay = clients[1].call("material.create", payload, context, "mcp-material138", version=1)
        require(replay["replayed"] is True and replay["transaction_id"] == committed["transaction_id"],
                "Cross-MCP idempotent retry did not preserve transaction")
        require(host.current() == clients[0].call("project.current"), "CLI and two MCP clients diverge")
        summary = clients[1].call("model.summary", context=updated)
        require(len(summary["materials"]) == 1 and summary["materials"][0]["young_modulus_mpa"] == 210000,
                "MCP committed material was not publicly observed")
        write(recorder.output / "mcp-summary.json", {"client_pids": [c.item["process"].pid for c in clients],
              "tools": [row["name"] for row in catalogs[0]], "created": created, "committed": committed,
              "replay": replay, "current": updated, "external_python": fact(recorder.config["python"]),
              "scope": "two local stdio clients, discovery and bounded shared application calls; no external AI"})
    finally:
        errors = []
        for client in clients:
            try:
                client.close()
            except Exception as error:
                errors.append(repr(error))
        require(not errors, "MCP cleanup failed: " + repr(errors))


def gui_workflow(recorder, host):
    cap = host.start()
    created = host.call("project.create", {"name": "Relocated GUI smoke138"}, key="gui-create138", version=1)
    fixture = Path(recorder.config["source_root"]) / "tests/fixtures/nastran"
    resources = [{"path": str(path.relative_to(fixture)), "text": path.read_text()}
                 for path in sorted(fixture.rglob("*.bdf"))]
    preview = host.call("changes.preview", {"command": "model.import", "root_resource": "cantilever.bdf",
                        "resources": resources, "unit_system": "mm-N-MPa",
                        "source_profile_ref": cap["declared_solver_profiles"][0]["profile_ref"]}, created)
    imported = host.call("changes.commit", {"preview_id": preview["preview_id"]}, created, "gui-import138")
    before = host.current()
    screenshot = host.directory / "real-gui.png"
    recorder.run("desktop-smoke", [host.bin / "qcae-desktop", "--smoke", "--socket", host.socket,
                 "--screenshot", screenshot, "--quit-after-ms", "5000"], timeout=25)
    require(screenshot.exists() and screenshot.stat().st_size >= 5000, "Real GUI screenshot lacks meaningful PNG bytes")
    require(screenshot.read_bytes()[:8] == b"\x89PNG\r\n\x1a\n", "Real GUI artifact is not PNG")
    current = host.current()
    require(current == before and current["revision"] == "1", "Smoke changed engine document state")
    summary = host.call("model.summary", context=current)
    require(summary["node_count"] == 2 and summary["beam_count"] == 1, "Imported GUI beam model differs")
    require(host.process["process"].poll() is None, "GUI exit terminated engine")
    write(recorder.output / "gui-summary.json", {"created": created, "import_receipt": imported,
          "before": before, "after": current, "model_summary": summary, "screenshot": fact(screenshot),
          "engine_still_running_after_GUI": True, "scope": "real Cocoa Qt/VTK --smoke; no formal selection/performance/P0 claim"})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", required=True)
    parser.add_argument("--action", choices=("package", "sqlite", "mcp", "gui"), required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--package-summary", help="Required for each separate runtime action")
    parser.add_argument("--root-authorized-execution", action="store_true")
    args = parser.parse_args()
    require(args.root_authorized_execution, "Prepared only: root must explicitly schedule actual execution")
    output = Path(args.output).absolute()
    require(not output.exists() and not output.is_symlink(), "Every attempt requires a fresh output directory")
    output.mkdir(parents=True)
    config = json.loads(Path(args.config).read_text())
    recorder = Recorder(config, output)
    host = None
    before = None
    binaries_before = None
    relocated_before = None
    failure = None
    try:
        before = source_fence(config)
        write(output / "source-before.json", before)
        write(output / "config-input.json", {"config": fact(args.config), "value": config})
        binaries_before = [fact(Path(config["build_dir"]) / name)
                           for name in (*TARGETS, "qcae_mcp_bridge.py")]
        write(output / "original-binaries-before.json", binaries_before)
        if args.action == "package":
            package(recorder)
        else:
            require(args.package_summary is not None, "Actual package summary is required before runtime")
            summary = json.loads(Path(args.package_summary).read_text())
            require(summary["source_head"] == config["expected_head"] and
                    summary["source_sha256"] == config["expected_source_sha256"], "Wrong package source binding")
            require(summary["relocated_bundle"] == str(Path(config["relocated_bundle"]).resolve()), "Wrong package path")
            require(summary["files"] == bundle_facts(config["relocated_bundle"]), "Actual package byte seal differs")
            relocated_before = summary["files"]
            require(summary["build_binaries_before_after"] == [fact(Path(config["build_dir"]) / name)
                    for name in (*TARGETS, "qcae_mcp_bridge.py")], "Original build binary seal differs")
            require(summary["staging_manifest"]["sha256"] == fact(summary["staging_manifest"]["path"])["sha256"],
                    "Original staging manifest changed")
            manifest = json.loads(Path(summary["staging_manifest"]["path"]).read_text())
            require(manifest["source_head"] == config["expected_head"], "Package source identity differs")
            write(output / "package-input.json", {"summary": fact(args.package_summary), "files": summary["files"]})
            directory = output / "work"
            directory.mkdir()
            host = Host(recorder, directory)
            {"sqlite": sqlite_workflow, "mcp": mcp_workflow, "gui": gui_workflow}[args.action](recorder, host)
            host.stop()
            require(summary["files"] == bundle_facts(config["relocated_bundle"]), "Runtime altered bundle bytes")
            require(summary["build_binaries_before_after"] == [fact(Path(config["build_dir"]) / name)
                    for name in (*TARGETS, "qcae_mcp_bridge.py")], "Runtime altered original build binaries")
    except BaseException as error:
        failure = repr(error)
        write(output / "failure.json", {"error": failure, "traceback": traceback.format_exc(), "action": args.action})
    finally:
        if host and host.process and not host.process["sealed"]:
            try:
                recorder.stop(host.process)
            except Exception as error:
                write(output / "cleanup-failure.json", {"error": repr(error)})
                failure = failure or repr(error)
        # Preserve start/finish receipts for non-engine failures as well. Never
        # use SIGKILL or act on a process not started by this attempt.
        for item in recorder.children:
            if not item["sealed"]:
                try:
                    if item["pipe_output"] and not (item["directory"] / "stdout.log").exists():
                        (item["directory"] / "stdout.log").write_bytes(b"")
                    recorder.stop(item)
                except Exception as error:
                    name = f"cleanup-unsealed-{item['process'].pid}.json"
                    write(output / name, {"error": repr(error), "pid": item["process"].pid})
                    failure = failure or repr(error)
        try:
            binaries_after = [fact(Path(config["build_dir"]) / name)
                              for name in (*TARGETS, "qcae_mcp_bridge.py")]
            write(output / "original-binaries-after.json", binaries_after)
            if binaries_before is not None:
                require(binaries_before == binaries_after, "Original binary before-after mismatch")
            if relocated_before is not None:
                relocated_after = bundle_facts(config["relocated_bundle"])
                write(output / "relocated-bundle-after.json", relocated_after)
                require(relocated_before == relocated_after, "Relocated bundle before-after mismatch")
        except Exception as error:
            write(output / "post-binary-failure.json", {"error": repr(error)})
            failure = failure or repr(error)
        try:
            after = source_fence(config)
            write(output / "source-after.json", after)
            require(before == after, "Source/tool/SDK before-after mismatch")
        except Exception as error:
            write(output / "post-fence-failure.json", {"error": repr(error)})
            failure = failure or repr(error)
    write(output / "complete.json", {"action": args.action, "actual_passed": failure is None,
          "error": failure, "source_head": config["expected_head"],
          "source_sha256": config["expected_source_sha256"], "actual_process_commands": recorder.sequence,
          "method": fact(__file__), "full_SK": False, "full_P0": False,
          "solver_execution": False, "external_AI": False})
    raise SystemExit(0 if failure is None else 1)


if __name__ == "__main__":
    main()
