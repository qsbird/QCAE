#!/usr/bin/env python3
"""Copy completed evidence only; never build, run products, or rewrite origins."""
from pathlib import Path
import hashlib
import io
import json
import tarfile

REPO = Path('/private/tmp/qcae-framework-delivery80')
DEST = REPO / 'docs/engineering/core-local-delivery-evidence/2026-10-03'
entries = {}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def add(name, path):
    path = Path(path)
    assert path.is_file() and not path.is_symlink(), path
    assert name not in entries and not name.startswith('/') and '..' not in Path(name).parts
    assert path.suffix in {'.json', '.log', '.py', '.md', '.txt', '.patch', '.png'}, path
    data = path.read_bytes()
    entries[name] = (path, data)


def tree(label, root):
    root = Path(root)
    assert root.is_dir(), root
    for path in sorted(root.rglob('*')):
        relative = path.relative_to(root)
        if not path.is_file() or path.is_symlink() or '__pycache__' in relative.parts:
            continue
        if relative.parts[0] == 'work':
            if str(relative) == 'work/real-gui.png':
                add(label + '/' + str(relative), path)
            continue
        if path.suffix in {'.json', '.log', '.py', '.md', '.txt', '.patch'}:
            add(label + '/' + str(relative), path)


for label, root in [
    ('regression/first-failed', '/private/tmp/qcae-framework-contracts141'),
    ('regression/final', '/private/tmp/qcae-framework-contracts141-successor01'),
    ('package/preflight-failed', '/private/tmp/qcae-delivery138-package-01'),
    ('package/staging-failed', '/private/tmp/qcae-delivery138-package-02'),
    ('package/final', '/private/tmp/qcae-delivery138-package-03'),
    ('native/sqlite', '/private/tmp/qcae-delivery138-sqlite-01'),
    ('native/mcp', '/private/tmp/qcae-delivery138-mcp-01'),
    ('native/gui', '/private/tmp/qcae-delivery138-gui-01'),
    ('reviews/lifecycle', '/private/tmp/qcae-lifecycle-review142'),
    ('reviews/assembly', '/private/tmp/qcae-assembly-review143'),
    ('methods/package-successor', '/private/tmp/qcae-local-delivery138-successor01'),
]:
    tree(label, root)

for name in ['run.py', 'README.md', 'seal.json', 'prepared-inputs.json']:
    path = Path('/private/tmp/qcae-local-delivery138') / name
    if path.exists():
        add('methods/package-original/' + name, path)
for name in ['final-freeze.json', 'final-config.json', 'final-config02.json']:
    add('methods/' + name, '/private/tmp/qcae-local-delivery138-' + name)
for config in ['core', 'local', 'desktop', 'package-off', 'sanitized']:
    root = Path('/private/tmp/qcae-framework-contracts141-builds') / config
    add('regression/build-inputs/' + config + '/CMakeCache.txt', root / 'CMakeCache.txt')
    add('regression/build-inputs/' + config + '/compile_commands.json', root / 'compile_commands.json')
add('package/QCAE-manifest.json', '/Users/qs/Documents/ChatGPT/QCAE/out/local-delivery138-02/QCAE-manifest.json')
add('methods/archive.py', __file__)

assert 400 <= len(entries) <= 650, len(entries)
candidate = json.loads(entries['regression/final/attempt-01/candidate.json'][1])
freeze = json.loads(entries['methods/final-freeze.json'][1])
assert candidate['candidate_files'] == freeze['source_files']
assert freeze['commit'] == 'f2d2e7f25eb2b6218f233c1612a0b16a7705f06a'
assert candidate['candidate_files_count'] == 414
assert candidate['source_dictionary_sha256'] == freeze['source_dictionary_sha256']
for relative, expected in freeze['source_files'].items():
    assert digest((REPO / relative).read_bytes()) == expected, relative
complete = json.loads(entries['regression/final/attempt-01/complete.json'][1])
assert complete['actual_exit_code'] == 0 and complete['total_test_executions'] == 265
assert [x['executed_count'] for x in complete['configurations']] == [40, 54, 94, 75, 2]
for name in ['package/final', 'native/sqlite', 'native/mcp', 'native/gui']:
    data = json.loads(entries[name + '/complete.json'][1])
    assert data['actual_passed'] and data['source_head'] == freeze['commit']
    assert data['source_sha256'] == freeze['source_dictionary_sha256']

DEST.mkdir(parents=True, exist_ok=True)
archive = DEST / 'evidence.tar.gz'
index = DEST / 'archive-index.json'
assert not archive.exists() and not index.exists()
with tarfile.open(archive, 'w:gz', format=tarfile.PAX_FORMAT) as output:
    for name, (_, data) in sorted(entries.items()):
        item = tarfile.TarInfo(name)
        item.size = len(data)
        item.mode = 0o444
        item.mtime = 0
        output.addfile(item, io.BytesIO(data))

# Independently read every archived member and re-read every original after copying.
with tarfile.open(archive, 'r:gz') as input_archive:
    members = input_archive.getmembers()
    assert [m.name for m in members] == sorted(entries)
    for member in members:
        original, data = entries[member.name]
        assert member.isfile() and input_archive.extractfile(member).read() == data
        assert original.read_bytes() == data, original

manifest = {
    'schema_version': 1,
    'tested_implementation_commit': freeze['commit'],
    'source_files_count': 414,
    'source_dictionary_sha256': freeze['source_dictionary_sha256'],
    'source_hash_algorithm': 'SHA256 of canonical sorted relative-path to file-SHA256 JSON; not C4-source-v1',
    'archive': {'path': 'evidence.tar.gz', 'bytes': archive.stat().st_size,
                'sha256': digest(archive.read_bytes()), 'members': len(entries)},
    'verification': {'all_members_read_back_equal': True, 'all_origins_re_read_equal': True,
                     'runtime_database_or_product_binary_included': False},
    'entries': [{'member': name, 'origin': str(path), 'bytes': len(data),
                 'sha256': digest(data)} for name, (path, data) in sorted(entries.items())],
    'limits': ['Completed actual root receipts only; preparation and review are separately labelled',
               'Failed runs remain failed and are included separately',
               'No full SK/P0, real Nastran, external AI, LSan, or performance acceptance claim'],
}
index.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'archive': manifest['archive'], 'index_sha256': digest(index.read_bytes()),
                  'verified_origins': len(entries)}))
