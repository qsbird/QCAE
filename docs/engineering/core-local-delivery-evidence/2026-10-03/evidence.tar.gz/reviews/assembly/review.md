QG-02 静态审查：assembly137，无阻塞发现。审查当前九个源文件，准确 SHA-256 见 review.json；未改共享源码、Git 或封存证据。依据 baseline README、REQ-02/10/15/16/17、acceptance.md:145、architecture README/runtime/module-dependencies。

调用路径：可信默认/显式贡献列表 → assemble_engine 的冻结记录注册表及选定 codec/profile/render → 同一 MemoryApplication/TypedHost → IPC 与 RenderService → 原 application/存储/历史。host 运行选择从实际 EngineAssembly 取得；编译开关仅选择默认贡献列表。ON 平台专用测试 main 传 qcae.model，调用同一宿主而无 Nastran 服务。

寿命：NastranArtifactCoordinator 的两个端口都 alias 同一个 State 内的 codec，共用控制块。host supports_profile 按值持有绑定；assembly 的逆序释放先于 typed/application，但回调和 operation/publisher 闭包继续持有 State。TypedHost 的 tasks_ 先停止/取消并 join，随后释放注册回调，application 最后释放；State 的析构不调用其借用 app 指针。RenderService 在 assembly/application 前释放，选定 renderer 已转入服务。

拒绝边界：空端口、无 owner/不同控制块、缺 profile 身份/族/分析、重复 codec/render/publisher owner、重复贡献身份、未冻结/空 renderer 在 assembly 返回前拒绝；局部记录表冻结后才交付。重复/保留操作名在 TypedHost 构造拒绝，早于 ready/event loop/能力响应。宿主 catch 返回 5。socket 在初始化前已经 listen，记录不将“发布前拒绝”扩大为“端点创建或所有存储初始化前拒绝”。

默认行为：ON 继续选 Nastran codec/profile 和三个投影；OFF 继续使用无 profile/codec 与既有四项冻结 generic renderer（含 Tri3）。缺显式 renderer 也走该同一 fallback。core public 与依赖边界没有改动。

测试源码已准备、未执行：engine_assembly 包括真实离线 fixture codec/projection、wrapper 释放、服务形状与重复拒绝、默认 ON/OFF/platform-only 选择；新增 platform_only_engine_ipc 只在 BUILD_TESTING/UNIX/IPC/STORAGE/NASTRAN_ON 注册，OFF 原测试继续。共享 disabled Python 使用实际 SQLite host 检查发现、缺 codec 的 import/export 拒绝和 current/history 保持，以及 common geometry/query/undo。其 Python AST 已解析，运行结果由根141另附；本审查不记 compile/native/CTest PASS。

范围：这是两个实际服务 owner 与宿主选定服务的修复；六类 owner 的完整 metadata 发现仍 pending。可信静态 alias 检查不保证任意恶意 alias；离线 fixture 不证明外部求解器、真实 AI、性能或完整 SK/P0。
